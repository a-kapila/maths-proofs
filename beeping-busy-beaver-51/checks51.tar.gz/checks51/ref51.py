# Reference implementation of the process R (dispatch level).
def decode(s):
    runs = [len(x) for x in s.split('U')]
    return runs[::-1]
def encode(S):
    return 'U'.join('X' * a for a in S[::-1])
def cand(S0, n):
    c = S0[-1]
    r = max(i for i in range(len(S0)) if S0[i] < c)
    Sp = S0[:-1] + [c - 1]
    B = Sp[r + 1:]
    def E(i):
        return Sp[i] if i < len(Sp) else B[(i - len(Sp)) % len(B)]
    idx = 0; L = len(S0) + 1
    while True:
        pre = [E(i) for i in range(L - 1)]
        for v in range(E(L - 1) + 1):
            if idx == n: return pre + [v]
            idx += 1
        L += 1
def step(S):
    z = 0
    while z < len(S) and S[len(S) - 1 - z] == 0: z += 1
    S0 = S[:len(S) - z]
    if S0 == [1]: return True, [1, 0, z]
    return False, cand(S0, 1 + 2 * z)
if __name__ == '__main__':
    import sys
    lines = open(sys.argv[1]).read().split('\n')
    ev = []
    for ln in lines:
        if ln.startswith('D '):
            _, t, pr, s = ln.split(' ', 3)
            if s.endswith('...'): break
            ev.append(('D', int(t), decode(s), s))
        elif ln.startswith('BEEP'):
            ev.append(('B', int(ln.split()[1])))
    # check
    Ds = [e for e in ev if e[0] == 'D']
    assert encode(Ds[0][2]) == Ds[0][3]
    ok = 0; beepcount = 0
    i = 0
    # walk events: between consecutive D's, number of beeps must equal 1 iff step says beep
    prevD = None; beeps_since = 0
    for e in ev:
        if e[0] == 'B': beeps_since += 1; continue
        if prevD is not None:
            isbeep, nxt = step(prevD[2])
            assert nxt == e[2], (prevD, e, nxt)
            assert beeps_since == (1 if isbeep else 0), (prevD[1], beeps_since, isbeep)
            ok += 1
        beeps_since = 0
        prevD = e
    print('checked transitions:', ok, 'last dispatch time', prevD[1], 'len', len(prevD[2]), 'max letter', max(prevD[2]))
