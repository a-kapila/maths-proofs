# Numerical checks for the 51-state proof

These scripts are the numerical checks described in §6.11 and §9 of `m51_selfcontained.md`.
They are **not part of any proof**; they test lemmas on small cases.

* `ref51.py` - reference implementation of the process R (§2.1 quotes its `step` function verbatim).
* `beeper51.txt` - the machine table (also printed in Appendix B of the document).
* `u51_lemmaG/` - checks for §§3-5 and the small-value computations of §9.
* `lemmaG_work/` - checks for §6, listed in §6.11.

Run a script from its own folder, e.g. `cd lemmaG_work && python3 nfchecks.py`.
Saved outputs are the `*.out` files next to each script. Some scripts take many minutes.
