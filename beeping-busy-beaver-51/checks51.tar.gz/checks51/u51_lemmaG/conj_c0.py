import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Test candidate lower bounds of the form Phi_Y(z) >= H_{alpha(Y)}(g(z)) on small worms.
import sys, itertools, random
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
import r51
from r51 import phi, Big
from ordw import ordw, fs, show, ZERO
import hardy
from hardy import Hsafe
r51.CAP = 10**40
hardy.CAP = 10**40

def P(X, z):
    try: return phi(tuple(X), z)
    except (Big, RecursionError): return None

def size(X): return sum(x + 1 for x in X)

worms = []
for L in range(1, 6):
    for X in itertools.product(range(0, 3), repeat=L):
        if X[-1] >= 1: worms.append(X)
random.seed(3)
worms += [tuple(random.choice([0, 1, 1, 2, 2, 3]) for _ in range(random.randint(1, 6))) for _ in range(300)]
worms = sorted(set(X for X in worms if X[-1] >= 1))
res = {}
def rec(name, ok, info):
    s = res.setdefault(name, [0, 0, []])
    s[0] += 1
    if not ok:
        s[1] += 1
        if len(s[2]) < 4: s[2].append(info)
for Y in worms:
    a = ordw(Y)
    a0 = fs(a, 0)
    for z in range(0, 7):
        v = P(Y, z)
        if v is None: continue
        h0 = Hsafe(a0, z)
        if h0 is not None: rec("C0: Phi_Y(z) >= H_{ord[0]}(z)", v >= h0, (Y, z, v, h0))
        h1 = Hsafe(a, z // max(1, size(Y)))
        if h1 is not None: rec("C1: Phi_Y(z) >= H_ord(z/size)", v >= h1, (Y, z, v, h1))
        h2 = Hsafe(a, 1)
        if h2 is not None: rec("C2: Phi_Y(z) >= H_ord(1)", v >= h2, (Y, z, v, h2))
        h3 = Hsafe(fs(a, 1), z)
        if h3 is not None: rec("C3: Phi_Y(z) >= H_{ord[1]}(z)", v >= h3, (Y, z, v, h3))
        h4 = Hsafe(a, 2)
        if h4 is not None and z >= 1: rec("C4: Phi_Y(z) >= H_ord(2), z>=1", v >= h4, (Y, z, v, h4))
for k, (n, f, ex) in res.items():
    print(f"{k:36s} checked {n:6d} failures {f}")
    for e in ex: print("     e.g.", e[0], "z=", e[1], "Phi=", e[2], "bound=", e[3])
