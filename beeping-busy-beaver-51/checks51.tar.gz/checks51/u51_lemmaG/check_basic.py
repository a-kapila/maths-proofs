import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Numerical checks of the structural and counter lemmas of unprovability51.md (sections 3-5).
import sys, random, itertools
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.path.insert(0, _ROOT)
import r51
from r51 import phi, Big, nth_candidate, expansion
from ordw import ordw, o, lt, cmp, show, ZERO
from ref51 import cand
r51.CAP = 10**30

def P(X, z):
    try: return phi(tuple(X), z)
    except Big: return None

def size(X): return sum(x + 1 for x in X)

random.seed(11)
worms = []
for L in range(1, 5):
    for X in itertools.product(range(0, 4), repeat=L):
        if X[-1] >= 1: worms.append(X)
worms += [tuple(random.randint(0, 5) for _ in range(random.randint(1, 7))) for _ in range(400)]
worms = [X for X in worms if X[-1] >= 1]
stats = {}
def rec(name, ok, info):
    s = stats.setdefault(name, [0, 0])
    s[0] += 1
    if not ok:
        s[1] += 1
        if s[1] <= 3: print("FAIL", name, info)

for X in worms:
    oX = ordw(X)
    # (D') lowering the last letter
    Xm = X[:-1] + (X[-1] - 1,)
    rec("D' ord(X^-)<ord(X)", lt(ordw(Xm), oX), X)
    rec("D' o(X^-)<o(X)", lt(o(Xm), o(X)), X)
    for n in range(0, 25):
        C = nth_candidate(X, n)
        assert list(C) == cand([1, 0] + list(X), n)[2:]
        rec("D ord(C_n)<ord(X)", lt(ordw(C), oX), (X, n))
        rec("D o(C_n)<o(X)", lt(o(C), o(X)), (X, n))
        rec("size(C_n)=size(X)+n", size(C) == size(X) + n, (X, n, C))
        C1 = nth_candidate(X, n + 1)
        same = (C1[:-1] == C[:-1] and C1[-1] == C[-1] + 1) or (C1 == C + (0,))
        rec("consecutive: +1 or append 0", same, (X, n, C, C1))
    # lift structure for zero-free X with last letter >= 2
    if 0 not in X and X[-1] >= 2:
        Y = tuple(x - 1 for x in X)
        lifts = []; extras = 0
        m = 0
        for n in range(0, 40):
            C = nth_candidate(X, n)
            if C[-1] == 0:
                Sp, B = expansion(X)
                extras += 1
                continue
            Cl = tuple(c - 1 for c in C)
            rec("lift: C_n = (C'_{n'})+1", Cl == nth_candidate(Y, m), (X, n, m))
            m += 1
    # counter lemmas
    for z in range(0, 4):
        v = P(X, z)
        if v is None: continue
        rec("size bound", v >= z + size(X), (X, z, v))
        w = P(X, z + 1)
        if w is not None: rec("M1 strict", w > v, (X, z, v, w))
    # (L++): Phi_{P(v+1)}(y) >= Phi_{Pv}(2y+2)
    Pp, c = X[:-1], X[-1]
    for y in range(0, 3):
        a = P(Pp + (c,), y); b = P(Pp + (c - 1,), 2 * y + 2)
        if None not in (a, b): rec("L++", a >= b, (X, y, a, b))
    # (IC): Phi_{C_{n+1}}(y) >= Phi_{C_n}(y+1)
    for n in range(0, 10):
        C = nth_candidate(X, n); C1 = nth_candidate(X, n + 1)
        for y in range(0, 3):
            a = P(C1, y); b = P(C, y + 1)
            if None not in (a, b): rec("IC", a >= b, (X, n, y, a, b))

for k, (n, f) in stats.items(): print(f"{k:32s} checked {n:7d} failures {f}")
print("ord((k)):", [show(ordw((k,))) for k in range(1, 5)])
print("ord((1,1)), ord((2,1)), ord((1,2)), ord((2,3)):", show(ordw((1,1))), "|", show(ordw((2,1))), "|", show(ordw((1,2))), "|", show(ordw((2,3))))
