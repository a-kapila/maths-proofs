import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Checks of Lemma 6.3 and Lemma 6.4 (n=2) of unprovability51.md on small cases.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
import r51
from r51 import phi, Big
r51.CAP = 10**60
def g(M, x):
    try: return phi(tuple([1]*M), x)
    except Big: return None
def a(M): return g(M, 0)
def F2(y): return 2**(y+1)*(y+1) - 1
ok = {'6.3a': [0,0], '6.3b': [0,0], '6.3c': [0,0], '6.4n2': [0,0]}
def rec(k, c):
    ok[k][0] += 1
    if not c: ok[k][1] += 1
for M in range(2, 7):
    for x in range(0, 8):
        v = g(M, x)
        if v is None: continue
        # (a)
        if x <= M - 2:
            aa = a(x + 1)
            w = g(M - 1, 1 + aa) if aa is not None else None
            if w is not None: rec('6.3a', v == w)
        # (b): g_M(x) >= G^{q+1}(1)
        q = (2*x + 1) // (2*M - 1)
        w = 1; good = True
        for _ in range(q + 1):
            w = g(M - 1, 1 + w)
            if w is None: good = False; break
        if good: rec('6.3b', v >= w)
        # (c): G(w) >= 2w+2M+1
        for w0 in range(0, 6):
            gg = g(M - 1, 1 + w0)
            if gg is not None: rec('6.3c', gg >= 2*w0 + 2*M + 1)
        rec('6.4n2', v >= F2(x // (4*M)))
print(ok)
print('a_1..a_3:', [a(M) for M in range(1, 4)])
