import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
import r51
from r51 import phi, Big
import hardy
from hardy import Hsafe
from ordw import ordw, fs, show
r51.CAP = 10**300; hardy.CAP = 10**300
for m in range(1, 7):
    for z in range(0, 6):
        try: v = phi(tuple([1]*m), z)
        except Big: v = None
        a = fs(ordw(tuple([1]*m)), 0)
        h = Hsafe(a, z)
        print(f"m={m} z={z} Phi={'BIG' if v is None else (v if v < 10**12 else f'~1e{len(str(v))-1}')} H_ord[0](z)={'BIG' if h is None else (h if h < 10**12 else f'~1e{len(str(h))-1}')}  ord[0]={show(a)}", flush=True)
