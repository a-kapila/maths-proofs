import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Capped Buchholz-Wainer Hardy and fast-growing functions on ordinals (ordw.py representation).
import sys, functools
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
from ordw import ZERO, ONE, fs, lt, cmp, show

class BigNum(Exception): pass

CAP = 10**40

def is_succ(a): return bool(a) and a[-1] == ZERO

def F(b, x):
    """F_b(x) (BW fast-growing), raising BigNum if any intermediate exceeds CAP."""
    if x > CAP: raise BigNum()
    if b == ZERO: return x + 1
    if b == ONE:
        v = 2 * x + 1
        if v > CAP: raise BigNum()
        return v
    if b == (ZERO, ZERO):  # 2
        if x > 200: raise BigNum()
        v = 2 ** (x + 1) * (x + 1) - 1
        if v > CAP: raise BigNum()
        return v
    if is_succ(b):
        bp = b[:-1]
        y = x
        for _ in range(x + 1):
            y = F(bp, y)
        return y
    return F(fs(b, x), x)

def H(a, x):
    """H_a(x) = F_{b1}(F_{b2}(... F_{br}(x))) for a = w^b1+...+w^br in CNF."""
    for b in reversed(a):
        x = F(b, x) if b != ZERO else x + 1
        if x > CAP: raise BigNum()
    return x

def Hsafe(a, x):
    try: return H(a, x)
    except (BigNum, RecursionError): return None

if __name__ == '__main__':
    # sanity: H_w(x) = 2x+1, H_{w^2}(x) = 2^{x+1}(x+1)-1, H_{w*m}(x) = 2^m (x+1) - 1
    w = (ONE,)
    assert all(H(w, x) == 2 * x + 1 for x in range(10))
    w2 = ((ZERO, ZERO),)
    assert all(H(w2, x) == 2 ** (x + 1) * (x + 1) - 1 for x in range(10))
    for m in range(1, 5):
        assert all(H(tuple([ONE] * m), x) == 2 ** m * (x + 1) - 1 for x in range(8))
    # direct definition check for small cases: H_{a+1}(x)=H_a(x+1), H_l(x)=H_{l[x]}(x)
    def Hdirect(a, x, budget=10**5):
        while a:
            if is_succ(a): a = a[:-1]; x += 1
            else: a = fs(a, x)
            budget -= 1
            if budget < 0: return None
        return x
    import itertools
    tests = [ (ONE,), (ONE, ONE), ((ZERO, ZERO),), ((ZERO, ZERO), ONE, ZERO), ((ONE,), ONE) ]
    for a in tests:
        for x in range(0, 4):
            d = Hdirect(a, x)
            if d is None: continue
            assert d == H(a, x), (show(a), x, d, H(a, x))
    print("hardy.py sanity checks passed")
