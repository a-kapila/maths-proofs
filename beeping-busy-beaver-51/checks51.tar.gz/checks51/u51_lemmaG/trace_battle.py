import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
import sys
sys.path.insert(0, _ROOT)
from ref51 import step
k = int(sys.argv[1]); N = int(sys.argv[2])
S = [1, 0, k]
for t in range(N):
    X = S[2:]
    z = 0
    while z < len(X) and X[-1-z] == 0: z += 1
    body = X[:len(X)-z]
    s = ' '.join(map(str, body))
    if len(s) > 150: s = s[:70] + ' ... ' + s[-70:]
    print(f"{t:4d} z={z:<6d} len={len(body):<5d} [{s}]")
    beep, S = step(S)
    if beep: print("BEEP"); break
