import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
import sys, random, itertools
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
from ordw import ordw, fs, cmp, show
from r51 import expansion
def Yj(Y, j):
    Sp, B = expansion(Y)   # Sp = Y^-, B = B(Y)
    return tuple(Sp) + tuple(B) * j
random.seed(7)
worms = [X for L in range(1, 6) for X in itertools.product(range(0, 4), repeat=L) if X[-1] >= 1]
worms += [tuple(random.randint(0, 5) for _ in range(random.randint(1, 7))) for _ in range(300)]
worms = [X for X in worms if X[-1] >= 1]
cnt = {'>': 0, '=': 0, '<': 0}; ex = []
for Y in worms:
    a = ordw(Y)
    for j in range(0, 4):
        c = cmp(ordw(Yj(Y, j)), fs(a, j))
        k = '>' if c > 0 else ('=' if c == 0 else '<')
        cnt[k] += 1
        if k == '<' and len(ex) < 5: ex.append((Y, j, show(ordw(Yj(Y, j))), show(fs(a, j))))
print(cnt); print(ex)
