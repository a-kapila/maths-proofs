import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Exact tools for the dispatch-level process R of SPEC.md (ref51.step) and the battle function Phi.
import sys, functools
sys.setrecursionlimit(1000000)
sys.path.insert(0, _ROOT)
from ref51 import step

def phi_direct(X, z, maxsteps=10**5, maxlen=10**5):
    S = [1, 0] + list(X) + [0] * z
    for _ in range(maxsteps):
        if all(v == 0 for v in S[2:]):
            return len(S) - 2
        beep, S = step(S)
        assert not beep
        if len(S) > maxlen: return None
    return None

def expansion(Q):
    S0 = [1, 0] + list(Q)
    c = S0[-1]
    r = max(i for i in range(len(S0)) if S0[i] < c)
    Sp = S0[:-1] + [c - 1]
    B = Sp[r+1:]
    return Sp[2:], B

def nth_candidate(Q, n):
    Sp, B = expansion(Q)
    W = sum(b + 1 for b in B)
    q, rem = divmod(n, W)
    j = 0
    while rem >= B[j] + 1:
        rem -= B[j] + 1; j += 1
    i = len(Sp) + q * len(B) + j
    E = list(Sp) + list(B) * (q + 1)
    return tuple(E[:i] + [rem])

CAP = 10**40
class Big(Exception): pass

@functools.lru_cache(maxsize=None)
def phi(X, z):
    if z > CAP: raise Big()
    X = tuple(X)
    while X and X[-1] == 0:
        X = X[:-1]; z += 1
    if not X: return z
    if 0 in X:
        i = len(X) - 1 - X[::-1].index(0)
        return phi(X[:i], 1 + phi(X[i+1:], z))
    n = 2 * z + 1
    if n > 10**6: raise Big()
    return phi(nth_candidate(X, n), 0)

def psi(k): return phi((k,), 0)

if __name__ == '__main__':
    import random
    from ref51 import cand
    random.seed(2)
    for _ in range(3000):
        L = random.randint(1, 5)
        Q = [random.randint(0, 4) for _ in range(L)]
        if Q[-1] == 0: Q[-1] = random.randint(1, 4)
        n = random.randint(0, 40)
        assert list(nth_candidate(Q, n)) == cand([1, 0] + Q, n)[2:], (Q, n)
    print("nth_candidate == ref51.cand on 3000 random cases", flush=True)
    ok = 0
    for _ in range(300):
        L = random.randint(1, 3)
        X = tuple(random.choice([0, 0, 1, 1, 2]) for _ in range(L))
        z = random.randint(0, 2)
        d = phi_direct(X, z, maxsteps=5000, maxlen=3000)
        if d is None: continue
        try: p = phi(X, z)
        except Big: continue
        assert p == d, (X, z, p, d)
        ok += 1
    print("phi == direct simulation on", ok, "random small cases", flush=True)
    print("Phi_(1)(z):", [phi((1,), z) for z in range(6)])
    print("Psi(1), Psi(2):", psi(1), psi(2))
