import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
import sys, itertools, random
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
import r51
from r51 import phi, Big, nth_candidate
r51.CAP = 10**30
def P(X, z):
    try: return phi(tuple(X), z)
    except Big: return None
random.seed(5)
worms = []
for L in range(1, 5):
    for X in itertools.product(range(0, 3), repeat=L):
        worms.append(X)
worms += [tuple(random.randint(0, 4) for _ in range(random.randint(1, 5))) for _ in range(300)]
st = {k: [0, 0] for k in ["M1 z-mono", "M2 append", "M3 letterwise", "M4 cand-mono", "M5 prefix", "M6 strict z"]}
def rec(name, ok, info):
    st[name][0] += 1
    if not ok:
        st[name][1] += 1
        if st[name][1] <= 3: print("FAIL", name, info)
for X in worms:
    for z in range(0, 4):
        a, b = P(X, z), P(X, z + 1)
        if None not in (a, b):
            rec("M1 z-mono", a <= b, (X, z, a, b)); rec("M6 strict z", a < b, (X, z, a, b))
        for v in range(0, 4):
            c = P(X + (v,), z)
            if None not in (a, c): rec("M2 append", c >= a, (X, v, z, a, c))
        # prefix: Phi_{X}(z) >= Phi_{X[:-1]}(z)?
        if len(X) >= 2:
            d = P(X[:-1], z)
            if None not in (a, d): rec("M5 prefix", a >= d, (X, z, a, d))
    # letterwise
    for i in range(len(X)):
        Y = list(X); Y[i] += 1; Y = tuple(Y)
        for z in range(0, 3):
            a, b = P(X, z), P(Y, z)
            if None not in (a, b): rec("M3 letterwise", a <= b, (X, Y, z, a, b))
    if X[-1] >= 1:
        prev = None
        for n in range(0, 12):
            C = nth_candidate(X, n)
            v = P(C, 0)
            if v is None: break
            if prev is not None: rec("M4 cand-mono", prev <= v, (X, n, prev, v))
            prev = v
for k, (n, f) in st.items(): print(f"{k:16s} checked {n:6d} failures {f}")
