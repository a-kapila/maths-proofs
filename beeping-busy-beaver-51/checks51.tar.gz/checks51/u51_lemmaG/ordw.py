# Ordinals below epsilon_0 in Cantor normal form, and the worm ordinal of unprovability51.md.
# An ordinal is a tuple of exponents (each an ordinal), non-increasing: (a1, a2, ..., ar) means
# w^a1 + ... + w^ar.  0 = ().
import functools, sys
sys.setrecursionlimit(100000)

ZERO = ()
ONE = (ZERO,)

def cmp(a, b):
    for x, y in zip(a, b):
        c = cmp(x, y)
        if c: return c
    return (len(a) > len(b)) - (len(a) < len(b))

def lt(a, b): return cmp(a, b) < 0

def add(a, b):
    if not b: return a
    lead = b[0]
    keep = [x for x in a]
    while keep and lt(keep[-1], lead): keep.pop()
    return tuple(keep) + b

def wexp(a): return (a,)

def fin(n): return tuple([ZERO] * n)

def blocks(W):
    out = [[]]
    for x in W:
        if x == 0: out.append([])
        else: out[-1].append(x)
    return [tuple(b) for b in out]

@functools.lru_cache(maxsize=None)
def theta(A):
    # A zero-free (possibly empty)
    if not A: return ZERO
    return o(tuple(x - 1 for x in A))

@functools.lru_cache(maxsize=None)
def o(W):
    bl = blocks(W)
    s = ZERO
    for i, b in enumerate(bl):
        if i == 0 and not b: continue
        s = add(s, wexp(theta(b)))
    return s

def ordw(X):
    return o((0,) + tuple(X))

def show(a):
    if not a: return "0"
    parts = []
    i = 0
    while i < len(a):
        j = i
        while j < len(a) and a[j] == a[i]: j += 1
        e = a[i]; k = j - i
        if e == ZERO: t = str(k)
        else:
            t = "w" if e == ONE else "w^(" + show(e) + ")"
            if k > 1: t += "*" + str(k)
        parts.append(t)
        i = j
    return "+".join(parts)

def norm(a):
    # max coefficient / max norm of exponents
    if not a: return 0
    m = 0; i = 0
    while i < len(a):
        j = i
        while j < len(a) and a[j] == a[i]: j += 1
        m = max(m, j - i, norm(a[i]))
        i = j
    return m

def tau(s):
    t = ZERO
    for _ in range(s): t = wexp(t)
    return t

def fs(a, n):
    # Buchholz-Wainer fundamental sequence a[n] (successor: predecessor; 0 -> 0)
    if not a: return ZERO
    rho, d = a[:-1], a[-1]
    if d == ZERO: return rho
    # d = gamma+1 ?
    if d and d[-1] == ZERO:
        g = d[:-1]
        return rho + tuple([g] * (n + 1))
    return rho + (fs(d, n),)
