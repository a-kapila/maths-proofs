import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Brute-force E(alpha,t) = max over plays (beta < alpha, ||beta|| <= t+1) and compare with 2*Phi for NF states.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG')); sys.path.insert(0, os.path.join(_ROOT,'lemmaG_work'))
sys.setrecursionlimit(1000000)
from ordw import o as ofun, cmp, add, fin, show, ZERO
from nfchecks_lib import NF, worms_of_size
import phis
phis.CAP = 10**12; phis.NMAX = 10**6
from phis import P
from functools import lru_cache, cmp_to_key
SMAX = 24
nfw = []
for s in range(0, SMAX + 1):
    for X in worms_of_size(s):
        if NF(X): nfw.append((ofun(X), s, X))
nfw.sort(key=cmp_to_key(lambda a, b: cmp(a[0], b[0])))
idx = {a[0]: i for i, a in enumerate(nfw)}
norm = {a[0]: a[1] for a in nfw}
print("NF worms up to size", SMAX, ":", len(nfw))
@lru_cache(maxsize=None)
def E(i, t):
    a = nfw[i][0]
    if all(e == ZERO for e in a):      # finite
        return t + len(a)
    best = None
    for k in range(i - 1, -1, -1):     # all beta < alpha
        if nfw[k][1] <= t + 1:
            v = E(k, t + 1)
            if best is None or v > best: best = v
    return best
ok = bad = 0
tests = [((1,), z) for z in range(0, 8)] + [((1,1), 0), ((1,1), 1), ((1,0,1), 0), ((1,0,1), 1), ((2,), 0), ((1,0,0,1), 0), ((1,1,0,1),0)]
for X, z in tests:
    a = add(ofun(X), fin(z)); t = sum(x+1 for x in X) + z
    phi = P(X, z)
    if phi is None or 2*phi > 2*SMAX: 
        print("skip", X, z, phi); continue
    e = E(idx[a], t)
    print(X, z, "2*Phi =", 2*phi, " E_brute =", e, "OK" if e == 2*phi else "MISMATCH")
