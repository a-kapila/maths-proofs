import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Checks: (1) NF (syntactic) == tight (min size); (2) Claim S; (3) KLL; (4) m_j formula; (5) norm bound for FS.
import sys, itertools
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.setrecursionlimit(100000)
from ordw import o as ofun, cmp, show, fs, ZERO, ONE
from r51 import expansion, nth_candidate
from functools import lru_cache
S = int(sys.argv[1]) if len(sys.argv) > 1 else 13
def worms_of_size(s):
    if s == 0:
        yield (); return
    for first in range(1, s + 1):
        for rest in worms_of_size(s - first):
            yield (first - 1,) + rest
allw = [X for s in range(0, S+1) for X in worms_of_size(s)]
def size(X): return sum(x+1 for x in X)
O = {X: ofun(X) for X in allw}
minsize = {}
for X in sorted(allw, key=size):
    if O[X] not in minsize: minsize[O[X]] = size(X)
def tight(X): return minsize[O[X]] == size(X)
def blocks(W):
    out = [[]]
    for x in W:
        if x == 0: out.append([])
        else: out[-1].append(x)
    return [tuple(b) for b in out]
def theta(A): return ofun(tuple(a-1 for a in A)) if A else ZERO
@lru_cache(maxsize=None)
def NF(W):
    W = tuple(W)
    if all(x == 0 for x in W): return True
    bl = blocks(W)
    if not bl[0]: return False
    # nonempty blocks then only empty blocks
    seen_empty = False
    for b in bl:
        if not b: seen_empty = True
        elif seen_empty: return False
    ne = [b for b in bl if b]
    for i in range(len(ne)-1):
        if cmp(theta(ne[i]), theta(ne[i+1])) < 0: return False
    return all(NF(tuple(a-1 for a in b)) for b in ne)
bad = sum(1 for X in allw if NF(X) != tight(X))
print("NF != tight:", bad, "of", len(allw))
# Claim S: NF V = W a U  =>  o(V) < o(W (a+1))
cs = 0; csf = 0
for V in allw:
    if not NF(V): continue
    for i in range(len(V)):
        W, a, U = V[:i], V[i], V[i+1:]
        cs += 1
        if cmp(O[V] if V in O else ofun(V), ofun(W + (a+1,))) >= 0:
            csf += 1
            if csf < 5: print("ClaimS FAIL", V, i)
print("Claim S checks", cs, "fails", csf)
# KLL: Y NF stripped, Y^- Z NF  =>  Z <=lex B^inf
kl = 0; klf = 0
nfset = [X for X in allw if NF(X)]
for Y in nfset:
    if not Y or Y[-1] == 0: continue
    Ym, B = expansion(Y)
    Ym = tuple(Ym); B = tuple(B)
    for X in nfset:
        if len(X) > len(Ym) and X[:len(Ym)] == Ym:
            Z = X[len(Ym):]
            kl += 1
            ok = True
            for k, zk in enumerate(Z):
                bk = B[k % len(B)]
                if zk < bk: break
                if zk > bk: ok = False; break
            if not ok:
                klf += 1
                if klf < 5: print("KLL FAIL", Y, Z, B)
print("KLL checks", kl, "fails", klf)
