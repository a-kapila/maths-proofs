import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Lemma 6.9(c),(d): every list reached by R is [1,0]+X with X NF -- from S_0=[1,0] (through beeps and restarts),
# from <(k),z>, and from random NF starting worms.  Also checks the bookkeeping used in Theorem 6.14 at each non-beep
# step: size(next) = size(Y)+2z+1 (Lemma 3.1(c)) and o(next) < o(Y) (Lemma 4.4).
import sys, random
sys.path.insert(0, _ROOT); sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.path.insert(0, os.path.join(_ROOT,'lemmaG_work'))
sys.setrecursionlimit(1000000)
from ref51 import step
from ordw import o as ofun, cmp
from nfchecks_lib import NF, worms_upto

MAXLEN = int(sys.argv[1]) if len(sys.argv) > 1 else 400
def size(X): return sum(x + 1 for x in X)

def run_check(S, maxsteps, label):
    """Run R from list S for at most maxsteps steps (or until the list exceeds MAXLEN); check NF of every worm."""
    steps = beeps = fails = 0
    X = tuple(S[2:])
    if not NF(X):
        print("START NOT NF", label, X); return 0, 0, 1
    for _ in range(maxsteps):
        z = 0
        while z < len(X) and X[len(X) - 1 - z] == 0: z += 1
        Y = X[:len(X) - z]
        beep, S2 = step(list(S))
        X2 = tuple(S2[2:])
        steps += 1
        if beep:
            beeps += 1
            if Y != () or X2 != (len(X) + 1,): fails += 1; print("BEEP SHAPE FAIL", label, X, X2)
        else:
            if size(X2) != size(Y) + 2 * z + 1: fails += 1; print("SIZE FAIL", label, X, X2)
            if len(X2) <= 60 and cmp(ofun(X2), ofun(Y)) >= 0: fails += 1; print("ORD FAIL", label, X, X2)
        if not NF(X2):
            fails += 1
            if fails < 10: print("NF FAIL", label, X, "->", X2)
        S, X = S2, X2
        if len(S) > MAXLEN: break
    return steps, beeps, fails

tot_steps = tot_beeps = tot_fail = 0
# 1. the run of R itself from [1,0]
s, b, f = run_check([1, 0], 10**6, "R from [1,0]")
print(f"run of R from [1,0]: {s} steps, {b} beeps, NF failures {f} (stopped at list length > {MAXLEN})")
tot_steps += s; tot_beeps += b; tot_fail += f
# 2. runs from <(k),z>
for k in range(1, 7):
    for zz in range(0, 8):
        s, b, f = run_check([1, 0, k] + [0] * zz, 20000, f"<({k}),{zz}>")
        tot_steps += s; tot_beeps += b; tot_fail += f
print("runs from <(k),z>, k<=6, z<=7: done")
# 3. runs from random NF worms (size <= 12) with random counters
random.seed(5)
nfw = [X for X in worms_upto(12) if NF(X)]
for _ in range(600):
    X = random.choice(nfw); zz = random.randint(0, 6)
    s, b, f = run_check([1, 0] + list(X) + [0] * zz, 3000, f"<{X},{zz}>")
    tot_steps += s; tot_beeps += b; tot_fail += f
print(f"TOTAL: {tot_steps} steps checked ({tot_beeps} beeps with restart), failures {tot_fail}")
