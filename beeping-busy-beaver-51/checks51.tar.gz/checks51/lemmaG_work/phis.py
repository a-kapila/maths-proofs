import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Exact Phi with a work budget (raises Big when exceeded). Same recursion as u51_lemmaG/r51.py.
import sys, functools
sys.setrecursionlimit(100000)
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
from r51 import nth_candidate
class Big(Exception): pass
CAP = 10**40
NMAX = 10**5
_cache = {}
def phi(X, z, budget=None):
    X = tuple(X)
    key = (X, z)
    if key in _cache:
        v = _cache[key]
        if v is None: raise Big()
        return v
    if z > CAP: raise Big()
    try:
        v = _phi(X, z)
    except Big:
        _cache[key] = None
        raise
    _cache[key] = v
    return v
def _phi(X, z):
    while X and X[-1] == 0:
        X = X[:-1]; z += 1
    if not X: return z
    if 0 in X:
        i = len(X) - 1 - X[::-1].index(0)
        inner = phi(X[i+1:], z)
        return phi(X[:i], 1 + inner)
    n = 2 * z + 1
    if n > NMAX: raise Big()
    return phi(nth_candidate(X, n), 0)
def P(X, z):
    try: return phi(X, z)
    except (Big, RecursionError): return None
def size(X): return sum(x+1 for x in X)
