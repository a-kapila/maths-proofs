import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Monotonicity of Phi on NF worms in (o + z, size + z): consequence of greedy domination.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG')); sys.path.insert(0, os.path.join(_ROOT,'lemmaG_work'))
sys.setrecursionlimit(100000)
from ordw import o as ofun, cmp, add, fin
import phis
phis.CAP = 10**25; phis.NMAX = 10**5
from phis import P
from nfchecks_lib import NF, worms_upto
S = 9
W = [X for X in worms_upto(S) if NF(X) and (not X or X[-1] != 0)]
data = []
for X in W:
    for z in range(0, 6):
        v = P(X, z)
        if v is None: continue
        data.append((add(ofun(X), fin(z)), sum(x+1 for x in X) + z, v, X, z))
print("states", len(data))
bad = 0; chk = 0
for a in data:
    for b in data:
        if cmp(a[0], b[0]) <= 0 and a[1] <= b[1]:
            chk += 1
            if a[2] > b[2]:
                bad += 1
                if bad < 6: print("MONO FAIL", a[3], a[4], a[2], "vs", b[3], b[4], b[2])
print("pairs", chk, "failures", bad)
