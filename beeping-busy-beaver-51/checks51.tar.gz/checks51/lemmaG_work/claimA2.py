import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Claim A' : for TIGHT stripped Y (size(Y) minimal among worms with ord = ord(Y)),
# ord(C_n(Y)) = max{ord(X): ord(X) < ord(Y), size(X) <= size(Y)+n}; also report whether C_n(Y) is tight.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.setrecursionlimit(100000)
from ordw import ordw, cmp, show
from r51 import nth_candidate
from functools import cmp_to_key
S = int(sys.argv[1]) if len(sys.argv) > 1 else 12
def worms_of_size(s):
    if s == 0:
        yield (); return
    for first in range(1, s + 1):
        for rest in worms_of_size(s - first):
            yield (first - 1,) + rest
allw = {s: list(worms_of_size(s)) for s in range(1, S + 1)}
O = {}
for s in allw:
    for X in allw[s]: O[X] = ordw(X)
def key(a): return a
# tightness: minimal size per ordinal (among sizes <= S)
minsize = {}
for s in range(1, S + 1):
    for X in allw[s]:
        k = O[X]
        if k not in minsize: minsize[k] = s
def tight(X): return minsize[O[X]] == sum(x+1 for x in X)
sorted_by_b = {}
acc = []
for s in range(1, S + 1):
    acc += [(O[X], X) for X in allw[s]]
    sorted_by_b[s] = sorted(acc, key=cmp_to_key(lambda a, b: cmp(a[0], b[0])))
def maxbelow(alpha, b):
    L = sorted_by_b[b]; lo, hi = 0, len(L)
    while lo < hi:
        mid = (lo + hi) // 2
        if cmp(L[mid][0], alpha) < 0: lo = mid + 1
        else: hi = mid
    return L[lo - 1] if lo > 0 else None
fails = checks = nontight = 0
for s in range(1, S):
    for Y in allw[s]:
        if Y[-1] == 0 or not tight(Y): continue
        a = O[Y]
        for n in range(0, S - s + 1):
            C = nth_candidate(Y, n)
            m = maxbelow(a, s + n)
            checks += 1
            if not tight(C): nontight += 1
            if cmp(O[C], m[0]) != 0:
                fails += 1
                if fails <= 12: print("FAIL Y", Y, "n", n, "C", C, show(O[C]), "best", m[1], show(m[0]))
print("tight stripped Y checks", checks, "fails", fails, "nontight candidates", nontight)
