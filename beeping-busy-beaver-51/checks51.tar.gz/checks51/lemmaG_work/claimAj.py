import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Generalized greedy claim at lifted level j: for stripped W that is (o, nu_j)-tight,
#   o(C_n(W)) = max{ o(X) : o(X) < o(W), nu_j(X) <= nu_j(C_n(W)) }   for all n.
# o = Beklemishev-style o of unprovability51 (first block counted only if nonempty); also test ord.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.setrecursionlimit(100000)
from ordw import o as ofun, ordw, cmp, show
from r51 import nth_candidate
from functools import cmp_to_key
j = int(sys.argv[1]); NB = int(sys.argv[2]); which = sys.argv[3] if len(sys.argv) > 3 else 'o'
F = (lambda X: ofun(tuple(X))) if which == 'o' else (lambda X: ordw(tuple(X)))
def nu(X): return sum(x + 1 + j for x in X)
# enumerate all worms with nu_j <= NB
allw = []
def gen(prefix, budget):
    allw.append(tuple(prefix))
    for x in range(0, budget):
        c = x + 1 + j
        if c <= budget:
            prefix.append(x); gen(prefix, budget - c); prefix.pop()
gen([], NB)
O = {X: F(X) for X in allw}
minnu = {}
for X in sorted(allw, key=nu):
    if O[X] not in minnu: minnu[O[X]] = nu(X)
def tight(X): return minnu[O[X]] == nu(X)
L = sorted(allw, key=cmp_to_key(lambda a, b: cmp(O[a], O[b])))
# for max query: for each budget b, we need max o(X) < alpha with nu(X) <= b. brute force via sorted list
byb = {}
for b in range(0, NB + 1):
    byb[b] = [X for X in L if nu(X) <= b]   # sorted by ordinal
def maxbelow(alpha, b):
    lst = byb[b]; lo, hi = 0, len(lst)
    while lo < hi:
        mid = (lo + hi) // 2
        if cmp(O[lst[mid]], alpha) < 0: lo = mid + 1
        else: hi = mid
    return lst[lo - 1] if lo > 0 else None
checks = fails = nt = 0
for W in allw:
    if not W or W[-1] == 0 or not tight(W): continue
    n = 0
    while True:
        C = nth_candidate(W, n)
        if nu(C) > NB: break
        m = maxbelow(O[W], nu(C))
        checks += 1
        if not tight(C): nt += 1
        if m is None or cmp(O[C], O[m]) != 0:
            fails += 1
            if fails <= 8: print("FAIL W", W, "n", n, "C", C, show(O[C]), "best", m, show(O[m]) if m else None)
        n += 1
print(f"j={j} NB={NB} {which}: checks {checks} fails {fails} nontight-candidates {nt}")
