import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Exhaustive check of Theorem 6.14:  E(o(Y)+z, size(Y)+z) = 2*Phi_Y(z)  for small NF states.
# Method (rigorous for each tested state).  Let N := 2*Phi+1.  Let R_N be the game of plays all of whose terms have
# worm norm <= N and that end by time N.  Every R_N-play is a play, so E_{R_N} <= E.  Conversely, if a play ends at
# T <= N, all its terms have norm <= T <= N, so it is an R_N-play; if it ends at T > N, follow it up to time N-1 and
# then jump to 0 at time N: an R_N-play ending at N.  So E_{R_N} >= min(E, N).  Hence E_{R_N} <= N-1 implies
# E = E_{R_N}.  We compute E_{R_N} exactly by dynamic programming over ALL ordinals below alpha of norm <= N
# (= all NF worms W <lex Y0^z of size <= N, Lemmas 6.4 and 6.7), and compare with 2*Phi from phis.py.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG')); sys.path.insert(0, os.path.join(_ROOT,'lemmaG_work'))
sys.setrecursionlimit(1000000)
from ordw import o as ofun, cmp
from nfchecks_lib import NF
import phis
phis.CAP = 10**12; phis.NMAX = 10**6
from phis import P
from functools import cmp_to_key

def size(X): return sum(x + 1 for x in X)

class TooMany(Exception): pass
CAPORD = 150000
def nf_below(A, N):
    """All NF worms W with W <lex A (W != A) and size(W) <= N, by DFS over NF prefixes (Lemma 6.8: prefix-closed)."""
    out = []
    def dfs(W, s, tight):   # tight: W is a prefix of A
        # W itself is < A unless W == A; record it if W != A (proper prefix of A, or already smaller)
        if not (tight and len(W) == len(A)):
            out.append(W)
            if len(out) > CAPORD: raise TooMany()
        for x in range(0, N - s):
            if s + x + 1 > N: break
            if tight:
                if len(W) >= len(A):
                    continue           # W == A: extensions are > A
                a = A[len(W)]
                if x > a: break
                nt = (x == a)
            else:
                nt = False
            W2 = W + (x,)
            if not NF(W2): continue
            dfs(W2, s + x + 1, nt)
    dfs((), 0, True)
    return out

def E_RN(Y, z):
    A = tuple(Y) + (0,) * z
    phi = P(Y, z)
    if phi is None: return None
    N = 2 * phi + 1
    S = size(A)
    NF.cache_clear()
    try: ws = nf_below(A, N)
    except TooMany: return "toomany"
    ords = [(ofun(W), size(W)) for W in ws]
    ords.sort(key=cmp_to_key(lambda a, b: cmp(a[0], b[0])))
    # sanity: distinct ordinals (uniqueness of NF worms)
    for i in range(len(ords) - 1):
        assert cmp(ords[i][0], ords[i + 1][0]) < 0
    alpha = ofun(A)
    norms = [nn for (_, nn) in ords] + [S]          # index len(ords) = alpha itself
    M = len(norms)
    NEG = -1
    E_next = [N if i == 0 else NEG for i in range(M)]   # time N: only ordinal 0 may stand here
    for t in range(N - 1, S - 1, -1):
        E_cur = [NEG] * M
        best = NEG
        for i in range(M):
            # E_cur[i] = max over k < i with norm_k <= t+1 of E_next[k]
            if i == 0: E_cur[0] = t
            else: E_cur[i] = best
            if norms[i] <= t + 1 and E_next[i] > best: best = E_next[i]
        E_next = E_cur
    return phi, N, len(ords), E_next[M - 1]

tests = [((1,), z) for z in range(0, 12)] + [((1, 1), z) for z in range(0, 5)] + \
        [((2,), 0), ((1, 0, 1), 0), ((1, 0, 1), 1), ((1, 0, 1), 2), ((1, 0, 0, 1), 0), ((1, 0, 1, 1), 0),
         ((1, 0, 1, 0, 1), 0), ((1, 1, 0, 1), 0), ((1, 1, 1), 0), ((2,), 1)]
ok = bad = 0
for Y, z in tests:
    r = E_RN(Y, z)
    if r is None or r == "toomany": print("skip", Y, z, "(Phi not computable)" if r is None else "(too many ordinals)", flush=True); continue
    phi, N, nords, e = r
    good = (e == 2 * phi and e <= N - 1)
    ok += good; bad += (not good)
    print(f"Y={Y} z={z}: 2*Phi={2*phi}  E_RN={e}  (N={N}, {nords} ordinals below alpha with norm<=N)  {'OK' if good else 'MISMATCH'}",
          flush=True)
print("states", ok + bad, "OK", ok, "MISMATCH", bad)
