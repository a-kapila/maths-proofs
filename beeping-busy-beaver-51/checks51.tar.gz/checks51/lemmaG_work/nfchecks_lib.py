import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
from ordw import o as ofun, cmp, ZERO
from functools import lru_cache
def worms_of_size(s):
    if s == 0:
        yield (); return
    for first in range(1, s + 1):
        for rest in worms_of_size(s - first):
            yield (first - 1,) + rest
def worms_upto(S):
    return [X for s in range(0, S+1) for X in worms_of_size(s)]
def blocks(W):
    out = [[]]
    for x in W:
        if x == 0: out.append([])
        else: out[-1].append(x)
    return [tuple(b) for b in out]
def theta(A): return ofun(tuple(a-1 for a in A)) if A else ZERO
@lru_cache(maxsize=None)
def NF(W):
    W = tuple(W)
    if all(x == 0 for x in W): return True
    bl = blocks(W)
    if not bl[0]: return False
    seen_empty = False
    for b in bl:
        if not b: seen_empty = True
        elif seen_empty: return False
    ne = [b for b in bl if b]
    for i in range(len(ne)-1):
        if cmp(theta(ne[i]), theta(ne[i+1])) < 0: return False
    return all(NF(tuple(a-1 for a in b)) for b in ne)
