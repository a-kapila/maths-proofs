import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Conjecture L: on TIGHT worms, ordinal order = lexicographic order (proper prefix < extension).
# Also: prefixes of tight worms are tight; characterize tight worms.
import sys
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.setrecursionlimit(100000)
from ordw import ordw, cmp, show
from functools import cmp_to_key
S = int(sys.argv[1]) if len(sys.argv) > 1 else 12
def worms_of_size(s):
    if s == 0:
        yield (); return
    for first in range(1, s + 1):
        for rest in worms_of_size(s - first):
            yield (first - 1,) + rest
allw = {s: list(worms_of_size(s)) for s in range(0, S + 1)}
O = {}
for s in allw:
    for X in allw[s]: O[X] = ordw(X)
minsize = {}
for s in range(0, S + 1):
    for X in allw[s]:
        if O[X] not in minsize: minsize[O[X]] = s
def size(X): return sum(x+1 for x in X)
tight = [X for s in range(0, S+1) for X in allw[s] if minsize[O[X]] == s]
print("tight counts by size", [sum(1 for X in allw[s] if minsize[O[X]] == s) for s in range(0, S+1)])
# uniqueness: is there exactly one tight worm per ordinal?
from collections import Counter
cnt = Counter(O[X] for X in tight)
print("ordinals with >1 tight worm:", sum(1 for k, v in cnt.items() if v > 1))
def lexcmp(X, Y):
    for a, b in zip(X, Y):
        if a != b: return -1 if a < b else 1
    return (len(X) > len(Y)) - (len(X) < len(Y))
bad = 0
T = sorted(tight, key=cmp_to_key(lambda a, b: cmp(O[a], O[b])))
for i in range(len(T) - 1):
    if lexcmp(T[i], T[i+1]) >= 0:
        bad += 1
        if bad <= 10: print("LEX FAIL", T[i], show(O[T[i]]), T[i+1], show(O[T[i+1]]))
print("adjacent pairs checked", len(T)-1, "lex failures", bad)
# prefixes of tight worms tight?
pf = 0
tset = set(tight)
for X in tight:
    for i in range(len(X)):
        if X[:i] not in tset:
            pf += 1
            if pf <= 5: print("PREFIX NOT TIGHT", X, X[:i])
print("prefix failures", pf)
