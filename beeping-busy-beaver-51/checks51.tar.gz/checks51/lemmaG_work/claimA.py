import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Test Claim A: C_n(Y) has the largest worm ordinal among all worms X with ord(X) < ord(Y)
# and size(X) <= size(Y)+n.
import sys, itertools
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG'))
sys.setrecursionlimit(100000)
from ordw import ordw, cmp, show
from r51 import nth_candidate
S = int(sys.argv[1]) if len(sys.argv) > 1 else 13
MODE = sys.argv[2] if len(sys.argv) > 2 else "all"
def worms_of_size(s):
    # compositions of s into parts >= 1; part a -> letter a-1
    if s == 0:
        yield (); return
    for first in range(1, s + 1):
        for rest in worms_of_size(s - first):
            yield (first - 1,) + rest
import functools
allw = {}
for s in range(1, S + 1):
    allw[s] = list(worms_of_size(s))
print("counts", [len(allw[s]) for s in range(1, S+1)], flush=True)
ordcache = {}
def O(X):
    if X not in ordcache: ordcache[X] = ordw(X)
    return ordcache[X]
# for each size bound b, list of (ord, worm) for all worms of size <= b, sorted
from functools import cmp_to_key
bysize = []
acc = []
for s in range(1, S + 1):
    acc = acc + [(O(X), X) for X in allw[s]]
    bysize.append(None)
# best below: for each b, sorted list of ordinals of worms of size <= b
sorted_by_b = {}
acc = []
for s in range(1, S + 1):
    acc += [(O(X), X) for X in allw[s]]
    sorted_by_b[s] = sorted(acc, key=cmp_to_key(lambda a, b: cmp(a[0], b[0])))
import bisect
def maxbelow(alpha, b):
    L = sorted_by_b[b]
    # binary search last element with ord < alpha
    lo, hi = 0, len(L)
    while lo < hi:
        mid = (lo + hi) // 2
        if cmp(L[mid][0], alpha) < 0: lo = mid + 1
        else: hi = mid
    return L[lo - 1] if lo > 0 else None
fails = 0; checks = 0; ties = 0
for s in range(1, S):
    for Y in allw[s]:
        if Y[-1] == 0: continue
        if MODE == "zf" and 0 in Y: continue
        if MODE == "nz" and Y[0] == 0: continue
        a = O(Y)
        for n in range(0, S - s + 1):
            C = nth_candidate(Y, n)
            b = s + n
            m = maxbelow(a, b)
            checks += 1
            c = cmp(O(C), m[0])
            if c != 0:
                fails += 1
                if fails <= 15:
                    print("FAIL Y", Y, "n", n, "C", C, show(O(C)), "best", m[1], show(m[0]))
print("checks", checks, "fails", fails)
