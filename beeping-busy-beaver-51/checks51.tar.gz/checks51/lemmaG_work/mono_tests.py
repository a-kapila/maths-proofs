import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
import sys, itertools, random
sys.path.insert(0, os.path.join(_ROOT,'lemmaG_work'))
import phis
from phis import P, size
phis.CAP = 10**30; phis.NMAX = 2*10**4
res = {}
def rec(name, ok, info):
    s = res.setdefault(name, [0, 0, []])
    s[0] += 1
    if not ok:
        s[1] += 1
        if len(s[2]) < 5: s[2].append(info)
worms = []
for L in range(1, 5):
    for X in itertools.product(range(0, 3), repeat=L):
        worms.append(X)
random.seed(7)
worms += [tuple(random.randint(0, 3) for _ in range(random.randint(1, 5))) for _ in range(150)]
worms = sorted(set(worms))
for X in worms:
    Xp = tuple(x+1 for x in X)
    for y in range(0, 4):
        a = P(Xp, y); b = P(X, y)
        if a is not None and b is not None:
            rec("lift: Phi_{X+1}(y) >= Phi_X(y)", a >= b, (X, y, a, b))
        d = P(X, 2*y+1)
        if a is not None and d is not None:
            rec("lift: Phi_{X+1}(y) >= Phi_X(2y+1)", a >= d, (X, y, a, d))
for X in worms:
    s = size(X)
    if s - 1 < 1: continue
    a = P((s-1,), 0); b = P(X, 0)
    if b is not None:
        rec("single-letter: Psi(s-1) >= Phi_T(0), size T = s", a is None or a >= b, (X, s, a, b))
for X in worms:
    for i in range(len(X)):
        if X[i] == 0 and 0 < i < len(X)-1:
            Y = X[:i] + X[i+1:]
            for z in range(0, 3):
                a = P(X, z); b = P(Y, z)
                if a is not None and b is not None:
                    rec("zero-removal: Phi_{A0Y} <= Phi_{AY}", a <= b, (X, Y, z, a, b))
for X in worms:
    for i in range(1, len(X)):
        Y = X[:i] + X[i+1:]
        for z in range(0, 3):
            a = P(X, z); b = P(Y, z)
            if a is not None and b is not None:
                rec("insertion: Phi_{AaB}(z) >= Phi_{AB}(z)", a >= b, (Y, X, z, b, a))
for X in worms:
    for i in range(len(X)):
        Y = list(X); Y[i] += 1; Y = tuple(Y)
        for z in range(0, 3):
            a = P(X, z); b = P(Y, z)
            if a is not None and b is not None:
                rec("letterwise: raise one letter", b >= a, (X, Y, z, a, b))
for k, (n, f, ex) in res.items():
    print(f"{k:55s} checked {n:6d} failures {f}")
    for e in ex: print("     e.g.", e)
