import os as _os_r, sys as _sys_r
_ROOT = _os_r.path.dirname(_os_r.path.dirname(_os_r.path.abspath(__file__)))
import os
# Norm formulas: m_j(beta) and NF worm construction; check m_j(mu[y]) <= (y+1) m_j(mu) for limits mu.
import sys, random, itertools
sys.path.insert(0, os.path.join(_ROOT,'u51_lemmaG')); sys.path.insert(0, os.path.join(_ROOT,'lemmaG_work'))
sys.setrecursionlimit(100000)
from ordw import o as ofun, cmp, fs, ZERO, ONE, show, tau
from nfchecks_lib import NF
from functools import lru_cache
@lru_cache(maxsize=None)
def NFw(b):
    # ordinal b = tuple of exponents (CNF, nonincreasing); returns NF worm with o = b
    inf = [e for e in b if e != ZERO]; r = len(b) - len(inf)
    if not inf: return tuple([0]*r)
    parts = []
    for e in inf:
        parts.append(tuple(x+1 for x in NFw(e)))
    W = list(parts[0])
    for p in parts[1:]: W += [0] + list(p)
    W += [0]*r
    return tuple(W)
def nu(W, j): return sum(x+1+j for x in W)
@lru_cache(maxsize=None)
def m(b, j):
    inf = [e for e in b if e != ZERO]; r = len(b) - len(inf)
    if not inf: return r*(1+j)
    return sum(m(e, j+1) for e in inf) + (len(inf) - 1 + r)*(1+j)
# random ordinals from small worms
def rand_ord(depth):
    if depth == 0: return tuple([ZERO]*random.randint(0, 3))
    k = random.randint(1, 3)
    exps = sorted([rand_ord(depth-1) for _ in range(k)], key=lambda e: e, reverse=False)
    # sort nonincreasing using cmp
    from functools import cmp_to_key
    exps = sorted(exps, key=cmp_to_key(cmp), reverse=True)
    tail = tuple([ZERO]*random.randint(0, 2))
    return tuple(e for e in exps) + tail
random.seed(11)
ords = set()
for _ in range(3000):
    try: ords.add(rand_ord(random.randint(1, 3)))
    except RecursionError: pass
ords.update([tau(s) for s in range(1, 6)])
f1 = f2 = f3 = f4 = 0; n = 0
for b in ords:
    W = NFw(b)
    n += 1
    if cmp(ofun(W), b) != 0: f1 += 1
    if not NF(W): f2 += 1
    for j in range(0, 4):
        if nu(W, j) != m(b, j): f3 += 1
    if b and b[-1] != ZERO:   # limit
        for y in range(0, 5):
            for j in range(0, 3):
                if m(fs(b, y), j) > (y+1)*m(b, j): f4 += 1
print("ordinals", n, "o(NF)!=b", f1, "NF not NF", f2, "nu_j != m_j", f3, "FS norm bound fails", f4)
