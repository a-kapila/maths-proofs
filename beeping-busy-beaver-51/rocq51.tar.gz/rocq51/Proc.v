(* Proc.v -- the dispatch-level process R (ref51.py, function [step]), the pair encoding
   of a sequence (ref51.py, function [encode]) and the dispatch configuration D(S). *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51.
Import ListNotations.

(* ------------------------------------------------------------------------- *)
(* The process R, transcribed from ref51.py.                                  *)

(* number of leading zeros of a list *)
Fixpoint lz (l : list nat) : nat :=
  match l with 0 :: t => S (lz t) | _ => 0 end.

(* z = number of trailing zeros of S:
     z = 0; while z < len(S) and S[len(S)-1-z] == 0: z += 1 *)
Definition tz (S : list nat) : nat := lz (rev S).

(* r = max(i for i in range(len(S0)) if S0[i] < c).  [maxlt_from c l i acc] scans l,
   whose first element has index i, keeping in acc the last index seen with a value < c.
   (When no element is < c it returns 0; that case does not arise in [cand].) *)
Fixpoint maxlt_from (c : nat) (l : list nat) (i acc : nat) : nat :=
  match l with
  | [] => acc
  | a :: t => maxlt_from c t (S i) (if a <? c then i else acc)
  end.
Definition maxlt (c : nat) (l : list nat) : nat := maxlt_from c l 0 0.

(* E(i) = Sp[i] if i < len(Sp) else B[(i - len(Sp)) % len(B)] *)
Definition Efun (Sp B : list nat) (i : nat) : nat :=
  if i <? length Sp then nth i Sp 0 else nth ((i - length Sp) mod length B) B 0.

(* The candidate loop of ref51.py:
     idx = 0; L = len(S0) + 1
     while True:
         pre = [E(i) for i in range(L - 1)]
         for v in range(E(L - 1) + 1):
             if idx == n: return pre + [v]
             idx += 1
         L += 1
   [candloop E fuel L m] runs it from length L, where m = n - idx is the number of
   candidates still to be skipped.  The fuel n+1 used in [cand] is always enough: every
   round of the while loop lowers m by at least 1, so with any fuel > m the loop returns
   pre + [v] in a round of its own and the result does not depend on the fuel
   ([candloop_returns], [candloop_fuel] in Comb.v). *)
Fixpoint candloop (E : nat -> nat) (fuel L m : nat) : list nat :=
  match fuel with
  | 0 => []
  | S f => if m <=? E (L - 1) then map E (seq 0 (L - 1)) ++ [m]
           else candloop E f (S L) (m - S (E (L - 1)))
  end.

(* def cand(S0, n):
       c = S0[-1]
       r = max(i for i in range(len(S0)) if S0[i] < c)
       Sp = S0[:-1] + [c - 1]
       B = Sp[r + 1:]
       ... candidate number n (counting from 0) *)
Definition cand (S0 : list nat) (n : nat) : list nat :=
  let c := last S0 0 in
  let r := maxlt c S0 in
  let Sp := removelast S0 ++ [c - 1] in
  let B := skipn (S r) Sp in
  candloop (Efun Sp B) (S n) (S (length S0)) n.

(* def step(S):
       z = number of trailing zeros of S
       S0 = S[:len(S) - z]
       if S0 == [1]: return True, [1, 0, z]
       return False, cand(S0, 1 + 2 * z) *)
Definition step (S : list nat) : bool * list nat :=
  let z := tz S in
  let S0 := firstn (length S - z) S in
  if list_eq_dec Nat.eq_dec S0 [1] then (true, [1; 0; z])
  else (false, cand S0 (1 + 2 * z)).

(* ------------------------------------------------------------------------- *)
(* The tape encoding.                                                         *)

(* Cell pairs.  X = 10 and U = 11 encode sequences; O = 01 and G = 00 occur only
   inside a dispatch cycle (as marks and as the gap). *)
Inductive Pr : Type := pX | pU | pO | pG.

Definition fb (p : Pr) : Sym := match p with pX | pU => s1 | pO | pG => s0 end.  (* first cell *)
Definition sb (p : Pr) : Sym := match p with pU | pO => s1 | pX | pG => s0 end.  (* second cell *)

Fixpoint cells (W : list Pr) : list Sym :=
  match W with [] => [] | p :: t => fb p :: sb p :: cells t end.

(* encode(S) = 'U'.join('X' * a for a in S[::-1]): the X/U word of the reversed sequence *)
Fixpoint pw (T : list nat) : list Pr :=
  match T with
  | [] => []
  | a :: t => repeat pX a ++ match t with [] => [] | _ :: _ => pU :: pw t end
  end.

Definition enc (S : list nat) : list Sym := cells (pw (rev S)).

(* ------------------------------------------------------------------------- *)
(* The dispatch configuration D(S), given relative to the head:
   state 22, the head on a 0 cell, every cell to its left 0, the encoding of S
   to its right, then 0 forever. *)

Definition blank : Stream Sym := const s0.
Definition Conf51 : Type := @Conf Sym St.
Definition Dconf (S : list nat) : Conf51 := (Q22, blank, s0, enc S *> blank).

(* the all-blank tape in state 31 (the start-31 run) *)
Definition C31 : Conf51 := (Q31, blank, s0, blank).

(* ------------------------------------------------------------------------- *)
(* The run of the process from [1;0], and the beep counts.                    *)

Fixpoint Sseq (j : nat) : list nat :=
  match j with 0 => [1; 0] | S i => snd (step (Sseq i)) end.

(* number of i < j with fst (step S_i) = true *)
Fixpoint nbeep_before (j : nat) : nat :=
  match j with 0 => 0 | S i => nbeep_before i + (if fst (step (Sseq i)) then 1 else 0) end.

(* Sanity checks against ref51.py (python3 -c "from ref51 import step; ..."):
   S_0..S_6 = [1,0], [1,0,1], [1,0,0,0,0], [1,0,4], [1,0,3,1], [1,0,3,0,1], [1,0,3,0,0,0,0];
   the steps from S_0 and S_2 beep, the others do not. *)
Example Sseq_check :
  map Sseq [0; 1; 2; 3; 4; 5; 6] =
  [[1;0]; [1;0;1]; [1;0;0;0;0]; [1;0;4]; [1;0;3;1]; [1;0;3;0;1]; [1;0;3;0;0;0;0]] /\
  map (fun j => fst (step (Sseq j))) [0; 1; 2; 3; 4; 5; 6] = [true; false; true; false; false; false; false].
Proof. vm_compute. split; reflexivity. Qed.

Example enc_check : enc [1;0;4] = cells [pX;pX;pX;pX;pU;pU;pX].
Proof. reflexivity. Qed.
