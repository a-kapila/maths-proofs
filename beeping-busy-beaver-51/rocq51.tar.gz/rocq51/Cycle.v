(* Cycle.v -- one dispatch cycle of the machine deltaP h, from D_J(S) to D_J'(S'), for every
   S = [1;0] ++ X and every tail J to the right of the encoding (whose first cell is 0).

     DconfJ S J = (state 22, all-0 to the left, head on a 0 cell, enc S, then the stream J).

   A non-beeping cycle never looks at J.  A beeping cycle reads the first two cells of J
   (26 reads the first, which must be 0; 50 reads and erases the second): the tail
   s0 >> y >> J2 becomes s0 >> J2. *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51 Proc Base Phases Loops Comb.
Import ListNotations.

Definition DconfJ (S : list nat) (J : Stream Sym) : Conf51 := (Q22, blank, s0, enc S *> J).

(* the tail after a cycle: unchanged, or (after a beep) its second cell is consumed *)
Definition newtail (b : bool) (J : Stream Sym) : Stream Sym := if b then s0 >> stl (stl J) else J.

Section G.
Variable h : bool.

(* reachability in at least one step *)
Definition Ev1 (b : nat) (X : Conf51) (P : Conf51 -> Prop) : Prop :=
  exists C n, Steps (deltaP h) isbeep (S n) b X C /\ P C.

Lemma ev1_RR b P q x lr r J w q' : deltaP h q x = Some (w, Rgt, q') -> isbeep q = false ->
  Ev h b (KR q' (w :: lr) r J) P -> Ev1 b (KR q lr (x :: r) J) P.
Proof.
  intros Hd Hb [C [[n Hn] HP]]. exists C, n. split; [|exact HP].
  replace b with (bp isbeep (KR q lr (x :: r) J) + b) by (unfold KR, cR; simpl; rewrite Hb; reflexivity).
  econstructor; [|exact Hn]. unfold KR, cR. simpl. rewrite Hd. reflexivity.
Qed.

(* a blank cell may be added at the far left end of the list *)
Lemma KR_padL b P q lr r J : Ev h b (KR q (lr ++ [s0]) r J) P -> Ev h b (KR q lr r J) P.
Proof. intros H. unfold KR in *. rewrite lpre_app in H. simpl in H. rewrite <- Z_unfold in H. exact H. Qed.

(* the start of a cycle, right after its first step (22 reads the 0 under the head) *)
Lemma entry b P z r J : Ev h b (KR Q26 (s1 :: s1 :: s0 :: s0 :: ones (2 * z)) r J) P ->
  Ev h b (KR Q22 [s0] (cells (repeat pU z) ++ s1 :: s0 :: r) J) P.
Proof.
  intros H. destruct z as [|z].
  - simpl. apply KR_padL. simpl. do 2 st. exact H.
  - simpl repeat. simpl cells. simpl app.
    do 4 st. apply eBlankL. do 3 st.
    apply (uloop h b P z 1). apply head_first. exact H.
Qed.

(* the whole cycle when S0 <> [1] *)
Lemma machine_nonbeep b P z c G t H J : 1 <= c -> Forall (fun g => c <= g) G -> t < c -> Forall XU (pw H) ->
  Ev h b (KR Q22 [s0] (s0 :: cells (iter (cpy (length (repeat pX (c - 1) ++ [pU] ++ blocksG G))) (S (2 * z))
        ([pU] ++ (repeat pX (c - 1) ++ [pU] ++ blocksG G) ++ repeat pX t ++ pU :: pw H))) J) P ->
  Ev h b (KR Q22 [s0] (cells (repeat pU z ++ repeat pX c ++ pU :: blocksG G ++ repeat pX t ++ pU :: pw H)) J) P.
Proof.
  intros Hc HG Ht HH Hfin.
  destruct c as [|c']; [lia|].
  rewrite cells_app. change (repeat pX (S c')) with (pX :: repeat pX c'). simpl app at 2. simpl cells at 2.
  apply entry. apply head_rest.
  apply (ekR _ _ _ _ _ (rc ([pG] ++ [] ++ [pU] ++ repeat pO (S c' - 1) ++ repeat pX 0 ++ [pU]) ++ ones (2 * z))
           _ (cells (blocksG G ++ repeat pX t ++ pU :: pw H))); [simpl; rewrite ?Nat.sub_0_r; rcn; reflexivity | reflexivity |].
  apply (rounds h b P (S c') (repeat pX t ++ pU :: pw H) (ones (2 * z)) J); [lia | exact HG | | constructor].
  intros P'' m'' HP'' Heq.
  apply round_fail; [exact Ht|].
  apply setup; [exact HP''|].
  simpl cells. apply ext9.
  set (A := P'' ++ [pU] ++ repeat pX (S c' - 1 - t + (t + m''))).
  set (Y := repeat pX t ++ pU :: pw H).
  assert (EA : A ++ [pU] = [pU] ++ repeat pX c' ++ [pU] ++ blocksG G).
  { unfold A. rewrite <- !app_assoc. replace (S c' - 1 - t + (t + m'')) with (S c' - 1 + m'') by lia.
    rewrite Heq. simpl. rewrite Nat.sub_0_r, Nat.add_0_r. reflexivity. }
  assert (HAlen : length A = length (repeat pX (S c' - 1) ++ [pU] ++ blocksG G)).
  { apply (f_equal (@length Pr)) in EA. rewrite !length_app in EA. simpl in EA.
    simpl. rewrite Nat.sub_0_r, !length_app. simpl. lia. }
  assert (EW : A ++ pU :: Y = [pU] ++ (repeat pX (S c' - 1) ++ [pU] ++ blocksG G) ++ Y).
  { replace (A ++ pU :: Y) with ((A ++ [pU]) ++ Y) by (rewrite <- app_assoc; reflexivity).
    rewrite EA. simpl. rewrite Nat.sub_0_r, <- !app_assoc. reflexivity. }
  assert (HXU : Forall XU (A ++ pU :: Y)).
  { unfold A, Y. apply Fa_app; [apply Fa_app; [exact HP'' | constructor; [right; reflexivity | apply Fa_XU_repeat_pX]] |].
    constructor; [right; reflexivity|]. apply Fa_app; [apply Fa_XU_repeat_pX|].
    constructor; [right; reflexivity | exact HH]. }
  apply (ekR _ _ _ _ _ (s0 :: ones (S (2 * z))) _ (s0 :: cells (mkw (length A) (A ++ pU :: Y)))); [reflexivity | |].
  { rewrite mkw_split. unfold A. simpl. rewrite ?Nat.sub_0_r, <- !app_assoc. reflexivity. }
  apply (copy_loop h b P (length A)).
  { unfold A. rewrite !length_app. simpl. lia. }
  { rewrite length_app. simpl. lia. }
  { exact HXU. }
  apply end_final.
  { rewrite iter_cpy_len, length_app. simpl. lia. }
  { apply iter_cpy_XU. exact HXU. }
  rewrite EW, HAlen. exact Hfin.
Qed.

(* the whole cycle when S0 = [1]: the beep.  State 50 reads y, the second cell of the tail. *)
Lemma machine_beep b P z y J2 : deltaP h Q50 y = Some (s0, Lft, Q48) ->
  Ev h b (KL Q22 [] (s1 :: cells (repeat pO z) ++ [s1; s1; s1; s1; s0; s0]) J2) P ->
  Ev h (S b) (KR Q22 [s0] (cells (repeat pU z ++ [pX])) (s0 >> y >> J2)) P.
Proof.
  intros Hy H. rewrite cells_app. simpl (cells [pX]).
  apply entry.
  change (KR Q26 (s1 :: s1 :: s0 :: s0 :: ones (2 * z)) [] (s0 >> y >> J2))
    with (KR Q26 (s1 :: s1 :: s0 :: s0 :: ones (2 * z)) [s0; y] J2).
  apply beep_case; [exact Hy|]. exact H.
Qed.

End G.

(* ------------------------------------------------------------------------- *)
(* the shape of every sequence [1;0] ++ X                                      *)

Lemma lz_decomp (l : list nat) :
  (exists k, l = repeat 0 k) \/ (exists z c T, l = repeat 0 z ++ c :: T /\ c <> 0).
Proof.
  induction l as [|a l IH].
  - left. exists 0. reflexivity.
  - destruct a as [|a].
    + destruct IH as [(k & ->) | (z & c & T & -> & Hc)].
      * left. exists (S k). reflexivity.
      * right. exists (S z), c, T. split; [reflexivity | exact Hc].
    + right. exists 0, (S a), l. split; [reflexivity | lia].
Qed.

Lemma first_lt c (l : list nat) : (exists x, In x l /\ x < c) ->
  exists G t H, l = G ++ t :: H /\ Forall (fun g => c <= g) G /\ t < c.
Proof.
  induction l as [|a l IH]; intros (x & Hx & Hxc); [destruct Hx|].
  destruct (Nat.lt_ge_cases a c) as [Ha|Ha].
  - exists [], a, l. split; [reflexivity | split; [constructor | exact Ha]].
  - destruct Hx as [-> | Hx]; [lia|].
    destruct IH as (G & t & H & -> & HG & Ht); [exists x; auto|].
    exists (a :: G), t, H. split; [reflexivity | split; [constructor; [exact Ha | exact HG] | exact Ht]].
Qed.

Lemma decompose (Xw : list nat) :
  (exists z, rev ([1; 0] ++ Xw) = repeat 0 z ++ [1]) \/
  (exists z c G t H, rev ([1; 0] ++ Xw) = repeat 0 z ++ c :: G ++ t :: H /\ 1 <= c /\
     Forall (fun g => c <= g) G /\ t < c /\ H <> [] /\ last H 0 = 1).
Proof.
  rewrite rev_app_distr. simpl rev at 2.
  destruct (lz_decomp (rev Xw)) as [(k & Hk) | (z & c & T & HT & Hc)].
  - left. exists (S k). rewrite Hk. rewrite repeat_snoc', <- app_assoc. reflexivity.
  - right. destruct (first_lt c (T ++ [0])) as (G & t & H0 & E & HG & Ht).
    { exists 0. split; [apply in_or_app; right; left; reflexivity | lia]. }
    exists z, c, G, t, (H0 ++ [1]). split; [|split; [lia | split; [exact HG | split; [exact Ht | split]]]].
    + rewrite HT, <- app_assoc. simpl. f_equal. f_equal.
      replace (T ++ [0; 1]) with ((T ++ [0]) ++ [1]) by (rewrite <- app_assoc; reflexivity).
      rewrite E, <- app_assoc. reflexivity.
    + destruct H0; simpl; congruence.
    + apply last_last.
Qed.

Lemma pw_XU T : Forall XU (pw T).
Proof.
  induction T as [|a T IH]; [constructor|]. simpl. apply Fa_app; [apply Fa_XU_repeat_pX|].
  destruct T; [constructor|]. constructor; [right; reflexivity | exact IH].
Qed.

Lemma step_beep z : step (rev (repeat 0 z ++ [1])) = (true, [1; 0; z]).
Proof.
  unfold step.
  assert (Htz : tz (rev (repeat 0 z ++ [1])) = z) by (unfold tz; rewrite rev_involutive; apply lz_rep; lia).
  assert (Hs : rev (repeat 0 z ++ [1]) = [1] ++ repeat 0 z) by (rewrite rev_app_distr, rev_repeat; reflexivity).
  rewrite Htz, Hs, length_app, length_repeat', Nat.add_sub, firstn_len_app.
  destruct (list_eq_dec Nat.eq_dec [1] [1]) as [_|Hn]; [reflexivity | contradiction].
Qed.

Lemma beep_tape z : s1 :: cells (repeat pO z) ++ [s1; s1; s1; s1; s0; s0] = enc [1; 0; z] ++ [s0].
Proof.
  unfold enc. simpl. rewrite app_comm_cons, s1_cells_pO, cells_app, <- !app_assoc. reflexivity.
Qed.

(* ------------------------------------------------------------------------- *)
(* one dispatch cycle, for either machine and any tail                         *)

Theorem dispatch_stepJ (h : bool) (X : list nat) (J : Stream Sym) : shd J = s0 ->
  (fst (step ([1; 0] ++ X)) = true -> deltaP h Q50 (shd (stl J)) = Some (s0, Lft, Q48)) ->
  exists n, Steps (deltaP h) isbeep (S n) (if fst (step ([1; 0] ++ X)) then 1 else 0)
                  (DconfJ ([1; 0] ++ X) J) (DconfJ (snd (step ([1; 0] ++ X))) (newtail (fst (step ([1; 0] ++ X))) J)).
Proof.
  intros HJ HJ2.
  assert (HS : [1; 0] ++ X = rev (rev ([1; 0] ++ X))) by (rewrite rev_involutive; reflexivity).
  destruct (decompose X) as [(z & Hz) | (z & c & G & t & H & Hrev & Hc & HG & Ht & HH & HH1)].
  - rewrite HS, Hz, step_beep in HJ2 |- *. simpl fst in HJ2 |- *. simpl snd. specialize (HJ2 eq_refl).
    destruct J as [x [y J2]]. simpl in HJ, HJ2. subst x.
    assert (E : Ev1 h 1 (DconfJ (rev (repeat 0 z ++ [1])) (s0 >> y >> J2))
                   (fun C => C = DconfJ [1; 0; z] (newtail true (s0 >> y >> J2)))).
    { change (DconfJ (rev (repeat 0 z ++ [1])) (s0 >> y >> J2))
        with (KR Q22 [] (s0 :: enc (rev (repeat 0 z ++ [1]))) (s0 >> y >> J2)).
      eapply ev1_RR; [reflexivity | reflexivity |].
      unfold enc. rewrite rev_involutive, pw_zeros by congruence. simpl (pw [1]).
      apply machine_beep; [exact HJ2|]. apply ev_done.
      unfold DconfJ, KL, cL. f_equal. rewrite beep_tape, lpre_app. reflexivity. }
    destruct E as (C & n & Hn & ->). exists n. exact Hn.
  - destruct (step_nonbeep z c G t H Hc HG Ht HH) as (S' & Hstep & _ & Hpw).
    rewrite HS, Hrev, Hstep. simpl fst. simpl snd. simpl newtail.
    assert (E : Ev1 h 0 (DconfJ (rev (repeat 0 z ++ c :: G ++ t :: H)) J) (fun C => C = DconfJ S' J)).
    { change (DconfJ (rev (repeat 0 z ++ c :: G ++ t :: H)) J)
        with (KR Q22 [] (s0 :: enc (rev (repeat 0 z ++ c :: G ++ t :: H))) J).
      eapply ev1_RR; [reflexivity | reflexivity |].
      unfold enc. rewrite rev_involutive, pw_zeros by congruence.
      rewrite pw_cons_ne by (destruct G; simpl; congruence).
      rewrite pw_app_blocks by congruence. rewrite pw_cons_ne by exact HH.
      rewrite <- ?app_assoc.
      apply machine_nonbeep; [exact Hc | exact HG | exact Ht | apply pw_XU |].
      apply ev_done. unfold DconfJ, enc, KR, cR. simpl.
      rewrite Hpw, <- Z_unfold. reflexivity. }
    destruct E as (C & n & Hn & ->). exists n. exact Hn.
Qed.

(* every S_j has the form [1;0] ++ X *)
Lemma step_prefix (X : list nat) : exists X', snd (step ([1; 0] ++ X)) = [1; 0] ++ X'.
Proof.
  assert (HS : [1; 0] ++ X = rev (rev ([1; 0] ++ X))) by (rewrite rev_involutive; reflexivity).
  destruct (decompose X) as [(z & Hz) | (z & c & G & t & H & Hrev & Hc & HG & Ht & HH & HH1)].
  - rewrite HS, Hz, step_beep. exists [z]. reflexivity.
  - destruct (step_nonbeep z c G t H Hc HG Ht HH) as (S' & Hstep & Hpre & _).
    rewrite HS, Hrev, Hstep. simpl snd.
    exists (skipn 2 S'). rewrite <- (firstn_skipn 2 S') at 1. f_equal.
    (* the first |H|+1 letters of S and S' agree, and |H| >= 1 *)
    assert (E1 : firstn (S (length H)) ([1; 0] ++ X) = rev H ++ [t]).
    { assert (ES : [1;0] ++ X = (rev H ++ [t]) ++ (rev G ++ [c] ++ repeat 0 z)).
      { rewrite HS, Hrev. rewrite !rev_app_distr, rev_repeat. simpl. rewrite !rev_app_distr. simpl.
        rewrite <- ?app_assoc. reflexivity. }
      rewrite ES. replace (S (length H)) with (length (rev H ++ [t]))
        by (rewrite length_app, length_rev; simpl; lia).
      apply firstn_len_app. }
    assert (HL : 2 <= S (length H)) by (destruct H; [congruence | simpl; lia]).
    replace (firstn 2 S') with (firstn 2 (firstn (S (length H)) S'))
      by (rewrite firstn_firstn; f_equal; lia).
    rewrite Hpre, <- E1, firstn_firstn. replace (Nat.min 2 (S (length H))) with 2 by lia. reflexivity.
Qed.

Lemma Sseq_prefix j : exists X, Sseq j = [1; 0] ++ X.
Proof.
  induction j as [|j [X HX]]; [exists []; reflexivity|].
  simpl. rewrite HX. apply step_prefix.
Qed.
