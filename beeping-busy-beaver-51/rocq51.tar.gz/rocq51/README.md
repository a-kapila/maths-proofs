# Rocq proof: the 51-state beeper M51 carries out the process R

## Status

**Complete. Everything is machine-checked. Nothing is admitted.** (26 Oct 2026)

* Items 1 to 4 of the task are done (main lemma, start lemma, main theorem), and both secondary goals:
  the start-30 run has the same beeps (`M51_run30`), and in the start-31 run state 50 always reads 0, so
  Racheline's unmodified table started in 31 never halts (`M51_state50_reads_0`, `orig_never_halts`).
* `grep -rn "Admitted\|admit\|Axiom" *.v` finds nothing (also no `Abort`, `Parameter`).
* `Print Assumptions` (file Assumptions.v, run by the build) prints `Closed under the global context`
  for all 10 main results.
* Independent kernel check: `rocqchk -o -Q . M51 M51.Main M51.ProcCheck` reports `Axioms: <none>`, no
  type-in-type, no unsafe (co)fixpoints, no assumed positivity.
* Clean build: about 10 s.

## Build

```
cd /home/claude/proofs51/rocq
source /home/claude/proofs/rocq/env.sh      # Rocq 9.1.1 (opam root /home/claude/proofs/tools/opamroot, switch rocq)
make                                        # = rocq makefile -f _CoqProject; make -f Makefile.rocq
rocqchk -o -Q . M51 M51.Main M51.ProcCheck  # optional independent re-check
```

Generated files (regenerating gives byte-identical files):
* `Machine51.v` <- `python3 -I gen/gen_machine.py /home/claude/proofs51/beeper51.txt .`
* `ProcCheck.v` <- `python3 -I gen/gen_proccheck.py /home/claude/proofs51 . 400 51`

## Main results (Main.v), verbatim

```coq
(* Main lemma *)
Theorem dispatch_step (X : list nat) :
  exists n, Steps delta isbeep (S n) (if fst (step ([1; 0] ++ X)) then 1 else 0)
                  (Dconf ([1; 0] ++ X)) (Dconf (snd (step ([1; 0] ++ X)))).

(* Start lemma *)
Theorem start31 : exists n, Steps delta isbeep n 1 C31 (Dconf [1; 0]).

(* Main theorem *)
Theorem M51_run (j : nat) :
  exists t, Steps delta isbeep t (1 + nbeep_before j) C31 (Dconf (Sseq j)).

(* Main theorem with the visiting times t_0 < t_1 < ... < t_j *)
Theorem M51_run_times (j : nat) :
  exists ts : list nat, length ts = S j /\
    (forall i, i < j -> nth i ts 0 < nth (S i) ts 0) /\
    (forall i, i <= j -> Steps delta isbeep (nth i ts 0) (1 + nbeep_before i) C31 (Dconf (Sseq i))).

(* Main theorem phrased with the run function *)
Corollary M51_run_fun (j : nat) :
  exists t, run delta t C31 = Some (Dconf (Sseq j)) /\ nbeeps_run delta t C31 = 1 + nbeep_before j.

(* M51 enters state 50 infinitely often iff R beeps infinitely often *)
Corollary M51_beeps_forever_iff :
  (forall N, exists t, N <= nbeeps_run delta t C31) <-> (forall N, exists j, N <= nbeep_before j).
```

`nbeeps_run d t C` (Main.v) counts the first t steps of the run from C that are taken from state 50
(the run starts in state 31, so this is the number of entries into state 50 at times 1..t-1).

Secondary goals:

```coq
Theorem orig_never_halts (n : nat) : exists C, run delta_orig n C31 = Some C.
Theorem M51_state50_reads_0 (n : nat) (C : Conf51) : run delta n C31 = Some C ->
  match C with (q, _, x, _) => q = Q50 -> x = s0 end.
Theorem M51_run30 (j : nat) :
  exists t, Steps delta isbeep t (1 + nbeep_before j) C30 (DconfJ (Sseq j) (tail30 (nbeep_before j))).
Corollary M51_run30_blank (j : nat) : 11 <= nbeep_before j ->
  exists t, Steps delta isbeep t (1 + nbeep_before j) C30 (Dconf (Sseq j)).
```

`Print Assumptions` for each of the 10: `Closed under the global context`.

## What the statements mean (the definitions they rest on)

* **TM semantics (TM.v, copied unchanged from /home/claude/proofs/rocq/TM.v).** A configuration is
  `(state, left, head symbol, right)`, `left`/`right` infinite streams listed outward from the head, so a
  configuration is given relative to the head ("up to translation"). `step` writes, then moves (Lft:
  `(q', stl L, shd L, w >> R)`, Rgt: `(q', w >> L, shd R, stl R)`), `None` if the transition is undefined.
  `Steps n b C C'`: C reaches C' in exactly n defined steps, and exactly b of these steps are taken from a
  beep state. `run n C` is the n-step run function. Since C and C' are in state 22 or 31, b is the number
  of entries into state 50 between them.
* **The machine (Machine51.v, generated).** `Sym = s0 | s1`, `St = Q0 | ... | Q50`, `delta` = the 102
  transitions of beeper51.txt (row i is `Qi`; entry `1L31` is `Some (s1, Lft, Q31)`), `isbeep q` is true
  only for `Q50`. Cross-checked: parsing Machine51.v back gives exactly beeper51.txt, and it differs from
  racheline51.py only at (50,1) (halt there).
* **The process R (Proc.v),** transcribed line by line from ref51.py:
  * `tz S = lz (rev S)` (trailing zeros), `S0 = firstn (length S - z) S`;
  * `step S = if S0 = [1] then (true, [1;0;z]) else (false, cand S0 (1 + 2*z))`;
  * `cand S0 n`: `c = last S0 0`, `r = maxlt c S0` (= max{i : S0[i] < c}), `Sp = removelast S0 ++ [c-1]`,
    `B = skipn (S r) Sp`, `E = Efun Sp B` (`E i = Sp[i]` if `i < |Sp|`, else `B[(i-|Sp|) mod |B|]`), and
    `candloop E (S n) (S |S0|) n` runs the candidate enumeration of ref51.py (for L = |S0|+1, ...: for
    v = 0..E(L-1): candidate E[:L-1]+[v]) and returns candidate number n. Comb.v proves that the fuel
    n+1 is never exhausted and does not matter (`candloop_returns`, `candloop_fuel`).
  * `Sseq 0 = [1;0]`, `Sseq (S j) = snd (step (Sseq j))`;
    `nbeep_before j` = number of i < j with `fst (step (Sseq i)) = true`.
  * ProcCheck.v checks `step`, `enc` and `Sseq` against ref51.py by `vm_compute` on 500 random sequences
    [1,0]+X (letters up to 12, up to 15 trailing zeros) and on S_0..S_11.
* **The encoding (Proc.v).** `enc S = cells (pw (rev S))`: `pw` is `'U'.join('X'*a for a in S[::-1])`,
  `cells` maps X to `s1;s0` and U to `s1;s1`.
  `Dconf S = (Q22, blank, s0, enc S *> blank)`: state 22, head on a 0 cell, all 0 to the left, the pair
  encoding of S to the right, all 0 beyond. `C31 = (Q31, blank, s0, blank)`.
* **Secondary-goal definitions.** `deltaP h` (Base.v): `deltaP false = delta` pointwise, `deltaP true` is
  delta with `(Q50, s1)` undefined, i.e. Racheline's unmodified table (`delta_orig := deltaP true`).
  `C30 = (Q30, blank, s0, blank)`. `DconfJ S J = (Q22, blank, s0, enc S *> J)` (any tail J).
  `tail30 k = if k <=? 10 then repeat s0 (11 - k) *> (s1 >> Z) else Z`: after the start-up the marker sits
  11 cells right of the encoding; each beep of a cycle moves the encoding's right end one cell to the
  right; the 11th such beep reads the marker with state 50 (which writes 0 whatever it reads) and from
  then on the start-30 run is in exactly the configurations of the start-31 run (`M51_run30_blank`).

## How it is proven

The whole development is generic in the flag h (both machines at once): for every pair other than
(Q50, s1), `deltaP h q x` computes to `delta q x`, and no lemma uses (Q50, s1) except the beep of
`beep_case`, which takes `deltaP h Q50 y = Some (s0, Lft, Q48)` as a hypothesis (true for y = s0 always,
and for every y when h = false). Results for `delta` follow by `Steps_sub` (`deltaP h` is contained in
`delta`).

Configurations are handled as lists around the head (`KR`/`KL`, Base.v); every step and scan lemma is in
continuation form `Ev h b X' P -> Ev h b X P`. One lemma per phase (Phases.v), loops by induction
(Loops.v), the combinatorics separately (Comb.v), the cycle (Cycle.v), the run (Main.v).

### Decoded phases (one dispatch = one R step)

Pair symbols: X = 10, U = 11, O = 01 (marked), gap = 00. At a dispatch the tape is
`0^inf [22 on 0] enc(S) 0^inf`, enc(S) = X^{s_m} U X^{s_{m-1}} U ... U X^{s_0}; z = number of leading U's
(= trailing zeros of S). Write the step as: new tape = [last 2z+2 pairs of beta^inf] beta rest, where
beta = X^{c-1} U X^{s_{m'-1}} U ... X^{s_{r+1}} U is the "bad part" with the head letter lowered.

1. U-loop (22,23,24,25; `uloop`): each leading U is erased and two 1s are written to its left; after z
   rounds the tape is `1^{2z} 00(gap) rest`, head on the gap. The block 1^{2z} is a unary counter.
2. Head letter (22,23,26,27,35,36; `head_first`, `head_rest`): its first X becomes 11 (it plays the role of a
   U: the "end marker"), its other c-1 X's become O (comparison markers).
   If the cell after the first X is 0 (S0 = [1]): 26 -> 50 (BEEP) -> 48,47,41, then 49/48 rewrite
   `1^{2z} 00 11` into `X^z U U` and enter 22 (`beep_case`).
3. Comparison rounds (28-42; `match_one`, `match_many`, `match_end`, `match_fail`, `round_pass`,
   `round_fail`, `rounds`): the "zone" is the previous letter, its first c-1 X's are markers O, preceded by
   an end marker (a U). For each X of the current letter: mark it O (28,30), walk left (31/32 over O's and
   the separator U, 33/34 over X's) to the rightmost unconsumed marker; an O is consumed (O -> X; 35, then
   36/37 back right to 28); reaching the end marker (35 -> 38) means current letter >= c: restore it,
   walk right (38/39, 40/41), un-mark the c-th matched X (42), skip the rest (36/37) and start the next
   round, the current letter becoming the zone. If 28 meets the U after the current letter, the letter is
   < c: it is s_r.
4. Set-up (0-8; `setup`): restore the current letter (0/1), mark the separator U before it as the copy
   source (2: 11 -> 01), restore the zone (4/3/5) and end marker (6), walk left to the gap (7/8). The first
   copy is free: the head letter's first X, now 11, already is the copy of that U.
5. Copy loop (9,11-21,6,10; `ext9`, `copy_fwd`, `copy_back`, `copy_step`, `copy_last`, `copy_loop`):
   9 extends the counter by one 1 on the left, 11 walks back to the gap, 12/13 walk right to the source
   mark and restore it, 14 reads the pair left of it (the next source), marks it (6: X -> 00, 10: U -> 01),
   walks left to the gap (15/16, 17/18) and writes the pair there (16; 18/19), then 20/21 erase the two
   counter cells left of the gap (they are the new gap). With the counter 2z+1 this makes 2z+1 copies,
   plus the free one: 2z+2 pairs copied with offset |beta|, which is the periodic extension.
6. End (43-46; `end_phase`): find the source mark (44), restore it, walk back left (45/46) -> 22.

Comb.v (`step_nonbeep`) shows that the result of 2z+1 copies is exactly the encoding of
`cand S0 (2z+1)`: the copy loop produces the first 2z+2 pairs of (rev beta)^inf (`copy_rev`), and the
candidate loop of ref51.py appends letters whose blocks `U X^a` are a prefix of the same stream
(`candloop_letters`, `app_letters_spec`).

Before formalizing, the phase invariants were checked in Python (`/home/claude/proofs51/work/model.py`):
the model matches the real machine at every phase boundary on 6000 random S and on all 3906 worms with
|X| <= 5 and letters <= 4.

| file | content |
|---|---|
| TM.v | generic TM library (copied unchanged) |
| Machine51.v | generated machine `delta`, `isbeep` |
| Proc.v | process R (`step`, `cand`, ...), encoding (`enc`), `Dconf`, `C31`, `Sseq`, `nbeep_before` |
| Base.v | `deltaP`, `KR`/`KL`, `Ev`, step lemmas `eRR eRL eLR eLL eBEEP eBEEP_L`, scans `scanR scanL skipR skipL scan1R scan1L`, tactics |
| Phases.v | one lemma per phase (list above) |
| Loops.v | `blocksG`, `cpy`, `mkw`, `iter`; `round_pass`, `round_fail`, `rounds`, `copy_loop`, `end_final` |
| Comb.v | `candloop_fuel`, `candloop_returns`, `candloop_letters`, `app_letters_spec`, `copy_rev`, `step_nonbeep` |
| Cycle.v | `DconfJ`, `newtail`, `entry`, `machine_nonbeep`, `machine_beep`, `decompose`, `step_beep`, `dispatch_stepJ`, `Sseq_prefix` |
| Main.v | transfer lemmas, all results above |
| ProcCheck.v | generated: Proc.v vs ref51.py by vm_compute |
| Assumptions.v | Print Assumptions |

## Scope notes

* For the start-30 run the theorem is at dispatch level: it passes through D(S_j) (with the marker in the
  tail, `tail30`) after exactly the same number 1 + nbeep_before j of entries into state 50 as the start-31
  run. That the visiting times differ by exactly 1 step (as the simulation shows) is not proven.
* `step` is defined for every list; the theorems use it only on [1;0] ++ X, where every Python operation
  of ref51.py is defined (r exists, B is nonempty). On other lists ref51.py may raise an error while the
  Rocq function returns some value.

## Not part of the proof

* `/home/claude/proofs51/work/`: Python tracing tools and the phase model used to design the invariants.
* `/home/claude/proofs51/snapshot_main_v1/`: snapshot of the development right after the main theorem was
  first completed (before the generic-h refactor); it builds on its own.
* Nothing under /home/claude/proofs/ was modified.
