(* Main.v -- the main results.

   M51 = the machine of beeper51.txt ([delta], Machine51.v).  A configuration is given
   relative to the head (state, left stream, head symbol, right stream), so "up to
   translation" is built in.  [Steps delta isbeep n b C C'] says that C reaches C' in exactly
   n steps and that exactly b of these n steps are taken from state 50; since C and C' are in
   state 22 (or 31), b is the number of entries into state 50 between C and C'.

   For M51 (all closed, no axioms):
     dispatch_step : from D(S), S = [1;0] ++ X, the machine reaches D(S'), (b,S') = step S,
                     in at least one step, entering state 50 exactly once if b, never if not;
     start31       : from the blank tape in state 31 it reaches D([1;0]), entering 50 once;
     M51_run, M51_run_times : the run from blank (state 31) passes through D(S_j) for every j,
                     after 1 + #{i < j | fst (step S_i) = true} entries into state 50, at
                     strictly increasing times;
     M51_run_fun   : the same with the run function (configuration after t steps) and an
                     explicit count of the steps taken from state 50;
     M51_beeps_forever_iff : M51 enters state 50 infinitely often iff R beeps infinitely often.
   Bonus:
     orig_* : the same for Racheline's unmodified table (state 50 reading 1 halts);
     orig_never_halts, M51_state50_reads_0 : started in 31 the unmodified table never halts,
                     and in the start-31 run of M51 state 50 always reads 0;
     M51_run30 : the start-30 run of M51 (with the end marker) passes through D(S_j) (followed
                     by the marker, until state 50 erases it) with the same beep counts. *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51 Proc Base Phases Loops Comb Cycle.
Import ListNotations.

(* ------------------------------------------------------------------------- *)
(* transfer between machines                                                  *)

Lemma step_sub (d1 d2 : St -> Sym -> option (Sym * Dir * St)) (C C' : Conf51) :
  (forall q s v, d1 q s = Some v -> d2 q s = Some v) -> TM.step d1 C = Some C' -> TM.step d2 C = Some C'.
Proof.
  intros Hd. destruct C as [[[q L] x] R]. simpl.
  destruct (d1 q x) as [v|] eqn:E; [|discriminate]. rewrite (Hd _ _ _ E). auto.
Qed.

Lemma Steps_sub d1 d2 n b (C C' : Conf51) : (forall q s v, d1 q s = Some v -> d2 q s = Some v) ->
  Steps d1 isbeep n b C C' -> Steps d2 isbeep n b C C'.
Proof. intros Hd H. induction H; econstructor; eauto using step_sub. Qed.

Lemma run_sub d1 d2 n (C C' : Conf51) : (forall q s v, d1 q s = Some v -> d2 q s = Some v) ->
  run d1 n C = Some C' -> run d2 n C = Some C'.
Proof.
  intros Hd. revert C. induction n as [|n IH]; intros C H; simpl in *; [exact H|].
  destruct (TM.step d1 C) as [C1|] eqn:E; [|discriminate]. rewrite (step_sub d1 d2 C C1 Hd E). auto.
Qed.

Lemma run_prefix d m k (C C' : Conf51) : run d (m + k) C = Some C' -> exists C'', run d m C = Some C''.
Proof.
  revert C. induction m as [|m IH]; intros C H; simpl in *; [eauto|].
  destruct (TM.step d C) as [C1|]; [eapply IH; eauto | discriminate].
Qed.

Lemma run_S_end d n (C : Conf51) :
  run d (S n) C = match run d n C with Some C' => TM.step d C' | None => None end.
Proof.
  revert C. induction n as [|n IH]; intros C.
  - simpl. destruct (TM.step d C); reflexivity.
  - change (run d (S (S n)) C) with (match TM.step d C with None => None | Some C' => run d (S n) C' end).
    change (run d (S n) C) with (match TM.step d C with None => None | Some C' => run d n C' end).
    destruct (TM.step d C) as [C1|]; [apply IH | reflexivity].
Qed.

(* ------------------------------------------------------------------------- *)
(* both machines                                                              *)

Lemma newtail_Z b : newtail b Z = Z.
Proof. destruct b; simpl; [symmetry; apply Z_unfold | reflexivity]. Qed.

Lemma start31_gen h : exists n, Steps (deltaP h) isbeep n 1 C31 (Dconf [1; 0]).
Proof.
  assert (E : Ev h 1 (KR Q31 [] [s0] Z) (fun C => C = Dconf [1; 0])).
  { st. do 9 (apply eBlankL; st). apply eBlankL. apply eBEEP_L.
    do 4 (apply eBlankL; st). apply ev_done.
    unfold Dconf, KL, cL, enc. change blank with Z. simpl. f_equal. rewrite <- !Z_unfold. reflexivity. }
  destruct E as (C & [n Hn] & ->). exists n. exact Hn.
Qed.

Lemma dispatch_step_gen h (X : list nat) :
  exists n, Steps (deltaP h) isbeep (S n) (if fst (step ([1; 0] ++ X)) then 1 else 0)
                  (Dconf ([1; 0] ++ X)) (Dconf (snd (step ([1; 0] ++ X)))).
Proof.
  destruct (dispatch_stepJ h X Z) as [n Hn]; [reflexivity | intros _; reflexivity |].
  rewrite newtail_Z in Hn. exists n. exact Hn.
Qed.

Lemma run_gen h (j : nat) :
  exists t, Steps (deltaP h) isbeep t (1 + nbeep_before j) C31 (Dconf (Sseq j)).
Proof.
  induction j as [|j [t Ht]].
  - apply start31_gen.
  - destruct (Sseq_prefix j) as [X HX].
    destruct (dispatch_step_gen h X) as [n Hn]. rewrite <- HX in Hn.
    exists (t + S n). simpl nbeep_before. rewrite Nat.add_assoc.
    eapply Steps_trans; [exact Ht | exact Hn].
Qed.

Lemma run_times_gen h (j : nat) :
  exists ts : list nat, length ts = S j /\
    (forall i, i < j -> nth i ts 0 < nth (S i) ts 0) /\
    (forall i, i <= j -> Steps (deltaP h) isbeep (nth i ts 0) (1 + nbeep_before i) C31 (Dconf (Sseq i))).
Proof.
  induction j as [|j (ts & Hlen & Hinc & Hst)].
  - destruct (start31_gen h) as [n Hn]. exists [n].
    split; [reflexivity | split; [intros; lia | intros i Hi; replace i with 0 by lia; exact Hn]].
  - destruct (Sseq_prefix j) as [X HX].
    destruct (dispatch_step_gen h X) as [n Hn]. rewrite <- HX in Hn.
    set (tj := nth j ts 0).
    exists (ts ++ [tj + S n]). split; [rewrite length_app; simpl; lia|]. split.
    + intros i Hi. rewrite (app_nth1 ts) by lia.
      destruct (Nat.eq_dec i j) as [->|Hne].
      * rewrite app_nth2 by lia. replace (S j - length ts) with 0 by lia. simpl. fold tj. lia.
      * rewrite (app_nth1 ts) by lia. apply Hinc. lia.
    + intros i Hi. destruct (Nat.eq_dec i (S j)) as [->|Hne].
      * rewrite app_nth2 by lia. replace (S j - length ts) with 0 by lia. simpl nth.
        simpl nbeep_before. rewrite Nat.add_assoc.
        eapply Steps_trans; [apply (Hst j); lia | exact Hn].
      * rewrite app_nth1 by lia. apply Hst. lia.
Qed.

(* ------------------------------------------------------------------------- *)
(* M51 (beeper51.txt)                                                          *)

(* Main lemma *)
Theorem dispatch_step (X : list nat) :
  exists n, Steps delta isbeep (S n) (if fst (step ([1; 0] ++ X)) then 1 else 0)
                  (Dconf ([1; 0] ++ X)) (Dconf (snd (step ([1; 0] ++ X)))).
Proof.
  destruct (dispatch_step_gen false X) as [n Hn]. exists n.
  exact (Steps_sub _ _ _ _ _ _ (deltaP_sub false) Hn).
Qed.

(* Start lemma *)
Theorem start31 : exists n, Steps delta isbeep n 1 C31 (Dconf [1; 0]).
Proof.
  destruct (start31_gen false) as [n Hn]. exists n.
  exact (Steps_sub _ _ _ _ _ _ (deltaP_sub false) Hn).
Qed.

(* Main theorem *)
Theorem M51_run (j : nat) :
  exists t, Steps delta isbeep t (1 + nbeep_before j) C31 (Dconf (Sseq j)).
Proof.
  destruct (run_gen false j) as [t Ht]. exists t.
  exact (Steps_sub _ _ _ _ _ _ (deltaP_sub false) Ht).
Qed.

(* Main theorem, with the visiting times t_0 < t_1 < ... < t_j listed *)
Theorem M51_run_times (j : nat) :
  exists ts : list nat, length ts = S j /\
    (forall i, i < j -> nth i ts 0 < nth (S i) ts 0) /\
    (forall i, i <= j -> Steps delta isbeep (nth i ts 0) (1 + nbeep_before i) C31 (Dconf (Sseq i))).
Proof.
  destruct (run_times_gen false j) as (ts & H1 & H2 & H3). exists ts.
  split; [exact H1 | split; [exact H2|]].
  intros i Hi. exact (Steps_sub _ _ _ _ _ _ (deltaP_sub false) (H3 i Hi)).
Qed.

Lemma nth_incr_ge' (ts : list nat) j : (forall i, i < j -> nth i ts 0 < nth (S i) ts 0) ->
  forall i, i <= j -> i <= nth i ts 0.
Proof.
  intros H i. induction i as [|i IH]; intros Hi; [lia|].
  specialize (H i ltac:(lia)). specialize (IH ltac:(lia)). lia.
Qed.

(* The same, phrased with the run function: [run delta t C31] is the configuration after t
   steps, and [nbeeps_run delta t C31] is the number of the first t steps that are taken
   from state 50. *)
Fixpoint nbeeps_run (d : St -> Sym -> option (Sym * Dir * St)) (n : nat) (C : Conf51) : nat :=
  match n with
  | 0 => 0
  | S n' => match TM.step d C with None => 0 | Some C' => bp isbeep C + nbeeps_run d n' C' end
  end.

Lemma Steps_run_beeps d n b (C C' : Conf51) :
  Steps d isbeep n b C C' -> run d n C = Some C' /\ nbeeps_run d n C = b.
Proof.
  induction 1 as [C|C C1 C2 n b Hs Hn IH]; [split; reflexivity|].
  simpl. rewrite Hs. exact (conj (proj1 IH) (f_equal (Nat.add (bp isbeep C)) (proj2 IH))).
Qed.

Corollary M51_run_fun (j : nat) :
  exists t, run delta t C31 = Some (Dconf (Sseq j)) /\ nbeeps_run delta t C31 = 1 + nbeep_before j.
Proof.
  destruct (M51_run j) as [t Ht]. exists t. exact (Steps_run_beeps _ _ _ _ _ Ht).
Qed.

Lemma nbeeps_run_S d n (C : Conf51) : nbeeps_run d n C <= nbeeps_run d (S n) C.
Proof.
  revert C. induction n as [|n IH]; intros C; [simpl; lia|].
  change (nbeeps_run d (S (S n)) C) with
    (match TM.step d C with None => 0 | Some C' => bp isbeep C + nbeeps_run d (S n) C' end).
  change (nbeeps_run d (S n) C) with
    (match TM.step d C with None => 0 | Some C' => bp isbeep C + nbeeps_run d n C' end).
  destruct (TM.step d C) as [C'|]; [specialize (IH C'); lia | lia].
Qed.

Lemma nbeeps_run_mono d m k (C : Conf51) : nbeeps_run d m C <= nbeeps_run d (m + k) C.
Proof.
  induction k as [|k IH]; [rewrite Nat.add_0_r; lia|].
  rewrite Nat.add_succ_r. etransitivity; [exact IH | apply nbeeps_run_S].
Qed.

(* M51 started in 31 on the blank tape enters state 50 infinitely often if and only if the
   process R started at [1;0] beeps infinitely often. *)
Corollary M51_beeps_forever_iff :
  (forall N, exists t, N <= nbeeps_run delta t C31) <-> (forall N, exists j, N <= nbeep_before j).
Proof.
  split.
  - intros H N. destruct (H (S N)) as [t Ht].
    destruct (M51_run_times t) as (ts & Hlen & Hinc & Hst).
    pose proof (nth_incr_ge' ts t Hinc t (le_n t)) as Hge.
    pose proof (Steps_run_beeps _ _ _ _ _ (Hst t (le_n t))) as [_ Hb].
    pose proof (nbeeps_run_mono delta t (nth t ts 0 - t) C31) as Hm.
    replace (t + (nth t ts 0 - t)) with (nth t ts 0) in Hm by lia.
    exists t. lia.
  - intros H N. destruct (H N) as [j Hj]. destruct (M51_run_fun j) as (t & _ & Ht).
    exists t. lia.
Qed.

(* ------------------------------------------------------------------------- *)
(* Racheline's unmodified table: state 50 reading 1 halts                     *)

Definition delta_orig : St -> Sym -> option (Sym * Dir * St) := deltaP true.

Lemma delta_orig_spec q s : delta_orig q s = if (match q, s with Q50, s1 => true | _, _ => false end)
                                              then None else delta q s.
Proof. destruct q, s; reflexivity. Qed.

Theorem orig_dispatch_step (X : list nat) :
  exists n, Steps delta_orig isbeep (S n) (if fst (step ([1; 0] ++ X)) then 1 else 0)
                  (Dconf ([1; 0] ++ X)) (Dconf (snd (step ([1; 0] ++ X)))).
Proof. apply dispatch_step_gen. Qed.

Theorem orig_run_times (j : nat) :
  exists ts : list nat, length ts = S j /\
    (forall i, i < j -> nth i ts 0 < nth (S i) ts 0) /\
    (forall i, i <= j -> Steps delta_orig isbeep (nth i ts 0) (1 + nbeep_before i) C31 (Dconf (Sseq i))).
Proof. apply run_times_gen. Qed.

(* the unmodified table, started in state 31 on the blank tape, never halts *)
Theorem orig_never_halts (n : nat) : exists C, run delta_orig n C31 = Some C.
Proof.
  destruct (orig_run_times n) as (ts & Hlen & Hinc & Hst).
  pose proof (nth_incr_ge' ts n Hinc n (le_n n)) as Hge.
  pose proof (Steps_run _ _ _ _ _ _ (Hst n (le_n n))) as Hr.
  replace (nth n ts 0) with (n + (nth n ts 0 - n)) in Hr by lia.
  exact (run_prefix _ _ _ _ _ Hr).
Qed.

(* in the start-31 run of M51, state 50 always reads 0 *)
Theorem M51_state50_reads_0 (n : nat) (C : Conf51) : run delta n C31 = Some C ->
  match C with (q, _, x, _) => q = Q50 -> x = s0 end.
Proof.
  intros HC. destruct (orig_never_halts (S n)) as [C2 HC2].
  rewrite run_S_end in HC2. destruct (run delta_orig n C31) as [C1|] eqn:E1; [|discriminate].
  pose proof (run_sub _ _ _ _ _ (deltaP_sub true) E1) as E1'.
  rewrite HC in E1'. injection E1' as <-.
  destruct C as [[[q L] x] R]. intros ->. destruct x; [reflexivity|].
  simpl in HC2. discriminate.
Qed.

(* ------------------------------------------------------------------------- *)
(* M51 started in state 30: step 0 writes the end marker 1 and enters state 31 *)

Definition C30 : Conf51 := (Q30, blank, s0, blank).

(* what is right of the encoding after k beeps of the cycles: 11-k blanks and the marker,
   until the marker is read (and erased) by state 50; from then on all blank *)
Definition tail30 (k : nat) : Stream Sym := if k <=? 10 then repeat s0 (11 - k) *> (s1 >> Z) else Z.

Lemma tail30_hd k : shd (tail30 k) = s0.
Proof.
  unfold tail30. destruct (k <=? 10) eqn:E; [|reflexivity].
  apply Nat.leb_le in E. replace (11 - k) with (S (10 - k)) by lia. reflexivity.
Qed.

Lemma newtail_tail30 b k : newtail b (tail30 k) = tail30 (k + if b then 1 else 0).
Proof.
  destruct b; [|rewrite Nat.add_0_r; reflexivity]. unfold tail30, newtail.
  destruct (Nat.le_gt_cases k 9) as [Hk|Hk].
  - replace (k <=? 10) with true by (symmetry; apply Nat.leb_le; lia).
    replace (k + 1 <=? 10) with true by (symmetry; apply Nat.leb_le; lia).
    replace (11 - k) with (S (S (9 - k))) by lia. replace (11 - (k + 1)) with (S (9 - k)) by lia.
    reflexivity.
  - destruct (Nat.eq_dec k 10) as [->|Hne].
    + simpl. symmetry. apply Z_unfold.
    + replace (k <=? 10) with false by (symmetry; apply Nat.leb_gt; lia).
      replace (k + 1 <=? 10) with false by (symmetry; apply Nat.leb_gt; lia).
      simpl. symmetry. apply Z_unfold.
Qed.

Theorem start30 : exists n, Steps delta isbeep n 1 C30 (DconfJ [1; 0] (tail30 0)).
Proof.
  assert (E : Ev false 1 (KR Q30 [] [s0] Z) (fun C => C = DconfJ [1; 0] (tail30 0))).
  { st. do 10 (apply eBlankL; st). apply eBlankL. apply eBEEP_L.
    do 4 (apply eBlankL; st). apply ev_done. reflexivity. }
  destruct E as (C & [n Hn] & ->). exists n.
  exact (Steps_sub _ _ _ _ _ _ (deltaP_sub false) Hn).
Qed.

(* the start-30 run passes through D(S_j) followed by tail30, with the same beep counts as
   the start-31 run *)
Theorem M51_run30 (j : nat) :
  exists t, Steps delta isbeep t (1 + nbeep_before j) C30 (DconfJ (Sseq j) (tail30 (nbeep_before j))).
Proof.
  induction j as [|j [t Ht]].
  - apply start30.
  - destruct (Sseq_prefix j) as [X HX].
    destruct (dispatch_stepJ false X (tail30 (nbeep_before j))) as [n Hn].
    { apply tail30_hd. }
    { intros _. destruct (shd (stl (tail30 (nbeep_before j)))); reflexivity. }
    rewrite <- HX, newtail_tail30 in Hn.
    exists (t + S n). simpl nbeep_before. rewrite Nat.add_assoc.
    eapply Steps_trans; [exact Ht | exact (Steps_sub _ _ _ _ _ _ (deltaP_sub false) Hn)].
Qed.

(* once 11 beeps have happened after the start-up, the marker is gone and the start-30 run
   is in exactly the configurations D(S_j) of the start-31 run *)
Corollary M51_run30_blank (j : nat) : 11 <= nbeep_before j ->
  exists t, Steps delta isbeep t (1 + nbeep_before j) C30 (Dconf (Sseq j)).
Proof.
  intros Hj. destruct (M51_run30 j) as [t Ht]. exists t.
  unfold tail30 in Ht. replace (nbeep_before j <=? 10) with false in Ht by (symmetry; apply Nat.leb_gt; lia).
  exact Ht.
Qed.
