# The 51-state beeper: specification shared by the proof efforts

## The machine M51

The table is in `beeper51.txt` (`state  on-0  on-1`, entries `write move next`). It is Racheline's 51-state
2-symbol machine (posted on the bbchallenge wiki, Talk:Champions, "BB(51) epsilon_0 champion", 3 Sep 2024;
table re-checked against that page, 26 Oct 2026). One change: the original halting transition
(state 50 reading 1 = halt) is replaced by `0L48`, the same as state 50 reading 0.

* Original start state: 30. Step 0 (state 30 on a blank cell) writes a 1 (an end marker that only the halting
  countdown uses), moves left, and enters state 31.
* Beep state: 50. A beep is an entry into state 50.
* Start-state variant: started in state 31 on an all-blank tape, the run is identical to the start-30 run
  from step 1 on, except that the marker cell is 0. Over 3*10^8 steps of the start-31 run, transition
  (50,1) is never used and no state other than 50 moves right of the start cell. Long-term, the work area
  drifts right by one cell per battle, so for the start-30 run the claim to prove is: the marker cell is
  first read by state 50, after which the two runs coincide.

## Tape encoding at a dispatch

A **dispatch** is an entry into state 22 from state 46 or 49. At a dispatch:

* The head is on a 0 cell. Every cell to its left is 0. (After a 46-entry the cell just left was written
  with a 0, so it is still blank.)
* Starting at the cell just right of the head, the tape holds cell pairs: `10` = X, `11` = U. They end at the
  first `00` pair, and everything after that is 0 (apart from the far-away marker in the start-30 run).
* The X/U string w encodes the sequence `S = [s_0, s_1, ..., s_m]` like this: split w at the U's into X-runs;
  their lengths, read right to left, are s_0, s_1, ..., s_m. So
  `w = X^{s_m} U X^{s_{m-1}} U ... U X^{s_0}`. The functions `encode`/`decode` are in `ref51.py`.
* Every reachable S has the form `[1, 0] + X`: a sentinel 1, a base 0, then a worm X of naturals. The head of
  the worm (its last letter) is at the left end of the tape.

## The process R (dispatch level): `ref51.py`, function `step`

Given S:

1. z = number of trailing zeros of S. If X consists only of zeros, the base 0 counts too.
   S0 = S with those zeros removed. n = 2z+1.
2. If S0 = [1]: **beep**, and the next configuration is [1, 0, z].
3. Otherwise let c = last(S0) >= 1 and r = max{i : S0[i] < c} (r >= 1, since S0[1] = 0).
   * S' = S0 with its last letter lowered to c-1.
   * B = S'[r+1:].
   * E = S' B B B ... (infinite).
   * The candidates, in order: for L = |S0|+1, |S0|+2, ... and, within each L, for v = 0, 1, ..., E[L-1],
     the sequence E[:L-1] + [v].
   * The next configuration is candidate number n, counting from 0. There is no beep.

The counter is not stored anywhere: it is the trailing-zero count. A **battle** runs from a configuration
[1,0,k] to the next beep. From the blank tape the configurations are [1,0] (after one beep that the start-up
code emits), then [1,0,1], [1,0,0,0,0], [1,0,4], ...

Battle structure: write Phi_X(z) for the number z' such that the process started at [1,0]+X+[0]*z reaches
[1,0]+[0]*z' (all of X consumed). The battle from [1,0,k] then ends in [1,0]+[0]*Phi_(k)(0), beeps, and the
next battle starts at [1, 0, 1+Phi_(k)(0)]. So the starting letters are k_1 = 1, k_2 = 4, and
k_{j+1} = 1 + Phi_(k_j)(0). Known values: Phi_(1)(z) = 2z+3, Phi_(2)(0) = 11.

## Evidence that M51 implements R (simulation only, not a proof)

* `sim51.c` logs every dispatch (decoded X/U string) and every beep; `ref51.py <log>` checks each consecutive
  pair against `step` and checks the beeps. From the blank tape (start 30), all 98 dispatches up to
  step 1.79*10^8 match, with worms up to 13,944 letters (largest letter 4). Beeps at steps 11, 28, 115.
* `rtest.py` places an arbitrary encoded S (head in state 22 on the 0 cell left of the pairs, blank
  elsewhere), runs to the next dispatch, and compares. 1,000 random tests with letters up to 20, worm
  lengths up to 12 and up to 30 trailing zeros (117 of them beep cases) all match. In every test, nothing
  nonzero is left to the right of the new work area.

## Structural facts (claims, to be proved where used)

* (Composition) For all worms X, Y and all z: Phi_{X+[0]+Y}(z) = Phi_X(1 + Phi_Y(z)). Also Phi_[](z) = z and
  Phi_{X+[0]}(z) = Phi_X(z+1).
  *Reason:* every expansion index r lies at or after the 0 that separates X from Y, so the process on
  X 0 Y mirrors the process on [1,0]+Y until Y is all zeros.
* Atomic case: if Q has no zeros (all letters >= 1), then Phi_Q(z) = Phi_C(0), where [1,0]+C is candidate
  number 2z+1 of [1,0]+Q.
* Worm ordinal: o([]) = 0. Split X at its zeros, X = A_0 0 A_1 0 ... 0 A_m, with each A_i zero-free (possibly
  empty). Then o(X) = [A_0 nonempty] w^{o(A_0 - 1)} + sum_{i>=1} w^{o(A_i - 1)}, where A - 1 lowers every letter
  by 1. The battle from [1,0,k] has ordinal o(0,k) = omega_k (tower of k omegas), and every step lowers o(0 X).
