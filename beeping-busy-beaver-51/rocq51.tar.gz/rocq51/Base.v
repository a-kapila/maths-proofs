(* Base.v -- list-based configurations of M51 and continuation-style reachability.

     KR q lr r J : state q, head on the first cell of (r ++ J)            ("facing right")
     KL q lr r J : state q, head on the first cell of (lr ++ 0^inf)        ("facing left")

   lr lists the cells LEFT of the head nearest-first (reversed); left of lr the tape is
   blank.  r lists cells to the right (left to right), followed by the stream J.

   The development is generic in a flag h:
     deltaP false = delta, the machine M51 of beeper51.txt (Machine51.v);
     deltaP true  = Racheline's unmodified table, in which state 50 reading 1 halts.
   For every pair (q, x) other than (Q50, s1), deltaP h q x computes to delta q x whatever h is.

   Ev h b X P : from X the machine deltaP h reaches, in finitely many defined steps of which
                exactly b are taken from the beep state 50, some configuration satisfying P.
   Every step / scan lemma is stated in continuation form  Ev h b X' P -> Ev h b X P. *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51 Proc.
Import ListNotations.

Definition deltaP (h : bool) (q : St) (s : Sym) : option (Sym * Dir * St) :=
  match q, s with
  | Q50, s1 => if h then None else delta Q50 s1
  | _, _ => delta q s
  end.

Lemma deltaP_false q s : deltaP false q s = delta q s.
Proof. destruct q, s; reflexivity. Qed.

Lemma deltaP_sub h q s v : deltaP h q s = Some v -> delta q s = Some v.
Proof. destruct h, q, s; simpl; congruence. Qed.

Definition Z : Stream Sym := const s0.

Definition KR (q : St) (lr r : list Sym) (J : Stream Sym) : Conf51 := cR q (lr *> Z) (r *> J).
Definition KL (q : St) (lr r : list Sym) (J : Stream Sym) : Conf51 := cL q (lr *> Z) (r *> J).
Arguments KR : simpl never.
Arguments KL : simpl never.

Lemma Z_unfold : Z = s0 >> Z.
Proof. apply const_unfold. Qed.

Section Gen.
Variable h : bool.

Definition R51 (b : nat) (C C' : Conf51) : Prop := Reach (deltaP h) isbeep b C C'.

Definition Ev (b : nat) (X : Conf51) (P : Conf51 -> Prop) : Prop := exists C, R51 b X C /\ P C.

Lemma ev_done X (P : Conf51 -> Prop) : P X -> Ev 0 X P.
Proof. intros H. exists X. split; [apply reach_refl | exact H]. Qed.

Lemma ev_conf b X Y P : X = Y -> Ev b Y P -> Ev b X P.
Proof. intros ->. auto. Qed.

(* ------------------------------------------------------------------------- *)
(* single steps                                                               *)

Section E.
Variables (b : nat) (P : Conf51 -> Prop).

Lemma eRR q x lr r J w q' : deltaP h q x = Some (w, Rgt, q') -> isbeep q = false ->
  Ev b (KR q' (w :: lr) r J) P -> Ev b (KR q lr (x :: r) J) P.
Proof.
  intros Hd Hb [C [HC HP]]. exists C. split; [|exact HP].
  unfold KR in *. simpl lpre in *. eapply sRR; eauto.
Qed.

Lemma eRL q x lr r J w q' : deltaP h q x = Some (w, Lft, q') -> isbeep q = false ->
  Ev b (KL q' lr (w :: r) J) P -> Ev b (KR q lr (x :: r) J) P.
Proof.
  intros Hd Hb [C [HC HP]]. exists C. split; [|exact HP].
  unfold KR, KL in *. simpl lpre in *. eapply sRL; eauto.
Qed.

Lemma eLR q x lr r J w q' : deltaP h q x = Some (w, Rgt, q') -> isbeep q = false ->
  Ev b (KR q' (w :: lr) r J) P -> Ev b (KL q (x :: lr) r J) P.
Proof.
  intros Hd Hb [C [HC HP]]. exists C. split; [|exact HP].
  unfold KR, KL in *. simpl lpre in *. eapply sLR; eauto.
Qed.

Lemma eLL q x lr r J w q' : deltaP h q x = Some (w, Lft, q') -> isbeep q = false ->
  Ev b (KL q' lr (w :: r) J) P -> Ev b (KL q (x :: lr) r J) P.
Proof.
  intros Hd Hb [C [HC HP]]. exists C. split; [|exact HP].
  unfold KL in *. simpl lpre in *. eapply sLL; eauto.
Qed.

(* the blank cell left of everything *)
Lemma eBlankL q r J : Ev b (KL q [s0] r J) P -> Ev b (KL q [] r J) P.
Proof. exact (fun H => H). Qed.

(* change the presentation of the lists *)
Lemma ekR q lr1 lr2 r1 r2 J : lr1 = lr2 -> r1 = r2 -> Ev b (KR q lr2 r2 J) P -> Ev b (KR q lr1 r1 J) P.
Proof. intros -> ->. auto. Qed.
Lemma ekL q lr1 lr2 r1 r2 J : lr1 = lr2 -> r1 = r2 -> Ev b (KL q lr2 r2 J) P -> Ev b (KL q lr1 r1 J) P.
Proof. intros -> ->. auto. Qed.

End E.

(* the beep: state 50 writes 0 and moves left to 48.  It reads x; for x = 0 this is a
   step of both machines, for x = 1 only of M51 (h = false). *)
Lemma eBEEP b P lr x r J : deltaP h Q50 x = Some (s0, Lft, Q48) ->
  Ev b (KL Q48 lr (s0 :: r) J) P -> Ev (S b) (KR Q50 lr (x :: r) J) P.
Proof.
  intros Hx [C [HC HP]]. exists C. split; [|exact HP].
  unfold KR, KL in *. simpl lpre in *.
  eapply sRL_beep; [exact Hx | reflexivity | exact HC].
Qed.

(* the beep step entered facing left (used by the start-up code, on a blank cell) *)
Lemma eBEEP_L b P lr r J : Ev b (KL Q48 lr (s0 :: r) J) P -> Ev (S b) (KL Q50 (s0 :: lr) r J) P.
Proof.
  intros [C [HC HP]]. exists C. split; [|exact HP].
  unfold KR, KL in *. simpl lpre in *.
  eapply step_beep1; [| reflexivity | exact HC]. reflexivity.
Qed.

End Gen.

(* ------------------------------------------------------------------------- *)
(* reversed cells, ones                                                       *)

Definition rc (W : list Pr) : list Sym := rev (cells W).
Definition ones (n : nat) : list Sym := repeat s1 n.
Arguments rc : simpl never.
Arguments ones : simpl never.

Lemma cells_app W1 W2 : cells (W1 ++ W2) = cells W1 ++ cells W2.
Proof. induction W1; simpl; congruence. Qed.

Lemma rc_app W1 W2 : rc (W1 ++ W2) = rc W2 ++ rc W1.
Proof. unfold rc. rewrite cells_app, rev_app_distr. reflexivity. Qed.

Lemma rc_cons p W : rc (p :: W) = rc W ++ [sb p; fb p].
Proof. unfold rc. simpl. rewrite <- app_assoc. reflexivity. Qed.

Lemma rc_snoc W p : rc (W ++ [p]) = sb p :: fb p :: rc W.
Proof. rewrite rc_app. reflexivity. Qed.

Lemma rc_nil : rc [] = [].
Proof. reflexivity. Qed.

Lemma rc_one p : rc [p] = [sb p; fb p].
Proof. reflexivity. Qed.

Lemma repeat_snoc' {A} (x : A) n : repeat x (S n) = repeat x n ++ [x].
Proof. induction n; simpl; [reflexivity|]. f_equal. exact IHn. Qed.

Lemma repeat_add' {A} (x : A) n m : repeat x (n + m) = repeat x n ++ repeat x m.
Proof. induction n; simpl; congruence. Qed.

Lemma rc_rep_S p n : rc (p :: repeat p n) = sb p :: fb p :: rc (repeat p n).
Proof. change (p :: repeat p n) with (repeat p (S n)). rewrite repeat_snoc', rc_snoc. reflexivity. Qed.

Lemma ones_S n : ones (S n) = s1 :: ones n.
Proof. reflexivity. Qed.

Lemma ones_pU n : cells (repeat pU n) = ones (2 * n).
Proof. induction n; [reflexivity|]. replace (2 * S n) with (S (S (2 * n))) by lia. simpl. rewrite IHn. reflexivity. Qed.

Lemma rc_pU n : rc (repeat pU n) = ones (2 * n).
Proof. unfold rc. rewrite ones_pU. unfold ones. apply rev_repeat. Qed.

Lemma cells_repeat_comm p n l : cells (repeat p n) ++ fb p :: sb p :: l = fb p :: sb p :: cells (repeat p n) ++ l.
Proof.
  change (fb p :: sb p :: cells (repeat p n) ++ l) with (cells (repeat p (S n)) ++ l).
  rewrite repeat_snoc', cells_app, <- app_assoc. reflexivity.
Qed.

(* ------------------------------------------------------------------------- *)
(* scans                                                                      *)

Section Scans.
Variables (h : bool) (b : nat) (P : Conf51 -> Prop).

(* rightward scan over a pair word: state qa reads the first cell of each pair p and
   writes fb (f p); state (m p) reads the second cell and writes sb (f p). *)
Lemma scanR (qa : St) (m : Pr -> St) (f : Pr -> Pr) (Q : Pr -> Prop) W lr r J :
  (forall p, Q p -> deltaP h qa (fb p) = Some (fb (f p), Rgt, m p) /\
                   deltaP h (m p) (sb p) = Some (sb (f p), Rgt, qa) /\ isbeep (m p) = false) ->
  isbeep qa = false -> Forall Q W ->
  Ev h b (KR qa (rc (map f W) ++ lr) r J) P -> Ev h b (KR qa lr (cells W ++ r) J) P.
Proof.
  intros H Hb HW. revert lr. induction HW as [|p W Hp HW IH]; intros lr Hk; [exact Hk|].
  destruct (H p Hp) as (H1 & H2 & H3). simpl.
  eapply eRR; [exact H1 | exact Hb |].
  eapply eRR; [exact H2 | exact H3 |].
  apply IH. simpl map in Hk. rewrite rc_cons, <- app_assoc in Hk. exact Hk.
Qed.

(* leftward scan: state qb reads the second cell of each pair (the pairs are met from
   right to left), state (m p) the first cell. *)
Lemma scanL (qb : St) (m : Pr -> St) (f : Pr -> Pr) (Q : Pr -> Prop) W lr r J :
  (forall p, Q p -> deltaP h qb (sb p) = Some (sb (f p), Lft, m p) /\
                   deltaP h (m p) (fb p) = Some (fb (f p), Lft, qb) /\ isbeep (m p) = false) ->
  isbeep qb = false -> Forall Q W ->
  Ev h b (KL qb lr (cells (map f W) ++ r) J) P -> Ev h b (KL qb (rc W ++ lr) r J) P.
Proof.
  intros H Hb HW. revert lr r. induction HW as [|p W Hp HW IH]; intros lr r Hk; [exact Hk|].
  destruct (H p Hp) as (H1 & H2 & H3).
  rewrite rc_cons, <- app_assoc. simpl app.
  apply IH.
  eapply eLL; [exact H1 | exact Hb |].
  eapply eLL; [exact H2 | exact H3 |].
  exact Hk.
Qed.

(* one state scanning a constant symbol *)
Lemma scan1R q x n lr r J : deltaP h q x = Some (x, Rgt, q) -> isbeep q = false ->
  Ev h b (KR q (repeat x n ++ lr) r J) P -> Ev h b (KR q lr (repeat x n ++ r) J) P.
Proof.
  intros Hd Hb. revert lr. induction n as [|n IH]; intros lr Hk; [exact Hk|].
  simpl. eapply eRR; [exact Hd | exact Hb |]. apply IH.
  rewrite repeat_snoc', <- app_assoc in Hk. exact Hk.
Qed.

Lemma scan1L q x n lr r J : deltaP h q x = Some (x, Lft, q) -> isbeep q = false ->
  Ev h b (KL q lr (repeat x n ++ r) J) P -> Ev h b (KL q (repeat x n ++ lr) r J) P.
Proof.
  intros Hd Hb. revert r. induction n as [|n IH]; intros r Hk; [exact Hk|].
  simpl. eapply eLL; [exact Hd | exact Hb |]. apply IH.
  rewrite repeat_snoc', <- app_assoc in Hk. exact Hk.
Qed.

(* scans that leave the pairs unchanged *)
Lemma skipR (qa : St) (m : Pr -> St) (Q : Pr -> Prop) W lr r J :
  (forall p, Q p -> deltaP h qa (fb p) = Some (fb p, Rgt, m p) /\
                   deltaP h (m p) (sb p) = Some (sb p, Rgt, qa) /\ isbeep (m p) = false) ->
  isbeep qa = false -> Forall Q W ->
  Ev h b (KR qa (rc W ++ lr) r J) P -> Ev h b (KR qa lr (cells W ++ r) J) P.
Proof.
  intros H Hb HW Hk. apply (scanR qa m (fun p => p) Q); auto. rewrite map_id. exact Hk.
Qed.

Lemma skipL (qb : St) (m : Pr -> St) (Q : Pr -> Prop) W lr r J :
  (forall p, Q p -> deltaP h qb (sb p) = Some (sb p, Lft, m p) /\
                   deltaP h (m p) (fb p) = Some (fb p, Lft, qb) /\ isbeep (m p) = false) ->
  isbeep qb = false -> Forall Q W ->
  Ev h b (KL qb lr (cells W ++ r) J) P -> Ev h b (KL qb (rc W ++ lr) r J) P.
Proof.
  intros H Hb HW Hk. apply (scanL qb m (fun p => p) Q); auto. rewrite map_id. exact Hk.
Qed.

End Scans.

(* Forall helpers *)
Lemma Fa_repeat {A} (Q : A -> Prop) x n : Q x -> Forall Q (repeat x n).
Proof. intros H. apply Forall_forall. intros y Hy. apply repeat_spec in Hy. subst. exact H. Qed.

Lemma Fa_app {A} (Q : A -> Prop) l1 l2 : Forall Q l1 -> Forall Q l2 -> Forall Q (l1 ++ l2).
Proof. intros; apply Forall_app; split; assumption. Qed.

Lemma map_repeat' {A B} (f : A -> B) x n : map f (repeat x n) = repeat (f x) n.
Proof. induction n; simpl; congruence. Qed.

(* ------------------------------------------------------------------------- *)
(* tactics                                                                    *)

(* normalise reversed cell lists: rc of a concatenation / cons is split into atoms *)
Ltac rcn := repeat (progress (rewrite ?rc_app, ?rc_cons, ?rc_nil, ?app_nil_l, <- ?app_assoc));
  simpl fb; simpl sb; simpl app.

(* one step; the head cell must be visible as a cons *)
Ltac st := first
  [ eapply eRR; [reflexivity | reflexivity | ]
  | eapply eRL; [reflexivity | reflexivity | ]
  | eapply eLR; [reflexivity | reflexivity | ]
  | eapply eLL; [reflexivity | reflexivity | ] ].
