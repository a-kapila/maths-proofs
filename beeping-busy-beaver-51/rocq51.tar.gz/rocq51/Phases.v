(* Phases.v -- one lemma per phase of a dispatch cycle of M51 (see README.md).
   All lemmas are in continuation form: Ev h b (after) P -> Ev h b (before) P, and hold for
   both machines (h = false: M51; h = true: the unmodified table, see Base.v). *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51 Proc Base.
Import ListNotations.

Definition XU (p : Pr) : Prop := p = pX \/ p = pU.

Section Ph.
Variables (h : bool) (b : nat) (P : Conf51 -> Prop).

(* ---- phase 1: the U-loop (states 22-25) ---------------------------------- *)

Lemma uloop_one k r J : Ev h b (KR Q22 (s0 :: ones (2 * S k)) (s0 :: r) J) P ->
  Ev h b (KR Q22 (s0 :: ones (2 * k)) (s0 :: s1 :: s1 :: r) J) P.
Proof.
  intros H. do 8 st.
  replace (2 * S k) with (S (S (2 * k))) in H by lia. exact H.
Qed.

Lemma uloop z : forall k r J, Ev h b (KR Q22 (s0 :: ones (2 * (k + z))) (s0 :: r) J) P ->
  Ev h b (KR Q22 (s0 :: ones (2 * k)) (s0 :: cells (repeat pU z) ++ r) J) P.
Proof.
  induction z as [|z IH]; intros k r J H.
  - rewrite Nat.add_0_r in H. exact H.
  - simpl repeat. simpl cells. simpl app.
    apply uloop_one. apply IH. replace (S k + z) with (k + S z) by lia. exact H.
Qed.

(* ---- phase 2: the head letter -------------------------------------------- *)

(* the first X of the head letter becomes 11 *)
Lemma head_first lr r J : Ev h b (KR Q26 (s1 :: s1 :: s0 :: s0 :: lr) r J) P ->
  Ev h b (KR Q22 (s0 :: lr) (s0 :: s1 :: s0 :: r) J) P.
Proof. intros H. do 3 st. exact H. Qed.

(* the remaining X's of the head letter become O; then the separator U *)
Lemma head_rest n lr R J : Ev h b (KR Q28 (rc (repeat pO n ++ [pU]) ++ lr) (cells R) J) P ->
  Ev h b (KR Q26 lr (cells (repeat pX n ++ pU :: R)) J) P.
Proof.
  intros H. rewrite cells_app.
  eapply (scanR _ _ _ Q26 (fun _ => Q27) (fun _ => pO) (fun p => p = pX));
    [| reflexivity | apply Fa_repeat; reflexivity |].
  - intros p ->. repeat split; reflexivity.
  - rewrite map_repeat'. simpl cells. do 4 st. rewrite rc_snoc in H. exact H.
Qed.

(* ---- phase 3: comparison rounds (states 28-42) ---------------------------- *)

(* One X of the current letter is matched against the rightmost unconsumed marker O
   of the zone (the previous letter); the marker is consumed (O -> X). *)
Lemma match_one Pp a m bb R lr0 J :
  Ev h b (KR Q28 (rc (Pp ++ repeat pO a ++ repeat pX (S m) ++ [pU]) ++ lr0)
               (cells (repeat pO bb ++ pO :: R)) J) P ->
  Ev h b (KR Q28 (rc (Pp ++ repeat pO (S a) ++ repeat pX m ++ [pU]) ++ lr0)
               (cells (repeat pO bb ++ pX :: R)) J) P.
Proof.
  intros H. rewrite cells_app.
  eapply (skipR _ _ _ Q28 (fun _ => Q29) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  simpl cells. do 3 st.
  eapply (skipL _ _ _ Q32 (fun _ => Q31) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  rewrite !rc_app, <- !app_assoc, rc_one. simpl app. do 2 st.
  eapply (skipL _ _ _ Q33 (fun _ => Q34) (fun p => p = pX));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  rewrite rc_rep_S. simpl sb; simpl fb. do 3 st.
  eapply (skipR _ _ _ Q37 (fun _ => Q36) (fun p => p = pX));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  do 2 st.
  revert H. apply ekR.
  - simpl repeat. rcn. reflexivity.
  - rewrite cells_app. reflexivity.
Qed.

(* i markers consumed in a row *)
Lemma match_many Pp R lr0 J : forall i a m bb s,
  Ev h b (KR Q28 (rc (Pp ++ repeat pO a ++ repeat pX (i + m) ++ [pU]) ++ lr0)
               (cells (repeat pO (bb + i) ++ repeat pX s ++ R)) J) P ->
  Ev h b (KR Q28 (rc (Pp ++ repeat pO (i + a) ++ repeat pX m ++ [pU]) ++ lr0)
               (cells (repeat pO bb ++ repeat pX (i + s) ++ R)) J) P.
Proof.
  induction i as [|i IH]; intros a m bb s H.
  - rewrite Nat.add_0_r in H. exact H.
  - change (S i + a) with (S (i + a)). change (S i + s) with (S (i + s)).
    change (repeat pX (S (i + s)) ++ R) with (pX :: (repeat pX (i + s) ++ R)).
    apply match_one.
    replace (repeat pO bb ++ pO :: repeat pX (i + s) ++ R)
      with (repeat pO (S bb) ++ repeat pX (i + s) ++ R)
      by (rewrite repeat_snoc', <- app_assoc; reflexivity).
    apply IH. replace (i + S m) with (S i + m) by lia. replace (S bb + i) with (bb + S i) by lia.
    exact H.
Qed.

(* the end marker is reached: the current letter is >= c.  The c-th matched X is
   un-marked, and the current letter (with its first c-1 X's marked) becomes the zone. *)
Lemma hd_s1 s R : cells (repeat pX s ++ pU :: R) = s1 :: tl (cells (repeat pX s ++ pU :: R)).
Proof. destruct s; reflexivity. Qed.

Lemma back42 lr r J : Ev h b (KR Q37 (s0 :: s1 :: lr) (s1 :: r) J) P ->
  Ev h b (KR Q40 (s1 :: s0 :: lr) (s1 :: r) J) P.
Proof. intros H. do 4 st. exact H. Qed.

Lemma match_end Pp m bb s R lr0 J :
  Ev h b (KR Q28 (rc (Pp ++ [pU] ++ repeat pX m ++ [pU] ++ repeat pO bb ++ repeat pX (S s) ++ [pU]) ++ lr0)
               (cells R) J) P ->
  Ev h b (KR Q28 (rc (Pp ++ [pU] ++ repeat pX m ++ [pU]) ++ lr0)
               (cells (repeat pO bb ++ pX :: repeat pX s ++ pU :: R)) J) P.
Proof.
  intros H. rewrite cells_app.
  eapply (skipR _ _ _ Q28 (fun _ => Q29) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  simpl cells. do 3 st.
  eapply (skipL _ _ _ Q32 (fun _ => Q31) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  rewrite !rc_app, <- !app_assoc, !rc_one. simpl app. do 2 st.
  eapply (skipL _ _ _ Q33 (fun _ => Q34) (fun p => p = pX));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  do 3 st.
  eapply (skipR _ _ _ Q38 (fun _ => Q39) (fun p => p = pX));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  do 2 st.
  eapply (skipR _ _ _ Q40 (fun _ => Q41) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  do 2 st.
  rewrite hd_s1. apply back42. rewrite <- hd_s1. rewrite cells_app.
  eapply (skipR _ _ _ Q37 (fun _ => Q36) (fun p => p = pX));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  simpl cells. do 2 st.
  revert H. apply ekR; [|reflexivity].
  simpl repeat. rcn. reflexivity.
Qed.

(* the U after the current letter is reached: the current letter is < c *)
Lemma match_fail W bb R lr0 J :
  Ev h b (KL Q0 (s0 :: rc (repeat pO bb) ++ rc W ++ lr0) (s1 :: cells R) J) P ->
  Ev h b (KR Q28 (rc W ++ lr0) (cells (repeat pO bb ++ pU :: R)) J) P.
Proof.
  intros H. rewrite cells_app.
  eapply (skipR _ _ _ Q28 (fun _ => Q29) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  simpl cells. do 2 st. exact H.
Qed.

(* ---- phase 4: set-up of the copy (states 0-8) ------------------------------ *)

(* Restore the current letter (0/1), mark the separator before it as the copy source
   (2: U -> O), restore the zone (4/3/5) and the end marker (6), and walk left to the
   gap (7/8). *)
Lemma setup P' a m bb R n J : Forall XU P' ->
  Ev h b (KL Q9 (ones n) (cells ([pG] ++ P' ++ [pU] ++ repeat pX (a + m) ++ [pO] ++ repeat pX bb ++ pU :: R)) J) P ->
  Ev h b (KL Q0 (s0 :: rc (repeat pO bb) ++ rc ([pG] ++ P' ++ [pU] ++ repeat pO a ++ repeat pX m ++ [pU]) ++ ones n)
              (s1 :: cells R) J) P.
Proof.
  intros HP H. st.
  eapply (scanL _ _ _ Q0 (fun _ => Q1) (fun _ => pX) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  rewrite map_repeat'. rcn. do 4 st.
  eapply (skipL _ _ _ Q4 (fun _ => Q3) (fun p => p = pX));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  eapply (scanL _ _ _ Q4 (fun _ => Q5) (fun _ => pX) (fun p => p = pO));
    [intros p ->; repeat split; reflexivity | reflexivity | apply Fa_repeat; reflexivity |].
  rewrite map_repeat'. do 4 st.
  eapply (skipL _ _ _ Q7 (fun p => match p with pX => Q8 | _ => Q7 end) XU);
    [intros p [-> | ->]; repeat split; reflexivity | reflexivity | exact HP |].
  do 2 st.
  revert H. apply ekL; [reflexivity|].
  rewrite repeat_add', !cells_app. simpl. rewrite ?cells_app, <- ?app_assoc. reflexivity.
Qed.

(* ---- phase 5: the copy loop (states 9-21) ---------------------------------- *)

(* 9 extends the counter by one 1 on the left, 11 walks back to the gap *)
Lemma ext9 m rr J : Ev h b (KR Q12 (s0 :: ones (S m)) (s0 :: rr) J) P ->
  Ev h b (KL Q9 (ones m) (s0 :: s0 :: rr) J) P.
Proof.
  intros H. rewrite <- (app_nil_r (ones m)). unfold ones at 1.
  apply scan1L; [reflexivity | reflexivity |].
  apply eBlankL. st.
  apply scan1R; [reflexivity | reflexivity |].
  st. rewrite <- repeat_snoc'. exact H.
Qed.

Definition mark (p : Pr) : Pr := match p with pX => pG | pU => pO | q => q end.

(* from the gap, go right to the source mark (12/13), restore it, and read the
   pair left of it: the next source (14) *)
Lemma copy_fwd W1 src p W2 l J : Forall XU W1 -> XU src -> XU p ->
  Ev h b (KL Q14 (sb src :: fb src :: rc W1 ++ s0 :: s0 :: ones l) (cells (p :: W2)) J) P ->
  Ev h b (KR Q12 (s0 :: ones l) (s0 :: cells (W1 ++ src :: mark p :: W2)) J) P.
Proof.
  intros H1 Hs Hp H. st.
  replace (W1 ++ src :: mark p :: W2) with ((W1 ++ [src]) ++ mark p :: W2) by (rewrite <- app_assoc; reflexivity).
  rewrite cells_app.
  eapply (skipR _ _ _ Q13 (fun _ => Q12) XU);
    [intros q [-> | ->]; repeat split; reflexivity | reflexivity | apply Fa_app; [exact H1 | constructor; [exact Hs | constructor]] |].
  replace (cells (mark p :: W2)) with (s0 :: sb p :: cells W2) by (destruct Hp as [-> | ->]; reflexivity).
  st. rewrite rc_snoc.
  replace (s1 :: sb p :: cells W2) with (cells (p :: W2)) by (destruct Hp as [-> | ->]; reflexivity).
  exact H.
Qed.

(* mark the source (6: X -> 00, 10: U -> 01), walk left to the gap (15/16, 17/18)
   and write the source pair there (16, 18/19) *)
Lemma copy_back W1 src V l J : Forall XU W1 -> XU src ->
  Ev h b (KL Q20 (ones l) (cells (src :: W1 ++ mark src :: V)) J) P ->
  Ev h b (KL Q14 (sb src :: fb src :: rc W1 ++ s0 :: s0 :: ones l) (cells V) J) P.
Proof.
  intros H1 [-> | ->] H; simpl in H |- *; rewrite cells_app in H; simpl in H.
  - do 2 st.
    eapply (skipL _ _ _ Q15 (fun _ => Q16) XU);
      [intros q [-> | ->]; repeat split; reflexivity | reflexivity | exact H1 |].
    do 2 st. exact H.
  - do 2 st.
    eapply (skipL _ _ _ Q17 (fun _ => Q18) XU);
      [intros q [-> | ->]; repeat split; reflexivity | reflexivity | exact H1 |].
    do 4 st. exact H.
Qed.

(* one round of the copy loop when the counter has at least two 1s *)
Lemma copy_step W1 src p W2 l J : Forall XU W1 -> XU src -> XU p ->
  Ev h b (KR Q12 (s0 :: ones (S l)) (s0 :: cells (src :: W1 ++ mark src :: p :: W2)) J) P ->
  Ev h b (KR Q12 (s0 :: ones (S (S l))) (s0 :: cells (W1 ++ src :: mark p :: W2)) J) P.
Proof.
  intros H1 Hs Hp H. apply copy_fwd; auto. apply copy_back; auto.
  rewrite ones_S, ones_S. do 2 st. apply ext9. exact H.
Qed.

(* the last round: the counter is a single 1 *)
Lemma copy_last W1 src p W2 J : Forall XU W1 -> XU src -> XU p ->
  Ev h b (KR Q43 [s0] (s0 :: cells (src :: W1 ++ mark src :: p :: W2)) J) P ->
  Ev h b (KR Q12 (s0 :: ones 1) (s0 :: cells (W1 ++ src :: mark p :: W2)) J) P.
Proof.
  intros H1 Hs Hp H. apply copy_fwd; auto. apply copy_back; auto.
  rewrite ones_S. st. apply eBlankL. st. exact H.
Qed.

(* ---- phase 6: the end (states 43-46) ---------------------------------------- *)

Lemma end_phase A p W2 J : Forall XU A -> XU p ->
  Ev h b (KR Q22 [s0] (s0 :: cells (A ++ p :: W2)) J) P ->
  Ev h b (KR Q43 [s0] (s0 :: cells (A ++ mark p :: W2)) J) P.
Proof.
  intros HA Hp H. st. rewrite cells_app.
  eapply (skipR _ _ _ Q44 (fun _ => Q43) XU);
    [intros q [-> | ->]; repeat split; reflexivity | reflexivity | exact HA |].
  replace (cells (mark p :: W2)) with (s0 :: sb p :: cells W2) by (destruct Hp as [-> | ->]; reflexivity).
  st.
  eapply (skipL _ _ _ Q45 (fun _ => Q46) XU);
    [intros q [-> | ->]; repeat split; reflexivity | reflexivity | exact HA |].
  do 2 st.
  revert H. apply ekR; [reflexivity|].
  rewrite cells_app. destruct Hp as [-> | ->]; reflexivity.
Qed.

End Ph.

(* ---- the beep (S0 = [1]) --------------------------------------------------- *)

Lemma s1_cells_pO z : s1 :: cells (repeat pO z) = cells (repeat pX z) ++ [s1].
Proof. induction z; simpl; [reflexivity|]. rewrite IHz. reflexivity. Qed.

Lemma beep_case h b P z y r J : deltaP h Q50 y = Some (s0, Lft, Q48) ->
  Ev h b (KL Q22 [] (s1 :: cells (repeat pO z) ++ [s1; s1; s1; s1; s0; s0] ++ r) J) P ->
  Ev h (S b) (KR Q26 (s1 :: s1 :: s0 :: s0 :: ones (2 * z)) (s0 :: y :: r) J) P.
Proof.
  intros Hy H. st. apply eBEEP; [exact Hy|]. do 5 st.
  rewrite <- rc_pU. rewrite <- (app_nil_r (rc (repeat pU z))).
  eapply (scanL _ _ _ Q49 (fun _ => Q48) (fun _ => pO) (fun p => p = pU));
    [ | reflexivity | apply Fa_repeat; reflexivity | ].
  - intros p ->. repeat split; reflexivity.
  - rewrite map_repeat'. apply eBlankL. st. exact H.
Qed.
