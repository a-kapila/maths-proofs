(* Comb.v -- the process step, as transcribed from ref51.py in Proc.v, computes exactly the
   tape that the copy loop of M51 produces.

   For  rev S = 0^z ++ c :: G ++ t :: H  with c >= 1, every letter of G >= c, t < c, H <> []:
     step S = (false, S')  and
     pw (rev S') = iter (cpy |beta|) (2z+1) ([U] ++ beta ++ X^t U pw H),
   where beta = X^{c-1} U X^{g1} U ... X^{gp} U is the pair word of the "bad part".
   The candidate enumeration of ref51.py is analysed directly ([candloop_letters]); the
   copy loop is shown to produce the reversed periodic extension of beta ([copy_rev]), and
   the two are matched block by block ([app_letters_spec]). *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51 Proc Base Phases Loops.
Import ListNotations.

(* ------------------------------------------------------------------------- *)
(* generic list facts                                                         *)

Lemma length_repeat' {A} (x : A) n : length (repeat x n) = n.
Proof. induction n; simpl; congruence. Qed.

Lemma firstn_repeat_app {A} (x : A) m n X : m <= n -> firstn m (repeat x n ++ X) = repeat x m.
Proof.
  revert n. induction m as [|m IH]; intros n Hn; [reflexivity|].
  destruct n as [|n]; [lia|]. simpl. f_equal. apply IH. lia.
Qed.

Lemma firstn_seq' m s N : m <= N -> firstn m (seq s N) = seq s m.
Proof.
  revert s N. induction m as [|m IH]; intros s N Hm; [reflexivity|].
  destruct N as [|N]; [lia|]. simpl. f_equal. apply IH. lia.
Qed.

Lemma nth_map_seq0 {A} (f : nat -> A) i N d : i < N -> nth i (map f (seq 0 N)) d = f i.
Proof.
  intros H. rewrite nth_indep with (d' := f 0) by (rewrite length_map, length_seq; exact H).
  rewrite map_nth, seq_nth by exact H. reflexivity.
Qed.

Lemma nth_rev0 {A} (l : list A) d : nth 0 (rev l) d = last l d.
Proof.
  induction l as [|a l IH] using rev_ind; [reflexivity|].
  rewrite rev_app_distr, last_last. reflexivity.
Qed.

Lemma rev_inj' {A} (l1 l2 : list A) : rev l1 = rev l2 -> l1 = l2.
Proof. intros H. rewrite <- (rev_involutive l1), <- (rev_involutive l2), H. reflexivity. Qed.

Lemma map_nth_seq_full {A} (w : list A) d : map (fun j => nth j w d) (seq 0 (length w)) = w.
Proof.
  induction w as [|a w IH]; [reflexivity|]. simpl. f_equal.
  rewrite <- seq_shift, map_map. exact IH.
Qed.

(* ------------------------------------------------------------------------- *)
(* cyclic access: cyc d w j = (w w w ...)[j]                                  *)

Definition cyc {A} (d : A) (w : list A) (j : nat) : A := nth (j mod length w) w d.

Lemma cyc_period {A} (d : A) w j : w <> [] -> cyc d w (length w + j) = cyc d w j.
Proof.
  intros Hw. unfold cyc. f_equal.
  replace (length w + j) with (j + 1 * length w) by lia. apply Nat.Div0.mod_add.
Qed.

Lemma map_cyc_seq0 {A} (d : A) w : w <> [] -> map (cyc d w) (seq 0 (length w)) = w.
Proof.
  intros Hw. transitivity (map (fun j => nth j w d) (seq 0 (length w))); [|apply map_nth_seq_full].
  apply map_ext_in. intros j Hj. apply in_seq in Hj. unfold cyc. rewrite Nat.mod_small by lia.
  reflexivity.
Qed.

Lemma map_cyc_shift {A} (d : A) w m : w <> [] -> forall s,
  map (cyc d w) (seq (length w + s) m) = map (cyc d w) (seq s m).
Proof.
  intros Hw. induction m as [|m IH]; intros s; [reflexivity|]. simpl.
  rewrite cyc_period by exact Hw. f_equal. replace (S (length w + s)) with (length w + S s) by lia.
  apply IH.
Qed.

Lemma map_cyc_split {A} (d : A) w m : w <> [] ->
  map (cyc d w) (seq 0 (length w + m)) = w ++ map (cyc d w) (seq 0 m).
Proof.
  intros Hw. rewrite seq_app, map_app, map_cyc_seq0 by exact Hw. f_equal.
  replace (0 + length w) with (length w + 0) by lia. apply map_cyc_shift. exact Hw.
Qed.

Lemma concat_repeat_cyc {A} (d : A) w M : w <> [] ->
  concat (repeat w M) = map (cyc d w) (seq 0 (M * length w)).
Proof.
  intros Hw. induction M as [|M IH]; [reflexivity|].
  simpl. rewrite map_cyc_split by exact Hw. f_equal. exact IH.
Qed.

(* ------------------------------------------------------------------------- *)
(* reading blocks right to left: blk a = U X^a                                *)

Definition blk (a : nat) : list Pr := pU :: repeat pX a.
Definition bl (L : list nat) : list Pr := concat (map blk L).

Lemma bl_app L1 L2 : bl (L1 ++ L2) = bl L1 ++ bl L2.
Proof. unfold bl. rewrite map_app, concat_app. reflexivity. Qed.

Lemma bl_cons a L : bl (a :: L) = blk a ++ bl L.
Proof. reflexivity. Qed.

Lemma bl_one a : bl [a] = blk a.
Proof. unfold bl. simpl. rewrite app_nil_r. reflexivity. Qed.

Lemma rev_blocksG L : rev (blocksG L) = bl (rev L).
Proof.
  induction L as [|a L IH]; [reflexivity|].
  rewrite blocksG_cons. simpl rev. rewrite bl_app, <- IH, !rev_app_distr, rev_repeat, bl_one.
  simpl. rewrite <- app_assoc. reflexivity.
Qed.

Lemma bl_concat_repeat B M : bl (concat (repeat B M)) = concat (repeat (bl B) M).
Proof. induction M as [|M IH]; [reflexivity|]. simpl. rewrite bl_app, IH. reflexivity. Qed.

(* ------------------------------------------------------------------------- *)
(* the candidate loop of ref51.py                                             *)

(* the letters appended after Sp: e j bounds the j-th appended letter *)
Fixpoint app_letters (e : nat -> nat) (fuel j m : nat) : list nat :=
  match fuel with
  | 0 => []
  | S f => if m <=? e j then [m] else e j :: app_letters e f (S j) (m - S (e j))
  end.

Lemma candloop_letters (E : nat -> nat) (Sp : list nat) : forall fuel j m, m < fuel ->
  candloop E fuel (S (length Sp + j)) m =
  map E (seq 0 (length Sp + j)) ++ app_letters (fun i => E (length Sp + i)) fuel j m.
Proof.
  induction fuel as [|f IH]; intros j m Hm; [lia|].
  simpl candloop. simpl app_letters. replace (length Sp + j - 0) with (length Sp + j) by lia.
  destruct (m <=? E (length Sp + j)) eqn:Hle; [reflexivity|].
  apply Nat.leb_gt in Hle.
  replace (S (S (length Sp + j))) with (S (length Sp + S j)) by lia.
  rewrite IH by lia. replace (length Sp + S j) with (S (length Sp + j)) by lia.
  rewrite seq_S, map_app, <- app_assoc. reflexivity.
Qed.

(* The fuel of [candloop] only bounds the number of rounds of the while loop of ref51.py:
   with any fuel > m the loop returns in a round of its own (never by running out of fuel),
   and the result does not depend on the fuel.  So [cand S0 n], which uses fuel n+1, is
   the value returned by the unbounded loop of ref51.py. *)
Lemma candloop_fuel (E : nat -> nat) : forall f1 f2 L m, m < f1 -> m < f2 ->
  candloop E f1 L m = candloop E f2 L m.
Proof.
  induction f1 as [|f1 IH]; intros f2 L m H1 H2; [lia|].
  destruct f2 as [|f2]; [lia|]. simpl.
  destruct (m <=? E (L - 1)) eqn:Hm; [reflexivity|].
  apply Nat.leb_gt in Hm. apply IH; lia.
Qed.

Lemma candloop_returns (E : nat -> nat) : forall f L m, m < f ->
  exists L' v, v <= E (L' - 1) /\ candloop E f L m = map E (seq 0 (L' - 1)) ++ [v].
Proof.
  induction f as [|f IH]; intros L m Hm; [lia|]. simpl.
  destruct (m <=? E (L - 1)) eqn:Hle.
  - exists L, m. split; [apply Nat.leb_le; exact Hle | reflexivity].
  - apply Nat.leb_gt in Hle. apply IH. lia.
Qed.

(* the appended letters, read as blocks, are a prefix of the block reading of e *)
Lemma app_letters_spec (e : nat -> nat) : forall fuel j m N, m < fuel -> m < N ->
  bl (app_letters e fuel j m) = firstn (S m) (bl (map e (seq j N))).
Proof.
  induction fuel as [|f IH]; intros j m N Hf HN; [lia|].
  destruct N as [|N]; [lia|]. simpl app_letters. simpl seq. simpl map.
  rewrite (bl_cons (e j) (map e (seq (S j) N))).
  destruct (m <=? e j) eqn:Hle.
  - apply Nat.leb_le in Hle.
    change (bl [m]) with (pU :: repeat pX m ++ []). rewrite app_nil_r.
    unfold blk. simpl. rewrite firstn_repeat_app by exact Hle. reflexivity.
  - apply Nat.leb_gt in Hle. rewrite bl_cons, (IH (S j) (m - S (e j)) N) by lia.
    rewrite firstn_app, (firstn_all2 (n := S m) (blk (e j))) by (unfold blk; simpl; rewrite length_repeat'; lia).
    f_equal. unfold blk. simpl length. rewrite length_repeat'. f_equal. lia.
Qed.

(* ------------------------------------------------------------------------- *)
(* the copy loop: after j further copies the window read right to left is     *)
(* the first |beta| + j + 1 pairs of (rev beta)^infinity                        *)

Lemma rev_ne {A} (l : list A) : l <> [] -> rev l <> [].
Proof. intros H E. apply H. rewrite <- (rev_involutive l), E. reflexivity. Qed.

Lemma copy_rev (beta rest : list Pr) : beta <> [] -> last beta pX = pU -> forall j,
  exists C, iter (cpy (length beta)) j ([pU] ++ beta ++ rest) = C ++ beta ++ rest /\
            rev (C ++ beta) = map (cyc pX (rev beta)) (seq 0 (length beta + S j)).
Proof.
  intros Hb Hl. assert (Hw : rev beta <> []) by (apply rev_ne; exact Hb).
  assert (Hk : length (rev beta) = length beta) by apply length_rev.
  assert (Hk1 : 1 <= length beta) by (destruct beta; [congruence | simpl; lia]).
  induction j as [|j IH].
  - exists [pU]. split; [reflexivity|].
    rewrite <- Hk, map_cyc_split by exact Hw. simpl rev. f_equal. simpl. f_equal.
    unfold cyc. rewrite Nat.Div0.mod_0_l. rewrite nth_rev0. symmetry. exact Hl.
  - destruct IH as (C & E1 & E2).
    assert (HN : length (C ++ beta) = length beta + S j)
      by (rewrite <- length_rev, E2, length_map, length_seq; reflexivity).
    exists (nth (length beta - 1) (C ++ beta) pX :: C). split.
    + change (iter (cpy (length beta)) (S j) ([pU] ++ beta ++ rest))
        with (cpy (length beta) (iter (cpy (length beta)) j ([pU] ++ beta ++ rest))).
      rewrite E1. unfold cpy. rewrite <- app_comm_cons. f_equal.
      rewrite app_assoc, app_nth1 by lia. reflexivity.
    + simpl rev. rewrite E2. replace (length beta + S (S j)) with (S (length beta + S j)) by lia.
      rewrite seq_S, map_app. f_equal. simpl. f_equal.
      rewrite <- (rev_involutive (C ++ beta)) at 1.
      rewrite rev_nth by (rewrite length_rev; lia).
      rewrite length_rev, HN, E2.
      rewrite nth_map_seq0 by lia.
      replace (length beta + S j - S (length beta - 1)) with (S j) by lia.
      rewrite <- Hk, cyc_period by exact Hw. reflexivity.
Qed.

(* ------------------------------------------------------------------------- *)
(* the pair word of a decomposed sequence                                     *)

Lemma pw_cons_ne a T : T <> [] -> pw (a :: T) = repeat pX a ++ pU :: pw T.
Proof. destruct T; [congruence | reflexivity]. Qed.

Lemma pw_app_blocks L T : T <> [] -> pw (L ++ T) = blocksG L ++ pw T.
Proof.
  intros HT. induction L as [|a L IH]; [reflexivity|].
  simpl app. rewrite pw_cons_ne by (destruct L; simpl; [exact HT | congruence]).
  rewrite IH, blocksG_cons, <- app_assoc. reflexivity.
Qed.

Lemma pw_zeros z T : T <> [] -> pw (repeat 0 z ++ T) = repeat pU z ++ pw T.
Proof.
  intros HT. induction z as [|z IH]; [reflexivity|].
  simpl repeat. simpl app. rewrite pw_cons_ne by (destruct z; simpl; [exact HT | congruence]).
  rewrite IH. reflexivity.
Qed.

(* ------------------------------------------------------------------------- *)
(* the pieces of [step] on a decomposed sequence                              *)

Lemma lz_rep z c T : c <> 0 -> lz (repeat 0 z ++ c :: T) = z.
Proof. intros Hc. induction z as [|z IH]; simpl; [destruct c; [congruence | reflexivity] | f_equal; exact IH]. Qed.

Lemma maxlt_from_app c l1 l2 i acc :
  maxlt_from c (l1 ++ l2) i acc = maxlt_from c l2 (i + length l1) (maxlt_from c l1 i acc).
Proof.
  revert i acc. induction l1 as [|a l1 IH]; intros i acc; simpl; [rewrite Nat.add_0_r; reflexivity|].
  rewrite IH. f_equal. lia.
Qed.

Lemma maxlt_from_ge c l i acc : Forall (fun x => c <= x) l -> maxlt_from c l i acc = acc.
Proof.
  intros H. revert i acc. induction H as [|a l Ha Hl IH]; intros i acc; simpl; [reflexivity|].
  replace (a <? c) with false by (symmetry; apply Nat.ltb_ge; exact Ha). apply IH.
Qed.

Lemma skipn_S_len_app {A} (l1 l2 : list A) x : skipn (S (length l1)) (l1 ++ x :: l2) = l2.
Proof. induction l1; simpl; [reflexivity|]. exact IHl1. Qed.

Lemma last_beta a G : last (repeat pX a ++ [pU] ++ blocksG G) pX = pU.
Proof.
  induction G as [|g G IH] using rev_ind.
  - unfold blocksG. simpl. rewrite last_last. reflexivity.
  - rewrite blocksG_app. unfold blocksG at 2. simpl. rewrite app_nil_r.
    rewrite !app_assoc, app_comm_cons, app_assoc, last_last. reflexivity.
Qed.

Theorem step_nonbeep z c G t H : 1 <= c -> Forall (fun g => c <= g) G -> t < c -> H <> [] ->
  exists S', step (rev (repeat 0 z ++ c :: G ++ t :: H)) = (false, S') /\
    firstn (S (length H)) S' = rev H ++ [t] /\
    pw (rev S') = iter (cpy (length (repeat pX (c - 1) ++ [pU] ++ blocksG G))) (S (2 * z))
                    ([pU] ++ (repeat pX (c - 1) ++ [pU] ++ blocksG G) ++ repeat pX t ++ pU :: pw H).
Proof.
  intros Hc HG Ht HH.
  set (Sq := rev (repeat 0 z ++ c :: G ++ t :: H)).
  set (S0 := ((rev H ++ [t]) ++ rev G) ++ [c]).
  assert (ES : Sq = S0 ++ repeat 0 z).
  { unfold Sq, S0. rewrite rev_app_distr, rev_repeat. simpl. rewrite rev_app_distr. simpl.
    rewrite <- !app_assoc. reflexivity. }
  assert (Htz : tz Sq = z).
  { unfold tz, Sq. rewrite rev_involutive. apply lz_rep. lia. }
  assert (HS0 : firstn (length Sq - z) Sq = S0).
  { rewrite ES, length_app, length_repeat'. replace (length S0 + z - z) with (length S0) by lia.
    apply firstn_len_app. }
  assert (HS0n : S0 <> [1]).
  { unfold S0. intros E. apply (f_equal (@length nat)) in E. rewrite !length_app in E.
    simpl in E. destruct H; [congruence | simpl in E; lia]. }
  set (n := 1 + 2 * z).
  set (Sp := ((rev H ++ [t]) ++ rev G) ++ [c - 1]).
  set (B := rev G ++ [c - 1]).
  assert (Hlast : last S0 0 = c) by (unfold S0; apply last_last).
  assert (Hr : maxlt c S0 = length H).
  { unfold maxlt, S0. rewrite !maxlt_from_app. simpl.
    replace (t <? c) with true by (symmetry; apply Nat.ltb_lt; exact Ht).
    rewrite maxlt_from_ge by (apply Forall_rev; exact HG).
    replace (c <? c) with false by (symmetry; apply Nat.ltb_ge; lia).
    rewrite length_rev. reflexivity. }
  assert (HSp : removelast S0 ++ [c - 1] = Sp) by (unfold S0, Sp; rewrite removelast_last; reflexivity).
  assert (HB : skipn (S (length H)) Sp = B).
  { unfold Sp, B. rewrite <- !app_assoc. simpl. rewrite <- (length_rev H). apply skipn_S_len_app. }
  assert (HlenS : length S0 = length Sp) by (unfold S0, Sp; rewrite !length_app; reflexivity).
  assert (HBne : B <> []) by (unfold B; destruct (rev G); simpl; congruence).
  set (E := Efun Sp B).
  set (e := fun i => E (length Sp + i)).
  set (Lout := app_letters e (S n) 0 n).
  assert (Hcand : cand S0 n = Sp ++ Lout).
  { unfold cand. rewrite Hlast, Hr, HSp, HB. fold E.
    rewrite HlenS, <- (Nat.add_0_r (length Sp)), candloop_letters by lia.
    rewrite Nat.add_0_r. f_equal.
    transitivity (map (fun i => nth i Sp 0) (seq 0 (length Sp))); [|apply map_nth_seq_full].
    apply map_ext_in. intros i Hi. apply in_seq in Hi. unfold E, Efun.
    replace (i <? length Sp) with true by (symmetry; apply Nat.ltb_lt; lia). reflexivity. }
  exists (Sp ++ Lout). split.
  { unfold step. fold Sq. rewrite Htz, HS0.
    destruct (list_eq_dec Nat.eq_dec S0 [1]) as [E1|E1]; [contradiction|].
    fold n. rewrite Hcand. reflexivity. }
  split.
  { unfold Sp. rewrite <- !app_assoc. rewrite <- (length_rev H).
    replace (S (length (rev H))) with (length (rev H ++ [t])) by (rewrite length_app; simpl; lia).
    rewrite (app_assoc (rev H) [t]). apply firstn_len_app. }
  (* the beta of the machine *)
  set (beta := repeat pX (c - 1) ++ [pU] ++ blocksG G).
  set (rest := repeat pX t ++ pU :: pw H).
  assert (Hbeta : beta = blocksG ((c - 1) :: G)) by (unfold beta; rewrite blocksG_cons; reflexivity).
  assert (Hbne : beta <> []) by (unfold beta; destruct (c - 1); simpl; congruence).
  assert (Hblast : last beta pX = pU) by apply last_beta.
  assert (Hw : rev beta = bl B).
  { rewrite Hbeta, rev_blocksG. unfold B. reflexivity. }
  (* the copy side *)
  destruct (copy_rev beta rest Hbne Hblast (S (2 * z))) as (C & E1 & E2).
  rewrite E1.
  (* the candidate side: rev C = bl Lout *)
  assert (HbLout : bl Lout = map (cyc pX (rev beta)) (seq 0 (S n))).
  { assert (HBlen : 1 <= length B) by (unfold B; rewrite length_app; simpl; lia).
    unfold Lout. rewrite (app_letters_spec e (S n) 0 n (S n * length B)) by nia.
    rewrite (map_ext e (cyc 0 B)).
    2:{ intros i. unfold e, E, Efun. replace (length Sp + i <? length Sp) with false
          by (symmetry; apply Nat.ltb_ge; lia).
        unfold cyc. f_equal. f_equal. lia. }
    rewrite <- concat_repeat_cyc by exact HBne. rewrite bl_concat_repeat, <- Hw.
    rewrite (concat_repeat_cyc pX) by (apply rev_ne; exact Hbne).
    rewrite firstn_map, firstn_seq'; [reflexivity|].
    rewrite length_rev. assert (1 <= length beta) by (destruct beta; [congruence | simpl; lia]). nia. }
  assert (HC : rev C = bl Lout).
  { rewrite HbLout. rewrite rev_app_distr in E2. rewrite <- (length_rev beta) in E2.
    rewrite map_cyc_split in E2 by (apply rev_ne; exact Hbne).
    apply app_inv_head in E2. rewrite E2. f_equal. }
  assert (HC' : C = blocksG (rev Lout)).
  { apply rev_inj'. rewrite HC, rev_blocksG, rev_involutive. reflexivity. }
  (* the pair word of the new sequence *)
  assert (HrSp : rev Sp = (c - 1) :: G ++ t :: H).
  { unfold Sp. rewrite !rev_app_distr, !rev_involutive. simpl. reflexivity. }
  rewrite rev_app_distr, pw_app_blocks by (rewrite HrSp; congruence).
  rewrite HC'. f_equal.
  rewrite HrSp, pw_cons_ne by (destruct G; simpl; congruence).
  rewrite pw_app_blocks by congruence. rewrite pw_cons_ne by exact HH.
  unfold beta, rest. rewrite <- !app_assoc. reflexivity.
Qed.
