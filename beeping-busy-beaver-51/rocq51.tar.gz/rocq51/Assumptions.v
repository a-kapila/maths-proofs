(* Assumptions.v -- Print Assumptions for the main results (run as part of the build). *)
From M51 Require Import TM Machine51 Proc Base Phases Loops Comb Cycle Main.

Print Assumptions dispatch_step.
Print Assumptions start31.
Print Assumptions M51_run.
Print Assumptions M51_run_times.
Print Assumptions M51_run_fun.
Print Assumptions M51_beeps_forever_iff.
Print Assumptions orig_never_halts.
Print Assumptions M51_state50_reads_0.
Print Assumptions M51_run30.
Print Assumptions M51_run30_blank.
