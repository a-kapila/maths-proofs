(* Loops.v -- the comparison rounds over all letters >= c, and the copy loop, by induction;
   then the whole non-beep dispatch cycle on the tape level. *)

From Stdlib Require Import List Arith Lia.
From M51 Require Import TM Machine51 Proc Base Phases.
Import ListNotations.

(* the pair word X^g1 U X^g2 U ... of a list of letters, each letter followed by a U *)
Definition blocksG (G : list nat) : list Pr := concat (map (fun g => repeat pX g ++ [pU]) G).

Lemma blocksG_cons g G : blocksG (g :: G) = repeat pX g ++ [pU] ++ blocksG G.
Proof. unfold blocksG. simpl. rewrite <- app_assoc. reflexivity. Qed.

Lemma blocksG_app G1 G2 : blocksG (G1 ++ G2) = blocksG G1 ++ blocksG G2.
Proof. unfold blocksG. rewrite map_app, concat_app. reflexivity. Qed.

Lemma Fa_XU_repeat_pX n : Forall XU (repeat pX n).
Proof. apply Fa_repeat. left. reflexivity. Qed.

Lemma Fa_XU_blocksG G : Forall XU (blocksG G).
Proof.
  induction G as [|g G IH]; [constructor|]. rewrite blocksG_cons.
  apply Fa_app; [apply Fa_XU_repeat_pX|]. constructor; [right; reflexivity | exact IH].
Qed.

(* ------------------------------------------------------------------------- *)
(* iteration, the copy step on pair words, and the marked word                *)

Fixpoint iter {A} (f : A -> A) (n : nat) (x : A) : A :=
  match n with 0 => x | S n' => f (iter f n' x) end.

Lemma iter_S {A} (f : A -> A) n x : iter f (S n) x = iter f n (f x).
Proof. induction n; simpl; [reflexivity|]. rewrite <- IHn. reflexivity. Qed.

(* one copy: the pair at index k-1 is put in front (offset k copy, one pair to the left) *)
Definition cpy (k : nat) (W : list Pr) : list Pr := nth (k - 1) W pX :: W.

(* the pair at index k carries the source mark *)
Definition mkw (k : nat) (W : list Pr) : list Pr :=
  firstn k W ++ match skipn k W with [] => [] | p :: t => mark p :: t end.

Lemma firstn_len_app {A} (l1 l2 : list A) : firstn (length l1) (l1 ++ l2) = l1.
Proof. induction l1; simpl; [reflexivity|]. f_equal. exact IHl1. Qed.

Lemma skipn_len_app {A} (l1 l2 : list A) : skipn (length l1) (l1 ++ l2) = l2.
Proof. induction l1; simpl; [reflexivity|]. exact IHl1. Qed.

Lemma nth_len_app {A} (l1 l2 : list A) x d : nth (length l1) (l1 ++ x :: l2) d = x.
Proof. induction l1; simpl; [reflexivity|]. exact IHl1. Qed.

Lemma mkw_split A p W2 : mkw (length A) (A ++ p :: W2) = A ++ mark p :: W2.
Proof. unfold mkw. rewrite firstn_len_app, skipn_len_app. reflexivity. Qed.

Lemma decomp n (W : list Pr) : S n < length W -> exists W1 x y W2, W = W1 ++ x :: y :: W2 /\ length W1 = n.
Proof.
  revert W. induction n as [|n IH]; intros W HW.
  - destruct W as [|x [|y W2]]; simpl in HW; try lia. exists [], x, y, W2. auto.
  - destruct W as [|x W]; simpl in HW; [lia|].
    destruct (IH W) as (W1 & a & c & W2 & -> & HL); [lia|].
    exists (x :: W1), a, c, W2. simpl. auto.
Qed.

Lemma decomp1 n (W : list Pr) : n < length W -> exists A p W2, W = A ++ p :: W2 /\ length A = n.
Proof.
  revert W. induction n as [|n IH]; intros W HW.
  - destruct W as [|p W2]; simpl in HW; [lia|]. exists [], p, W2. auto.
  - destruct W as [|x W]; simpl in HW; [lia|].
    destruct (IH W) as (A & p & W2 & -> & HL); [lia|].
    exists (x :: A), p, W2. simpl. auto.
Qed.

Lemma Fa_app_inv {A} (Q : A -> Prop) l1 l2 : Forall Q (l1 ++ l2) -> Forall Q l1 /\ Forall Q l2.
Proof. intros H. apply Forall_app in H. exact H. Qed.

Lemma XU_nth W k : Forall XU W -> XU (nth k W pX).
Proof.
  intros H. revert k. induction H as [|p W Hp HW IH]; intros k; destruct k; simpl; auto.
  left. reflexivity. left. reflexivity.
Qed.

Lemma cpy_XU k W : Forall XU W -> Forall XU (cpy k W).
Proof. intros H. constructor; [apply XU_nth; exact H | exact H]. Qed.

Lemma iter_cpy_XU k n W : Forall XU W -> Forall XU (iter (cpy k) n W).
Proof. intros H. induction n; simpl; [exact H | apply cpy_XU; exact IHn]. Qed.

Lemma iter_cpy_len k n W : length (iter (cpy k) n W) = n + length W.
Proof. induction n; simpl; [reflexivity|]. rewrite IHn. reflexivity. Qed.

Section L.
Variables (h : bool) (b : nat) (P : Conf51 -> Prop).

Lemma ekR' q l1 l2 lr0 r1 r2 J : l1 = l2 -> r1 = r2 ->
  Ev h b (KR q (rc l2 ++ lr0) (cells r2) J) P -> Ev h b (KR q (rc l1 ++ lr0) (cells r1) J) P.
Proof. intros -> ->. auto. Qed.

(* ---- comparison rounds -------------------------------------------------- *)

(* a whole round for a letter g >= c: the zone moves on to g *)
Lemma round_pass P' c m g R lr0 J : 1 <= c -> c <= g ->
  Ev h b (KR Q28 (rc ([pG] ++ P' ++ [pU] ++ repeat pX (c - 1 + m) ++ [pU] ++ repeat pO (c - 1)
                    ++ repeat pX (g - (c - 1)) ++ [pU]) ++ lr0) (cells R) J) P ->
  Ev h b (KR Q28 (rc ([pG] ++ P' ++ [pU] ++ repeat pO (c - 1) ++ repeat pX m ++ [pU]) ++ lr0)
               (cells (repeat pX g ++ pU :: R)) J) P.
Proof.
  intros Hc Hg H.
  apply (ekR' _ _ (([pG] ++ P' ++ [pU]) ++ repeat pO ((c - 1) + 0) ++ repeat pX m ++ [pU]) _ _
                  (repeat pO 0 ++ repeat pX ((c - 1) + S (g - c)) ++ pU :: R)).
  { rewrite Nat.add_0_r, <- !app_assoc. reflexivity. }
  { simpl. replace (c - 1 + S (g - c)) with g by lia. reflexivity. }
  apply match_many.
  apply (ekR' _ _ (([pG] ++ P') ++ [pU] ++ repeat pX (c - 1 + m) ++ [pU]) _ _
                  (repeat pO (c - 1) ++ pX :: repeat pX (g - c) ++ pU :: R)).
  { simpl. rewrite <- !app_assoc. reflexivity. }
  { reflexivity. }
  apply match_end.
  revert H. apply ekR'; [|reflexivity].
  rewrite <- !app_assoc. replace (S (g - c)) with (g - (c - 1)) by lia. reflexivity.
Qed.

(* the round for the letter t < c: it ends at state 0 *)
Lemma round_fail P' c m t R lr0 J : t < c ->
  Ev h b (KL Q0 (s0 :: rc (repeat pO t) ++ rc ([pG] ++ P' ++ [pU] ++ repeat pO (c - 1 - t)
                    ++ repeat pX (t + m) ++ [pU]) ++ lr0) (s1 :: cells R) J) P ->
  Ev h b (KR Q28 (rc ([pG] ++ P' ++ [pU] ++ repeat pO (c - 1) ++ repeat pX m ++ [pU]) ++ lr0)
               (cells (repeat pX t ++ pU :: R)) J) P.
Proof.
  intros Ht H.
  apply (ekR' _ _ (([pG] ++ P' ++ [pU]) ++ repeat pO (t + (c - 1 - t)) ++ repeat pX m ++ [pU]) _ _
                  (repeat pO 0 ++ repeat pX (t + 0) ++ pU :: R)).
  { rewrite <- !app_assoc. replace (t + (c - 1 - t)) with (c - 1) by lia. reflexivity. }
  { simpl. rewrite Nat.add_0_r. reflexivity. }
  apply match_many.
  apply (ekR' _ _ (([pG] ++ P' ++ [pU]) ++ repeat pO (c - 1 - t) ++ repeat pX (t + m) ++ [pU]) _ _
                  (repeat pO t ++ pU :: R)).
  { reflexivity. }
  { simpl. reflexivity. }
  apply match_fail.
  revert H. apply ekL; [rewrite <- !app_assoc; reflexivity | reflexivity].
Qed.

(* all rounds for the letters of G, each >= c *)
Lemma rounds c R lr0 J : 1 <= c -> forall G, Forall (fun g => c <= g) G -> forall P' m,
  (forall P'' m'', Forall XU P'' ->
     P'' ++ [pU] ++ repeat pX (c - 1 + m'') ++ [pU] = P' ++ [pU] ++ repeat pX (c - 1 + m) ++ [pU] ++ blocksG G ->
     Ev h b (KR Q28 (rc ([pG] ++ P'' ++ [pU] ++ repeat pO (c - 1) ++ repeat pX m'' ++ [pU]) ++ lr0) (cells R) J) P) ->
  Forall XU P' ->
  Ev h b (KR Q28 (rc ([pG] ++ P' ++ [pU] ++ repeat pO (c - 1) ++ repeat pX m ++ [pU]) ++ lr0)
               (cells (blocksG G ++ R)) J) P.
Proof.
  intros Hc G HG. induction HG as [|g G Hg HG IH]; intros P' m K HP.
  - apply K; [exact HP | unfold blocksG; simpl; rewrite ?app_nil_r; reflexivity].
  - rewrite blocksG_cons, <- !app_assoc. simpl app.
    apply round_pass; [exact Hc | exact Hg |].
    apply (ekR' _ _ ([pG] ++ (P' ++ [pU] ++ repeat pX (c - 1 + m)) ++ [pU] ++ repeat pO (c - 1)
                     ++ repeat pX (g - (c - 1)) ++ [pU]) _ _ (blocksG G ++ R)).
    { rewrite <- !app_assoc. reflexivity. }
    { reflexivity. }
    apply IH.
    + intros P'' m'' HP'' Heq. apply K; [exact HP''|].
      rewrite Heq, blocksG_cons, <- !app_assoc. replace (c - 1 + (g - (c - 1))) with g by lia.
      reflexivity.
    + apply Fa_app; [exact HP|]. constructor; [right; reflexivity | apply Fa_XU_repeat_pX].
Qed.

(* ---- the copy loop ------------------------------------------------------ *)

Lemma copy_loop k : 1 <= k -> forall l W J, k < length W -> Forall XU W ->
  Ev h b (KR Q43 [s0] (s0 :: cells (mkw k (iter (cpy k) (S l) W))) J) P ->
  Ev h b (KR Q12 (s0 :: ones (S l)) (s0 :: cells (mkw k W)) J) P.
Proof.
  intros Hk l. induction l as [|l IH]; intros W J HW HX H;
    destruct (decomp (k - 1) W) as (W1 & src & p & W2 & -> & HL); try lia;
    assert (HX' := HX); apply Fa_app_inv in HX' as [HX1 HX2];
    inversion HX2 as [|? ? Hs HX3]; subst; inversion HX3 as [|? ? Hp HX4]; subst;
    assert (Ek : k = length (W1 ++ [src])) by (rewrite length_app; simpl; lia);
    assert (Ecpy : cpy k (W1 ++ src :: p :: W2) = src :: W1 ++ src :: p :: W2)
      by (unfold cpy; replace (k - 1) with (length W1) by lia; rewrite nth_len_app; reflexivity);
    assert (Emk : mkw k (W1 ++ src :: p :: W2) = W1 ++ src :: mark p :: W2)
      by (replace (W1 ++ src :: p :: W2) with ((W1 ++ [src]) ++ p :: W2) by (rewrite <- app_assoc; reflexivity);
          rewrite Ek, mkw_split, <- app_assoc; reflexivity);
    assert (Emk' : mkw k (src :: W1 ++ src :: p :: W2) = src :: W1 ++ mark src :: p :: W2)
      by (replace k with (length (src :: W1)) by (simpl; lia); exact (mkw_split (src :: W1) src (p :: W2)));
    rewrite Emk.
  - apply copy_last; auto. rewrite <- Emk', <- Ecpy. exact H.
  - apply copy_step; auto. rewrite <- Emk', <- Ecpy.
    apply IH.
    + rewrite Ecpy. simpl. rewrite length_app in *. simpl in *. lia.
    + apply cpy_XU. exact HX.
    + rewrite <- iter_S. exact H.
Qed.

Lemma end_final k V J : k < length V -> Forall XU V ->
  Ev h b (KR Q22 [s0] (s0 :: cells V) J) P ->
  Ev h b (KR Q43 [s0] (s0 :: cells (mkw k V)) J) P.
Proof.
  intros Hk HV H. destruct (decomp1 k V Hk) as (A & p & W2 & -> & <-).
  rewrite mkw_split. apply Fa_app_inv in HV as [HA HpW]. inversion HpW; subst.
  apply end_phase; auto.
Qed.

End L.
