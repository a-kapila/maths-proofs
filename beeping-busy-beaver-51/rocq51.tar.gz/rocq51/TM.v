(* TM.v -- generic deterministic Turing machines on a two-way infinite tape.

   A configuration is (state, left, current, right) where [left] and [right] are
   infinite streams of symbols listed from the cell nearest to the head outwards.
   A blank tape side is [const blank].  Steps are counted, and so are visits to
   "beep" states (a state is counted each time a step is taken from it).        *)

From Stdlib Require Import List Arith Lia.
Import ListNotations.

Inductive Dir : Type := Lft | Rgt.

(* ------------------------------------------------------------------------- *)
(* Streams                                                                    *)

CoInductive Stream (A : Type) : Type := Cons : A -> Stream A -> Stream A.
Arguments Cons {A} _ _.

Definition shd {A} (s : Stream A) : A := match s with Cons x _ => x end.
Definition stl {A} (s : Stream A) : Stream A := match s with Cons _ t => t end.

CoFixpoint const {A} (a : A) : Stream A := Cons a (const a).

(* prepend a finite list to a stream *)
Fixpoint lpre {A} (l : list A) (s : Stream A) : Stream A :=
  match l with [] => s | x :: t => Cons x (lpre t s) end.

Infix ">>" := Cons (at level 60, right associativity).
Infix "*>" := lpre (at level 60, right associativity).

Lemma frob {A} (s : Stream A) : s = match s with Cons x t => Cons x t end.
Proof. destruct s; reflexivity. Qed.

Lemma const_unfold {A} (a : A) : const a = a >> const a.
Proof. rewrite (frob (const a)) at 1. reflexivity. Qed.

Lemma lpre_app {A} (l1 l2 : list A) (s : Stream A) : (l1 ++ l2) *> s = l1 *> l2 *> s.
Proof. induction l1; simpl; congruence. Qed.

Lemma lpre_cons {A} (x : A) l s : (x :: l) *> s = x >> l *> s.
Proof. reflexivity. Qed.

Lemma lpre_nil {A} (s : Stream A) : [] *> s = s.
Proof. reflexivity. Qed.

(* bisimilarity of streams *)
CoInductive EqS {A} (s1 s2 : Stream A) : Prop :=
  eqs : shd s1 = shd s2 -> EqS (stl s1) (stl s2) -> EqS s1 s2.

Lemma EqS_refl {A} (s : Stream A) : EqS s s.
Proof. revert s. cofix CH. intro s. constructor; [reflexivity | apply CH]. Qed.

Lemma EqS_sym {A} (s1 s2 : Stream A) : EqS s1 s2 -> EqS s2 s1.
Proof.
  revert s1 s2. cofix CH. intros s1 s2 [H1 H2]. constructor; [symmetry; exact H1 | apply CH; exact H2].
Qed.

Lemma EqS_trans {A} (s1 s2 s3 : Stream A) : EqS s1 s2 -> EqS s2 s3 -> EqS s1 s3.
Proof.
  revert s1 s2 s3. cofix CH. intros s1 s2 s3 [H1 H2] [H3 H4].
  constructor; [congruence | eapply CH; eauto].
Qed.

Lemma EqS_cons {A} (x : A) s1 s2 : EqS s1 s2 -> EqS (x >> s1) (x >> s2).
Proof. intro H. constructor; [reflexivity | exact H]. Qed.

(* bisimulation principle *)
Lemma EqS_coind {A} (Rel : Stream A -> Stream A -> Prop) :
  (forall s1 s2, Rel s1 s2 -> shd s1 = shd s2 /\ Rel (stl s1) (stl s2)) ->
  forall s1 s2, Rel s1 s2 -> EqS s1 s2.
Proof.
  intros H. cofix CH. intros s1 s2 HR. destruct (H _ _ HR) as [H1 H2].
  constructor; [exact H1 | apply CH; exact H2].
Qed.

(* ------------------------------------------------------------------------- *)
(* Machines                                                                   *)

Section Machine.
Context {Sym St : Type}.
Variable delta : St -> Sym -> option (Sym * Dir * St).
Variable isbeep : St -> bool.

Definition Conf : Type := (St * Stream Sym * Sym * Stream Sym)%type.

Definition step (C : Conf) : option Conf :=
  match C with
  | (q, L, x, R) =>
    match delta q x with
    | None => None
    | Some (w, Lft, q') => Some (q', stl L, shd L, w >> R)
    | Some (w, Rgt, q') => Some (q', w >> L, shd R, stl R)
    end
  end.

(* 1 if the configuration is in a beep state *)
Definition bp (C : Conf) : nat := match C with (q, _, _, _) => if isbeep q then 1 else 0 end.

(* [Steps n b C C']: from C the machine reaches C' in exactly n steps, every step
   being defined, and b of the n configurations from which a step is taken are in a
   beep state. *)
Inductive Steps : nat -> nat -> Conf -> Conf -> Prop :=
| steps0 C : Steps 0 0 C C
| stepsS C C' C'' n b : step C = Some C' -> Steps n b C' C'' -> Steps (S n) (bp C + b) C C''.

Lemma Steps_trans n1 b1 C1 C2 n2 b2 C3 :
  Steps n1 b1 C1 C2 -> Steps n2 b2 C2 C3 -> Steps (n1 + n2) (b1 + b2) C1 C3.
Proof.
  induction 1; intros; simpl; auto.
  rewrite <- Nat.add_assoc. econstructor; eauto.
Qed.

(* the run function, for reference: n steps from C (None if a step is undefined) *)
Fixpoint run (n : nat) (C : Conf) : option Conf :=
  match n with
  | 0 => Some C
  | S n' => match step C with None => None | Some C' => run n' C' end
  end.

Lemma Steps_run n b C C' : Steps n b C C' -> run n C = Some C'.
Proof. induction 1; simpl; auto. rewrite H. assumption. Qed.

Definition Reach (b : nat) (C C' : Conf) : Prop := exists n, Steps n b C C'.

Lemma reach_refl C : Reach 0 C C.
Proof. exists 0. constructor. Qed.

Lemma reach_trans b1 b2 C1 C2 C3 : Reach b1 C1 C2 -> Reach b2 C2 C3 -> Reach (b1 + b2) C1 C3.
Proof. intros [n1 H1] [n2 H2]. exists (n1 + n2). eapply Steps_trans; eauto. Qed.

Lemma reach_trans0 b C1 C2 C3 : Reach 0 C1 C2 -> Reach b C2 C3 -> Reach b C1 C3.
Proof. intros H1 H2. exact (reach_trans 0 b _ _ _ H1 H2). Qed.

Lemma reach_eq b C1 C2 C3 : Reach b C1 C2 -> C2 = C3 -> Reach b C1 C3.
Proof. intros H ->. exact H. Qed.

(* Directed views of a configuration.
   [cR q L R]: state q, head on the first cell of R (the machine "faces right").
   [cL q L R]: state q, head on the first cell of L (the machine "faces left").  *)
Definition cR (q : St) (L R : Stream Sym) : Conf := (q, L, shd R, stl R).
Definition cL (q : St) (L R : Stream Sym) : Conf := (q, stl L, shd L, R).

Lemma cR_cons q L x R : cR q L (x >> R) = (q, L, x, R).
Proof. reflexivity. Qed.
Lemma cL_cons q L x R : cL q (x >> L) R = (q, L, x, R).
Proof. reflexivity. Qed.

Lemma step_beep0 b q L x R C' C :
  step (q, L, x, R) = Some C' -> isbeep q = false -> Reach b C' C -> Reach b (q, L, x, R) C.
Proof.
  intros Hs Hb [n Hn]. exists (S n).
  replace b with (bp (q, L, x, R) + b) by (simpl; rewrite Hb; reflexivity).
  econstructor; eauto.
Qed.

Lemma step_beep1 b q L x R C' C :
  step (q, L, x, R) = Some C' -> isbeep q = true -> Reach b C' C -> Reach (S b) (q, L, x, R) C.
Proof.
  intros Hs Hb [n Hn]. exists (S n).
  replace (S b) with (bp (q, L, x, R) + b) by (simpl; rewrite Hb; reflexivity).
  econstructor; eauto.
Qed.

(* one step, in the four directed forms (non-beep source state) *)
Lemma sRR b q L x R w q' C : delta q x = Some (w, Rgt, q') -> isbeep q = false ->
  Reach b (cR q' (w >> L) R) C -> Reach b (cR q L (x >> R)) C.
Proof. intros Hd Hb H. eapply step_beep0; eauto. simpl. rewrite Hd. reflexivity. Qed.

Lemma sRL b q L x R w q' C : delta q x = Some (w, Lft, q') -> isbeep q = false ->
  Reach b (cL q' L (w >> R)) C -> Reach b (cR q L (x >> R)) C.
Proof. intros Hd Hb H. eapply step_beep0; eauto. simpl. rewrite Hd. reflexivity. Qed.

Lemma sLR b q L x R w q' C : delta q x = Some (w, Rgt, q') -> isbeep q = false ->
  Reach b (cR q' (w >> L) R) C -> Reach b (cL q (x >> L) R) C.
Proof. intros Hd Hb H. eapply step_beep0; eauto. simpl. rewrite Hd. reflexivity. Qed.

Lemma sLL b q L x R w q' C : delta q x = Some (w, Lft, q') -> isbeep q = false ->
  Reach b (cL q' L (w >> R)) C -> Reach b (cL q (x >> L) R) C.
Proof. intros Hd Hb H. eapply step_beep0; eauto. simpl. rewrite Hd. reflexivity. Qed.

(* one step from a beep state *)
Lemma sRL_beep b q L x R w q' C : delta q x = Some (w, Lft, q') -> isbeep q = true ->
  Reach b (cL q' L (w >> R)) C -> Reach (S b) (cR q L (x >> R)) C.
Proof. intros Hd Hb H. eapply step_beep1; eauto. simpl. rewrite Hd. reflexivity. Qed.

(* scanning loops: a state that keeps its direction and state on every cell of l,
   rewriting each cell x as f x *)
Lemma mapR q f l L R : (forall x, In x l -> delta q x = Some (f x, Rgt, q)) -> isbeep q = false ->
  Reach 0 (cR q L (l *> R)) (cR q (rev (map f l) *> L) R).
Proof.
  revert L. induction l as [|a l IH]; intros L H Hb; simpl.
  - apply reach_refl.
  - eapply sRR; [apply H; left; reflexivity | exact Hb |].
    rewrite lpre_app. simpl. apply IH; auto. intros x Hx. apply H. right. exact Hx.
Qed.

Lemma mapL q f l L R : (forall x, In x l -> delta q x = Some (f x, Lft, q)) -> isbeep q = false ->
  Reach 0 (cL q (l *> L) R) (cL q L (rev (map f l) *> R)).
Proof.
  revert R. induction l as [|a l IH]; intros R H Hb; simpl.
  - apply reach_refl.
  - eapply sLL; [apply H; left; reflexivity | exact Hb |].
    rewrite lpre_app. simpl. apply IH; auto. intros x Hx. apply H. right. exact Hx.
Qed.

Lemma skipR q l L R : (forall x, In x l -> delta q x = Some (x, Rgt, q)) -> isbeep q = false ->
  Reach 0 (cR q L (l *> R)) (cR q (rev l *> L) R).
Proof. intros H Hb. pose proof (mapR q (fun x => x) l L R H Hb) as H'. rewrite map_id in H'. exact H'. Qed.

Lemma skipL q l L R : (forall x, In x l -> delta q x = Some (x, Lft, q)) -> isbeep q = false ->
  Reach 0 (cL q (l *> L) R) (cL q L (rev l *> R)).
Proof. intros H Hb. pose proof (mapL q (fun x => x) l L R H Hb) as H'. rewrite map_id in H'. exact H'. Qed.

(* ------------------------------------------------------------------------- *)
(* Bisimilar configurations behave identically.                              *)

Definition ConfEq (C1 C2 : Conf) : Prop :=
  match C1, C2 with
  | (q1, L1, x1, R1), (q2, L2, x2, R2) => q1 = q2 /\ x1 = x2 /\ EqS L1 L2 /\ EqS R1 R2
  end.

Lemma step_ConfEq C1 C2 C1' : ConfEq C1 C2 -> step C1 = Some C1' ->
  exists C2', step C2 = Some C2' /\ ConfEq C1' C2'.
Proof.
  destruct C1 as [[[q1 L1] x1] R1], C2 as [[[q2 L2] x2] R2].
  intros (-> & -> & HL & HR) Hs. simpl in *.
  destruct (delta q2 x2) as [[[w [|]] q']|]; [| |discriminate]; inversion Hs; subst; clear Hs.
  - destruct HL as [Hh Ht]. eexists; split; [reflexivity|]. simpl.
    split; [reflexivity | split; [exact Hh | split; [exact Ht | apply EqS_cons; exact HR]]].
  - destruct HR as [Hh Ht]. eexists; split; [reflexivity|]. simpl.
    split; [reflexivity | split; [exact Hh | split; [apply EqS_cons; exact HL | exact Ht]]].
Qed.

Lemma Steps_ConfEq n b C1 C1' C2 : Steps n b C1 C1' -> ConfEq C1 C2 ->
  exists C2', Steps n b C2 C2' /\ ConfEq C1' C2'.
Proof.
  intros H. revert C2. induction H as [C|C C' C'' n b Hs Hn IH]; intros C2 HE.
  - exists C2. split; [constructor | exact HE].
  - destruct (step_ConfEq _ _ _ HE Hs) as (C2' & Hs2 & HE2).
    destruct (IH _ HE2) as (C3 & H3 & HE3).
    exists C3. split; auto.
    replace (bp C) with (bp C2).
    + econstructor; eauto.
    + destruct C as [[[q1 L1] x1] R1], C2 as [[[q2 L2] x2] R2]. simpl in HE. destruct HE as (-> & _). reflexivity.
Qed.

End Machine.

Arguments cR {Sym St} q L R.
Arguments cL {Sym St} q L R.
