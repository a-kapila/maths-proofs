#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MODE="${1:---checks}"
case "$MODE" in --checks|--full) ;; *) echo 'Usage: bash reproduce.sh [--checks|--full]' >&2; exit 2;; esac
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONHASHSEED=0
mkdir -p execution_logs
python verify_manifest.py
CXX="${CXX:-g++}"
FLAGS=(-O3 -std=c++17 -fPIC -fno-fast-math -ffp-contract=off)
"$CXX" "${FLAGS[@]}" -shared mpfr_backend/interval.cpp -o mpfr_backend/libinterval.so -Wl,-l:libmpfr.so.6 -lgmp
cp mpfr_backend/libinterval.so mpfr_backend/libinterval_new.so
B=prime_gap_boundary_bundle
"$CXX" "${FLAGS[@]}" -shared -fopenmp "$B/new/fft_native.cpp" -o "$B/new/fft_native_lib.so"
"$CXX" "${FLAGS[@]}" -shared -fopenmp "$B/progress/profile_parallel.cpp" -o "$B/progress/profile_parallel.so"
"$CXX" "${FLAGS[@]}" -shared "$B/analysis/profile_bounds_raw.cpp" -o "$B/analysis/profile_bounds_raw.so"
run() { local name="$1"; shift; "$@" 2>&1 | tee "execution_logs/$name.log"; }
if [[ "$MODE" == --full ]]; then
 run backend python test_mpfr_backend.py
 run quotient2 python run_mpfr_quotient.py 2
 run quotient3 python run_mpfr_quotient.py 3
 run quotient4 python run_mpfr_global_quotient.py 4
 run quotient5 python run_mpfr_finer_quotient.py 5
 run support python run_mpfr_support.py
 run amplitudes python test_mpfr_primitives_amplitudes.py
 run pair_moments python run_mpfr_pair_moments.py 2 3
 run capped_means python run_mpfr_means.py
 run pair_postprocess python postprocess_fresh_pairs.py 2 3
 run slicing_postprocess python postprocess_fresh_slicing.py 4 5
fi
run exact_links python verify_certificate_links.py
(cd "$B"; bash continuation2/prepare_h5.sh) 2>&1 | tee execution_logs/large_parent.log
run finite python verify_all_finite.py
python - <<'PY'
from pathlib import Path
import json
A=Path('.');links=json.load(open(A/'verified_final/certificate_links.json'));finite=json.load(open(A/'verified_final/finite_verification.json'))
assert links['all_passed'] and finite['all_passed']
for m in range(2,6):
 a=next(x for x in links['results'] if x['m']==m);b=next(x for x in finite['results'] if x['m']==m)
 assert a['span']==b['span']
 print('PROVED CERTIFICATE:',m,a['span'],'margin >',a['margin_printed_inputs'])
PY
