from pathlib import Path
from fractions import Fraction as F
import sys,json,time,math,runpy,shutil
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';O=A/'verified_final';O.mkdir(exist_ok=True)
sys.set_int_max_str_digits(0);sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as iv;sys.modules['flint']=iv
for m in map(int,sys.argv[1:] or [4,5]):
 st=time.time();src=A/({4:'mpfr_global_runs',5:'mpfr_finer_runs'}[m])/f'm{m}.interval_certificate.json';srcp=src.with_name(f'm{m}.json');qq=json.load(open(src));actual=json.load(open(srcp));tr=json.load(open(B/f'accurate/m{m}.json'))
 for key in ['k','theta','beta','relative_shift','profiles','basis']:assert actual[key]==tr[key]
 assert [F(actual['delta'])*x for x in actual['E']]==[F(tr['delta'])*x for x in tr['E']]
 assert F(actual['delta'])*actual['eps_cells']==F(tr['delta'])*tr['eps_cells']
 oldpath=B/f'accurate/m{m}.interval_certificate.json';
 if not (O/f'm{m}_archived_quotient.json').exists():shutil.copyfile(oldpath,O/f'm{m}_archived_quotient.json')
 shutil.copyfile(src,oldpath)
 # For H5 use a newly proved outward amplitude rather than an older endpoint.
 if m==5:
  proof=json.load(open(A/'mpfr_primitives_amplitudes_checks.json'));C=[x['generic_amplitude_upper'] for x in proof['amplitude_checks'] if x.get('m')==5][0]
  path=B/'trials/m5_fine.interval_certificate.json';base=json.load(open(path));shutil.copyfile(path,O/'m5_original_support_denominator.json')
  base['amplitude_upper']=C;base['den_lower']=qq['den_lower'];scaled=F(qq['den_lower'])/F(C)**2;base['scaled_den_lower']=math.nextafter(float(scaled),-math.inf);assert F(base['scaled_den_lower'])<=scaled
  path.write_text(json.dumps(base,indent=2)+'\n')
  save=sys.argv;sys.argv=['test_support.py','5','4','3'];runpy.run_path(str(B/'continuation/test_support.py'),run_name='__main__');sys.argv=save
  shutil.copyfile(B/'continuation/support_m5_4_3.json',A/'mpfr_support/support_m5_4_3_final.json')
 # Link the independently evaluated quotient and explicit stricter-support bound.
 support=json.load(open(B/f'continuation/support_m{m}_{10 if m==4 else 4}_{9 if m==4 else 3}.json'))
 linked=dict(qq);linked['restriction']=support['restriction'];linked['restriction_source']=str(B/f'continuation/support_m{m}_{10 if m==4 else 4}_{9 if m==4 else 3}.json')
 oldpath.write_text(json.dumps(linked,indent=2)+'\n')
 sys.path.insert(0,str(B/'radial_pair'));import radial_mass;radial_mass.build(m)
 # Load using an unambiguous module name: several historical modules are compute.py.
 import importlib.util
 spec=importlib.util.spec_from_file_location('fresh_radial_compute',B/'radial_pair/compute.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 d={4:850,5:35000}[m];v=c.constants(m,d);BD={4:4076241,5:3267409565}[m];D={4:82234788,5:4830355416}[m];margin=v['raw_surplus']-BD*v['raw_pair_upper'];smargin=v['strict_raw_surplus']-BD*v['strict_raw_pair_upper'];assert margin>0 and smargin>0,(m,float(margin),float(smargin))
 su=json.load(open(B/f'continuation/support_m{m}_{10 if m==4 else 4}_{9 if m==4 else 3}.json'))
 out={'m':m,'source_k':v['original_k'],'K':v['k'],'span':D,'long_pairs':BD,'rho':v['rho'],'sigma':v['sigma'],'beta_lower':v['beta_lower'],'eta':v['eta'],'quotient_lower_before_loss':F(qq['Q_lower']),'support_loss_upper':F(su['restriction']['loss_upper']),'q_lower':v['source_quotient'],'den_lower':F(qq['den_lower']),'den_upper':F(qq['den_upper']),'pair_upper':v['raw_pair_upper'],'surplus':v['raw_surplus'],'margin':margin,'strict_margin':smargin,'pair_calculation':v,'elapsed_seconds':time.time()-st,'backend':'Independent MPFR scalar intervals and primitive tables; fresh capped moments and support probabilities; rational terminal arithmetic'}
 (O/f'm{m}_final.json').write_text(json.dumps(c.old.encode(out),indent=2)+'\n')
 print(json.dumps({'stage':'completed_final','m':m,'Q_lower':qq['Q_lower'],'pair_upper':float(v['raw_pair_upper']),'mean_beta_lower':float(v['beta_lower']),'margin':float(margin),'strict_margin':float(smargin),'elapsed':time.time()-st}),flush=True)
