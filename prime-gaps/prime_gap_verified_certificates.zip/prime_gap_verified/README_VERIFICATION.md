# Finite prime gaps — completed MPFR certificate package

The authoritative conclusions are

H2 <= 19,844
H3 <= 1,357,780
H4 <= 82,234,788
H5 <= 4,830,355,416.

The accompanying manuscript proves the analytic implications, including the
mixed prime–divisor transfer, enlarged-support first moment, trace-preserving
prime-pair majorant, signed support-loss bounds, moment reduction and numerical
error bounds. It explicitly cites the external prime-distribution theorem
(Corollary 2.19 of *Improved short gaps between primes*, 30 August 2026) and
Polymath's unweighted Selberg second-moment theorem.

## Exact output registry

`verified_final/m2_final.json` through `m5_final.json` contain exact rational
acceptance endpoints. `verified_final/certificate_links.json` verifies the
physical trial identities, parameter conditions, scaled denominator
compatibility, exact polynomial and rounding-budget identities, conservative
printed endpoints and all terminal signs.

`verified_final/finite_verification.json` records complete admissibility and
long-pair checks, including every relevant prime, not a sample. The largest
parent has 233,950,978 entries and 12,204,094 residue witnesses.

The four completed fresh quotient evaluations are:

* `mpfr_runs/m2.interval_certificate.json`: Q >= 7.6199897108687304
* `mpfr_runs/m3.interval_certificate.json`: Q >= 11.428883231398524
* `mpfr_global_runs/m4.interval_certificate.json`: Q >= 15.238578705875785
* `mpfr_finer_runs/m5.interval_certificate.json`: Q >= 19.048047627456253

These are the unrestricted quotients. The final JSONs separately subtract the
fresh arithmetic support losses. The H4/H5 final criterion uses raw
source-averaged pair costs and the recorded capped-slicing correction.

The package contains all required exact trial specifications, compressed tuple
witnesses, rational interpolation nodes, fresh weighted CDF tables, source code,
completed execution logs and a SHA-256 manifest. No earlier download is needed.
The `prime_gap_boundary_bundle` directory preserves working module paths and
additional input provenance; its historical result files are not the final
acceptance registry.

## Dependencies and arithmetic model

The executed environment uses Python 3, NumPy, SciPy, SymPy, mpmath (diagnostics
only), a C++17/OpenMP compiler, GMP and system MPFR 4.2.2 (`libmpfr.so.6`). GMP
headers are required. The C++ MPFR wrapper includes the minimal public MPFR 4.x
ABI declarations; on a system with a different ABI these must instead be
compiled against the matching official header. The published run is Linux
x86-64 with IEEE binary64 and gradual underflow.

The independent scalar backend uses endpoint MPFR with RNDD/RNDU rounding,
including its own bounded exponential-integral evaluator. The H4/H5 primitive
tables are also independently evaluated in MPFR. H2/H3 primitives use the
included directed-binary64 positive-series and recurrence implementation.

The finite Fourier interpolation and signed-integration algorithms are shared
mathematical implementations, with explicitly audited operation/error budgets;
this is not a claim that the entire Fourier pipeline was independently rewritten.
The proof, not agreement between diagnostic tests, supplies containment. All
native kernels are compiled without fast-math or fused multiply-add contraction.
Do not disable Python or C++ assertions.

## Reproduction

In an extracted clean copy, run:

    bash reproduce.sh --checks

This checks all manifest hashes, rebuilds native kernels, rechecks exact
component compatibility and terminal inequalities, reconstructs the entire
large signed-prime parent, and completely verifies all four selected tuples and
long-pair counts. It does not recompute the Fourier integrations.

To independently regenerate all numerical enclosures as well, use a fresh copy:

    bash reproduce.sh --full

This runs all four full quotient evaluations, all support probabilities,
primitive/amplitude checks, all pair and capped-moment CDFs, rational
post-processing, and the complete finite checks. Neither mode performs a search
for better profiles or tuples. Candidate Chernoff tilts are merely proposals;
every retained probability bound is interval evaluated.

A full run generates several gigabytes of temporary primitive tables and
reconstructed prime data. These are not distributed. The new drivers find the
package root relative to their own paths. Successful reproduction should be
judged by containment, positivity and exact finite results, not elapsed-time
fields or absolute output paths. Run either mode in a fresh extracted copy
because generated metadata changes outputs included in the manifest.

## Completed run

All four complete quotient integrations, all support and weighted-moment
calculations, exact rational deductions, and all complete finite checks finished
in the recorded run. Earlier coarse or block-split lower enclosures that were
too weak are not used. The H4 result uses a global Abel sum; H5 uses a finer grid
of the same exact physical trial. The final H5 support calculation was rerun
with the outward amplitude 17.16601081281021.

The manuscript does not claim optimal bounds, a new distribution exponent,
a proof-assistant formalization, or a wholly separate second implementation of
every routine. It supplies a computer-assisted proof with explicit analytic
inputs and numerical error analysis.
