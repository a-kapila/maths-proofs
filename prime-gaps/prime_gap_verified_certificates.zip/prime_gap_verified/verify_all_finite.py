"""Complete finite verification, not a search or sampling of primes or pairs."""
from pathlib import Path
import subprocess,json,hashlib,math,struct,time
import numpy as np
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';O=A/'verified_final';O.mkdir(exist_ok=True)
for src,out in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','verify_pairs')]:
 subprocess.run(['g++','-O3','-std=c++17',str(B/src),'-o',str(O/out)],check=True)
def run(args,name):
 p=subprocess.run(list(map(str,args)),check=True,capture_output=True,text=True);(O/name).write_text(p.stdout);return json.loads(p.stdout)
def python_check(a,witness):
 k=len(a);assert np.all(a[1:]>a[:-1]);sieve=np.ones(k+1,dtype=bool);sieve[:2]=False
 for p in range(2,math.isqrt(k)+1):
  if sieve[p]:sieve[p*p::p]=False
 primes=np.flatnonzero(sieve);w=np.loadtxt(witness,delimiter=',',skiprows=1,dtype=np.int64);w=w[w[:,0]<=k];assert np.array_equal(w[:,0],primes)
 for p,r in w:
  assert 0<=r<p and not np.any(a%p==r),(int(p),int(r))
 return dict(verified=True,cardinality=k,checked_primes=len(primes),first=int(a[0]),last=int(a[-1]))
def py_pair_count(a,D):
 # Independent binary-search formula, not the C++ two-pointer loop.
 thresholds=np.searchsorted(a,a+D,side='right');return int(np.sum(len(a)-thresholds,dtype=np.int64))
rows=[]
for m,tp,wp,D,expected in [(2,'four_moment/m2_tuple.txt','four_moment/m2_witness.csv',19844,7),(3,'continuation_next/m3_tuple.txt','continuation_next/m3_witness.csv',1357780,3639)]:
 a=np.loadtxt(B/tp,dtype=np.int64);k=len(a);v=run([O/'verify_tuple',B/tp,B/wp,k],f'm{m}_tuple_native.json');p=run([O/'verify_pairs','tuple',B/tp,D],f'm{m}_pairs_native.json');pyp=python_check(a,B/wp);count=py_pair_count(a,D);assert count==p['long_pairs']==expected
 rows.append(dict(m=m,span=D,long_pairs=count,native_admissibility=v,independent_python_admissibility=pyp,native_pair_count=p,tuple_source=tp,witness_source=wp,tuple_sha256=hashlib.sha256((B/tp).read_bytes()).hexdigest(),witness_sha256=hashlib.sha256((B/wp).read_bytes()).hexdigest()))
 print('finite complete',m,rows[-1]['native_admissibility'],count,flush=True)
row=json.load(open(B/'radial_pair/m4_d850.json'))['selection'];parent=np.loadtxt(B/'baseline/inherited/tuples/h4.csv',dtype=np.int64);a=parent[row['index']:row['index']+row['k']];assert len(a)==row['k'] and int(a[0])==row['first'] and int(a[-1])==row['last'];path=O/'h4_selected.txt';np.savetxt(path,a,fmt='%d')
v=run([O/'verify_tuple',path,B/'baseline/inherited/tuples/h4_witness.csv',len(a)],'m4_tuple_native.json');p=run([O/'verify_pairs','tuple',path,row['D']],'m4_pairs_native.json');count=py_pair_count(a,row['D']);assert count==p['long_pairs']==row['long_pairs']==4076241
rows.append(dict(m=4,span=row['D'],long_pairs=count,native_admissibility=v,native_pair_count=p,python_pair_count=count,selection=row,parent_source='baseline/inherited/tuples/h4.csv',witness_source='baseline/inherited/tuples/h4_witness.csv',tuple_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
print('finite complete',4,v,count,flush=True)
row=json.load(open(B/'radial_pair/m5_d35000.json'))['selection'];parent=json.load(open(B/'continuation2/h5_parent_verified.json'));assert parent['verified'] and parent['failures']==0 and parent['certificate_prime_count']==12204094 and parent['parent_cardinality']==233950978
file=B/'continuation2/recomputed/h5_tail.bin'
with open(file,'rb') as f:r0,N=struct.unpack('<QQ',f.read(16));a=np.fromfile(f,dtype='<u4').astype(np.int64)
assert len(a)==N-r0+1 and np.all(a[1:]>a[:-1]);neg,pos=row['negative_count'],row['positive_count'];assert min(neg,pos)>=r0 and neg+pos==row['k'];assert row['first']==-int(a[neg-r0]) and row['last']==int(a[pos-r0]);D=row['D'];assert a[0]+a[-1]<=D and a[-1]<D
p=run([O/'verify_pairs','signed',file,D,neg,pos],'m5_pairs_native.json');aa=a[:neg-r0+1];bb=a[:pos-r0+1];count=int(np.sum(len(bb)-np.searchsorted(bb,D-aa,side='right'),dtype=np.int64));assert count==p['long_pairs']==row['long_pairs']==3267409565
rows.append(dict(m=5,span=D,long_pairs=count,parent_admissibility=parent,native_pair_count=p,independent_python_pair_count=count,selection=row,decoded_witness_sha256=hashlib.sha256((B/'continuation2/recomputed/current.bin').read_bytes()).hexdigest(),tail_sha256=hashlib.sha256(file.read_bytes()).hexdigest()))
print('finite complete',5,count,flush=True)
(O/'finite_verification.json').write_text(json.dumps({'all_passed':True,'results':rows,'scope':'All relevant primes and all long pairs; no random sampling.'},indent=2)+'\n')
