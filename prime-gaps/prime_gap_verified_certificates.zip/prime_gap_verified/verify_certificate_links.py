"""Exact compatibility, terminal, support-normalization and rounding-budget checks.
This checks the junctions between the separately evaluated proof components.
The component enclosures themselves are recomputed by reproduce.sh --full.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';O=A/'verified_final'
sys.set_int_max_str_digits(0)
def rat(x):
 if isinstance(x,dict) and 'numerator' in x:return F(int(x['numerator']),int(x['denominator']))
 if isinstance(x,list):return F(*map(int,x))
 return F(x)
def load(p):return json.load(open(p))
rows={2:('7.61991945321770','1.986930449098e-5','0'),3:('11.42888323139851','2.185545128531e-8','0'),4:('15.23857870587577','1.945365350719e-11','0.00015523001241465'),5:('19.04804762745624','1.491020798040e-14','0.00014210693394371')}
trials={2:A/'mpfr_runs/m2.json',3:A/'mpfr_runs/m3.json',4:A/'mpfr_global_runs/m4.json',5:A/'mpfr_finer_runs/m5.json'}
old={2:B/'trials/m2_final.json',3:B/'focus23/m3_fine.json',4:B/'trials/m4_cross.json',5:B/'trials/m5_fine.json'}
supports={2:A/'mpfr_support/m2_k2305_support.json',3:A/'mpfr_support/m3_arithmetic.json',4:A/'mpfr_support/support_m4_10_9.json',5:A/'mpfr_support/support_m5_4_3_final.json'}
res=[]
for m in range(2,6):
 v=load(O/f'm{m}_final.json');t=load(trials[m]);base=load(old[m]);qcert=load(trials[m].with_suffix('.interval_certificate.json'));sup=load(supports[m]);rs=sup.get('restriction',sup.get('support'))
 for key in ['k','theta','beta','relative_shift','basis','profiles']:assert t[key]==base[key],(m,key)
 assert [F(t['delta'])*x for x in t['E']]==[F(base['delta'])*x for x in base['E']]
 eps=F(t['delta'])*t['eps_cells'];assert eps==F(base['delta'])*base['eps_cells']
 for h in t['profiles']:
  assert h[0]==0
  assert all(abs(F(x))<=1 and (F(x)*2**40).denominator==1 for x in h)
 assert t['E'][0]==0 and all(x<y for x,y in zip(t['E'],t['E'][1:])) and F(t['E'][-1])*F(t['delta'])==1+eps
 rho=F(1,4)+F(rs['omega']);delta=F(rs['delta']);assert rho==rat(v['rho'])
 assert 240*F(rs['omega'])+80*delta<3 and 2*rho*(1+eps)<1
 assert F(rs['loss_upper'])==rat(v['support_loss_upper'])
 assert F(qcert['Q_lower'])==rat(v['quotient_lower_before_loss'])
 assert rat(v['q_lower'])==F(qcert['Q_lower'])-F(rs['loss_upper'])
 assert 0<F(qcert['den_lower'])<=F(qcert['den_upper'])
 if m==2:
  C=F(sup['amplitude_upper']);scaled=F(sup['scaled_den_lower'])
 elif m==3:
  oldq=load(B/'focus23/m3_fine.interval_certificate.json');sm=load(A/'mpfr_support/m3_support_mass.json');C=F(sm['amplitude_upper']);scaled=F(oldq['scaled_den_lower'])
 else:
  oldq=load(old[m].with_suffix('.interval_certificate.json'));C=F(sup['amplitude_upper']);scaled=F(oldq['scaled_den_lower'])
 assert 0<scaled<=F(qcert['den_lower'])/C**2,(m,'scaled support denominator')
 if m in [4,5]:
  a=rat(sup['A']);u=F(sup['new_ufrac'])*delta/rho
  assert a*u<delta/rho
  assert a*F(sup['new_kappa']) < (F(1,4)+delta/2)/rho
 else:assert F(base['ufrac'])<1
 q,Cup,bl=map(F,rows[m]);assert q<=rat(v['q_lower']) and Cup>=rat(v['pair_upper']) and bl<=rat(v['beta_lower'])
 margin=rho*F(v['K'],v['source_k'])*q-m*(1-bl)-v['long_pairs']*Cup
 exact=rho*F(v['K'],v['source_k'])*rat(v['q_lower'])-m*(1-rat(v['beta_lower']))-v['long_pairs']*rat(v['pair_upper'])
 assert exact==rat(v['margin']) and margin>0 and rat(v['strict_margin'])>0
 res.append(dict(m=m,span=v['span'],Q_lower=qcert['Q_lower'],q_printed=str(rows[m][0]),C_printed=str(rows[m][1]),beta_printed=rows[m][2],margin_printed_inputs=float(margin),margin_exact=float(exact),strict_margin=float(rat(v['strict_margin'])),normalization_compatible=True,exact_physical_profiles_equal=True,arithmetic_hypotheses=True,trial_sha256=hashlib.sha256(trials[m].read_bytes()).hexdigest()))
# Exact forward-error estimates used in the native kernels, on their full domains.
u=F(1,2**53)
def gam(n):return n*u/(1-n*u)
# Real/imaginary product: 4 products+2 additions, bounded in Euclidean norm by 6u/(1-6u).
c=6*u/(1-6*u)
def tw_error(n):
 # Starting and multiplier factors each have complex error <=2u;
 # at most n complex multiplications, all near the unit circle.
 return (1+2*u)**(n+1)*(1+c)**n-1
assert tw_error(8)<128*u
assert tw_error(256)<4096*u
assert (1+128*u)*(1+c)*(1+u)-1<256*u
# Profile accumulation: <= one product per exact dyadic difference plus n additions.
for n in [601,801,901]:
 bound=4*(n+3)*u*F.from_float(1+1e-10)
 assert bound>gam(n+2)/(1-gam(n+2))
# Unstructured binary64 reduction: the code's doubled budget covers the rounded sum(abs()).
for n in [2**18+4,2**24+4]:
 assert n*u<F(1,10000)
 assert 2*gam(n)*F.from_float(1+1e-10)>gam(n)/(1-gam(n))
# Direct weighted Fourier summation and Horner allowances.
for J in [1217,1522,1903,2379]:
 assert tw_error(256)+gam(4*J+16)<(8192+8*J)*u
assert gam(14)<gam(32)
# Every coefficient of the exact squared-remnant polynomial is handled symbolically.
import sympy as s
z,a,b=s.symbols('z a b',positive=True);ss=a+b;pp=a*b;dd=(1+ss+pp)**3
q1=-2*(pp**2*ss+3*pp*ss**2+6*pp*ss+3*pp+ss**3+3*ss**2+3*ss+1)/dd
q2=(2*pp**2+pp*ss**2+6*pp*ss+9*pp+3*ss**3+9*ss**2+9*ss+3)/dd
q3=-2*(pp*ss+3*ss**2+6*ss+2)/dd;q4=(pp+3*ss+5)/dd
Q=1+q1*z+q2*z**2+q3*z**3+q4*z**4;cstar=1+2/(1+a)+2/(1+b)
assert s.factor(Q-(1+z)**-2-z*(z-a)**2*(z-b)**2*(cstar*(1+z)+1)/((1+a)**2*(1+b)**2*(1+z)**2))==0
out=dict(all_passed=True,results=res,roundoff_budget_inequalities=True,quartic_symbolic_identity=True,scope='Exact compatibility and endpoint deductions; the full numerical component evaluations have separate completed logs.')
(O/'certificate_links.json').write_text(json.dumps(out,indent=2)+'\n')
for row in res:print(row['m'],row['span'],'margin >',row['margin_printed_inputs'])
print('All exact compatibility, arithmetic, polynomial and forward-error-budget checks passed.')
