from pathlib import Path
import sys,json,runpy,time,hashlib
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle'
sys.path.insert(0,str(A/'mpfr_backend'))
import mpfr_interval as mpiv
sys.modules['flint']=mpiv
m=int(sys.argv[1]);sources={2:B/'continued/m2_fine.json',3:B/'continuation_next/m3_finer.json',4:B/'accurate/m4.json',5:B/'accurate/m5.json'}
out=A/'mpfr_runs';out.mkdir(exist_ok=True);trial=out/f'm{m}.json';trial.write_bytes(sources[m].read_bytes())
print(json.dumps({'stage':'independent_scalar_backend','m':m,'MPFR':mpiv.L.iv_version().decode(),'input_sha256':hashlib.sha256(trial.read_bytes()).hexdigest(),'source':str(sources[m])}),flush=True)
ns=runpy.run_path(str(B/'continued/run_quotient.py'),run_name='mpfr_quotient_driver')
ns['run'](str(trial))
cert=trial.with_suffix('.interval_certificate.json');v=json.loads(cert.read_text());v['backend']='MPFR '+mpiv.L.iv_version().decode()+' endpoint directed intervals, independent special-function evaluator; audited retained outward binary64 Fourier interpolation and signed integration kernels';v['verification_time']=time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime());cert.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'stage':'complete','m':m,'Q_lower':v['Q_lower']}),flush=True)
