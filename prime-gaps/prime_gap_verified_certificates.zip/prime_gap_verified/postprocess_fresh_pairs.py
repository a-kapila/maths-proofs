from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';O=A/'verified_final';O.mkdir(exist_ok=True)
sys.set_int_max_str_digits(0);sys.path.insert(0,str(B/'four_moment'));import postprocess as pp
for m in map(int,sys.argv[1:] or [2,3]):
 start=time.time();v=pp.hp.inputs(m);raw=pp.load_raw(m);qq=json.load(open(A/f'mpfr_runs/m{m}.interval_certificate.json'));tt=json.load(open(A/f'mpfr_runs/m{m}.json'))
 for key in ['k','theta','beta','relative_shift','basis','profiles']:assert tt[key]==v['tr'][key],key
 assert [F(tt['delta'])*x for x in tt['E']]==v['edges']
 if m==2:
  su=json.load(open(A/'mpfr_support/m2_k2305_support.json'));loss=F(su['restriction']['loss_upper']);bad=F(*map(int,su['removed_mass_upper']))
 else:
  su=json.load(open(A/'mpfr_support/m3_arithmetic.json'));loss=F(su['loss_upper']) if 'loss_upper' in su else F(su['support']['loss_upper']);sm=json.load(open(A/'mpfr_support/m3_support_mass.json'));bad=F(*map(int,sm['removed_mass_upper']))
 dl,du=F(qq['den_lower']),F(qq['den_upper']);v['q']=F(qq['Q_lower'])-loss
 v['src']['den_upper']=[du.numerator,du.denominator];v['src']['removed_square_mass_upper']=[bad.numerator,bad.denominator]
 # Norms are fresh independently directed MPFR quotient denominators.
 pp.norm.norm_endpoints=lambda vv,dl=dl,du=du:(dl,du)
 old=json.load(open(B/f'abel_pair/norm_m{m}_result.json'));eta=pp.ab.frac(old['eta']);a0=pp.ab.frac(old['intercept']);nodes=json.load(open(B/f'four_moment/m{m}_nodes.json'))
 rho=v['rho'];sig=v['sigma'];z=2*rho*sig
 print(json.dumps({'stage':'fresh_pair_postprocess','m':m,'source_q':float(v['q']),'loss':float(loss),'bad_mass':float(bad)}),flush=True)
 rr=pp.estimate(m,v,raw,eta,z,a0,node_plan=nodes);pair=rr['pair_upper'];BD={2:7,3:3639}[m];D={2:19844,3:1357780}[m]
 margin=rho*v['q']-m-BD*pair
 lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);sr=pp.estimate(m,v,raw,eta,lam*sig/b,a0,node_plan=nodes);smargin=lam*v['q']-m-BD*sr['pair_upper']
 assert margin>0 and smargin>0,(m,float(margin),float(smargin))
 ratio=(rho*v['q']-m)/pair
 out={'m':m,'source_k':v['k'],'K':v['k'],'span':D,'long_pairs':BD,'rho':rho,'sigma':sig,'beta_lower':F(0),'eta':eta,'intercept':a0,'quotient_lower_before_loss':F(qq['Q_lower']),'support_loss_upper':loss,'q_lower':v['q'],'den_lower':dl,'den_upper':du,'removed_square_mass_upper':bad,'pair_upper':pair,'surplus':rho*v['q']-m,'margin':margin,'strict_margin':smargin,'ratio':ratio,'budget':(ratio.numerator-1)//ratio.denominator,'pair_calculation':rr,'strict_pair_calculation':sr,'elapsed_seconds':time.time()-start,'backend':'Independent MPFR endpoint enclosures; all acceptance arithmetic rational','new_moment_source':str(A/f'mpfr_pair_moments/m{m}_summary.json')}
 (O/f'm{m}_final.json').write_text(json.dumps(pp.rad.old.encode(out),indent=2)+'\n')
 print(json.dumps({'stage':'completed_final','m':m,'Q_lower':qq['Q_lower'],'pair_upper':float(pair),'margin':float(margin),'strict_margin':float(smargin),'budget':out['budget'],'elapsed':time.time()-start}),flush=True)
