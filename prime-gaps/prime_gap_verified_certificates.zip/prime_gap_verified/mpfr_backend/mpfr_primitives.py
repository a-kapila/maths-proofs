from pathlib import Path
import ctypes as ct,math,tempfile,time,json
import numpy as np
from mpfr_interval import arb,ctx
L=ct.CDLL(str(Path(__file__).with_name('libinterval_new.so')))
L.iv_fill_primitives.argtypes=[ct.c_long,ct.c_double,ct.c_double,ct.c_double,ct.c_double,ct.c_long,ct.c_long,ct.c_int,ct.c_void_p,ct.c_void_p,ct.c_long];L.iv_fill_primitives.restype=ct.c_int

def block_table(k,theta,beta,shift,delta,first,count,pmax,prec=256):
 assert k<2**53 and first+count<2**53 and math.frexp(delta)[0]==.5
 lo=np.empty((pmax+1,count));hi=np.empty_like(lo)
 status=L.iv_fill_primitives(k,theta,beta,shift,delta,first,count,pmax,lo.ctypes.data,hi.ctypes.data,prec)
 assert status==0,status
 return lo,hi

def make_tables(d,cdf,block=2**16,directory=None):
 from shifted_core import setup
 ctx.prec=256;S=setup(d['k'],d['theta'],d['beta'],d['relative_shift']);nmax=math.ceil(float(S['T'].upper())/d['delta'])+2;pmax=max(d['powers']);assert d['powers']==list(range(1,pmax+1));dr=Path(directory or tempfile.mkdtemp(prefix='mpfr_primitives_'))
 dr.mkdir(exist_ok=True);tabs=[tuple(np.memmap(dr/f'p{p}_{side}.bin',dtype='float64',mode='w+',shape=nmax+1) for side in ['lo','hi']) for p in range(pmax+1)];start=time.time()
 for first in range(0,nmax+1,block):
  last=min(first+block,nmax+1);lo,hi=block_table(d['k'],d['theta'],d['beta'],d['relative_shift'],d['delta'],first,last-first,pmax)
  for p in range(pmax+1):tabs[p][0][first:last]=lo[p];tabs[p][1][first:last]=hi[p]
 for pair in tabs:
  for a in pair:a.flush()
 print(json.dumps({'stage':'independent_MPFR_primitives','points':nmax+1,'powers':pmax+1,'seconds':time.time()-start}),flush=True)
 return tabs,S['m2'],S
