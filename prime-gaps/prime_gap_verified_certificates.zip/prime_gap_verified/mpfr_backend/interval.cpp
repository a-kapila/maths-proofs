// Directed-rounding interval kernel backed by the system MPFR library.
// The minimal MPFR declarations below follow MPFR 4.x's public C ABI.
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <gmp.h>
extern "C" {
typedef long mpfr_prec_t; typedef long mpfr_exp_t; typedef int mpfr_sign_t;
typedef struct {mpfr_prec_t _mpfr_prec; mpfr_sign_t _mpfr_sign; mpfr_exp_t _mpfr_exp; mp_limb_t *_mpfr_d;} __mpfr_struct;
typedef __mpfr_struct mpfr_t[1]; typedef __mpfr_struct *mpfr_ptr; typedef const __mpfr_struct *mpfr_srcptr;
typedef enum {MPFR_RNDN=0, MPFR_RNDZ=1, MPFR_RNDU=2, MPFR_RNDD=3, MPFR_RNDA=4, MPFR_RNDF=5} mpfr_rnd_t;
void mpfr_init2(mpfr_ptr,mpfr_prec_t); void mpfr_clear(mpfr_ptr);
int mpfr_set(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_set_d(mpfr_ptr,double,mpfr_rnd_t); int mpfr_set_si(mpfr_ptr,long,mpfr_rnd_t); int mpfr_set_str(mpfr_ptr,const char*,int,mpfr_rnd_t); void mpfr_set_nan(mpfr_ptr);
int mpfr_add(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_sub(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_mul(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_div(mpfr_ptr,mpfr_srcptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_neg(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t);
int mpfr_sqrt(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_log(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_exp(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_sin(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_cos(mpfr_ptr,mpfr_srcptr,mpfr_rnd_t); int mpfr_pow_si(mpfr_ptr,mpfr_srcptr,long,mpfr_rnd_t);
int mpfr_cmp(mpfr_srcptr,mpfr_srcptr); int mpfr_cmp_si(mpfr_srcptr,long); int mpfr_number_p(mpfr_srcptr); int mpfr_const_pi(mpfr_ptr,mpfr_rnd_t); int mpfr_const_euler(mpfr_ptr,mpfr_rnd_t); double mpfr_get_d(mpfr_srcptr,mpfr_rnd_t); const char *mpfr_get_version(void);
char *mpfr_get_str(char*,mpfr_exp_t*,int,size_t,mpfr_srcptr,mpfr_rnd_t);void mpfr_free_str(char*);
}
struct interval { mpfr_t lo,hi; long prec; explicit interval(long p):prec(p){mpfr_init2(lo,p);mpfr_init2(hi,p);} ~interval(){mpfr_clear(lo);mpfr_clear(hi);} };
static constexpr mpfr_rnd_t DN=MPFR_RNDD, UP=MPFR_RNDU, NE=MPFR_RNDN;
extern "C" {
void *iv_new(long p){return new interval(p);} void iv_free(void *p){delete (interval*)p;}
const char* iv_version(){return mpfr_get_version();}
void iv_set_double(interval*r,double x){mpfr_set_d(r->lo,x,DN);mpfr_set_d(r->hi,x,UP);}
int iv_set_string(interval*r,const char*x){int a=mpfr_set_str(r->lo,x,10,DN),b=mpfr_set_str(r->hi,x,10,UP);return a||b;}
void iv_copy(interval*r,const interval*a){mpfr_set(r->lo,a->lo,DN);mpfr_set(r->hi,a->hi,UP);}
void iv_bounds(interval*r,const interval*a,const interval*b){mpfr_set(r->lo,a->lo,DN);mpfr_set(r->hi,b->hi,UP);}
void iv_add(interval*r,const interval*a,const interval*b){mpfr_add(r->lo,a->lo,b->lo,DN);mpfr_add(r->hi,a->hi,b->hi,UP);}
void iv_sub(interval*r,const interval*a,const interval*b){mpfr_sub(r->lo,a->lo,b->hi,DN);mpfr_sub(r->hi,a->hi,b->lo,UP);}
void iv_neg(interval*r,const interval*a){mpfr_neg(r->lo,a->hi,DN);mpfr_neg(r->hi,a->lo,UP);}
void iv_mul(interval*r,const interval*a,const interval*b){mpfr_t t;mpfr_init2(t,r->prec);mpfr_srcptr aa[]={a->lo,a->hi},bb[]={b->lo,b->hi};mpfr_mul(r->lo,aa[0],bb[0],DN);mpfr_mul(r->hi,aa[0],bb[0],UP);for(int i=0;i<2;++i)for(int j=0;j<2;++j){mpfr_mul(t,aa[i],bb[j],DN);if(mpfr_cmp(t,r->lo)<0)mpfr_set(r->lo,t,DN);mpfr_mul(t,aa[i],bb[j],UP);if(mpfr_cmp(t,r->hi)>0)mpfr_set(r->hi,t,UP);}mpfr_clear(t);}
void iv_div(interval*r,const interval*a,const interval*b){if(mpfr_cmp_si(b->lo,0)<=0 && mpfr_cmp_si(b->hi,0)>=0){mpfr_set_nan(r->lo);mpfr_set_nan(r->hi);return;}mpfr_t t;mpfr_init2(t,r->prec);mpfr_srcptr aa[]={a->lo,a->hi},bb[]={b->lo,b->hi};mpfr_div(r->lo,aa[0],bb[0],DN);mpfr_div(r->hi,aa[0],bb[0],UP);for(int i=0;i<2;++i)for(int j=0;j<2;++j){mpfr_div(t,aa[i],bb[j],DN);if(mpfr_cmp(t,r->lo)<0)mpfr_set(r->lo,t,DN);mpfr_div(t,aa[i],bb[j],UP);if(mpfr_cmp(t,r->hi)>0)mpfr_set(r->hi,t,UP);}mpfr_clear(t);}
void iv_abs(interval*r,const interval*a){if(mpfr_cmp_si(a->lo,0)>=0){iv_copy(r,a);return;}if(mpfr_cmp_si(a->hi,0)<=0){iv_neg(r,a);return;}mpfr_set_si(r->lo,0,DN);mpfr_neg(r->hi,a->lo,UP);if(mpfr_cmp(a->hi,r->hi)>0)mpfr_set(r->hi,a->hi,UP);}
void iv_pow(interval*r,const interval*a,long n){if(n<0){interval t(r->prec),one(r->prec);iv_pow(&t,a,-n);iv_set_double(&one,1);iv_div(r,&one,&t);return;}if(n==0){iv_set_double(r,1);return;}if(n%2==1){mpfr_pow_si(r->lo,a->lo,n,DN);mpfr_pow_si(r->hi,a->hi,n,UP);return;}interval t(r->prec);iv_abs(&t,a);mpfr_pow_si(r->lo,t.lo,n,DN);mpfr_pow_si(r->hi,t.hi,n,UP);}
void iv_sqrt(interval*r,const interval*a){mpfr_sqrt(r->lo,a->lo,DN);mpfr_sqrt(r->hi,a->hi,UP);}
void iv_log(interval*r,const interval*a){mpfr_log(r->lo,a->lo,DN);mpfr_log(r->hi,a->hi,UP);}
void iv_exp(interval*r,const interval*a){mpfr_exp(r->lo,a->lo,DN);mpfr_exp(r->hi,a->hi,UP);}
void iv_endpoint(interval*r,const interval*a,int side){mpfr_srcptr t=side<0?a->lo:a->hi;mpfr_set(r->lo,t,DN);mpfr_set(r->hi,t,UP);}
void iv_mid(interval*r,const interval*a){mpfr_t two;mpfr_init2(two,r->prec);mpfr_set_si(two,2,NE);mpfr_add(r->lo,a->lo,a->hi,NE);mpfr_div(r->lo,r->lo,two,NE);mpfr_set(r->hi,r->lo,NE);mpfr_clear(two);}
void iv_radius(interval*r,const interval*a){interval mid(r->prec);iv_mid(&mid,a);mpfr_t t;mpfr_init2(t,r->prec);mpfr_sub(r->hi,mid.lo,a->lo,UP);mpfr_sub(t,a->hi,mid.hi,UP);if(mpfr_cmp(t,r->hi)>0)mpfr_set(r->hi,t,UP);mpfr_set(r->lo,r->hi,NE);mpfr_clear(t);}
void iv_trig(interval*r,const interval*a,int cosine){interval mid(r->prec),rad(r->prec);iv_mid(&mid,a);iv_radius(&rad,a);if(cosine){mpfr_cos(r->lo,mid.lo,DN);mpfr_cos(r->hi,mid.hi,UP);}else{mpfr_sin(r->lo,mid.lo,DN);mpfr_sin(r->hi,mid.hi,UP);}mpfr_sub(r->lo,r->lo,rad.hi,DN);mpfr_add(r->hi,r->hi,rad.hi,UP);if(mpfr_cmp_si(r->lo,-1)<0)mpfr_set_si(r->lo,-1,DN);if(mpfr_cmp_si(r->hi,1)>0)mpfr_set_si(r->hi,1,UP);}
void iv_const(interval*r,int euler){if(euler){mpfr_const_euler(r->lo,DN);mpfr_const_euler(r->hi,UP);}else{mpfr_const_pi(r->lo,DN);mpfr_const_pi(r->hi,UP);}}
int iv_compare(const interval*a,const interval*b,int op){switch(op){case 0:return mpfr_cmp(a->hi,b->lo)<0;case 1:return mpfr_cmp(a->hi,b->lo)<=0;case 2:return mpfr_cmp(a->lo,b->hi)>0;case 3:return mpfr_cmp(a->lo,b->hi)>=0;case 4:return mpfr_cmp(a->lo,b->lo)==0&&mpfr_cmp(a->hi,b->hi)==0;case 5:return mpfr_cmp(a->lo,b->lo)<=0&&mpfr_cmp(a->hi,b->hi)>=0;}return 0;}
int iv_finite(const interval*a){return mpfr_number_p(a->lo)&&mpfr_number_p(a->hi);}
double iv_double(const interval*a,int side){if(side<0)return mpfr_get_d(a->lo,DN);if(side>0)return mpfr_get_d(a->hi,UP);interval mid(a->prec);iv_mid(&mid,a);return mpfr_get_d(mid.lo,NE);}
// Return an exact dyadic endpoint as a base-2 integer mantissa and exponent.
char* iv_digits(const interval*a,int side, long*exponent){mpfr_exp_t e;char*s=mpfr_get_str(NULL,&e,2,0,side<0?a->lo:a->hi,NE);*exponent=e;return s;}
void iv_free_digits(char*s){mpfr_free_str(s);}
}
// Independently enclose the entire primitive table in MPFR, rather than
// evaluating the logarithm/recurrences with widened binary64 operations.
// Output row p is integral_0^min(T,j*delta) (t/T)^p g(t) dt.
extern "C" int iv_fill_primitives(long k,double theta,double beta,double shift,
 double delta,long first,long count,int maxp,double* lo,double* hi,long prec) {
 interval kk(prec),lg(prec),cc(prec),bb(prec),TT(prec),AA(prec),one(prec),th(prec),be(prec),rr(prec);
 interval t1(prec),t2(prec),t3(prec),t4(prec),w(prec),wp(prec),wn(prec),tp(prec),tn(prec),jcur(prec),jn(prec),gg(prec),pp(prec),cb(prec),grid(prec);
 iv_set_double(&kk,(double)k);iv_set_double(&one,1.0);iv_log(&lg,&kk);iv_set_double(&th,theta);iv_set_double(&be,beta);iv_set_double(&rr,shift);
 iv_div(&cc,&th,&lg);iv_div(&TT,&be,&lg);iv_sub(&bb,&kk,&one);iv_mul(&t1,&bb,&TT);iv_add(&t2,&cc,&t1);iv_div(&AA,&rr,&t2);iv_div(&cb,&cc,&bb);
 for(long ii=0;ii<count;++ii) {
  long j=first+ii;double x=(double)j*delta; // j<2^53, delta exact power of two.
  iv_set_double(&grid,x);mpfr_set(w.lo,mpfr_cmp(grid.lo,TT.lo)<0?grid.lo:TT.lo,DN);mpfr_set(w.hi,mpfr_cmp(grid.hi,TT.hi)<0?grid.hi:TT.hi,UP);
  iv_mul(&t1,&bb,&w);iv_div(&t2,&t1,&cc);iv_add(&t3,&one,&t2);iv_log(&t4,&t3);iv_div(&jcur,&t4,&bb);
  iv_mul(&t1,&AA,&w);iv_add(&gg,&jcur,&t1);
  lo[ii]=std::max(0.0,mpfr_get_d(gg.lo,DN));hi[ii]=std::max(0.0,mpfr_get_d(gg.hi,UP));
  iv_copy(&wp,&w);iv_copy(&tp,&TT);
  for(int p=1;p<=maxp;++p) {
   iv_set_double(&pp,(double)p);iv_mul(&t1,&bb,&pp);iv_div(&t2,&wp,&t1);iv_mul(&t3,&cb,&jcur);iv_sub(&jn,&t2,&t3);
   iv_mul(&wn,&wp,&w);iv_set_double(&pp,(double)(p+1));iv_mul(&t1,&AA,&wn);iv_div(&t2,&t1,&pp);iv_add(&t3,&jn,&t2);iv_div(&gg,&t3,&tp);
   lo[(long)p*count+ii]=std::max(0.0,mpfr_get_d(gg.lo,DN));hi[(long)p*count+ii]=std::max(0.0,mpfr_get_d(gg.hi,UP));
   if(!iv_finite(&gg) || lo[(long)p*count+ii]>hi[(long)p*count+ii]) return p;
   iv_copy(&jcur,&jn);iv_copy(&wp,&wn);iv_mul(&tn,&tp,&TT);iv_copy(&tp,&tn);
  }
 }
 return 0;
}
