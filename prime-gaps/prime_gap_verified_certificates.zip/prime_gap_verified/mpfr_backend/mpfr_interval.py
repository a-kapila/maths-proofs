"""Independent endpoint interval backend using MPFR directed rounding.

This is not FLINT/Arb. The small compatibility API matches the retained
certificate's imports, while every elementary operation uses MPFR.
"""
from __future__ import annotations
import ctypes as ct
import math
from fractions import Fraction
from pathlib import Path
L=ct.CDLL(str(Path(__file__).with_name('libinterval.so')))
P=ct.c_void_p
L.iv_new.argtypes=[ct.c_long];L.iv_new.restype=P
L.iv_free.argtypes=[P]
L.iv_version.restype=ct.c_char_p
for name in ['copy','neg','abs','sqrt','log','exp','mid','radius']:
 getattr(L,'iv_'+name).argtypes=[P,P]
for name in ['add','sub','mul','div','bounds']:
 getattr(L,'iv_'+name).argtypes=[P,P,P]
for name in ['endpoint','trig']:
 getattr(L,'iv_'+name).argtypes=[P,P,ct.c_int]
L.iv_const.argtypes=[P,ct.c_int]
L.iv_set_double.argtypes=[P,ct.c_double]
L.iv_set_string.argtypes=[P,ct.c_char_p];L.iv_set_string.restype=ct.c_int
L.iv_pow.argtypes=[P,P,ct.c_long]
L.iv_compare.argtypes=[P,P,ct.c_int];L.iv_compare.restype=ct.c_int
L.iv_finite.argtypes=[P];L.iv_finite.restype=ct.c_int
L.iv_double.argtypes=[P,ct.c_int];L.iv_double.restype=ct.c_double
L.iv_digits.argtypes=[P,ct.c_int,ct.POINTER(ct.c_long)];L.iv_digits.restype=P
L.iv_free_digits.argtypes=[P]
class Context:
 prec=256
ctx=Context()
def _new():
 obj=object.__new__(arb);obj.p=L.iv_new(ctx.prec);return obj
class arb:
 __slots__=('p',)
 def __init__(self,x=0):
  self.p=L.iv_new(ctx.prec)
  if isinstance(x,arb):L.iv_copy(self.p,x.p)
  else:
   if hasattr(x,'item'):x=x.item()
   if isinstance(x,float):L.iv_set_double(self.p,x)
   elif isinstance(x,(str,int)):
    if '/' in str(x):
     v=Fraction(str(x));y=arb(v.numerator)/arb(v.denominator);L.iv_copy(self.p,y.p)
    elif L.iv_set_string(self.p,str(x).encode()):raise ValueError(x)
   elif isinstance(x,Fraction):
    v=arb(x.numerator)/arb(x.denominator);L.iv_copy(self.p,v.p)
   else:raise TypeError(type(x))
 def __del__(self):
  p=getattr(self,'p',None)
  if p:L.iv_free(p)
 def _op(self,b,name):
  if isinstance(b,acb):return NotImplemented
  b=b if isinstance(b,arb) else arb(b);r=_new();getattr(L,'iv_'+name)(r.p,self.p,b.p);return r
 def _unary(self,name):
  r=_new();getattr(L,'iv_'+name)(r.p,self.p);return r
 def __add__(self,b):return self._op(b,'add')
 __radd__=__add__
 def __sub__(self,b):return self._op(b,'sub')
 def __rsub__(self,b):return arb(b)._op(self,'sub')
 def __mul__(self,b):return self._op(b,'mul')
 __rmul__=__mul__
 def __truediv__(self,b):return self._op(b,'div')
 def __rtruediv__(self,b):return arb(b)._op(self,'div')
 def __pow__(self,n):
  if hasattr(n,'item'):n=n.item()
  if not isinstance(n,int):
   if isinstance(n,arb) and n.lower_fraction()==n.upper_fraction() and n.lower_fraction().denominator==1:n=n.lower_fraction().numerator
   else:raise TypeError(('noninteger power',n))
  r=_new();L.iv_pow(r.p,self.p,n);return r
 def __neg__(self):return self._unary('neg')
 def __abs__(self):return self._unary('abs')
 def __float__(self):return L.iv_double(self.p,0)
 def _cmp(self,b,op):
  if isinstance(b,acb):return False
  b=b if isinstance(b,arb) else arb(b);return bool(L.iv_compare(self.p,b.p,op))
 def __lt__(self,b):return self._cmp(b,0)
 def __le__(self,b):return self._cmp(b,1)
 def __gt__(self,b):return self._cmp(b,2)
 def __ge__(self,b):return self._cmp(b,3)
 def __eq__(self,b):
  try:return self._cmp(b,4)
  except (ValueError,TypeError):return False
 def __bool__(self):return not self==0
 def contains(self,b):return self._cmp(b,5)
 def __repr__(self):return '[%s,%s]'%(L.iv_double(self.p,-1),L.iv_double(self.p,1))
 def lower(self):r=_new();L.iv_endpoint(r.p,self.p,-1);return r
 def upper(self):r=_new();L.iv_endpoint(r.p,self.p,1);return r
 def mid(self):return self._unary('mid')
 def rad(self):return self._unary('radius')
 def abs_upper(self):return abs(self).upper()
 def sqrt(self):return self._unary('sqrt')
 def log(self):return self._unary('log')
 def exp(self):return self._unary('exp')
 def sin_cos(self):
  s,c=_new(),_new();L.iv_trig(s.p,self.p,0);L.iv_trig(c.p,self.p,1);return s,c
 def union(self,b):
  b=arb(b);r=_new();lo=self if self.lower()<=b.lower() else b;hi=self if self.upper()>=b.upper() else b;L.iv_bounds(r.p,lo.p,hi.p);return r
 def is_finite(self):return bool(L.iv_finite(self.p))
 def _frac(self,side):
  e=ct.c_long();p=L.iv_digits(self.p,side,ct.byref(e))
  try:s=ct.string_at(p).decode()
  finally:L.iv_free_digits(p)
  neg=s.startswith('-');s=s.lstrip('-');v=int(s,2)*(-1 if neg else 1);exp=e.value-len(s)
  return Fraction(v<<exp) if exp>=0 else Fraction(v,1<<(-exp))
 def lower_fraction(self):return self._frac(-1)
 def upper_fraction(self):return self._frac(1)
 @staticmethod
 def pi():r=_new();L.iv_const(r.p,0);return r
 @staticmethod
 def euler():r=_new();L.iv_const(r.p,1);return r
 def expint(self,n):
  assert n==1 and self>0
  old=ctx.prec
  try:
   ctx.prec=max(640,old);m=self.mid();rad=abs(self-m).abs_upper();v=_real_e1(m);err=rad*(-self.lower()).exp()/self.lower();return v+sym(err)
  finally:ctx.prec=old
 def ei(self):
  if self<0:return -(-self).expint(1)
  assert self>0
  old=ctx.prec
  try:
   ctx.prec=max(640,old);m=self.mid();v=_ei(m);err=abs(self-m).abs_upper()*self.upper().exp()/self.lower();return v+sym(err)
  finally:ctx.prec=old

def sym(radius):
 radius=arb(radius).abs_upper();r=_new();lo=-radius;L.iv_bounds(r.p,lo.p,radius.p);return r
class acb:
 __slots__=('real','imag')
 def __init__(self,a=0,b=None):
  if isinstance(a,acb) and b is None:self.real,self.imag=arb(a.real),arb(a.imag)
  elif isinstance(a,complex) and b is None:self.real,self.imag=arb(a.real),arb(a.imag)
  else:self.real,self.imag=arb(a),arb(0 if b is None else b)
 def __add__(self,b):
  b=acb(b);return acb(self.real+b.real,self.imag+b.imag)
 __radd__=__add__
 def __sub__(self,b):
  b=acb(b);return acb(self.real-b.real,self.imag-b.imag)
 def __rsub__(self,b):return acb(b)-self
 def __mul__(self,b):
  b=acb(b);return acb(self.real*b.real-self.imag*b.imag,self.real*b.imag+self.imag*b.real)
 __rmul__=__mul__
 def __truediv__(self,b):
  b=acb(b);d=b.real**2+b.imag**2;return acb((self.real*b.real+self.imag*b.imag)/d,(self.imag*b.real-self.real*b.imag)/d)
 def __rtruediv__(self,b):return acb(b)/self
 def __neg__(self):return acb(-self.real,-self.imag)
 def __pow__(self,n):
  n=int(n)
  if n<0:return 1/(self**(-n))
  r=acb(1);v=self
  while n:
   if n&1:r=r*v
   n//=2
   if n:v=v*v
  return r
 def exp(self):
  sn,cs=self.imag.sin_cos();e=self.real.exp();return acb(e*cs,e*sn)
 def abs_upper(self):return (self.real**2+self.imag**2).sqrt().upper()
 def is_finite(self):return self.real.is_finite() and self.imag.is_finite()
 def expint(self,n):
  assert n==1
  if self.imag==0:return acb(self.real.expint(1))
  assert self.real==0 and self.imag<0
  old=ctx.prec
  try:
   ctx.prec=max(640,old);x=-self.imag;m=x.mid();v=_imag_e1(m);err=abs(x-m).abs_upper()/x.lower();return v+acb(sym(err),sym(err))
  finally:ctx.prec=old
 def __repr__(self):return f'{self.real}+i{self.imag}'

def _real_e1(x):
 if x>=128:
  N=128;term=1/x;tot=term
  for j in range(1,N):term=term*(-j)/x;tot=tot+term
  return (-x).exp()*(tot+sym(arb(math.factorial(N))/x**(N+1)))
 term=arb(1);tot=arb(0);tol=arb(2)**-400
 for n in range(1,3000):
  term=term*(-x)/n;tot=tot+term/n;ratio=x/(n+2)
  if ratio<arb(1)/2:
   err=abs(term)*x/((n+1)**2)/(1-ratio)
   if err<tol:return -arb.euler()-x.log()-tot+sym(err)
 raise ArithmeticError('E1 real series did not converge')
def _imag_e1(x):
 if x>=128:
  N=128;term=acb(0,1)/x;tot=term
  for j in range(1,N):term=term*acb(0,-j)/x;tot=tot+term
  err=arb(math.factorial(N))/x**(N+1);v=acb(0,x).exp()*tot;return v+acb(sym(err),sym(err))
 term=acb(1);tot=acb(0);tol=arb(2)**-400
 for n in range(1,3000):
  term=term*acb(0,x)/n;tot=tot+term/n;ratio=x/(n+2)
  if ratio<arb(1)/2:
   err=term.abs_upper()*x/((n+1)**2)/(1-ratio)
   if err<tol:return acb(-arb.euler()-x.log(),arb.pi()/2)-tot+acb(sym(err),sym(err))
 raise ArithmeticError('E1 imaginary series did not converge')
def _ei(x):
 term=arb(1);tot=arb(0);tol=arb(2)**-400
 for n in range(1,3000):
  term=term*x/n;tot=tot+term/n;ratio=x/(n+2)
  if ratio<arb(1)/2:
   err=abs(term)*x/((n+1)**2)/(1-ratio)
   if err<tol:return arb.euler()+x.log()+tot+sym(err)
 raise ArithmeticError('Ei series did not converge')
if __name__=='__main__':
 ctx.prec=256
 print('MPFR',L.iv_version().decode())
 print('pi',arb.pi())
 print('sqrt2',arb(2).sqrt())
 print('E1(1)',arb(1).expint(1))
 print('E1(-i)',acb(0,-1).expint(1))
 print('Ei(1)',arb(1).ei())
 print('exp(i)',acb(0,1).exp())
 print('endpoints',(arb(1)/3).lower_fraction(),(arb(1)/3).upper_fraction())
