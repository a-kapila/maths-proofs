"""Verify the distributed source/data before any output is regenerated."""
from pathlib import Path
import hashlib,json
A=Path(__file__).resolve().parent
j=json.load(open(A/'MANIFEST.json'))
for rel,digest in j['files'].items():
 p=A/rel
 assert p.is_file(),('missing input',rel)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,('changed input',rel)
print('Manifest verified:',len(j['files']),'files')
