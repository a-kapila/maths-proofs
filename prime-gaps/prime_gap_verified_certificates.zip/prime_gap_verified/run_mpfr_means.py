from pathlib import Path
from fractions import Fraction as F
import sys,json,time,runpy,shutil
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';O=A/'mpfr_means';O.mkdir(exist_ok=True)
sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as mpiv;sys.modules['flint']=mpiv
sys.path.insert(0,str(B/'continuation'));from capped_mean_general import run
for m,r in [(4,10),(5,4)]:
 print(json.dumps({'stage':'start','m':m,'r':r,'backend':'MPFR 4.2.2'}),flush=True)
 for tail in ('.json','_cdf.npz'):
  p=B/f'continuation/mean_m{m}_r{r}{tail}';shutil.copyfile(p,O/('original_'+p.name))
 run(m,r)
 for tail in ('.json','_cdf.npz'):
  p=B/f'continuation/mean_m{m}_r{r}{tail}';shutil.copyfile(p,O/p.name)
 print(json.dumps({'stage':'complete','m':m}),flush=True)
