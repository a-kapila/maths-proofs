# Current continuation: boundary-aware post-processing

The latest result is **H3 <= 1,358,004**, improving the preceding 1,358,006.
H2 <= 19,844, H4 <= 82,234,788, and H5 <= 4,830,355,416 are unchanged.

Read `abel_pair/README.md` and `abel_pair/proof_note.pdf`.
Authoritative results: `abel_pair/RESULTS.json`.
Run: `bash abel_pair/reproduce.sh`.
Integrity check: `python abel_pair/check_manifest.py`.

Older root-level readmes and result files are retained verbatim for provenance.
All numerical/sieve inputs are inherited except the newly executed exact
post-processing and finite checks. The whole analytic chain is not independently
expert-reviewed or formally verified.
