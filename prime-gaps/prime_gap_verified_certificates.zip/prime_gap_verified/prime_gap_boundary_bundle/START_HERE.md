# Current continuation

Start with radial_pair/README.md and radial_pair/proof_note.pdf.
The new authoritative bounds and status are in radial_pair/RESULTS.json.
Earlier directories and results are retained dependencies and history.
No inherited successful Fourier quotient or tagged-CDF calculation was rerun.
