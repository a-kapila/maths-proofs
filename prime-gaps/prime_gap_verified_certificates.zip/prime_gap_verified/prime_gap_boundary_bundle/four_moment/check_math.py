"""Independent finite/exact checks, supplementary to the mathematical proof."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
import random,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import postprocess as p
rng=random.Random(20261105);counts={}
# Exact pointwise remainder and four-moment extremum comparisons.
count=0
for _ in range(1000):
 a=F(rng.randrange(1,40),rng.randrange(1,70));b=F(rng.randrange(1,40),rng.randrange(1,70));z=F(rng.randrange(60),rng.randrange(1,70))
 q=p.qfour(a,b);c=1+2/(1+a)+2/(1+b)
 rem=z*(z-a)**2*(z-b)**2*(c*(1+z)+1)/((1+a)**2*(1+b)**2*(1+z)**2)
 assert p.peval(q,z)-1/(1+z)**2==rem and rem>=0
 count+=1
counts['exact_quartic_remainders']=count
count=0
for _ in range(300):
 xs=[F(rng.randrange(1,35),40) for j in range(5)];weights=[F(rng.randrange(1,10),10) for j in xs]
 mu=[sum(w*x**j for w,x in zip(weights,xs)) for j in range(5)]
 d=mu[1]*mu[3]-mu[2]**2
 if d==0:continue
 s=(mu[1]*mu[4]-mu[2]*mu[3])/d;pp=(mu[2]*mu[4]-mu[3]**2)/d
 U4=mu[0]-((2*(1+s)**2+s*pp)*mu[1]-(3+2*s+pp)*mu[2])/(1+s+pp)**2
 U2=mu[0]-mu[1]**2*(2*mu[1]+mu[2])/(mu[1]+mu[2])**2
 actual=sum(w/(1+x)**2 for x,w in zip(xs,weights))
 assert actual<=U4<=U2
 count+=1
counts['exact_four_moment_comparisons']=count
count=0
for _ in range(180):
 k=rng.randrange(3,12);raw=[rng.randrange(1,30) for j in range(k)];den=sum(raw)+rng.randrange(5,60)
 ys=[F(y,den) for y in raw];x=sum(ys);eta=F(rng.randrange(100,180),100);a=k*eta;r=1-x
 V={i:sum(y**i for y in ys) for i in range(1,7)}
 tags={1:x,2:V[2],3:V[3],4:V[4],5:V[5],6:V[6],22:V[2]**2,23:V[2]*V[3],24:V[2]*V[4],33:V[3]**2}
 tp=p.pair_polynomials(k,eta)
 for j in range(1,5):
  direct=F(0)
  for ii in range(k):
   for jj in range(ii+1,k):
    u,v=ys[ii],ys[jj];W=(r+a*u)*(r+a*v)+a*a/(2*k)*(u-v)**2
    direct+=W*(u+v)**j
  direct/=F(k*(k-1),2)
  computed=sum(p.peval(poly,x)*tags[tag] for tag,poly in tp[j].items())
  assert computed==direct,(k,j)
  count+=1
counts['exact_pair_moment_identities']=count
count=0
for _ in range(200):
 poly=[F(rng.randrange(-100,100),rng.randrange(1,100)) for _ in range(7)]
 l=F(rng.randrange(900),1000);r=l+F(1,100);z=F(53,100)
 lo,hi=p.rational_range(poly,z,l,r)
 for j in range(11):
  x=l+(r-l)*F(j,10);val=p.peval(poly,x)/(1-z*x)**6
  assert lo<=val<=hi;count+=1
counts['exact_Bernstein_ratio_tests']=count
# Independently enumerate a discrete law to test all 5 new product tags.
sys.path[:0]=[str(p.B/'baseline/polynomial'),str(p.B/'baseline/inherited/analysis')]
from polynomial_core import weights as transform
xs=[F(0),F(1,5),F(3,7)];probs=[F(1,4),F(1,4),F(1,2)]
basekeys=[(),(2,),(3,),(2,2),(2,3),(4,),(2,2,3)]
newtags=[(5,),(6,),(2,3),(2,4),(3,3)];count=0
keys=sorted(set(tuple(sorted(a+b)) for a in basekeys for b in newtags))
for n in [2,3,4]:
 for phase in [[F(1)]*3,[F(1),F(1,2),F(-1,3)]]:
  mu=[sum(w*x**j*t for x,w,t in zip(xs,probs,phase)) for j in range(17)]
  pred=transform(n,mu,keys);actual=[F(0)]*len(keys)
  for ind in product(range(3),repeat=n):
   ys=[xs[i] for i in ind];w=prod(probs[i]*phase[i] for i in ind);V={j:sum(y**j for y in ys) for j in range(2,7)}
   for i,key in enumerate(keys):actual[i]+=w*prod(V[j] for j in key)
  assert pred==actual;count+=len(keys)
counts['exact_positive_product_transform_tests']=count
out=dict(passed=True,counts=counts,scope='Diagnostics supplement exact majorant and interval Fourier remainder proofs.')
(p.O/'exact_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
