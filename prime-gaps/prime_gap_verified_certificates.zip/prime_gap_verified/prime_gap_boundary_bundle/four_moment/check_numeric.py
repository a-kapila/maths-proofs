"""Independent high-precision integral and finite Fourier diagnostics."""
from pathlib import Path
from fractions import Fraction as F
import sys,json
import numpy as np
import mpmath as mp
B=Path(__file__).resolve().parents[1];O=Path(__file__).resolve().parent
sys.path[:0]=[str(B/'direct_mean'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from flint import ctx,acb
from shifted_core import setup
from multi_core import single_moments
from polynomial_core import weights
mp.mp.dps=90;ctx.prec=256
mpv=lambda a:mp.make_mpf(a.x._mpi_[0])
integ=0;fourier=0
for m in [2,3]:
 tp=B/('trials/m2_final.json' if m==2 else 'focus23/m3_fine.json');tr=json.load(open(tp));k=tr['k']
 sig=1+F(tr['delta'])*tr['eps_cells'];S=setup(k,tr['theta'],tr['beta'],tr['relative_shift'])
 meta=json.load(open(O/f'm{m}_raw_cdf.json'));keys=[tuple(x) for x in meta['keys']];jmax=max(map(sum,keys))
 c=mp.mpf(tr['theta'])/mp.log(k);T=mp.mpf(tr['beta'])/mp.log(k);b=k-1;A=mp.mpf(tr['relative_shift'])/(c+b*T)
 L=mp.log1p(b*T/c);norm=(1/c-1/(c+b*T))/b+2*A*L/b+A*A*T
 for xi in [0,3,30]:
  mu=single_moments(S,jmax,'zero') if xi==0 else single_moments(S,jmax,'fourier',xi)
  for j in [5,6,jmax]:
   def f(y):
    x=c*mp.expm1(y)/b;dx=c*mp.exp(y)/b
    return (x/T)**j*(1/(c+b*x)+A)**2*mp.exp(1j*xi*x)*dx/norm
   val=mp.quad(f,[0,L/4,L/2,3*L/4,L]);enc=acb(mu[j])
   assert mpv(enc.real.lower())<=val.real<=mpv(enc.real.upper()),(m,xi,j,'real')
   assert mpv(enc.imag.lower())<=val.imag<=mpv(enc.imag.upper()),(m,xi,j,'imag')
   integ+=1
 dat=np.load(O/f'm{m}_raw_cdf.npz');C=dat['C'];mu=single_moments(S,jmax);mass=weights(k,mu,keys)
 # Use all positive moment transforms at two cell boundaries, summing the
 # finite series independently in 90-digit arithmetic.
 for at in [300,500]:
  y=mp.mpf(float(dat['y'][at]));ph=[mp.exp(-1j*2*mp.pi/8*y*j) for j in range(1,C.shape[1]+1)]
  for row in range(len(keys)):
   cc=[mp.mpc(float(v.real),float(v.imag)) for v in C[row]]
   val=mpv(mass[row].mid())*y/8+2*mp.fsum(v.real for v in cc)-2*mp.fsum((v*p).real for v,p in zip(cc,ph))
   assert mp.mpf(float(dat['L'][row,at]))<=val<=mp.mpf(float(dat['V'][row,at])),(m,row,at)
   fourier+=1
 print(json.dumps(dict(m=m,integrals=integ,finite_fourier=fourier)),flush=True)
out=dict(passed=True,integrals=integ,finite_Fourier_comparisons=fourier,mp_digits=90,scalar_interval_bits=256,scope='Supplementary comparisons; no proof of error bounds is inferred from tests.')
(O/'numeric_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)
