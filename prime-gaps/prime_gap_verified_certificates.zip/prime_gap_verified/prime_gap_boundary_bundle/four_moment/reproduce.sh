#!/usr/bin/env bash
# Reproduce the new deductions from the retained cumulative archive.
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
MODE="${1:---checks-only}"
case "$MODE" in
  --checks-only|--full) ;;
  *) printf 'Usage: %s [--checks-only|--full]\n' "$0" >&2; exit 2 ;;
esac
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
export PYTHONUNBUFFERED=1
python four_moment/check_manifest.py
if [[ "$MODE" == "--full" ]]; then
  # Disable contraction/fast-math; the retained error analysis assumes these
  # ordinary arithmetic operations. The check-only path builds its own
  # independent integer-verification executables in verify.py.
  g++ -O3 -std=c++17 -shared -fPIC -ffp-contract=off \
    analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
  g++ -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off \
    progress/profile_parallel.cpp -o progress/profile_parallel.so
  g++ -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off \
    new/fft_native.cpp -o new/fft_native_lib.so
  python four_moment/new_moments.py 2
  python four_moment/new_moments.py 3
  python continued/run_quotient.py four_moment/m3_quotient_fine.json
fi
python four_moment/check_math.py
python four_moment/check_numeric.py
python four_moment/verify.py
printf '\nPASS: new exact deductions, diagnostics, complete tuple checks, and pair counts.\n'
printf 'This does not independently audit the inherited sieve or numerical-error proofs.\n'
