"""Verify archive inputs before computations can overwrite generated outputs."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "four_moment/MANIFEST.json").read_text())
for rel, expected in manifest["sha256"].items():
    path = root / rel
    if not path.is_file():
        raise FileNotFoundError(f"Missing archive entry: {rel}")
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise ValueError(f"Hash mismatch: {rel}")
print(f"MANIFEST PASS: {len(manifest['sha256'])} files")
