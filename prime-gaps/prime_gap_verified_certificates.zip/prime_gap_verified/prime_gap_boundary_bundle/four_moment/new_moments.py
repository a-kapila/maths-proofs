"""Enclose new positive products of coordinate power sums, retaining the
inherited interval Fourier engine. Constant tagging reproduces untagged
positive moment measures exactly: sum_i (1/k) = 1.

All base keys are collected once. The saved output for each tag V_A is
(T/sigma)^sum(A) times the CDF of Z_(A+B). No Monte Carlo is used.
"""
from pathlib import Path
from fractions import Fraction as F
import sys, json, time, hashlib
import numpy as np
B=Path(__file__).resolve().parents[1]; O=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'direct_mean'))
from capped_mean import CappedMeanCDF, ar, arb, acb, ctx, up, down
from multi_core import single_moments
import capped_mean
from polynomial_core import weights as untagged_weights
# Here the tag is identically 1/k and n=k, so its sum is exactly 1.
# Use the already retained untagged set-partition formula directly.
capped_mean.tagged_weights = lambda n,mu,nu,keys: untagged_weights(n,mu,keys)
TAGS=((5,),(6,),(2,3),(2,4),(3,3))

class AllCDF(CappedMeanCDF):
    def __init__(self,tr,sigma):
        super().__init__(tr,sigma)
        self.original_keys=self.keys[:]
        keys={tuple(sorted(a+b)) for a in self.original_keys for b in TAGS}
        self.keys=sorted(keys,key=lambda x:(len(x),x))
        self.co={key:[F(0)]*(len(self.y)-1) for key in self.keys}
        self.jmax=max(map(sum,self.keys))
        self.nmin=self.k-max(map(len,self.keys))-1
        self.J=128
        while True:
            z=self.phi(acb(self.freq*self.J))
            if z.abs_upper()<1 and self.nmin*z.abs_upper().log() < -140:break
            self.J=int(self.J*1.25)+1
            assert self.J<100000
    def moments(self,kind='zero',value=0):
        mu=single_moments(self.S,self.jmax,kind,value)
        return mu,[x/self.k for x in mu]

def run(m):
    ctx.prec=256;start=time.time()
    tp=B/{2:'trials/m2_final.json',3:'focus23/m3_fine.json'}[m]
    tr=json.load(open(tp));sigma=1+F(tr['delta'])*tr['eps_cells']
    cdf=AllCDF(tr,sigma)
    print(json.dumps(dict(stage='start',m=m,keys=len(cdf.keys),base_keys=len(cdf.original_keys),highest_power=cdf.jmax,J=cdf.J)),flush=True)
    cdf.run_setup();cdf.evaluate()
    np.savez_compressed(O/f'm{m}_raw_cdf.npz',y=cdf.y,C=cdf.C,L=cdf.L,V=cdf.V)
    raw=dict(m=m,keys=cdf.keys,precision_bits=ctx.prec,frequencies=cdf.J,tail=cdf.tail,alias=list(map(up,cdf.alias)),cdf_errors=cdf.errors,trial=str(tp.relative_to(B)),trial_sha256=hashlib.sha256(tp.read_bytes()).hexdigest())
    (O/f'm{m}_raw_cdf.json').write_text(json.dumps(raw,indent=2)+'\n')
    for tag in TAGS:
        factor=(cdf.S['T']/ar(sigma))**sum(tag)
        inds=[cdf.keys.index(tuple(sorted(key+tag))) for key in cdf.original_keys]
        ls=[];us=[]
        for ind in inds:
            ls.append([max(0.,down(arb(float(x))*factor)) for x in cdf.L[ind]])
            us.append([up(arb(float(x))*factor) for x in cdf.V[ind]])
        name=''.join(map(str,tag));prefix=O/f'm{m}_power{name}'
        np.savez_compressed(str(prefix)+'_cdf.npz',y=cdf.y,L=np.array(ls),V=np.array(us))
        out=dict(m=m,k=tr['k'],tag=list(tag),moment_keys=cdf.original_keys,source_raw_keys=[cdf.keys[i] for i in inds],source='constant-tag positive moments',normalization_factor_lower=down(factor),normalization_factor_upper=up(factor),precision_bits=ctx.prec,highest_power=cdf.jmax,fourier_frequencies=cdf.J,trial=str(tp.relative_to(B)),trial_sha256=raw['trial_sha256'],sigma=[sigma.numerator,sigma.denominator])
        prefix.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
        print(json.dumps(dict(stage='tag_saved',m=m,tag=name)),flush=True)
    print(json.dumps(dict(stage='complete',m=m,seconds=time.time()-start)),flush=True)
if __name__=='__main__':run(int(sys.argv[1]))
