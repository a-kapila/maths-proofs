"""Four-moment inverse-square majorants and boundary-correlated integration.
All acceptance arithmetic uses Fractions plus the inherited directed rational
interval accumulator. Floating moments choose rational positive interpolation
nodes only; the global polynomial majorant is valid for any such nodes.
"""
from pathlib import Path
from fractions import Fraction as F
from math import comb,sqrt
from collections import defaultdict
import sys,json,hashlib,time
import numpy as np
B=Path(__file__).resolve().parents[1];O=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'abel_pair'))
import normalization as norm
ab=norm.ab;hp=ab.hp;I=ab.I;J=ab.J;rad=ab.rad;base=ab.base
TAGS=(1,2,3,4,22,5,6,23,24,33)

# Exact univariate polynomial arithmetic; ascending powers.
def trim(p):
    p=list(p)
    while len(p)>1 and p[-1]==0:p.pop()
    return p

def add(p,q):
    out=[F(0)]*max(len(p),len(q))
    for i,c in enumerate(p):out[i]+=c
    for i,c in enumerate(q):out[i]+=c
    return trim(out)

def scale(p,s):return trim([c*s for c in p])

def mul(p,q):
    out=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):out[i+j]+=a*b
    return trim(out)

def power(p,n):
    a=[F(1)]
    for _ in range(n):a=mul(a,p)
    return a

def peval(p,x):
    y=F(0)
    for c in reversed(p):y=y*x+c
    return y

def put(dst,key,p):dst[key]=add(dst.get(key,[F(0)]),p)

def vproduct(p,q,k):
    tag=[];degree=0;factor=F(1)
    for a in (p,q):
        if a==0:factor*=k
        elif a==1:degree+=1
        else:tag.append(a)
    return tuple(sorted(tag)),[F(0)]*degree+[factor]

def power_pair(j,k,product=False):
    """Average (yi+yj)^j, or yi*yj*(yi+yj)^j."""
    out={};off=1 if product else 0
    for a in range(j+1):
        key,p=vproduct(a+off,j-a+off,k);put(out,key,scale(p,F(comb(j,a))))
    q=j+2*off
    if q==0:key=();p=[F(k)]
    elif q==1:key=();p=[F(0),F(1)]
    else:key=(q,);p=[F(1)]
    put(out,key,scale(p,-F(2**j)))
    return {key:scale(p,F(1,k*(k-1))) for key,p in out.items()}

def pair_polynomials(k,e):
    out={};a=k*e
    for j in range(1,5):
        v={}
        for src,factor in [(power_pair(j,k),[F(1),-2,F(1)]),
                           (power_pair(j+1,k),[a,-a]),
                           (power_pair(j+2,k),[a*a/(2*k)]),
                           (power_pair(j,k,True),[a*a*(1-F(2,k))])]:
            for key,p in src.items():put(v,key,mul(p,factor))
        row={}
        for key,p in v.items():
            p=trim(p)
            if all(c==0 for c in p):continue
            if not key:
                assert p[0]==0
                put(row,1,p[1:])
            else:put(row,int(''.join(map(str,key))),p)
        assert set(row)<=set(TAGS),(j,set(row))
        out[j]=row
    return out

def bernstein(p,l,r,n):
    """Coefficients of p(l+(r-l)t) in the degree-n Bernstein basis."""
    assert len(p)<=n+1
    h=r-l
    a=[sum((p[q]*comb(q,j)*l**(q-j)*h**j for q in range(j,len(p))),F(0)) for j in range(n+1)]
    return [sum((a[j]*F(comb(i,j),comb(n,j)) for j in range(i+1)),F(0)) for i in range(n+1)]

def rational_range(p,z,l,r,exponent=6):
    """Bernstein ratio hull: denominator Bernstein coefficients are positive."""
    d=power([F(1),-z],exponent);n=max(len(p),len(d))-1
    pn=bernstein(p,l,r,n);pd=bernstein(d,l,r,n)
    assert min(pd)>0
    rr=[a/b for a,b in zip(pn,pd)]
    return min(rr),max(rr)

def qfour(a,b):
    assert a>=0 and b>=0
    s=a+b;p=a*b;d=(1+s+p)**3
    return [F(1),
        -2*(p*p*s+3*p*s*s+6*p*s+3*p+s**3+3*s*s+3*s+1)/d,
        (2*p*p+p*s*s+6*p*s+9*p+3*s**3+9*s*s+9*s+3)/d,
        -2*(p*s+3*s*s+6*s+2)/d,
        (p+3*s+5)/d]

def qtwo(theta):
    assert theta>=0
    return [F(1),-2*(1+3*theta+theta*theta)/(1+theta)**3,(3+theta)/(1+theta)**3,F(0),F(0)]

def load_raw(m):
    cdfs,polynomial,edges=ab.load_cdfs(m)
    for tag in [5,6,23,24,33]:
        stem=O/f'm{m}_power{tag}';meta=json.load(open(stem.with_suffix('.json')))
        tp=B/meta['trial'];assert hashlib.sha256(tp.read_bytes()).hexdigest()==meta['trial_sha256']
        dd=np.load(str(stem)+'_cdf.npz');assert all(F(float(x))==y for x,y in zip(dd['y'],edges))
        cdfs[tag]=([tuple(key) for key in meta['moment_keys']],
            [[F(float(x)) for x in row] for row in dd['L']],
            [[F(float(x)) for x in row] for row in dd['V']])
    return cdfs,polynomial,edges

def cell_moments(raw):
    cdfs,polys,edges=raw;nc=len(edges)-1;out={}
    for tag,(keys,ls,us) in cdfs.items():
        lo=[F(0)]*nc;hi=[F(0)]*nc
        for key,ll,uu in zip(keys,ls,us):
            for j,c in enumerate(polys[key]):
                ml=max(F(0),ll[j+1]-uu[j]);mu=uu[j+1]-ll[j]
                assert 0<=ml<=mu
                lo[j]+=c*(ml if c>=0 else mu);hi[j]+=c*(mu if c>=0 else ml)
        assert all(h>=max(0,l) for l,h in zip(lo,hi))
        out[tag]=[np.array([float(max(0,x)) for x in lo]),np.array(list(map(float,hi)))]
    return out

def nodes_for_cell(j,x,z,tp,cm,oldtheta):
    # Exploratory selection only; positive rational nodes are independently valid.
    mm=[]
    for r in range(1,5):
        v=sum(float(peval(p,F(float(x))))*(cm[tag][0][j]+cm[tag][1][j])/2 for tag,p in tp[r].items())
        mm.append(v*z**r/(1-z*x)**(r+2))
    a,b,c,d=mm
    new=None
    if min(mm)>0 and a*c>b*b:
        delta=a*c-b*b;s=(a*d-b*c)/delta;p=(b*d-c*c)/delta
        if p>0 and s>0 and s*s>4*p:
            root=sqrt(s*s-4*p);n1=2*p/(s+root);n2=(s+root)/2
            if 0<n1<n2<10:
                nodes=[F(max(1,round(t*10**7)),10**7) for t in (n1,n2)]
                q=qfour(*nodes)
                gain=-sum(float(q[t+1])*mm[t] for t in range(4))
                oq=qtwo(oldtheta);oldgain=-sum(float(oq[t+1])*mm[t] for t in range(4))
                if gain>oldgain:new=(nodes,q,mm,gain-oldgain)
    return new

def estimate(m,v,raw,e,z,intercept,save_nodes=False,node_plan=None):
    start=time.time();oldrows,used=norm.coeff_rows(v,e,z,intercept)
    cm=cell_moments(raw);tp=pair_polynomials(v['k'],e)
    cs={tag:[] for tag in TAGS};nodes=[];n4=0;pred=0.
    k=v['k'];sig=v['sigma']
    for j,(left,right) in enumerate(zip(v['edges'][:-1],v['edges'][1:])):
        l=left/sig;r=right/sig
        if l==0 or all(F(h[j])==0 for h in v['tr']['profiles']):
            for tag in TAGS:cs[tag].append(oldrows.get(tag,[F(0)]*len(cm[1][0]))[j] if tag in oldrows else F(0))
            nodes.append(None);continue
        t1=hp.m1_lower(k,e,l,r,v['lo1'][j],v['lows'][j],v['hi3'][j])
        t2=hp.m2_upper(k,e,l,r,v['hi1'][j],v['highs'][j],v['hi3'][j],v['hi22'][j],v['lo4'][j])
        aa=I(z*t1/(1-z*l)**3).lo;bb=I(z*z*t2/(1-z*r)**4).hi
        th=bb/aa if aa>0 else F(1)
        if node_plan is None:
            proposal=nodes_for_cell(j,float((l+r)/2),float(z),tp,cm,th) if aa>0 else None
        else:
            saved=node_plan[j]
            nd=[F(*x) for x in saved] if saved is not None else None
            proposal=(nd,qfour(*nd),None,0.0) if nd is not None else None
        if proposal is None:
            for tag in TAGS:cs[tag].append(oldrows[tag][j] if tag in oldrows else F(0))
            nodes.append(None);continue
        nd,q,mm,gain=proposal;n4+=1;pred+=gain
        nums={tag:[F(0)] for tag in TAGS}
        for order in range(1,5):
            fac=scale(power([F(1),-z],4-order),-q[order]*z**order)
            for tag,p in tp[order].items():nums[tag]=add(nums[tag],mul(p,fac))
        for tag in TAGS:
            low,_=rational_range(nums[tag],z,l,r)
            cs[tag].append(I(low).lo)
        g=lambda x:((1+(e-1)*x)/(1-z*x))**2
        slope=max((g(l)-intercept)/l,(g(r)-intercept)/r)
        cs[1][-1]-=slope
        nodes.append([[a.numerator,a.denominator] for a in nd])
    cdfs,polynomial,edges=raw;total=I(0);parts={}
    for tag in TAGS:
        part=I(0);keys,ll,uu=cdfs[tag]
        for key,lo,hi in zip(keys,ll,uu):
            cc=[t*h for t,h in zip(cs[tag],polynomial[key])]
            part+=I(max(ab.abel_lower(cc,lo,hi),ab.difference_lower(cc,lo,hi)))
        total+=part;parts[str(tag)]=part.lo
    bad=F(*v['src']['removed_square_mass_upper'])
    # The whole majorant (radial line + pair Q) is nonnegative; hence the
    # integrated improvement E satisfies E <= intercept pointwise.
    removal=max(F(0),intercept)*bad
    N=total.lo-removal;dl,du=norm.norm_endpoints(v);assert dl>bad
    den=du if N>=0 else dl-bad
    M=intercept-N/den;jj=J(k,k*e);pair=2*z*z*jj.hi*M
    result=dict(pair_upper=pair,moment_upper=M,numerator_lower=N,denominator_used=den,
       nonzero_quartic_cells=n4,exploratory_unnormalized_extra_gain=pred,
       removed_upper=removal,J_lower=jj.lo,J_upper=jj.hi,by_tag=parts,seconds=time.time()-start)
    if save_nodes:
        (O/f'm{m}_nodes.json').write_text(json.dumps(nodes)+'\n')
    return result

def compute(m):
    started=time.time();v=hp.inputs(m);raw=load_raw(m)
    old=json.load(open(B/f'abel_pair/norm_m{m}_result.json'))
    e=ab.frac(old['eta']);a=ab.frac(old['intercept']);rho=v['rho'];sig=v['sigma'];z=2*rho*sig
    rr=estimate(m,v,raw,e,z,a,True);pair=rr['pair_upper'];sur=rho*v['q']-m
    ratio=sur/pair;budget=(ratio.numerator-1)//ratio.denominator
    out=dict(m=m,k=v['k'],eta=e,intercept=a,rho=rho,sigma=sig,q_lower=v['q'],surplus=sur,
         pair_upper=pair,ratio=ratio,budget=budget,previous_pair=ab.frac(old['pair_upper']),calculation=rr)
    (O/f'm{m}_preliminary.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
    print(json.dumps(dict(m=m,seconds=time.time()-started,pair=float(pair),old_pair=float(out['previous_pair']),budget=budget,ratio=float(ratio),quartic_cells=rr['nonzero_quartic_cells'])),flush=True)
    return out
if __name__=='__main__':compute(int(sys.argv[1]))
