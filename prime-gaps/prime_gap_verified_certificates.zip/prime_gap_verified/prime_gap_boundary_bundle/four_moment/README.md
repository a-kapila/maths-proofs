# Four-moment pair bounds and a finer H3 quotient

## Current deductions

The new directory is `four_moment/`. Earlier directories and their result files
are retained historical dependencies, not the current results table.

Within the inherited sieve and numerical-enclosure framework:

| Quantity | Preceding bound | Current bound |
|---|---:|---:|
| H2 | 19,844 | 19,844 |
| H3 | 1,358,004 | **1,357,812** |
| H4 | 82,234,788 | 82,234,788 |
| H5 | 4,830,355,416 | 4,830,355,416 |

`RESULTS.json` records the final verified values, including both complete finite
checks. `proof_note.pdf` and its LaTeX source explain the new argument.

**Scope:** These are computer-assisted research deductions, not independently
peer-reviewed records, formally verified proofs, or priority claims. The retained
prime-distribution theorem, enlarged-support implication, support-loss analysis,
Fourier error bounds, implementation, and arithmetic model remain dependencies.
The scalar compatibility implementation is mpmath.iv with explicit remainders,
not FLINT/Arb, despite the historical module name `flint.py`.

## What was actually recomputed

1. New positive moment distributions for V5, V6, V2*V3, V2*V4, and V3^2, for the
   saved H2 and H3 symmetric trials. Deduplicated transforms number 60 and 75;
   these supply 70 and 90 normalized tag tables. The highest single-coordinate
   powers are 14 and 16. These are interval Fourier calculations, not sampling.
2. Quartic inverse-square upper majorants with fixed positive rational nodes.
   The acceptance calculation uses the saved `m2_nodes.json` and
   `m3_nodes.json`; no floating-point optimizer is required for reproduction.
3. A fresh finer quotient evaluation of the **same physical H3 trial** at
   dimension 110,070, changing integration spacing from 2^-23 to 2^-25. The
   lower endpoint increases from 11.428771538130004 to 11.428871133926435.
4. Rational scalar deductions, strict-support checks, fixed-residue window
   searches, and complete independent C++ and Python tuple/pair checks.

The successful H2 quotient, both final arithmetic support losses, and the older
weighted distributions were reused, not recomputed. Three new arithmetic
parameter experiments failed their support-loss bounds; their outputs in
`retuned_support.json` are excluded from successful deductions.

## Attribution of the improvement

The four-moment step lowers the pair-cost upper bounds to approximately
1.986930455739631e-5 and 2.185545575923232e-8. With the old quotients it does not
cross a new integer prime-gap threshold.

The finer H3 quotient supplies the actual span improvement. With that quotient,
even the old pair upper bound permits the same span 1,357,812. The quartic
estimate increases the integer pair budget from 3,494 to 3,495 and strengthens
the margin; it does not independently save another two units.

The selected H3 tuple has 110,070 entries, endpoints -627124 and 731882, and
exactly 3,483 pairs of span greater than 1,357,812. Its full diameter is
1,359,006. The cluster length and full tuple diameter are deliberately different.
The exact strict-support sufficient margin exceeds 2.64317e-7.

## Reproduction

Requirements: Python 3 with NumPy, SciPy, and mpmath; a C++17 compiler. Full
numerical recomputation also needs OpenMP. Keep assertions enabled and do not
compile numerical kernels with fast-math. Full evaluation uses several GB of
memory and working storage; reconstructible memory-mapped primitive tables are
excluded from the archive.

From the cumulative archive root:

```bash
bash four_moment/reproduce.sh --checks-only
bash four_moment/reproduce.sh --full
```

`--checks-only` verifies every manifest hash, recomputes exact algebra tests,
independent high-precision diagnostics on saved moment tables, rational endpoint
deductions, fixed-residue window scans, and both complete tuple/pair checks.

`--full` first rebuilds the interval arithmetic kernels, recomputes the new H2/H3
moment tables and the finer H3 quotient, then performs those checks. It does not
rerun the full inherited analytic chain or the unsuccessful arithmetic sweep.
Reproduction commands for older certificates remain in their original folders.

### Important implementation details

- Positive raw product moments use the retained labelled set-partition formula;
  they do not use approximate independent-coordinate models for the final
  squared-trial measure.
- New normalization factors are applied with interval-directed rounding.
- Quartic coefficient bounds use exact Bernstein-ratio cell enclosures. Signed
  polynomial expansions are integrated with the retained boundary-aware Abel
  bounds. All final acceptance comparisons use exact rational endpoints.
- Full physical equality of the finer H3 trial with its source is checked.
- The quotient-only certificate retains its own original arithmetic parameter
  display. The final deduction combines its unrestricted quotient with the
  separately retained retuned loss from `direct_pair/m3_arithmetic.json`.
- Temporary runtimes and the `seconds` field are not mathematical data.
- Outputs are deterministic under the retained arithmetic/platform assumptions;
  passing numerical diagnostics is not a proof of the inherited error analysis.

### Files

- `m*_raw_cdf.*`, `m*_power*.{json,npz}`: new interval moment distributions.
- `m*_nodes.json`: exact rational interpolation nodes.
- `m3_quotient_fine.json`, `.interval_certificate.json`, `.log`: exact finer
  input, completed certificate, and computation log.
- `m*_result.json`: full exact rational endpoint deductions, with strict checks.
- `m*_tuple.txt`, `m*_witness.csv`, `m*_long_pairs.csv`: complete finite outputs.
- `m*_cpp*.json`, `m*_python_verified.json`: independent finite checks.
- `check_math.py`, `check_numeric.py`, `verify.py`: supplementary exact/numeric
  checks and complete finite verification.
- `PROVENANCE.json`: inherited input provenance and original archive hash.
- `MANIFEST.json`: SHA-256 hashes of all packaged input files, excluding itself.

No terminal bound, globally optimal tuple, smaller-dimensional DHL statement,
new distribution exponent, or H1 improvement is claimed.
