"""Recompute exact endpoint deductions and independently check finite tuples."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,subprocess,math,hashlib
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import finalize
p=finalize.p;B=p.B;O=p.O
for source,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
 subprocess.run(['g++','-O3','-std=c++17',str(B/source),'-o',str(O/name)],check=True)

def strip_times(x):
 if isinstance(x,dict):return {k:strip_times(v) for k,v in x.items() if k!='seconds'}
 if isinstance(x,list):return list(map(strip_times,x))
 return x
rows=[]
for m in [2,3]:
 old=json.load(open(O/f'm{m}_result.json'))
 rr=finalize.compute(m);encoded=p.rad.old.encode(rr)
 assert strip_times(encoded)==strip_times(old),'Exact result differs on rerun'
 k=rr['k'];D=rr['selection']['D'];ap=O/f'm{m}_tuple.txt';wp=O/f'm{m}_witness.csv'
 def run(args,name):
  res=subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True,cwd=B)
  (O/name).write_text(res.stdout);return json.loads(res.stdout)
 cc=run([O/'verify_tuple',ap,wp,k],f'm{m}_cpp_verified.json')
 cp=run([O/'check_pairs','tuple',ap,D],f'm{m}_cpp_pairs.json')
 aa=np.loadtxt(ap,dtype=np.int64);assert len(aa)==k and np.all(aa[1:]>aa[:-1])
 ww=dict(map(tuple,np.loadtxt(wp,dtype=np.int64,delimiter=',',skiprows=1)))
 sieve=np.ones(k+1,bool);sieve[:2]=False
 for q in range(2,math.isqrt(k)+1):
  if sieve[q]:sieve[q*q::q]=False
 primes=np.flatnonzero(sieve)
 for q in primes:
  r=ww[int(q)];assert 0<=r<q and np.all(aa%q!=r)
 pairs=[]
 for i,a in enumerate(aa):
  j=int(np.searchsorted(aa,int(a)+D,side='right'))
  for q in range(j,k):pairs.append((i,q,int(a),int(aa[q]),int(aa[q]-a)))
 saved=np.loadtxt(O/f'm{m}_long_pairs.csv',dtype=np.int64,delimiter=',',skiprows=1).reshape(-1,5)
 assert np.array_equal(np.array(pairs,dtype=np.int64).reshape(-1,5),saved)
 assert cp['long_pairs']==len(pairs)==rr['selection']['long_pairs']
 assert cc['verified'] and cc['checked_primes']==len(primes)
 assert rr['margin']>0 and rr['strict_margin']>0
 row=dict(m=m,k=k,previous_bound=rr['previous_bound'],new_bound=D,
  reduction=rr['previous_bound']-D,first=int(aa[0]),last=int(aa[-1]),
  full_diameter=int(aa[-1]-aa[0]),pair_budget=rr['budget'],actual_pairs=len(pairs),
  pair_upper=float(rr['pair_upper']),old_pair_upper=float(rr['old_pair_upper']),
  surplus=float(rr['surplus']),margin=float(rr['margin']),strict_margin=float(rr['strict_margin']),
  q_lower=float(rr['q_lower']),old_q_lower=float(rr['old_q_lower']),
  next_span=D-2,next_min_count=rr['selection']['previous_even_min_count'],
  windows=rr['selection']['windows'],checked_primes=len(primes),
  tuple_sha256=hashlib.sha256(ap.read_bytes()).hexdigest())
 (O/f'm{m}_python_verified.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row)
 print('VERIFIED',json.dumps(row),flush=True)
cert=json.load(open(O/'m3_quotient_fine.interval_certificate.json'))
assert 'direct_fourier_checks' in cert and 'bitwise_CDF_checks' in cert and cert['elapsed']>0
out=dict(status='passed',bounds={'H2':rows[0]['new_bound'],'H3':rows[1]['new_bound'],'H4':82234788,'H5':4830355416},
 results=rows,scope='Fresh positive-moment tables, rational quartic post-processing, and a completed finer H3 quotient evaluation. Support-loss and analytic sieve arguments inherited. Separate finite verification is not an expert audit of the analytic chain.')
(O/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
