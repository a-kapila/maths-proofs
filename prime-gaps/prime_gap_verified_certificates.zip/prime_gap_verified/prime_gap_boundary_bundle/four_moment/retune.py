"""Fresh support checks for arithmetic retuning of the existing H3 trial."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time,copy
B=Path(__file__).resolve().parents[1];O=Path(__file__).resolve().parent
sys.path[:0]=[str(B/'rescaled'),str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from loss_joint import restriction_loss
from scaled_slicing import bad_probability,down
ctx.prec=256
tr=json.load(open(B/'focus23/m3_fine.json'));cert=json.load(open(B/'focus23/m3_fine.interval_certificate.json'))
rows=[]
for delta in map(float,sys.argv[1:]):
    st=time.time();omega=float(F(1,80)-F(delta)/3-F(1,10**12))
    assert 240*F(omega)+80*F(delta)<3
    eps=tr['delta']*tr['eps_cells']
    r=restriction_loss(tr['k'],tr['theta'],tr['beta'],delta,omega,cert['scaled_den_lower'],ufrac=tr['ufrac'],sum_cap=1+eps,relative_shift=tr['relative_shift'],inner_cap=1-eps)
    print(json.dumps(dict(stage='loss',delta=delta,omega=omega,loss=r['loss_upper'],seconds=time.time()-st)),flush=True)
    dd=dict(tr,smooth_delta=delta,omega=omega)
    rho=arb(1)/4+arb(omega);kap=down((arb(1)/4+arb(delta)/2)/rho-arb('0.0001'))
    pbad,n=bad_probability(dd,tr['ufrac'],kap)
    C=F(cert['amplitude_upper']);removed=C*C*F(pbad)
    row=dict(delta=delta,omega=omega,support=r,removed_square_mass_upper=[str(removed.numerator),str(removed.denominator)],bad_probability=pbad,bins=n,amplitude_upper=cert['amplitude_upper'],seconds=time.time()-st)
    rows.append(row);(O/'retuned_support.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps(dict(stage='done',delta=delta,omega=omega,loss=r['loss_upper'],bad=pbad,removed=float(removed),seconds=time.time()-st)),flush=True)
