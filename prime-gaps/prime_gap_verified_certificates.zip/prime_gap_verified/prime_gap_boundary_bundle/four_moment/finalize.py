"""Exact deductions from the new moment enclosures and H3 quotient.
Uses saved rational interpolation nodes; no optimizer is run for acceptance.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import postprocess as p
B=p.B;O=p.O

def compute(m):
 st=time.time();v=p.hp.inputs(m);raw=p.load_raw(m)
 old=json.load(open(B/f'abel_pair/norm_m{m}_result.json'))
 e=p.ab.frac(old['eta']);a=p.ab.frac(old['intercept']);rho=v['rho'];sig=v['sigma']
 nodes=json.load(open(O/f'm{m}_nodes.json'))
 calc=p.estimate(m,v,raw,e,2*rho*sig,a,node_plan=nodes)
 lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60)
 strict=p.estimate(m,v,raw,e,lam*sig/b,a,node_plan=nodes)
 q=v['q'];source=v['quotient_source'];oldq=q
 if m==3:
  source='four_moment/m3_quotient_fine.interval_certificate.json'
  cc=json.load(open(B/source));nc=json.load(open(B/'four_moment/m3_quotient_fine.json'));oc=json.load(open(B/'focus23/m3_fine.json'))
  for key in ['k','theta','beta','relative_shift','profiles','basis']:
   assert nc[key]==oc[key],key
  assert [F(nc['delta'])*i for i in nc['E']]==[F(oc['delta'])*i for i in oc['E']]
  assert F(nc['delta'])*nc['eps_cells']==F(oc['delta'])*oc['eps_cells']
  assert cc['k']==v['k']
  oldquot=json.load(open(B/'focus23/m3_fine.interval_certificate.json'))
  inherited_loss=F(oldquot['Q_lower'])-oldq
  assert inherited_loss>0
  q=F(cc['Q_lower'])-inherited_loss
 pair=calc['pair_upper'];sur=rho*q-m;ratio=sur/pair;budget=(ratio.numerator-1)//ratio.denominator
 w=p.base.load_witness(v['witness']);arr=p.base.allowed(w,-v['extent'],v['extent']);sub,sel=p.base.choose(arr,v['k'],budget)
 for pr in p.base.primes_up_to(v['k']):
  if int(pr) not in w:
   missing=np.flatnonzero(np.bincount(sub%pr,minlength=int(pr))==0);assert len(missing);w[int(pr)]=int(missing[0])
 cnt=sel['long_pairs'];margin=sur-cnt*pair;sm=lam*q-m-cnt*strict['pair_upper'];assert margin>0 and sm>0
 np.savetxt(O/f'm{m}_tuple.txt',sub,fmt='%d')
 np.savetxt(O/f'm{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
 pairs=p.base.enumerate_long_pairs(sub,sel['D']);assert len(pairs)==cnt
 np.savetxt(O/f'm{m}_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
 out=dict(m=m,k=v['k'],eta=e,intercept=a,rho=rho,sigma=sig,q_lower=q,old_q_lower=oldq,
     quotient_source=source,surplus=sur,pair_upper=pair,old_pair_upper=p.ab.frac(old['pair_upper']),
     ratio=ratio,budget=budget,selection=sel,margin=margin,strict_margin=sm,
     first=int(sub[0]),last=int(sub[-1]),full_diameter=int(sub[-1]-sub[0]),
     calculation=calc,strict_calculation=strict,previous_bound={2:19844,3:1358004}[m])
 if m==3:
  before=p.ab.frac(old['pair_upper']);oldratio=sur/before;oldbudget=(oldratio.numerator-1)//oldratio.denominator
  _,oldsel=p.base.choose(arr,v['k'],oldbudget)
  out['attribution_with_new_quotient_and_old_pair']=dict(budget=oldbudget,selection=oldsel)
 (O/f'm{m}_result.json').write_text(json.dumps(p.rad.old.encode(out),indent=2)+'\n')
 print(json.dumps(dict(m=m,k=v['k'],oldq=float(oldq),q=float(q),pair=float(pair),budget=budget,ratio=float(ratio),selection=sel,margin=float(margin),strict_margin=float(sm),seconds=time.time()-st)),flush=True)
 return out
if __name__=='__main__':
 for arg in sys.argv[1:]:compute(int(arg))
