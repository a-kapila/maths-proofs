from pathlib import Path
import subprocess,json,numpy as np,time
B=Path(__file__).resolve().parents[1];O=B/'advance';st=time.time();hist=[]
w0=np.loadtxt(B/'progress/h2_final_witness.csv',dtype=np.int64,delimiter=',',skiprows=1)
for run in range(12):
 shift=10+2*(run%2);w=w0.copy();w[:,1]=(w[:,1]-shift)%w[:,0];pref=O/f'h2_escape_{run}'
 inp=Path(str(pref)+'_input.csv');np.savetxt(inp,w,delimiter=',',fmt='%d',header='prime,missing_residue',comments='')
 with open(str(pref)+'.log','w') as f: subprocess.run([str(O/'tuple_escape'),'19858','2304',str(inp),'180000',str(pref),str(4823+run*729)],stdout=f,stderr=subprocess.STDOUT,check=True)
 tp=Path(str(pref)+'.csv');wp=Path(str(pref)+'_witness.csv')
 if tp.exists():
  a=np.loadtxt(tp,dtype=np.int64)
  if len(a)>=2304:
   j=np.argmin(a[2303:]-a[:len(a)-2303]);np.savetxt(tp,a[j:j+2304],fmt='%d');v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(tp),str(wp),'2304'],text=True))
   hist.append(dict(**v,tuple=str(tp.relative_to(B)),witness=str(wp.relative_to(B)),seconds=time.time()-st));(O/'h2_escape_results.json').write_text(json.dumps(hist,indent=2));print(json.dumps(hist[-1]),flush=True);break
 print(json.dumps({'run':run,'seconds':time.time()-st,'found':False}),flush=True)
