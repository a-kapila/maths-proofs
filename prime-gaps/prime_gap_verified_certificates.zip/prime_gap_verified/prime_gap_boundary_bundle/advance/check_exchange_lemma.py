"""Small exhaustive reference checks for the exact exchange-enumeration logic."""
from pathlib import Path
import itertools,random,json

def minimal_requirements(req,R):
 states={0}
 for opts in req:
  unions={a|b for a in states for b in opts if (a|b).bit_count()<=R}
  # Independent order-free minimality test, suitable for small examples.
  states={a for a in unions if not any(b!=a and b&a==b for b in unions)}
 return states

def implemented_requirements(req,R):
 states={0}
 for ops in req:
  new={s|b for s in states for b in ops if (s|b).bit_count()<=R}
  if not new:return set()
  ordered=sorted(new,key=int.bit_count);minimal=[];short=[];previous=0
  for s in ordered:
   length=s.bit_count()
   if length>previous:short=minimal.copy();previous=length
   if not any((b&s)==b for b in short):minimal.append(s)
  states=set(minimal)
 return states

def closure_test(families,R):
 gens=set().union(*families) if families else set();seen={0};todo=[0]
 while todo:
  s=todo.pop();eligible=sum(any(b&s==b for b in f) for f in families)
  if eligible>s.bit_count():return False,len(seen)
  if s.bit_count()==R:continue
  for b in gens:
   u=s|b
   if u.bit_count()<=R and u not in seen:seen.add(u);todo.append(u)
 return True,len(seen)

def main():
 rng=random.Random(930177);nc=0;nd=0;subsets=0
 for case in range(400):
  n=rng.randrange(2,10);R=rng.randrange(1,min(n,4)+1);masks=[s for s in range(1,1<<n) if s.bit_count()<=R]
  req=[rng.sample(masks,min(len(masks),rng.randrange(1,6))) for _ in range(rng.randrange(1,5))]
  assert minimal_requirements(req,R)==implemented_requirements(req,R);nc+=1
  families=[]
  for y in range(rng.randrange(1,9)):
   xs=set(rng.sample(masks,min(len(masks),rng.randrange(1,5))))
   families.append({a for a in xs if not any(b!=a and b&a==b for b in xs)})
  brute=True
  for s in range(1<<n):
   if s.bit_count()>R:continue
   subsets+=1
   if sum(any(b&s==b for b in f) for f in families)>s.bit_count():brute=False
  assert closure_test(families,R)[0]==brute;nd+=1
 out=dict(minimal_support_cases=nc,closure_equivalence_cases=nd,full_deletion_sets_checked=subsets,all_exact=True)
 (Path(__file__).parent/'exchange_diagnostics.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':main()
