#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
  echo 'usage: bash advance/reproduce.sh --checks-only|--full' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o advance/verify_tuple
if [[ "$mode" == --full ]]; then
  "$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
  "$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off progress/profile_parallel.cpp -o progress/profile_parallel.so
  "$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
  python progress/run_refined.py advance/m3_k110039.json | tee advance/m3_k110039_recomputed.log
fi
python advance/check_exchange_lemma.py
python advance/exact_exchange_obstruction.py 4 0
python advance/exact_exchange_obstruction.py 4 2
python advance/verify_final.py
