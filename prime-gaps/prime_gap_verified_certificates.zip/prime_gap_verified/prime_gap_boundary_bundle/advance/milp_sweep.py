from exchange_milp import run,B,O
import json,time
st=time.time();hist=[]
for R,shift in [(4,2),(5,0),(5,2),(6,0),(6,2)]:
 a=run(B/'progress/h2_final.csv',R,shift,seconds=30);hist.append(a)
 (O/'milp_sweep.json').write_text(json.dumps(hist,indent=2)+'\n')
 if a['success']:break
