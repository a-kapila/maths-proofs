from pathlib import Path
import numpy as np,json,subprocess,time
B=Path(__file__).resolve().parents[1];O=B/'advance';st=time.time();w=np.loadtxt(O/'h3_step4_witness.csv',dtype=np.int64,delimiter=',',skiprows=1)
lo=-5000000;hi=5000000;ok=np.ones((hi-lo)//2+1,bool)
for p,r in w:
 if p==2:assert r==1;continue
 a=((int(r)-lo)*((int(p)+1)//2))%int(p);ok[a::int(p)]=False
A=lo+2*np.flatnonzero(ok)
for K in [110040,110039]:
 widths=A[K-1:]-A[:len(A)-K+1];j=int(np.argmin(widths));out=A[j:j+K];pref=O/f'h3_completion_{K}';np.savetxt(str(pref)+'.csv',out,fmt='%d');np.savetxt(str(pref)+'_witness.csv',w[w[:,0]<=K],delimiter=',',fmt='%d',header='prime,missing_residue',comments='')
 v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(pref)+'.csv',str(pref)+'_witness.csv',str(K)],text=True));v.update(universe=[lo,hi],permitted_points=len(A),windows=int(len(widths)),seconds=time.time()-st)
 print(json.dumps(v),flush=True);Path(str(pref)+'.json').write_text(json.dumps(v,indent=2))
