from pathlib import Path
import json,sys,time
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from loss_joint import restriction_loss
from flint import arb,ctx
ctx.prec=256; d=json.load(open(B/'progress/m3_k110040_finer.json'));c=json.load(open(B/'progress/m3_k110040_finer.interval_certificate.json'))
out=[]
for delta in [5e-7,3e-7,2e-7,1e-7]:
 omega=.0125-delta/3-1e-9
 assert 240*arb(omega)+80*arb(delta)<3
 st=time.time();loss=restriction_loss(d['k'],d['theta'],d['beta'],delta,omega,c['scaled_den_lower'],ufrac=d['ufrac'],sum_cap=1+d['delta']*d['eps_cells'],relative_shift=d['relative_shift'],inner_cap=1-d['delta']*d['eps_cells'])
 r=dict(delta=delta,omega=omega,loss=loss,target_upper=float((arb(3)/(arb(1)/4+arb(omega))).upper()),elapsed=time.time()-st);out.append(r);print(json.dumps(r),flush=True)
 (B/'advance/arithmetic_candidates.json').write_text(json.dumps(out,indent=2)+'\n')
