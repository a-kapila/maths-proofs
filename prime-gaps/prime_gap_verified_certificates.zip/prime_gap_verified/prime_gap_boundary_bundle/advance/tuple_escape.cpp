#include <bits/stdc++.h>
using namespace std;
// Exact residue-cover local search, heuristic search only; result verified separately.
int main(int argc,char**argv){
 if(argc<6){cerr<<"D target witness iterations output [seed]\n";return 2;}
 int D=stoi(argv[1]),target=stoi(argv[2]),steps=stoi(argv[4]); string out=argv[5];
 mt19937 rng(argc>6?stoul(argv[6]):1);vector<int> ps,rs;
 ifstream f(argv[3]);string s;getline(f,s);while(getline(f,s)){replace(s.begin(),s.end(),',',' ');istringstream ss(s);int p,r;ss>>p>>r;if(p<=target){ps.push_back(p);rs.push_back(r);}}
 int N=D/2+1; vector<int> c(N),a(ps.size());
 for(int i=0;i<(int)ps.size();i++){
  int p=ps[i];if(p==2){a[i]=-1;continue;}
  a[i]=(1LL*rs[i]*((p+1)/2))%p;
  for(int x=a[i];x<N;x+=p)c[x]++;
 }
 auto count=[&](){return count_if(c.begin(),c.end(),[](int z){return z==0;});};
 int best=count(),val=best;vector<int> bestA=a;
 cerr<<"initial "<<best<<"\n";
 auto save=[&](){ofstream ff(out+".csv");int cnt=0;for(int x=0;x<N;x++)if(!c[x]){ff<<2*x<<"\n";cnt++;}ofstream w(out+"_witness.csv");w<<"prime,missing_residue\n";for(int i=0;i<(int)ps.size();i++)w<<ps[i]<<","<<(ps[i]==2?1:2*a[i]%ps[i])<<"\n";cerr<<"saved "<<cnt<<" D="<<D<<"\n";};
 vector<int> cnt(target+1),options;int stuck=0;
 for(int step=0;step<steps;step++){
  int i=1+rng()%(ps.size()-1),p=ps[i];
  fill(cnt.begin(),cnt.begin()+p,0);
  for(int x=0;x<N;x++)if(c[x]==0||(c[x]==1&&x%p==a[i]))cnt[x%p]++;
  int old=cnt[a[i]], mn=*min_element(cnt.begin(),cnt.begin()+p);
  options.clear();
  // Plateau walks, and occasional small uphill perturbations.
  int cap=mn;
  if(stuck>400 && rng()%12==0)cap=mn+1;
  if(stuck>4000 && rng()%150==0)cap=mn+2;
  for(int r=0;r<p;r++)if(cnt[r]<=cap)options.push_back(r);
  int b=options[rng()%options.size()];
  if(b!=a[i]){
   for(int x=a[i];x<N;x+=p)c[x]--;
   for(int x=b;x<N;x+=p)c[x]++;
   val+=old-cnt[b];a[i]=b;
  }
  stuck++;
  if(val>best){best=val;bestA=a;stuck=0;cerr<<"step="<<step<<" best="<<best<<"\n";save();if(best>=target)break;}
  if(step%20000==19999){cerr<<"step="<<step<<" val="<<val<<" best="<<best<<"\n";}
 }
 cerr<<"final best="<<best<<"\n";
}
