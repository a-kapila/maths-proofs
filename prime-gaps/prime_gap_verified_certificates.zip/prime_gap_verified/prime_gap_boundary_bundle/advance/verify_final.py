"""Exact saved-endpoint checks and two full integer verifiers.
Does not independently audit the inherited analytic implication or Fourier bounds.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib,math,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'advance'
def tuple_check(stem,k):
 tp=O/f'{stem}.csv';wp=O/f'{stem}_witness.csv';a=np.loadtxt(tp,dtype=np.int64);w=np.loadtxt(wp,dtype=np.int64,delimiter=',',skiprows=1)
 assert len(a)==k and np.all(np.diff(a)>0)
 sv=bytearray(b'\1')*(k+1);sv[:2]=b'\0\0'
 for p in range(2,math.isqrt(k)+1):
  if sv[p]:sv[p*p::p]=b'\0'*(((k-p*p)//p)+1)
 ps=[p for p in range(2,k+1) if sv[p]];W={int(p):int(r) for p,r in w}
 for p in ps:assert p in W and 0<=W[p]<p and not np.any(a%p==W[p]),(p,W.get(p))
 own=dict(verified=True,k=k,first=int(a[0]),last=int(a[-1]),diameter=int(a[-1]-a[0]),checked_primes=len(ps))
 cpp=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(tp),str(wp),str(k)],text=True));assert own==cpp
 own.update(tuple_sha256=hashlib.sha256(tp.read_bytes()).hexdigest(),witness_sha256=hashlib.sha256(wp.read_bytes()).hexdigest(),python_method='direct modular reduction at every relevant prime',cpp_method='missing-residue arithmetic progression scan')
 return own

def main():
 tr=json.load(open(O/'m3_k110039.json'));old=json.load(open(B/'progress/m3_k110040_finer.json'));c=json.load(open(O/'m3_k110039.interval_certificate.json'))
 assert tr['k']==110039 and old['k']==110040
 for key in set(old)|set(tr):
  if key!='k':assert tr.get(key)==old.get(key),key
 assert c['trial_sha256']==hashlib.sha256((O/'m3_k110039.json').read_bytes()).hexdigest()
 rho=F(1,4)+F(tr['omega']);eps=F(tr['delta'])*tr['eps_cells'];q=F(c['Q_lower'])-F(c['restriction']['loss_upper']);threshold=F(3)/rho;mg=q-threshold
 assert 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3 and 2*rho*(1+eps)<1
 assert mg>0 and F(c['target_upper'])>=threshold and F(110038,110039)*q<=threshold
 assert len(c['direct_fourier_checks'])==108 and c['bitwise_CDF_checks']==[2002]*3
 for x in c['direct_fourier_checks']:assert abs(F(x['direct'])-F(x['raw_fft']))<=F(x['raw_error'])
 # The unchanged H2 result uses exactly its previous successfully selected lower quotient.
 inherited=json.load(open(B/'focus23/RESULTS.json'))['results'][0];t2=json.load(open(B/inherited['trial']));q2=F(inherited['component_quotient_lower'])-F(inherited['restriction_loss_upper'])
 assert q2>2/(F(1,4)+F(t2['omega'])) and t2['k']==2304
 h2=tuple_check('h2_final',2304);h3=tuple_check('h3_final',110039);h3old=tuple_check('h3_old_dimension',110040)
 assert h3old['diameter']==1358372
 assert h2['diameter']==19860 and h3['diameter']==1358360
 ob=[json.load(open(O/f'exact_exchange_4_{s}.json')) for s in (0,2)]
 assert all(x['necessary_condition_obstruction'] and x['R']==4 and x['starting_cardinality']==2303 and x['width']==19858 for x in ob)
 out=dict(scope='Computer-assisted deductions in the inherited framework; no independent expert audit or global optimality claim.',bounds={'H2':19860,'H3':1358360,'H4':82258490,'H5':4831230984},H3=dict(previous_bound=1358724,saving=364,previous_dimension=110040,dimension=110039,Q_lower=c['Q_lower'],restriction_loss_upper=c['restriction']['loss_upper'],target_upper=c['target_upper'],margin=float(mg),margin_fraction=[str(mg.numerator),str(mg.denominator)],new_full_evaluation=True,ordinary_slicing_one_more_fails=True,tuple=h3,old_dimension_tuple=h3old,combinatorial_saving_at_old_dimension=352,additional_saving_at_new_dimension=12),H2=dict(unchanged=True,analytic_reused=True,tuple=h2,local_exclusions=[{k:v for k,v in x.items() if k not in ('details','seconds')} for x in ob]),diagnostics=dict(direct_fourier_checks=108,bitwise_CDF_checks=6006,exchange=json.load(open(O/'exchange_diagnostics.json'))))
 (O/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
