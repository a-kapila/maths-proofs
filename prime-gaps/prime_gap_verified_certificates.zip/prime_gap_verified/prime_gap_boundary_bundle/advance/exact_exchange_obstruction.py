"""Exact necessary-condition enumeration for an exchange neighborhood.
No solver tolerances. No claim about tuples outside the specified neighborhood.
"""
from pathlib import Path
import json,math,sys,time
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'advance'
def run(R=4,shift=0):
 st=time.time();width=19858;K=2304;N=width//2+1
 raw=np.loadtxt(B/'progress/h2_final.csv',dtype=np.int64);raw=raw-raw[0]-shift;A=raw[(raw>=0)&(raw<=width)]//2;assert len(A)==K-1
 sv=bytearray(b'\1')*(K+1);sv[:2]=b'\0\0'
 for p in range(2,math.isqrt(K)+1):
  if sv[p]:sv[p*p::p]=b'\0'*(((K-p*p)//p)+1)
 ps=[p for p in range(3,K+1) if sv[p]]
 possible=np.ones(N,bool);requirements=[]
 for p in ps:
  buckets=[0]*p
  for i,x in enumerate(A):buckets[int(x)%p]|=1<<i
  missing=[r for r,b in enumerate(buckets) if b==0]
  assert missing
  if len(missing)!=1:continue
  options=[b for b in buckets if 0<b.bit_count()<=R]
  if not options:possible[missing[0]::p]=False
  else:requirements.append((p,missing[0],options))
 possible[A]=False;candidates=np.flatnonzero(possible);supports=[];details=[]
 for y0 in candidates:
  y=int(y0);req=[ops for p,r,ops in requirements if y%p==r];req.sort(key=len)
  states={0}
  for ops in req:
   new={s|b for s in states for b in ops if (s|b).bit_count()<=R}
   if not new:states=set();break
   ordered=sorted(new,key=int.bit_count);minimal=[];short=[];previous=0
   for s in ordered:
    length=s.bit_count()
    if length>previous:short=minimal.copy();previous=length
    if not any((b&s)==b for b in short):minimal.append(s)
   states=set(minimal)
  assert 0 not in states,'one-point augmentation should have been found earlier'
  if states:supports.append((y,states))
  details.append(dict(point=2*y,requirements=len(req),minimal_supports=len(states),minimum_deletions=min(map(int.bit_count,states)) if states else None))
 gens=set().union(*(states for y,states in supports)) if supports else set()
 # Enumerate every union of generator sets with at most R elements.
 lookup={}
 for ci,(y,states) in enumerate(supports):
  for mask in states:lookup[mask]=lookup.get(mask,0)|(1<<ci)
 seen={0};todo=[0]
 while todo:
  s=todo.pop()
  bits=0;sub=s
  while sub:
   bits |= lookup.get(sub,0);sub=(sub-1)&s
  eligible=[y for ci,(y,states) in enumerate(supports) if (bits>>ci)&1]
  if len(eligible)>s.bit_count():
   out=dict(necessary_condition_obstruction=False,removed=[int(2*A[i]) for i in range(len(A)) if s>>i&1],eligible=[2*y for y in eligible],states_enumerated=len(seen));break
  if s.bit_count()==R:continue
  for b in gens:
   u=s|b
   if u.bit_count()<=R and u not in seen:seen.add(u);todo.append(u)
  if len(seen)>2000000:raise RuntimeError('state budget exceeded: no obstruction certified')
 else:out=dict(necessary_condition_obstruction=True,states_enumerated=len(seen))
 out.update(R=R,shift=shift,width=width,starting_cardinality=len(A),candidate_points=len(candidates),individually_feasible_candidates=len(supports),generator_sets=len(gens),details=details,seconds=time.time()-st)
 (O/f'exact_exchange_{R}_{shift}.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='details'}),flush=True)
 return out
if __name__=='__main__':run(int(sys.argv[1]),int(sys.argv[2]))
