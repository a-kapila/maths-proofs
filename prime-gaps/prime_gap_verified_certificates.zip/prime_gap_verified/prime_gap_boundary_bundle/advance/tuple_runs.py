from pathlib import Path
import subprocess,json,time,numpy as np
B=Path(__file__).resolve().parents[1];O=B/'advance';tp=O/'h3_try1.csv';wp=O/'h3_try1_witness.csv';hist=[];st=time.time()
for it in range(12):
 a=np.loadtxt(tp,dtype=np.int64);pref=O/f'h3_step{it}';lo=int(a[0]);hi=int(a[-1])-2
 with open(str(pref)+'.log','w') as f:
  subprocess.run([str(O/'cover_descent'),'110040',str(lo),str(hi),str(wp),'180',str(pref),str(812231+it*173),'110040'],stdout=f,stderr=subprocess.STDOUT,check=True)
 nt=Path(str(pref)+'.csv');nw=Path(str(pref)+'_witness.csv')
 if not nt.exists():break
 v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(nt),str(nw),'110040'],text=True))
 hist.append(dict(**v,tuple=str(nt.relative_to(B)),witness=str(nw.relative_to(B)),seconds=time.time()-st));tp,wp=nt,nw
 (O/'h3_search_history.json').write_text(json.dumps(hist,indent=2));print(json.dumps(hist[-1]),flush=True)
