from pathlib import Path
import numpy as np,json,subprocess,time
B=Path(__file__).resolve().parents[1];O=B/'advance';K=110040;wp=O/'h3_completion_110040_witness.csv';tp=O/'h3_completion_110040.csv';hist=[];start=time.time()
for step in range(8):
 a=np.loadtxt(tp,dtype=np.int64);wp0=wp;gain=False
 for side in [0,1]:
  lo=int(a[0])+2*side;hi=int(a[-1])-2*(1-side);pref=O/f'h3_flex_{step}_{side}'
  with open(str(pref)+'.log','w') as f:subprocess.run([str(O/'cover_descent'),str(K),str(lo),str(hi),str(wp),'90',str(pref),str(15919+223*step+side*43),str(K)],stdout=f,stderr=subprocess.STDOUT,check=True)
  if not Path(str(pref)+'.csv').exists():continue
  w=np.loadtxt(str(pref)+'_witness.csv',dtype=np.int64,delimiter=',',skiprows=1);left=-5000000;right=5000000;ok=np.ones((right-left)//2+1,bool)
  for p,r in w:
   if p==2:continue
   residue=((int(r)-left)*((int(p)+1)//2))%int(p);ok[residue::int(p)]=0
  u=left+2*np.flatnonzero(ok);j=np.argmin(u[K-1:]-u[:len(u)-K+1]);a=u[j:j+K]
  np.savetxt(str(pref)+'.csv',a,fmt='%d');tp=Path(str(pref)+'.csv');wp=Path(str(pref)+'_witness.csv')
  v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(tp),str(wp),str(K)],text=True));v.update(tuple=str(tp.relative_to(B)),witness=str(wp.relative_to(B)),seconds=time.time()-start,completion_range=[left,right],permitted_points=len(u));hist.append(v)
  (O/'h3_flex_history.json').write_text(json.dumps(hist,indent=2));print(json.dumps(v),flush=True);gain=True;break
 if not gain:break
