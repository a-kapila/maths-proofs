"""Bounded exchange search. Solver output is NOT a proof; integer tuple checks are mandatory."""
from pathlib import Path
import json,sys,time,math
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
B=Path(__file__).resolve().parents[1];O=B/'advance'
def run(path,R,shift=0,width=19858,seconds=30):
 t=time.time();A0=np.loadtxt(path,dtype=np.int64);K=2304
 A0=A0-A0[0]-shift;A=A0[(A0>=0)&(A0<=width)]//2
 N=width//2+1;ps=[];sv=np.ones(K+1,bool);sv[:2]=0
 for p in range(2,math.isqrt(K)+1):
  if sv[p]:sv[p*p::p]=0
 ps=np.flatnonzero(sv)[1:];eligible={};ok=np.ones(N,bool)
 for p in ps:
  co=np.bincount(A%p,minlength=p);r=np.flatnonzero(co<=R);eligible[int(p)]=r
  if len(r)==1:ok[r[0]::p]=0
 U=np.flatnonzero(ok);assert set(map(int,A))<=set(map(int,U))
 uid={int(x):i for i,x in enumerate(U)};active=[];cntY=0
 for p in ps:
  co=np.bincount(U%p,minlength=p)
  if np.any(co==0):continue
  r=eligible[int(p)];active.append((int(p),r));cntY+=len(r)
 nv=len(U)+cntY;rr=[];cc=[];vv=[];lower=[];upper=[]
 def row(idx,val,lo,hi):
  n=len(lower);rr.extend([n]*len(idx));cc.extend(idx);vv.extend(val);lower.append(lo);upper.append(hi)
 row(list(range(len(U))),[1]*len(U),K,np.inf)
 ai=[uid[int(a)] for a in A];row(ai,[1]*len(ai),len(A)-R,np.inf)
 y=len(U)
 for p,rs in active:
  yi=list(range(y,y+len(rs)));row(yi,[1]*len(yi),1,1)
  for r in rs:
   for x in range(int(r),N,p):
    if x in uid:row([uid[x],y],[1,1],-np.inf,1)
   y+=1
 assert y==nv
 M=coo_matrix((vv,(rr,cc)),shape=(len(lower),nv)).tocsc()
 objective=np.zeros(nv);objective[:len(U)]=-1
 opts={'time_limit':seconds,'mip_rel_gap':0.,'presolve':True,'disp':True}
 print(json.dumps(dict(stage='start',R=R,shift=shift,width=width,starting_cardinality=len(A),universe=len(U),active_primes=len(active),variables=nv,constraints=len(lower))),flush=True)
 res=milp(objective,integrality=np.ones(nv),bounds=Bounds(0,1),constraints=LinearConstraint(M,lower,upper),options=opts)
 rec=dict(R=R,shift=shift,width=width,seconds=time.time()-t,status=int(res.status),message=res.message,success=False)
 if res.x is not None:
  out=2*U[res.x[:len(U)]>.5]
  if len(out)>=K:
   j=int(np.argmin(out[K-1:]-out[:len(out)-K+1]));out=out[j:j+K];W=[(2,1)]
   for p in ps:
    miss=np.flatnonzero(np.bincount(out%p,minlength=p)==0);assert len(miss)>0;W.append((p,int(miss[0])))
   pref=O/f'h2_milp_{R}_{shift}_{width}';np.savetxt(str(pref)+'.csv',out,fmt='%d');np.savetxt(str(pref)+'_witness.csv',W,fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
   rec.update(success=True,diameter=int(out[-1]-out[0]),first=int(out[0]),last=int(out[-1]),tuple=str(pref.relative_to(B))+'.csv',witness=str(pref.relative_to(B))+'_witness.csv')
 print(json.dumps(rec),flush=True)
 (O/f'milp_{R}_{shift}_{width}.json').write_text(json.dumps(rec,indent=2)+'\n');return rec
if __name__=='__main__':run(B/'progress/h2_final.csv',int(sys.argv[1]),int(sys.argv[2]) if len(sys.argv)>2 else 0,seconds=45)
