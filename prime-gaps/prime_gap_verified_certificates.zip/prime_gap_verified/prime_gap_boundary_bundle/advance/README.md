# New H3 certificate and exact H2 local exchange obstructions

Current result: **H3 <= 1,358,360**, from **DHL[110039,4]** and a separately verified admissible tuple. H2 <= 19,860, H4 <= 82,258,490 and H5 <= 4,831,230,984 are unchanged inherited results. These are computer-assisted deductions within the retained framework, not independently audited published records.

Read `proof_note.pdf` and `RESULTS.json`. The successful new analytic evaluation was actually run; it is not a dimension extrapolation. It uses the same six profiles and physical boundaries as `../progress/m3_k110040_finer.json`, but recomputes the coordinate factor and all distributions at k=110039. The inherited numerical error analysis and distribution theorem remain dependencies.

## Reproduction

From the bundle root:

```sh
bash advance/reproduce.sh --checks-only
bash advance/reproduce.sh --full
```

Checks-only reruns exact finite-neighborhood enumeration, exhaustive small-example diagnostics, rational endpoint implications, and independent C++/Python integer tuple checks. Full additionally rebuilds the native numerical kernels and recomputes the successful H3 Fourier/support-loss certificate. Python 3, NumPy, SciPy, mpmath and a C++17 compiler with OpenMP are needed. Keep assertions enabled. The scalar module named `flint.py` is the inherited mpmath.iv compatibility implementation, NOT FLINT/Arb.

The complete analytic chain is not independently audited by these finite checks. Successful analytic evaluations for H2, H4 and H5 were not rerun this turn. No global admissible-tuple optimum is asserted.

## Authoritative new files

- `m3_k110039.json`, `m3_k110039.interval_certificate.json`, `m3_k110039.log`: exact trial, completed certificate and log.
- `h3_final.csv`, `h3_final_witness.csv`: complete 110,039-element tuple and omitted residues.
- `h3_old_dimension.csv`, `h3_old_dimension_witness.csv`: checked 110,040-element tuple of diameter 1,358,372, separating 352 of the gain from the additional 12 supplied by the smaller dimension.
- `h2_final.csv`, `h2_final_witness.csv`: unchanged H2 tuple, rechecked.
- `verify_final.py`: exact rational deductions and two complete tuple checks.
- `exact_exchange_obstruction.py`: exact deletion-support enumeration for the two specified cropped H2 parents in width 19,858.
- `exact_exchange_4_0.json`, `exact_exchange_4_2.json`: complete enumeration summaries; 184,323 and 184,966 unions checked.
- `check_exchange_lemma.py`, `exchange_diagnostics.json`: exhaustive small reference checks, not substitutes for the reduction proof.
- `MANIFEST.json`: hashes for principal new sources, trials and outputs.

## Meaning of the H2 local obstruction

Let H be the unchanged tuple with endpoints 10 and 19,870. Set A0=(H-10) intersect [0,19858], A2=(H-12) intersect [0,19858]. Both have 2,303 entries. For either parent, removing any S of at most four entries makes at most |S| new points individually admissible. Therefore no exchange deleting at most four entries can enlarge either cropped parent to 2,304 points. An improvement elsewhere, or an exchange with at least five deletions, is not excluded.

The proof reduces arbitrary deletion sets to unions of minimal deletion requirements; see the PDF. It uses exact integer masks, not floating-point solver infeasibility. The separate MILP experiments are exploratory and are not used as exclusion certificates.

## Unsuccessful and optional searches

`exchange_milp.py`, `milp_sweep.py` and associated logs record time-limited mixed-integer searches; inconclusive runs prove nothing. `tuple_escape.cpp` and `run_h2_escape.py` record unsuccessful additional local searches. `test_arithmetic.py` recomputed support losses for four smaller smoothness parameters, all unsuccessful. None of these outputs contributes to the reported bound.

`tuple_runs.py`, `complete_descent.py`, the cover-descent source retained in `../baseline/inherited/search/`, and completion scripts record heuristic H3 discovery. Search is unnecessary for verifying the fixed final tuples. Intermediate historical results must not be confused with `advance/RESULTS.json`.

Timing fields are not mathematical data. All source attribution and earlier analytic inputs remain in the complete archive.
