# Further mixed-profile reductions and sharper support-loss enclosures

Research continuation, 3 November 2026.

## Results

| Constant | Previous | New | Sieve dimension |
|---|---:|---:|---:|
| H2 | 19,928 | **19,920** | **2,305** |
| H3 | 1,360,138 | 1,360,138 (inherited, unchanged) | 110,100 |
| H4 | 82,334,462 | **82,294,500** | **5,089,918** |
| H5 | 4,835,451,398 | **4,832,823,366** | **232,497,861** |

These are computer-assisted derivations within the inherited sieve framework,
not independently peer-reviewed published records or formally verified proofs.
The original distribution theorem, enlarged-support proof, scalar/FFT enclosure
argument, code, and stated arithmetic model remain dependencies. The new tagged
support-loss argument is proved in `proof_note.pdf`; it is not externally reviewed.
No new H1 or asymptotic distribution improvement is asserted.

`RESULTS.json` links the new exact trials to their saved outputs and tuple checks.
The full prior archive is retained under `baseline/`, including source attribution,
mathematical dependencies, exact inputs, and complete tuple certificates.

## What is new

The existing mixed basis `1,Z2,Z3,Z4,Z2^2` is now certified in three more trial
dimensions. The exact quadratic amplitude envelope in `analysis/amplitude_envelope.py`
retains relationships among the power sums instead of bounding terms separately.
For H2, this is combined with `analysis/loss_tagged.py`: any bad tail-support
threshold is attained at an actual coordinate. Tagging that coordinate yields a
sharper union bound than simply summing every scale event. The complete finite-bin
formula and signed-loss justification are in the proof note.

The H2 Fourier run at 2,305 coordinates initially **failed** after the old support
loss. The final H2 result reuses that completed calculation's **smaller inherited
component-wise numerator**, not its optional Hilbert-space improvement. It then
recomputes support loss with the tagged argument, amplitude 3.622, strict slack
eta=1e-8 and grid ratio 1.03. The arithmetic pair delta_s,omega and the trial itself
are unchanged. `analysis/finalize_m2.py` reproduces this step and asserts a positive
margin. The final files are `trials/m2_final.*`, not the failed `m2_cross` certificate.

For H5 the first mesh 2^-22 failed. The **same physical trial** succeeds on mesh
2^-23. `verification/same_trial_checks.json` records exact equality of all physical
edges, heights and parameters. No unsuccessful quotient is used as a proof.

No new H5 prime pairs were restored. The smaller dimension selects a narrower
window from exactly the previous parent. Its complete residue certificate is
reconstructed from the retained compressed sequence and 577 inherited patches.

## Dependencies and execution

Python 3, NumPy, SciPy, mpmath, and a C++17 compiler with OpenMP are required.
The local module named `flint.py` is an inherited compatibility implementation
using **mpmath.iv**, not FLINT or Arb. Do not silently substitute another backend.
The accelerator must be compiled with `-ffp-contract=off`, without fast-math.
C++ assertions must remain enabled. The largest FFT has 2^25 entries; run the
numerical certificates sequentially to avoid combined memory pressure.

From the archive root, the full sequence is:

```sh
bash reproduce.sh
```

This recomputes all three new quotient calculations, the tagged H2 restriction,
exact slicing, and the final tuple checks. Floating optimization is not necessary.
The main commands, also usable individually, are:

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
g++ -O3 -std=c++17 -shared -fPIC -ffp-contract=off \
  analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
python analysis/check_fast_profile.py
python analysis/check_enclosures.py
python analysis/check_tagged.py
python baseline/polynomial/certify_polynomial.py trials/m4_cross.json
python analysis/certify_centered.py trials/m5_fine.json
python analysis/certify_centered.py trials/m2_cross.json
python analysis/finalize_m2.py trials/m2_cross.json trials/m2_final.json
python verify_saved.py
```

The final margins after exact slicing exceed 1.1257e-4, 5.5773e-7 and 2.4230e-8
for H2, H4 and H5 respectively. The tiny positive H4/H5 support-loss endpoints
are rounded upward to the smallest positive binary64 number, not treated as zero.
`verification/saved_checks.json` includes the full exact fractions.

## Exact tuple verification

`rebuild_small_tuples.py` reconstructs the selected H2/H4 windows from complete
retained parents, so duplicate large text files are unnecessary. Compile and run:

```sh
python rebuild_small_tuples.py
g++ -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o verification/verify_tuple
verification/verify_tuple verification/h2.csv baseline/inherited/tuples/h2_witness.csv 2305
verification/verify_tuple verification/h4.csv baseline/inherited/tuples/h4_witness.csv 5089918
```

Expected H2 endpoints are 112,20032, with 342 primes checked. Expected H4 endpoints
are -37972414,44322086, with 354319 primes checked. The independent H5 check is:

```sh
python baseline/inherited/tuples/decode_h5.py verification/baseline_h5.bin
python baseline/h5/apply_patches.py verification/baseline_h5.bin verification/current_h5.bin
g++ -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o verification/verify_h5
OMP_NUM_THREADS=4 verification/verify_h5 234360000 232497861 10000000 2432107459 verification/current_h5.bin
```

Expected: all 12204094 witnesses checked; zero failures; parent cardinality
233950386; selected endpoints -2405632139,2427191227; diameter 4832823366.
All 1452526 consecutive windows are checked. Optimality is asserted only within
this specified parent, not among all admissible tuples.

## Updated fixed-universe construction limit

```sh
g++ -O3 -std=c++17 limits/optimistic_h5.cpp -o verification/optimistic_h5
verification/optimistic_h5 232497861
```

The relaxed universe contains ALL signed primes between 10^7 and 2432107459.
Its shortest 232497861-element window has diameter **4804108302**, after checking
2781416 windows. This is a **lower bound** on the diameter possible by restoring
prime pairs at the fixed dimension in that fixed universe. It is NOT an upper
bound on H5 and need not be admissible. The maximum remaining improvement in
that search is therefore 0.5941674633...%. Changing the dimension, universe or
construction escapes this statement.

## Tests, failed attempts, and scope

The new diagnostic checks include 300 bitwise arithmetic-order comparisons, 2000
exact amplitude tests, 2000 tests of the optional Hilbert inequality, and 6000 exact
vector tests comprising 11557 triggering cases for the tagged conditions. Each
completed numerical trial retains 84 direct Fourier diagnostics. These do not
replace the mathematical error analysis.

The optional Hilbert numerator is never required by the reported results. Exploratory
higher-basis scores, the failed coarse H5 result, and selected failed H2 restrictions
are separated under `exploratory/`. A purported marginal envelope used in one scout
was only numerical; that scout is not a certificate and is not used. A higher-degree
exploration and one overlapping numerical run were interrupted by memory limits;
neither produced a usable certificate. Successful computations completed separately.

A new method-wide variational upper certificate was not obtained. The unchanged H3
bound remains inherited. `MANIFEST.sha256.json` describes the saved archive files;
recomputed logs may differ in timings and local paths without changing the maths.
