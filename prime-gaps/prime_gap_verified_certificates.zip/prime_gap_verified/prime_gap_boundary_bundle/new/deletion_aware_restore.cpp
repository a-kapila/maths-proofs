// Dependency-aware restoration of signed primes in a fixed universe.
// A restored prime receives a new missing residue. Every deleted prime that
// would hit ANY currently retained nonzero witness is permanently blocked.
// This preserves all old witnesses, unlike an unchecked simultaneous batch.
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
struct Bits {
 std::vector<uint64_t> a;
 explicit Bits(uint64_t n):a((n+63)/64,~uint64_t(0)){}
 bool get(uint64_t i)const{return (a[i>>6]>>(i&63))&1;}
 void clear(uint64_t i){a[i>>6]&=~(uint64_t(1)<<(i&63));}
 void set(uint64_t i){a[i>>6]|=uint64_t(1)<<(i&63);}
};
int main(int argc,char**argv){
 if(argc!=6){std::cerr<<"witness.bin max-attempted-primes trials-per-prime seed output-prefix\n";return 2;}
 const uint64_t cut=10000000,limit=2432107459;
 const uint64_t max_attempts=std::stoull(argv[2]),trials=std::stoull(argv[3]);
 uint64_t state=std::stoull(argv[4]);assert(state);
 auto rand64=[&](){state^=state<<13;state^=state>>7;state^=state<<17;return state;};
 std::string pref=argv[5];auto start=std::chrono::steady_clock::now();
 auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
 std::vector<uint32_t>ps,rs;std::vector<size_t>zi;uint32_t pair[2];
 std::ifstream in(argv[1],std::ios::binary);assert(in);
 while(in.read(reinterpret_cast<char*>(pair),8)){
  assert(pair[0]>cut && pair[1]<pair[0]);
  if(!ps.empty())assert(pair[0]>ps.back());
  ps.push_back(pair[0]);rs.push_back(pair[1]);if(!pair[1])zi.push_back(ps.size()-1);
 }
 assert(in.eof()&&!zi.empty());
 uint64_t zmax=ps[zi.back()];std::vector<int32_t>zindex(zmax+1,-1);
 for(size_t i=0;i<zi.size();++i)zindex[ps[zi[i]]]=int32_t(i);
 Bits live((limit+1)/2);live.clear(0);
 for(uint64_t p=3;p*p<=limit;p+=2)if(live.get(p/2))
  for(uint64_t q=p*p;q<=limit;q+=2*p)live.clear(q/2);
 for(size_t i:zi){assert(live.get(ps[i]/2));live.clear(ps[i]/2);}
 std::vector<uint8_t>blocked(zi.size(),0);std::vector<size_t>blocked_list;
 // All possible conflicts with a witness lie at originally deleted primes.
 auto protect=[&](uint64_t p,uint64_t r){
  uint64_t newblocks=0;
  for(uint64_t s:{r,p-r}){
   uint64_t q=s;if(q<=cut)q+=((cut-q)/p+1)*p;
   for(;q<=zmax;q+=p){int32_t j=zindex[q];if(j>=0){
    assert(!live.get(q/2));
    if(!blocked[j]){blocked[j]=1;blocked_list.push_back(j);++newblocks;}
   }}
  }
  return newblocks;
 };
 for(size_t i=0;i<ps.size();++i)if(rs[i])protect(ps[i],rs[i]);
 uint64_t initially_blocked=blocked_list.size(),attempted=0,restored=0,candidate_tests=0;
 uint64_t dependencies=0;
 std::cerr<<"sieved; zeros="<<zi.size()<<" initially_blocked="<<initially_blocked<<" seconds="<<elapsed()<<"\n";
 std::ofstream patches(pref+"_patches.csv");patches<<"prime,missing_residue\n";
 for(size_t jj=zi.size();jj-->0 && attempted<max_attempts;){
  if(blocked[jj])continue;
  size_t i=zi[jj];uint64_t p=ps[i];++attempted;
  for(uint64_t t=0;t<trials;++t){
   size_t donor;
   if(blocked_list.size()>=128 && (t&1))donor=blocked_list[rand64()%blocked_list.size()];
   else donor=rand64()%zi.size();
   uint64_t q0=ps[zi[donor]];
   if(live.get(q0/2))continue;
   uint64_t r=q0%p;if(!r)continue;r=std::min(r,p-r);++candidate_tests;
   bool hit=false;
   for(uint64_t s:{r,p-r}){
    uint64_t q=s;if(q<=cut)q+=((cut-q)/p+1)*p;if(!(q&1))q+=p;
    for(;q<=limit;q+=2*p)if(live.get(q/2)){hit=true;break;}
    if(hit)break;
   }
   if(hit)continue;
   // The donor is a prime in the original universe, so this missing class
   // genuinely relies on a retained deletion, not just a longer residue search.
   assert(q0%p==r || q0%p==p-r);
   dependencies+=protect(p,r);
   assert(!blocked[jj]);rs[i]=uint32_t(r);live.set(p/2);++restored;
   patches<<p<<","<<r<<"\n";break;
  }
  if(attempted%1000==0)std::cerr<<"attempted="<<attempted<<" restored="<<restored<<" blocked="<<blocked_list.size()<<" seconds="<<elapsed()<<"\n";
 }
 patches.close();std::ofstream out(pref+"_witness.bin",std::ios::binary);
 for(size_t i=0;i<ps.size();++i){uint32_t row[2]={ps[i],rs[i]};out.write(reinterpret_cast<const char*>(row),8);}
 out.close();
 std::ofstream meta(pref+"_result.json");
 meta<<"{\"restored_pairs\":"<<restored<<",\"attempted_primes\":"<<attempted<<",\"candidate_tests\":"<<candidate_tests
 <<",\"initially_blocked\":"<<initially_blocked<<",\"newly_blocked_deletions\":"<<dependencies<<",\"seconds\":"<<elapsed()<<"}\n";
 std::cerr<<"DONE restored="<<restored<<" seconds="<<elapsed()<<"\n";
}
