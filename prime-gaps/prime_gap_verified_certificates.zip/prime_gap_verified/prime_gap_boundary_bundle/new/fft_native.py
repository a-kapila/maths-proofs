"""Same radix-two butterflies and interval-generated twiddles as the baseline."""
from pathlib import Path
import ctypes,numpy as np
from periodic_shifted import twiddles,bit_reverse
lib=ctypes.CDLL(str(Path(__file__).with_name('fft_native_lib.so')))
lib.radix2_inplace.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_uint64]
lib.radix2_inplace.restype=None

def fft_rounded(values):
    N=len(values)
    assert N>=2 and N&(N-1)==0
    w=twiddles(N)
    a=np.asarray(values,dtype=np.complex128)[bit_reverse(N)]
    assert a.flags.c_contiguous and w.flags.c_contiguous
    lib.radix2_inplace(a.ctypes.data,w.ctypes.data,N)
    return a
