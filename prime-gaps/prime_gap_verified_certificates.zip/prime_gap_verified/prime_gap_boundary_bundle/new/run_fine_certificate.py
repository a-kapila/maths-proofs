"""Fine-grid certificate with native explicit radix-two butterflies.
The inherited 8192*2^-53 per-butterfly budget remains unchanged.
The generic absolute polynomial envelope is used for the added Z2*Z3 term.
"""
import sys,json
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'new'),str(BASE/'baseline/inherited/analysis'),str(BASE/'baseline/polynomial'),str(BASE/'analysis')]
import polynomial_cdf
from fft_native import fft_rounded
polynomial_cdf.fft_rounded=fft_rounded
import certify_centered as C
from certify_polynomial import amplitude

def generic_amplitude(hs,basis,E,spacing,S):
    v=amplitude(hs,basis,E,spacing,S)
    return v,v
C.profile_amplitude=generic_amplitude
out=C.run(sys.argv[1])
out['new_enclosures']['amplitude']='inherited generic absolute polynomial envelope'
out['new_enclosures']['fft']='explicit native IEEE radix-two butterflies; same interval twiddles and 8192u budget, no FMA or fast-math'
Path(sys.argv[1]).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
