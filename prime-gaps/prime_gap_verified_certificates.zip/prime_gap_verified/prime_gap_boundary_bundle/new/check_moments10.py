"""Independent high-precision quadrature diagnostics, not interval proofs."""
from pathlib import Path
import sys,json
import mpmath as mp
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from flint import arb,ctx
from shifted_core import setup
from multi_core import single_moments
mp.mp.dps=90;ctx.prec=256
d=json.load(open(B/'new/m3_fine.json'));k=d['k']
S=setup(k,d['theta'],d['beta'],d['relative_shift'])
c=mp.mpf(d['theta'])/mp.log(k);T=mp.mpf(d['beta'])/mp.log(k);b=k-1
A=mp.mpf(d['relative_shift'])/(c+b*T);u=c+b*T
m2=(1/c-1/u)/b+2*A*mp.log(u/c)/b+A*A*T
end=mp.log(u/c);cuts=[mp.mpf(i) for i in range(int(end)+1)]+[end]
results=[]
for xi in [0,7,70]:
 vals=single_moments(S,10,'zero' if xi==0 else 'fourier',arb(xi))
 for j in [0,1,2,3,4,5,6,8,10]:
  def f(y):
   t=c/b*mp.expm1(y)
   return (1/(c+b*t)+A)**2/m2*(t/T)**j*mp.exp(1j*xi*t)*c/b*mp.exp(y)
  direct=mp.quad(f,cuts)
  v=vals[j]
  if xi==0: mid=mp.make_mpf(v.mid().x._mpi_[0])
  else:mid=mp.mpc(mp.make_mpf(v.real.mid().x._mpi_[0]),mp.make_mpf(v.imag.mid().x._mpi_[0]))
  err=abs(mid-direct)/(1+abs(direct));assert err<mp.mpf('1e-55')
  results.append({'power':j,'frequency':xi,'scaled_absolute_error':mp.nstr(err,12)})
out={'checks':len(results),'precision_decimal_digits':90,'max_scaled_error':max(float(x['scaled_absolute_error']) for x in results),'results':results}
(B/'new/moment10_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
