import json,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'baseline/exploratory'))
from explore_products import optimize
D=json.load(open(BASE/'baseline/polynomial/m3.json'))
for name,basis in [('add23',[(),(2,),(3,),(4,),(2,2),(2,3)]),('degree5',[(),(2,),(3,),(4,),(2,2),(5,),(2,3)])]:
 r=optimize(D,basis,ncell=400,N=2**20,ng=40,spacing=2**-21,tol=1e-12)
 d={**D,**r};(BASE/f'new/m3_{name}_scout.json').write_text(json.dumps(d,indent=2))
 print(json.dumps({k:v for k,v in r.items() if k not in ['E','profiles']}),flush=True)
