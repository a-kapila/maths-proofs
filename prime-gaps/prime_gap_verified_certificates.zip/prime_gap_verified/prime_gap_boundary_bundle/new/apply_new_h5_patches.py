"""Reconstruct the complete new H5 residue certificate from the preceding one.
Usage: python new/apply_new_h5_patches.py previous.bin output.bin
The saved patch sequence is reproducible without rerunning the search.
"""
from pathlib import Path
import csv,hashlib,json,sys
import numpy as np

def main():
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    here=Path(__file__).resolve().parent
    meta=json.loads((here/'h5_patch_encoding.json').read_text())
    src,dst=map(Path,sys.argv[1:]);data=src.read_bytes()
    if hashlib.sha256(data).hexdigest()!=meta['base_sha256']:
        raise ValueError('Incorrect preceding certificate')
    a=np.frombuffer(data,dtype='<u4').reshape(-1,2).copy()
    if len(a)!=meta['pair_count']:raise ValueError('Wrong prime count')
    seen=set();total=0
    for rec in meta['patches']:
        path=here/rec['file']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=rec['sha256']:
            raise ValueError('Patch checksum mismatch')
        count=0
        with path.open() as f:
            for row in csv.DictReader(f):
                p,r=int(row['prime']),int(row['missing_residue'])
                i=int(np.searchsorted(a[:,0],p))
                if i==len(a) or int(a[i,0])!=p or int(a[i,1])!=0 or not 0<r<p or p in seen:
                    raise ValueError(f'Invalid restoration {p},{r}')
                seen.add(p);a[i,1]=r;count+=1
        if count!=rec['count']:raise ValueError('Wrong patch count')
        if hashlib.sha256(a.tobytes()).hexdigest()!=rec['output_sha256']:
            raise ValueError('Intermediate reconstructed checksum mismatch')
        total+=count
    dst.parent.mkdir(parents=True,exist_ok=True);a.tofile(dst)
    digest=hashlib.sha256(dst.read_bytes()).hexdigest()
    if digest!=meta['final_sha256']:raise ValueError('Final checksum mismatch')
    print(json.dumps({'restored_pairs':total,'prime_witnesses':len(a),'sha256':digest,'output':str(dst)}))
if __name__=='__main__':main()
