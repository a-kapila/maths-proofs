#include <cstddef>
#include <cstdint>
// The input is already bit-reversed. Every butterfly uses precisely the four
// real multiplications and six additions/subtractions of complex radix two.
// Build without fast-math and with FMA contraction disabled.
extern "C" void radix2_inplace(double *a,const double *w,std::uint64_t N){
 unsigned level=0;
 for(std::uint64_t half=1;half<N;half<<=1,++level){
  const std::uint64_t mask=half-1, stride=N/(2*half);
  #pragma omp parallel for schedule(static)
  for(std::uint64_t i=0;i<N/2;++i){
   std::uint64_t j=i&mask;
   std::uint64_t left=((i>>level)<<(level+1))+j,right=left+half;
   double ar=a[2*left],ai=a[2*left+1];
   double br=a[2*right],bi=a[2*right+1];
   double wr=w[2*j*stride],wi=w[2*j*stride+1];
   double rr=br*wr-bi*wi,ri=br*wi+bi*wr;
   a[2*left]=ar+rr; a[2*left+1]=ai+ri;
   a[2*right]=ar-rr; a[2*right+1]=ai-ri;
  }
 }
}
