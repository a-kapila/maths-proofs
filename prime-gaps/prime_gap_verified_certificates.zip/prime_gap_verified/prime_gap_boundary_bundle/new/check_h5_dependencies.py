"""Verify that every new witness uses a prime pair still deleted in the final set.
This supplements, not replaces, the all-prime admissibility verifier.
Usage: python new/check_h5_dependencies.py reconstructed-witness.bin
"""
from pathlib import Path
import csv,json,sys
import numpy as np
P=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit(__doc__)
a=np.fromfile(sys.argv[1],dtype='<u4').reshape(-1,2)
z=a[a[:,1]==0,0];upper=int(z[-1]);all_dependencies=set();rows=[]
for path in ['h5_dependent_patches.csv','h5_dependent2_patches.csv']:
    with (P/path).open() as f:
        for row in csv.DictReader(f):
            p,r=int(row['prime']),int(row['missing_residue']);deps=set()
            for s in (r,p-r):
                start=s+max(0,(10000000-s)//p+1)*p
                for q in range(start,upper+1,p):
                    i=int(np.searchsorted(z,q))
                    if i<len(z) and int(z[i])==q:deps.add(q)
            assert deps,(p,r)
            all_dependencies|=deps
            rows.append({'prime':p,'residue':r,'required_deleted_pairs':sorted(deps)})
out={'restored_pairs':len(rows),'distinct_remaining_deletions_used':len(all_dependencies),
     'every_new_witness_hits_a_deleted_prime_in_full_universe':True,'rows':rows}
assert len(rows)==296 and len(all_dependencies)==285
(P/'h5_dependency_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='rows'}))
