"""Exact finite-distribution checks of the newly used mixed moment identities."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import sys,json,math,random
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from polynomial_core import weights,needed_moments,marginal_terms
basis=[(),(2,),(3,),(4,),(2,2),(2,3)]
keys,marginal=needed_moments(basis)
checks=0
for n in range(1,6):
 for q in [F(1,2),F(1),F(3,2)]:
  support=[F(0),F(1,2),F(1)]
  probs=[F(1,5),F(1,3),F(7,15)]
  mu=[sum(p*x**j*q**int(2*x) for p,x in zip(probs,support)) for j in range(11)]
  formula=weights(n,mu,keys)
  direct=[F(0) for _ in keys]
  for ix in product(range(3),repeat=n):
   xs=[support[i] for i in ix]
   prob=math.prod(probs[i] for i in ix)*q**sum(int(2*x) for x in xs)
   Z={j:sum(x**j for x in xs) for j in range(2,11)}
   for j,key in enumerate(keys):direct[j]+=prob*math.prod(Z[p] for p in key)
  for a,b in zip(formula,direct):assert a==b;checks+=1
rng=random.Random(20261104); expansions=0
for _ in range(300):
 xs=[F(rng.randrange(0,101),100) for i in range(rng.randrange(1,8))];t=F(rng.randrange(0,101),100)
 Z={j:sum(x**j for x in xs) for j in range(2,11)}
 for mon in basis:
  lhs=math.prod(Z[p]+t**p for p in mon)
  rhs=sum(c*math.prod(Z[p] for p in keep)*t**power for keep,power,c in marginal_terms(mon))
  assert lhs==rhs;expansions+=1
out=dict(exact=True,basis=basis,moment_keys=keys,finite_distribution_moment_checks=checks,marginal_expansion_checks=expansions)
(B/'new/mixed_identity_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
