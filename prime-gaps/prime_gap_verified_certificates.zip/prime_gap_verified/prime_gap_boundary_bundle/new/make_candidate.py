import json,sys
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'baseline/exploratory'))
from explore_products import optimize
D=json.load(open(BASE/'baseline/polynomial/m3.json'));D['k']=110050
basis=[(),(2,),(3,),(4,),(2,2),(2,3)]
r=optimize(D,basis,ncell=600,N=2**20,ng=40,spacing=2**-21,tol=1e-12)
d={**D,**r};(BASE/'new/m3_candidate.json').write_text(json.dumps(d,indent=2))
print(json.dumps({k:v for k,v in r.items() if k not in ['E','profiles']}),flush=True)
