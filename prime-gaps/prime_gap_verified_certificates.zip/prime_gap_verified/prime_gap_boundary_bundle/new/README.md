# Mixed-coordinate and deletion-dependent prime-gap continuation

Date: 4 November 2026. This is a computational research continuation, not an
independently reviewed publication or a formally verified proof.

## Results

| Quantity | Preceding bound | This continuation | Analytic dimension |
|---|---:|---:|---:|
| H2 | 19920 | 19920 (unchanged) | 2305 (inherited) |
| H3 | 1360138 | 1359754 | 110070 (new) |
| H4 | 82294500 | 82294500 (unchanged) | 5089918 (inherited) |
| H5 | 4832823366 | 4832810284 | 232497861 (inherited) |

H3 uses the new mixed statistic Z2*Z3, a fresh fine-grid interval evaluation,
and an independently checked 110070-element tuple. H5 uses 296 restored signed
prime pairs with deletion-dependent witnesses, and a complete independent check
of the resulting 12204094-prime certificate. Its analytic certificate is reused.
No new prime-distribution theorem, H1 improvement, or global optimum is claimed.

## Run

This directory is `new/` inside the supplied complete bundle. All required
baseline source, earlier analytic certificates, and compressed H5 witnesses are
included. Python 3, NumPy, SciPy, mpmath, and a C++17 compiler with OpenMP are
required. The local `flint.py` is the inherited mpmath.iv compatibility backend,
NOT FLINT/Arb. Do not disable C++ or Python assertions; do not use fast-math.

From the bundle root:

```sh
bash new/reproduce.sh --checks-only
bash new/reproduce.sh --full
```

`--checks-only` verifies the saved rational endpoints, new identities, numerical
diagnostics, full H3 tuple, and the complete reconstructed H5 tuple. It does not
recompute the analytic quotient. `--full` additionally repeats the NEW H3
interval evaluation. Neither option independently audits all inherited
mathematical assumptions. The older root `reproduce.sh` reruns the preceding
continuation; the inherited subdirectories contain earlier reproduction scripts.

The saved fine H3 certificate was obtained with spacing 2^-22 and period 8,
using 2^25 FFT entries, six signed profiles, and 18 positive moment measures
for each of k-1 and k. It uses several GB of working memory. Full H5 verification
uses an independent segmented-byte sieve. The uncompressed prime/residue file
is reconstructed locally and is deliberately not duplicated in the archive.

## Files and status

- `m3_fine.json`, `m3_fine.interval_certificate.json`: exact new trial and
  successful certificate. Binary64 inputs are exact dyadic values; displays
  in the proof note are conservatively shortened.
- `m3_test.json`, `m3_test.interval_certificate.json`: FAILED coarse evaluation
  of the same physical trial. It is retained for transparency, not used as proof.
- `m3_candidate.json`: exploratory optimizer result at k=110050, NOT certified.
  The final trial uses the same coefficients at k=110070.
- `run_fine_certificate.py`, `fft_native.cpp`, `fft_native.py`: new evaluator
  wrapper and explicit radix-two butterflies. Same inherited 8192*2^-53 local
  error allowance and interval-generated twiddles; no bitwise equality to NumPy
  is assumed. See the proof note for the arithmetic argument.
- `h3.csv`, `h3_verified.json`, `h3_selection.json`: complete new tuple, independent
  check, and its selection from the preceding parent.
- `h5_dependent_patches.csv`, `h5_dependent2_patches.csv`: all 66+230 new patches.
- `h5_patch_encoding.json`: exact baseline, patch, intermediate, and final hashes.
- `apply_new_h5_patches.py`: reconstructs every prime/residue pair with hash checks.
- `h5_verified.json`: complete independent verification and exhaustive window scan.
- `h5_dependency_checks.json`: each new residue hits at least one prime that
  remains deleted. The 296 new witnesses jointly use 285 such deleted pairs.
- `deletion_aware_restore.cpp`: optional deterministic search; not required for
  verification of the saved result.
- `verify_new.py`: exact rational slicing, geometry equality, and result checks.
- `check_mixed_identities.py`, `check_moments10.py`, `check_fft_native.py`: diagnostics.
- `RESULTS.json`: authoritative summary for this continuation.

## Optional search reproduction

After the reconstruction stage has produced the previous full witness file:

```sh
g++ -O3 -std=c++17 new/deletion_aware_restore.cpp -o new/deletion_aware_restore
new/deletion_aware_restore new/recomputed/previous_h5.bin 20000 2048 20261104 new/recomputed/pass1
new/deletion_aware_restore new/recomputed/pass1_witness.bin 80000 4096 20261105 new/recomputed/pass2
```

Successful restorations are sequential. Every existing nonzero residue witness
is protected. Deleted primes that would invalidate a witness are blocked from
future restoration. No additional pair is deleted during the search. A final
independent all-prime check is still required and is provided by `reproduce.sh`.

## Dependencies and scope

The distribution theorem of Hexagon 2610.00419v1, inherited enlarged-support
argument, scalar interval/remainder bounds, Fourier and periodization estimates,
FFT error analysis, and IEEE arithmetic model remain dependencies. The new H3
certificate uses the inherited component-wise numerator bound, not the optional
Hilbert-space bound. Integer verification is separate from the search but is not
an independent expert review of the analytic proof. Search diagnostics are not
used as substitute proofs. No priority over unpublished work is asserted.
