#!/usr/bin/env bash
# Reproduce this continuation. Search is optional: the saved patches suffice.
# --checks-only omits the new interval evaluation; it still runs full tuple checks.
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---full}"
if [[ "$mode" != --full && "$mode" != --checks-only ]]; then
  echo "usage: bash new/reproduce.sh [--full|--checks-only]" >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-4}"
mkdir -p new/recomputed
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
"$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
python new/check_mixed_identities.py
python new/check_moments10.py
python new/check_fft_native.py
if [[ "$mode" == --full ]]; then
  python new/run_fine_certificate.py new/m3_fine.json
fi
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o new/recomputed/verify_tuple
new/recomputed/verify_tuple new/h3.csv baseline/inherited/tuples/h3_witness.csv 110070 > new/recomputed/h3_verified.json
python baseline/inherited/tuples/decode_h5.py new/recomputed/old_unpatched.bin
python baseline/h5/apply_patches.py new/recomputed/old_unpatched.bin new/recomputed/previous_h5.bin
python new/apply_new_h5_patches.py new/recomputed/previous_h5.bin new/recomputed/current_h5.bin
python new/check_h5_dependencies.py new/recomputed/current_h5.bin
"$cxx" -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o new/recomputed/verify_h5
new/recomputed/verify_h5 234360000 232497861 10000000 2432107459 new/recomputed/current_h5.bin > new/recomputed/h5_verified.json
python - <<'PY'
from pathlib import Path
import json
p=Path('new')
for name in ['h3_verified.json','h5_verified.json']:
    old=json.loads((p/name).read_text());new=json.loads((p/'recomputed'/name).read_text())
    assert new['verified']
    for k,v in old.items():
        if k!='seconds':assert new[k]==v,(name,k,new[k],v)
    print(name, 'verified, diameter =',new['diameter'])
PY
python new/verify_new.py
