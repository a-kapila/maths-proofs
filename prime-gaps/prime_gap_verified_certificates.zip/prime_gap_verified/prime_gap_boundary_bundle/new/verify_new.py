"""Exact checks of the new saved certificate, trial relation, and integer outputs.

This verifies the saved endpoints and their mathematical use. It does not replace
rerunning the interval evaluator or reviewing the inherited analytic theorem.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
load=lambda name:json.loads((ROOT/name).read_text())
t=load('m3_fine.json');c=load('m3_fine.interval_certificate.json')
q=F(c['Q_lower'])-F(c['restriction']['loss_upper'])
rho=F(1,4)+F(t['omega']);m=t['m'];k=t['k']
assert m==3 and k==110070 and c['m']==m and c['k']==k
assert 240*F(t['omega'])+80*F(t['smooth_delta'])<3
assert F(t['ufrac'])<1
K=int(F(k*m)/(rho*q))+1
assert K==k and q>F(m)/rho
v=load('h3_verified.json');assert v['verified'] and v['k']==K
assert v['last']-v['first']==v['diameter']==1359754
coarse=load('m3_test.json')
# Fine certificate evaluates exactly the same physical profile as the failed run.
assert t['k']==coarse['k'] and t['basis']==coarse['basis']
for key in t:
    if key not in {'delta','E','eps_cells','note'}:
        assert t[key]==coarse[key], key
assert F(t['delta'])*2==F(coarse['delta'])
assert t['eps_cells']==2*coarse['eps_cells']
assert t['E']==[2*e for e in coarse['E']]
eps=F(t['eps_cells'])*F(t['delta'])
assert 2*rho*(1+eps)<1
assert F(c['restriction']['kappa'])<(F(1,4)+F(t['smooth_delta'])/2)/rho
co=load('m3_test.interval_certificate.json')
assert co['Q_lower']<co['target_upper']
assert c['num_original_lower']>=c['num_triangle_lower']
h5=load('h5_verified.json');assert h5['verified'] and h5['failures']==0
assert h5['k']==232497861 and h5['diameter']==4832810284
assert h5['last']-h5['first']==h5['diameter']
assert h5['nonzero_witnesses_checked']+h5['zero_witnesses_checked']==12204094
assert h5['parent_cardinality']==233950386+2*296
assert h5['candidate_windows']==h5['parent_cardinality']-h5['k']+1
relax=4804108302
out={'analytic_dimension':K,'exact_margin':str(q-F(m)/rho),
     'margin_decimal':float(q-F(m)/rho),'trial_sha256':hashlib.sha256((ROOT/'m3_fine.json').read_bytes()).hexdigest(),
     'H3':v['diameter'],'H5':h5['diameter'],'restored_pairs':296,
     'H5_restore_only_remaining_fraction_exact':str(F(h5['diameter']-relax,h5['diameter'])),
     'H5_restore_only_remaining_percent':float(100*F(h5['diameter']-relax,h5['diameter']))}
(ROOT/'saved_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
