"""Reuses the inherited certifier, with its exact-operation-order accelerator.
The changes here are memory management and substitution of the separately
checked implementation of the SAME directed arithmetic profile bounds.
"""
import sys,json,time
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'baseline/inherited/analysis'),str(BASE/'baseline/polynomial'),str(BASE/'analysis')]
import certify_polynomial as C
from streaming_cdf import StreamingCDF,direct_check
from fast_profile import profile_bounds
import direct_fourier_check
C.PolynomialCDF=StreamingCDF
C.profile_bounds=profile_bounds
direct_fourier_check.check=direct_check
C.run(sys.argv[1])
