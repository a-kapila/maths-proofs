"""Diagnostics for the explicit IEEE butterfly kernel.
Bitwise equality to NumPy is NOT assumed. Both satisfy the inherited error budget.
The proof is by operation count; these comparisons are diagnostics, not the proof.
"""
from pathlib import Path
import sys,json,time
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from periodic_shifted import fft_rounded as reference
from fft_native import fft_rounded as native
rng=np.random.default_rng(20261104)
results=[]
for power in list(range(1,19))+[20,21]:
    a=rng.standard_normal(2**power)+1j*rng.standard_normal(2**power)
    st=time.time(); r=reference(a);rt=time.time()-st
    st=time.time(); n=native(a);nt=time.time()-st
    exact=np.array_equal(r.view(np.uint64),n.view(np.uint64))
    difference=float(np.max(abs(r-n)))
    budget=4*8192*2.**-53*power*float(np.sum(abs(a)))
    assert difference<budget
    results.append(dict(power=power,bitwise_identical=exact,max_difference=difference,comparison_budget=budget,reference_seconds=rt,native_seconds=nt))
print(json.dumps(results))
(B/'new/fft_checks.json').write_text(json.dumps(results,indent=2)+'\n')
