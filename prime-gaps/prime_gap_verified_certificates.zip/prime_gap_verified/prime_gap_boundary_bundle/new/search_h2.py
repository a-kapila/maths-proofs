# Launch bounded, reproducible integer searches; the output is independently checked.
import subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parents[1]
log=open(p/'new/h2_long.log','w')
for seed in [1003,1019,1031,1061]:
 cmd=[str(p/'new/tuple_local'),'19918','2305',str(p/'new/h2_shifted_witness.csv'),'300000',str(p/f'new/h2_local_{seed}'),str(seed)]
 subprocess.run(cmd,stdout=log,stderr=log,check=True)
 f=p/f'new/h2_local_{seed}.csv'
 if f.exists() and len(f.read_text().splitlines())>=2305: break
log.close()
