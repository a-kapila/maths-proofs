from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parents[1]
v=json.load(open(B/'next_pair/MANIFEST.json'))
for name,want in v['sha256'].items():
 actual=hashlib.sha256((B/name).read_bytes()).hexdigest()
 assert actual==want,(name,actual,want)
print('MANIFEST OK',len(v['sha256']))
