#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
mode="${1:---checks-only}"
case "$mode" in --checks-only|--full) ;; *) echo 'usage: bash next_pair/reproduce.sh --checks-only|--full' >&2; exit 2;; esac
python next_pair/check_manifest.py
if [[ "$mode" == --full ]]; then
 for m in 2 3; do
  python continued/power_mean.py "$m" 3
  cp "continued/m${m}_power3.json" "continued/m${m}_power3_cdf.npz" next_pair/
  python next_pair/extra_moments.py "$m" 4 22
 done
fi
python next_pair/check_algebra.py
python next_pair/check_moments.py
python next_pair/verify.py
