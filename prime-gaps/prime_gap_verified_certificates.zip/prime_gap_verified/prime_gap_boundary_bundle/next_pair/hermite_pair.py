"""Quadratic Hermite upper majorant for inverse squared pair denominator.
Fresh tags V3,V4,V2^2 are combined with inherited V1,V2 CDF enclosures.
No inherited quotient or arithmetic support bound is recomputed.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import numpy as np
from scipy.optimize import minimize_scalar
sys.path.insert(0,str(Path(__file__).resolve().parent));import cubic_pair as cp
B=cp.B;O=cp.O;I=cp.I;J=cp.J;rad=cp.rad;base=cp.base

def inputs(m):
    v=cp.inputs(m)
    for p in [1,4,22]:
        ed,lo,hi=cp.cells(m,p);assert ed==v['edges'];v['lo'+str(p)]=lo;v['hi'+str(p)]=hi
    return v

def m1_lower(k,e,l,r,h1,h2,h3):
    # All coefficient bounds are exact and conservative on [l,r].
    z=1-r
    c0=F(2,k)*(z*z+e*F(k,k-1)*z*l)
    c2=(2*e*(k-2)*(1-l)+e*e*(2*k-1)*l)/(k-1)
    c3=e*e*k/(k-1)
    return max(F(0),I(c0*h1+c2*h2-c3*h3).lo)

def m2_upper(k,e,l,r,h1,h2,h3,h22,h4):
    z=1-l
    c0=2*z*z*r/(k*(k-1))
    c2=2*z*z*(k-2)/(k*(k-1))+6*z*e*r/(k-1)
    c3=(2*e*(k-4)*(1-r)+2*e*e*k*r)/(k-1) # increasing
    c22=e*e*(2*k-1)/(k-1);c4=3*e*e*k/(k-1)
    ans=I(c0*h1+c2*h2+c3*h3+c22*h22-c4*h4).hi
    assert ans>=0
    return ans

def correction(v,eta,zeta):
    assert eta>=1
    k=v['k'];sigma=v['sigma'];src=v['src'];den=F(*src['den_upper']);bad=F(*src['removed_square_mass_upper']);total=I(0);theta=[];used=0
    for j,(left,right) in enumerate(zip(v['edges'][:-1],v['edges'][1:])):
        l=left/sigma;r=right/sigma
        t1=m1_lower(k,eta,l,r,v['lo1'][j],v['lows'][j],v['hi3'][j])
        t2=m2_upper(k,eta,l,r,v['hi1'][j],v['highs'][j],v['hi3'][j],v['hi22'][j],v['lo4'][j])
        aa=I(zeta*t1/(1-zeta*l)**3).lo
        bb=I(zeta*zeta*t2/(1-zeta*r)**4).hi
        if aa<=0:
            theta.append(None);continue
        th=bb/aa
        gain=I(aa*aa*(2*aa+bb)/(aa+bb)**2).lo
        assert gain>=0
        total+=I(gain);theta.append(th);used+=1
    # A_theta <= 2 for theta >= 0, so the positive part of the correction
    # is bounded by 2*zeta/(1-zeta)^3 * M1, and M1 <= 2U eta^2.
    removal=4*zeta*v['U']*eta**2/(1-zeta)**3*bad
    low=(total.lo-removal)/den
    assert low>0
    return dict(correction_lower=low,integral_lower=total.lo,removed_upper=removal,den_upper=den,nonzero_cells=used,theta=theta)

def choose_eta(v):
    k=v['k'];sig=v['sigma'];src=v['src'];z=float(2*v['rho']*sig);den=float(F(*src['den_upper']));bad=float(F(*src['removed_square_mass_upper']));U=float(v['U'])
    l=np.array([float(x/sig) for x in v['edges'][:-1]]);r=np.array([float(x/sig) for x in v['edges'][1:]]);rr=1-r;rl=1-l
    arrays={a:np.array(list(map(float,v[a]))) for a in ['lo1','hi1','lows','highs','lo3','hi3','lo4','hi4','lo22','hi22']}
    xx=np.array([float(F(*c['right'])/sig) for c in src['cells']]);mass=np.array([float(F(*c['mass_lower'])) for c in src['cells']]);ok=xx>0;xx=xx[ok];mass=mass[ok]
    def obj(e):
        r1=(e/(1-z))**2;R=(1+(e-1)*xx)/(1-z*xx);M=r1-((mass*(r1-R*R)/xx).sum()-r1*bad)/den
        t1=(2/k*(rr*rr+e*k/(k-1)*rr*l))*arrays['lo1'] + (2*e*(k-2)*(1-l)+e*e*(2*k-1)*l)/(k-1)*arrays['lows']-e*e*k/(k-1)*arrays['hi3'];t1=np.maximum(t1,0)
        t2=(2*rl*rl*r/(k*(k-1)))*arrays['hi1'] +(2*rl*rl*(k-2)/(k*(k-1))+6*rl*e*r/(k-1))*arrays['highs'] +(2*e*(k-4)*(1-r)+2*e*e*k*r)/(k-1)*arrays['hi3']+e*e*(2*k-1)/(k-1)*arrays['hi22']-3*e*e*k/(k-1)*arrays['lo4']
        t2=np.maximum(t2,0);a=z*t1/(1-z*l)**3;b=z*z*t2/(1-z*r)**4;mask=a>0
        gain=(a[mask]**2*(2*a[mask]+b[mask])/(a[mask]+b[mask])**2).sum()
        corr=(gain-4*z*U*e*e/(1-z)**3*bad)/den
        return 2*z*z*base.jf(k,k*e)*(M-corr)
    opt=minimize_scalar(obj,bounds=(1.0,1.7),method='bounded',options={'xatol':1e-9})
    return F(round(float(opt.x)*10**6),10**6)

def compute(m,eta=None,select=True):
    v=inputs(m);k=v['k'];rho=v['rho'];sig=v['sigma'];z=2*rho*sig
    if eta is None:eta=choose_eta(v)
    mo=rad.radial_moment(m,eta,z);cr=correction(v,eta,z);jj=J(k,k*eta)
    pair=2*z*z*jj.hi*(mo['moment_upper']-cr['correction_lower']);sur=rho*v['q']-m
    ratio=sur/pair;budget=(ratio.numerator-1)//ratio.denominator
    lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);zs=lam*sig/b
    mos=rad.radial_moment(m,eta,zs);crs=correction(v,eta,zs);ps=2*zs*zs*jj.hi*(mos['moment_upper']-crs['correction_lower']);ss=lam*v['q']-m
    out=dict(m=m,k=k,eta=eta,rho=rho,sigma=sig,q_lower=v['q'],surplus=sur,pair_upper=pair,budget=budget,radial=mo,correction=cr,J_lower=jj.lo,J_upper=jj.hi,strict_radial=mos,strict_correction=crs,strict_pair_upper=ps,coordinate_cap_upper=v['U'],previous_bound={2:19846,3:1358012}[m])
    if select:
        w=base.load_witness(v['witness']);arr=base.allowed(w,-v['extent'],v['extent']);sub,sel=base.choose(arr,k,budget)
        for p in base.primes_up_to(k):
            if int(p) not in w:
                missing=np.flatnonzero(np.bincount(sub%p,minlength=int(p))==0);assert len(missing);w[int(p)]=int(missing[0])
        cnt=sel['long_pairs'];margin=sur-cnt*pair;strict=ss-cnt*ps;assert margin>0 and strict>0
        np.savetxt(O/f'hermite_m{m}_tuple.txt',sub,fmt='%d');np.savetxt(O/f'hermite_m{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
        pairs=base.enumerate_long_pairs(sub,sel['D']);assert len(pairs)==cnt
        np.savetxt(O/f'hermite_m{m}_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
        out.update(selection=sel,first=int(sub[0]),last=int(sub[-1]),tuple_diameter=int(sub[-1]-sub[0]),margin=margin,strict_margin=strict)
    (O/f'hermite_m{m}_result.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
    print(json.dumps(dict(m=m,eta=float(eta),pair=float(pair),surplus=float(sur),correction=float(cr['correction_lower']),budget=budget,selection=out.get('selection'),margin=float(out.get('margin',0)))),flush=True)
    return out
if __name__=='__main__':
    for arg in sys.argv[1:]:compute(int(arg))
