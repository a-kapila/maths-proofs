"""Exact endpoint recomputation plus independent integer tuple/pair checks."""
from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'next_pair';sys.path.insert(0,str(O))
from hermite_pair import compute,rad
for source,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
    subprocess.run(['g++','-O3','-std=c++17',str(B/source),'-o',str(O/name)],check=True)
rows=[]
for m in [2,3]:
    old=json.load(open(O/f'hermite_m{m}_result.json'));eta=F(int(old['eta']['numerator']),int(old['eta']['denominator']))
    new=compute(m,eta=eta);assert rad.old.encode(new)==old
    k=new['k'];D=new['selection']['D'];ap=O/f'hermite_m{m}_tuple.txt';wp=O/f'hermite_m{m}_witness.csv'
    def run(args,path):
        r=subprocess.run(list(map(str,args)),text=True,capture_output=True,check=True,cwd=B);path.write_text(r.stdout);return json.loads(r.stdout)
    cpp=run([O/'verify_tuple',ap,wp,k],O/f'm{m}_cpp_verified.json');pairs=run([O/'check_pairs','tuple',ap,D],O/f'm{m}_cpp_pairs.json')
    a=np.loadtxt(ap,dtype=np.int64);assert len(a)==k and np.all(a[1:]>a[:-1])
    w=dict(map(tuple,np.loadtxt(wp,dtype=np.int64,delimiter=',',skiprows=1)))
    sieve=np.ones(k+1,dtype=bool);sieve[:2]=False
    for p in range(2,math.isqrt(k)+1):
        if sieve[p]:sieve[p*p::p]=False
    primes=np.flatnonzero(sieve)
    for p in primes:assert 0<=w[int(p)]<p and np.all(a%p!=w[int(p)])
    listed=[];j=0
    for i,ai in enumerate(a):
        j=max(j,i+1)
        while j<k and a[j]-ai<=D:j+=1
        for q in range(j,k):listed.append((i,q,int(ai),int(a[q]),int(a[q]-ai)))
    saved=np.loadtxt(O/f'hermite_m{m}_long_pairs.csv',dtype=np.int64,delimiter=',',skiprows=1).reshape(-1,5)
    assert np.array_equal(np.array(listed,dtype=np.int64).reshape(-1,5),saved)
    assert pairs['long_pairs']==len(listed)==new['selection']['long_pairs']
    assert cpp['verified'] and cpp['checked_primes']==len(primes)
    row=dict(m=m,k=k,previous_bound=new['previous_bound'],new_bound=D,reduction=new['previous_bound']-D,first=int(a[0]),last=int(a[-1]),full_diameter=int(a[-1]-a[0]),pair_budget=new['budget'],long_pairs=len(listed),pair_upper=float(new['pair_upper']),surplus=float(new['surplus']),margin=float(new['margin']),strict_margin=float(new['strict_margin']),eta=float(new['eta']),checked_primes=len(primes),sha256=hashlib.sha256(ap.read_bytes()).hexdigest())
    assert row['reduction']>0
    (O/f'm{m}_python_verified.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);print('VERIFIED',row,flush=True)
result=dict(status='passed',bounds={'H2':rows[0]['new_bound'],'H3':rows[1]['new_bound'],'H4':82234788,'H5':4830355416},results=rows,scope='New Hermite pair-denominator inequality; fresh V3, V4 and V2^2 weighted CDFs for two trials. Earlier quotient, support-loss, radial V1 and V2 CDF certificates inherited. Complete tuple and pair checks. Full analytic chain not independently expert-reviewed.')
(O/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
