"""Restricted pair-sum cap and exact cubic-moment denominator correction.
Inherited Fourier certificates are explicit dependencies. New scalar acceptance
uses outward rational interval arithmetic and exact Fractions only.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,hashlib
import numpy as np
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1]; O=B/'next_pair'
sys.path.insert(0,str(B/'continued'))
import pair_improvement as old
I=old.I; J=old.J; base=old.base; rad=old.rad

def cells(m,p):
    prefix=O/f'm{m}_power{p}'
    meta=json.load(open(prefix.with_suffix('.json'))); tp=B/meta['trial'];tr=json.load(open(tp));zz=np.load(str(prefix)+'_cdf.npz')
    assert meta['trial_sha256']==hashlib.sha256(tp.read_bytes()).hexdigest()
    keys=[tuple(x) for x in meta['moment_keys']];hs=[[F(x) for x in h] for h in tr['profiles']];nc=len(hs[0]);co=defaultdict(lambda:[F(0)]*nc)
    for h,bi in zip(hs,tr['basis']):
        for g,bj in zip(hs,tr['basis']):
            key=tuple(sorted(bi+bj));co[key]=[a+x*y for a,x,y in zip(co[key],h,g)]
    assert set(keys)==set(co)
    edges=[F(tr['delta'])*e for e in tr['E']];assert all(F(float(x))==e for x,e in zip(zz['y'],edges))
    lows=[F(0)]*nc;highs=[F(0)]*nc
    for i,key in enumerate(keys):
        lo=list(map(F,map(float,zz['L'][i])));hi=list(map(F,map(float,zz['V'][i])))
        for j,c in enumerate(co[key]):
            ml=max(F(0),lo[j+1]-hi[j]);mu=hi[j+1]-lo[j];assert 0<=ml<=mu
            lows[j]+=c*(ml if c>=0 else mu);highs[j]+=c*(mu if c>=0 else ml)
    lows=[max(F(0),v) for v in lows];assert all(l<=u for l,u in zip(lows,highs))
    return edges,lows,highs

def inputs(m):
    v=old.inputs(m);edges,lo3,hi3=cells(m,3); assert edges==v['edges']
    v['lo3']=lo3;v['hi3']=hi3
    delta=F(v['tr']['smooth_delta']) if m==2 else F(float(6e-7))
    omega=v['rho']-F(1,4)
    assert 240*omega+80*delta<3
    kappa=(F(1,4)+delta/2)/v['rho']/v['sigma']
    v0=delta/v['rho']/v['sigma'];U=v['U']
    L0=min(2*U,max(U+v0,(3*U+2*kappa)/5),F(1))
    assert 0<L0<2*U
    v.update(delta=delta,kappa_normalized_upper=kappa,v0_normalized_upper=v0,L0=L0)
    return v

def slope(zeta,L0,x):
    d=1-zeta*x;L=min(L0,x)
    assert d>0
    return zeta*(2*d+zeta*L)/(d*d*(d+zeta*L)**2)

def coeff(k,eta,zeta,L0,x):
    A=slope(zeta,L0,x)
    b2=(2*eta*(k-2)*(1-x)+eta**2*(2*k-1)*x)/(k-1)
    b3=eta**2*k/(k-1)
    return A*b2,A*b3

def correction(v,eta,zeta):
    assert eta>=1
    k=v['k'];sig=v['sigma'];L0=v['L0'];U=v['U'];src=v['src'];den=F(*src['den_upper']);bad=F(*src['removed_square_mass_upper'])
    total=I(0);terms=[]
    for j,(l,r,l2,u3) in enumerate(zip(v['edges'][:-1],v['edges'][1:],v['lows'],v['hi3'])):
        l/=sig;r/=sig
        b2,_=coeff(k,eta,zeta,L0,l);_,b3=coeff(k,eta,zeta,L0,r)
        # Exact M1 is positive. The omitted scalar is also positive. Its
        # nonlinear part is positive under the source coordinate cutoff.
        assert 2*(k-2)-eta*k*U>=0
        t=max(F(0),b2*l2-b3*u3)
        total+=I(t);terms.append(t)
    scalar=I(0)
    for c in src['cells']:
        l=F(*c['left'])/sig;r=F(*c['right'])/sig;mass=F(*c['mass_lower'])
        a0=slope(zeta,L0,l)*F(2,k)*((1-r)**2+eta*F(k,k-1)*(1-r)*l)
        scalar+=I(mass)*a0
    # On the unrestricted profile support M1 <= 2U * eta^2. Its polynomial
    # nonnegativity makes this a bound for mass subsequently removed.
    removed=slope(zeta,L0,F(1))*2*U*eta**2*bad
    low=(total.lo+scalar.lo-removed)/den
    assert low>0
    return dict(correction_lower=low,nonlinear_integral_lower=total.lo,scalar_integral_lower=scalar.lo,removed_upper=removed,den_upper=den,restricted_pair_sum_upper=L0)

def choose_eta(v,m):
    sig=v['sigma'];src=v['src'];k=v['k'];z=float(2*v['rho']*sig);L0=float(v['L0']);den=float(F(*src['den_upper']));bad=float(F(*src['removed_square_mass_upper']));U=float(v['U'])
    x=np.array([float(F(*c['right'])/sig) for c in src['cells']]);mass=np.array([float(F(*c['mass_lower'])) for c in src['cells']]);ok=x>0;x=x[ok];mass=mass[ok]
    l=np.array([float(x/sig) for x in v['edges'][:-1]]);r=np.array([float(x/sig) for x in v['edges'][1:]]);l2=np.array(list(map(float,v['lows'])));u3=np.array(list(map(float,v['hi3'])))
    def sl(x):
        d=1-z*x;L=np.minimum(L0,x);return z*(2*d+z*L)/(d*d*(d+z*L)**2)
    def objective(e):
        R1=(e/(1-z))**2;R=(1+(e-1)*x)/(1-z*x);M=R1-((mass*(R1-R*R)/x).sum()-R1*bad)/den
        b2=sl(l)*(2*e*(k-2)*(1-l)+e*e*(2*k-1)*l)/(k-1);b3=sl(r)*e*e*k/(k-1)
        corr=(np.maximum(0,b2*l2-b3*u3).sum()-sl(1)*2*U*e*e*bad)/den
        return 2*z*z*base.jf(k,k*e)*(M-corr)
    opt=minimize_scalar(objective,bounds=(1.0,1.7),method='bounded',options={'xatol':1e-8})
    return F(round(float(opt.x)*1000000),1000000)

def compute(m,select=True):
    v=inputs(m);k=v['k'];rho=v['rho'];sig=v['sigma'];z=2*rho*sig;eta=choose_eta(v,m)
    mo=rad.radial_moment(m,eta,z);cr=correction(v,eta,z);j=J(k,k*eta)
    pair=2*z*z*j.hi*(mo['moment_upper']-cr['correction_lower']);sur=rho*v['q']-m
    frac=sur/pair;budget=(frac.numerator-1)//frac.denominator
    lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);zs=lam*sig/b
    mos=rad.radial_moment(m,eta,zs);crs=correction(v,eta,zs);ps=2*zs*zs*j.hi*(mos['moment_upper']-crs['correction_lower']);ss=lam*v['q']-m
    out=dict(m=m,k=k,eta=eta,rho=rho,sigma=sig,q_lower=v['q'],surplus=sur,pair_upper=pair,budget=budget,radial=mo,correction=cr,J_lower=j.lo,J_upper=j.hi,strict_radial=mos,strict_correction=crs,strict_pair_upper=ps,coordinate_cap_upper=v['U'],normalized_tail_cap_upper=v['kappa_normalized_upper'],normalized_u0_upper=v['v0_normalized_upper'],previous_bound={2:19846,3:1358012}[m])
    if select:
        w=base.load_witness(v['witness']);arr=base.allowed(w,-v['extent'],v['extent']);sub,sel=base.choose(arr,k,budget)
        for p in base.primes_up_to(k):
            if int(p) not in w:
                missing=np.flatnonzero(np.bincount(sub%p,minlength=int(p))==0);assert len(missing);w[int(p)]=int(missing[0])
        cnt=sel['long_pairs'];margin=sur-cnt*pair;strict=ss-cnt*ps;assert margin>0 and strict>0
        np.savetxt(O/f'm{m}_tuple.txt',sub,fmt='%d');np.savetxt(O/f'm{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
        pairs=base.enumerate_long_pairs(sub,sel['D']);assert len(pairs)==cnt
        np.savetxt(O/f'm{m}_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
        out.update(selection=sel,first=int(sub[0]),last=int(sub[-1]),tuple_diameter=int(sub[-1]-sub[0]),margin=margin,strict_margin=strict)
    (O/f'm{m}_result.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
    print(json.dumps(dict(m=m,eta=float(eta),pair=float(pair),surplus=float(sur),L0=float(v['L0']),correction=float(cr['correction_lower']),budget=budget,selection=out.get('selection'),margin=float(out.get('margin',0)))),flush=True)
    return out
if __name__=='__main__':
    for a in sys.argv[1:]:compute(int(a))
