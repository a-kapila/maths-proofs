"""Exact rational checks of the new identities and cell inequalities."""
from fractions import Fraction as F
from pathlib import Path
import sys,json,random,itertools
sys.path.insert(0,str(Path(__file__).resolve().parent));import hermite_pair as hp
O=hp.O;random.seed(20261105)
counts=dict(weight_identities=0,first_moment_identities=0,second_moment_identities=0,hermite_identities=0,cell_enclosures=0)
for _ in range(1000):
    k=random.randrange(3,14);raw=[random.randrange(0,30) for j in range(k)];total=sum(raw)
    if total==0:raw[0]=1;total=1
    yy=[F(u,total+random.randrange(0,30)+1) for u in raw]
    # Normalize one more time if the differing denominators allow sum > 1.
    sm=sum(yy)
    if sm>1:yy=[q/(2*sm) for q in yy]
    x=sum(yy);r=1-x;e=F(random.randrange(100,171),100);a=k*e;P=k*(k-1)//2
    vv={p:sum(y**p for y in yy) for p in range(1,5)}
    weights=[]
    for i in range(k):
        for j in range(i+1,k):
            w=(r+a*yy[i])*(r+a*yy[j])+a*a/F(2*k)*(yy[i]-yy[j])**2
            weights.append((w,yy[i]+yy[j]))
    assert sum(w for w,u in weights)/P==(r+e*x)**2;counts['weight_identities']+=1
    t1=sum(w*u for w,u in weights)/P
    m1=2*r*r*x/k+2*r*e/(k-1)*(x*x+(k-2)*vv[2])+e*e/(k-1)*((2*k-1)*x*vv[2]-k*vv[3])
    assert m1==t1;counts['first_moment_identities']+=1
    t2=sum(w*u*u for w,u in weights)/P
    m2=2*r*r/(k*(k-1))*(x*x+(k-2)*vv[2])+2*r*e/(k-1)*((k-4)*vv[3]+3*x*vv[2])+e*e/(k-1)*(2*k*x*vv[3]+(2*k-1)*vv[2]**2-3*k*vv[4])
    assert m2==t2;counts['second_moment_identities']+=1
    left=max(F(0),x-F(1,37));right=min(F(1),x+F(1,29))
    lo=hp.m1_lower(k,e,left,right,x,vv[2],vv[3]);hi=hp.m2_upper(k,e,left,right,x,vv[2],vv[3],vv[2]**2,vv[4])
    assert lo<=t1 and hi>=t2;counts['cell_enclosures']+=1
for _ in range(3000):
    z=F(random.randrange(0,2000),random.randrange(1,100));t=F(random.randrange(0,1000),random.randrange(1,100))
    A=2*(1+3*t+t*t)/(1+t)**3;B=(3+t)/(1+t)**3
    err=1-A*z+B*z*z-1/(1+z)**2
    fact=z*(z-t)**2*(t*z+2*t+3*z+4)/((1+t)**3*(1+z)**2)
    assert err==fact and err>=0 and 0<A<=2;counts['hermite_identities']+=1
(O/'algebra_checks.json').write_text(json.dumps(counts,indent=2)+'\n');print(counts)
