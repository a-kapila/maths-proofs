"""Independent diagnostics, not substitutes for the analytic remainder proofs."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,itertools,math
import numpy as np
import mpmath as mp
B=Path(__file__).resolve().parents[1];O=B/'next_pair'
sys.path[:0]=[str(O),str(B/'continued'),str(B/'direct_mean'),str(B/'fused_pair')]
from extra_moments import SquareCDF,PowerCDF,ctx
from capped_mean import tagged_weights,acb
from polynomial_core import weights
mp.mp.dps=90;ctx.prec=256

def mpv(a):return mp.make_mpf(a.x._mpi_[0])
integ=0;fourier=0;finite=0
for m in [2,3]:
    tp=B/('trials/m2_final.json' if m==2 else 'focus23/m3_fine.json');tr=json.load(open(tp));sig=1+F(tr['delta'])*tr['eps_cells'];k=tr['k']
    theta=mp.mpf(tr['theta']);beta=mp.mpf(tr['beta']);rr=mp.mpf(tr['relative_shift']);c=theta/mp.log(k);T=beta/mp.log(k);b=k-1;A=rr/(c+b*T)
    g=lambda x:1/(c+b*x)+A
    norm=(1/c-1/(c+b*T))/b+2*A*mp.log((c+b*T)/c)/b+A*A*T
    for tag in [3,4,22]:
        ob=SquareCDF(tr,sig) if tag==22 else PowerCDF(tr,sig,tag)
        dat=np.load(O/f'm{m}_power{tag}_cdf.npz');mu,nu=ob.moments();mass=tagged_weights(k,mu,nu,ob.keys)
        for xi in [0,3,30]:
            mm,nn=ob.moments('zero') if xi==0 else ob.moments('fourier',xi)
            for j in [0,2,ob.jmax-(1 if tag==22 else tag)]:
                L=mp.log(1+b*T/c)
                def f(y):
                    x=c*mp.expm1(y)/b;dx=c*mp.exp(y)/b
                    factor=(T/mp.mpf(float(sig)))**4/k if tag==22 else (x/mp.mpf(float(sig)))**tag
                    return factor*(x/T)**j*g(x)**2*mp.exp(1j*xi*x)*dx/norm
                val=mp.quad(f,[0,L/4,L/2,3*L/4,L]);enc=nn[j]
                if xi==0:
                    assert mpv(enc.lower())<=val.real<=mpv(enc.upper()),(m,tag,xi,j)
                else:
                    enc=acb(enc)
                    assert mpv(enc.real.lower())<=val.real<=mpv(enc.real.upper()),(m,tag,xi,j,'real')
                    assert mpv(enc.imag.lower())<=val.imag<=mpv(enc.imag.upper()),(m,tag,xi,j,'imag')
                integ+=1
        C=dat['C'];freq=2*mp.pi/8;Jnum=C.shape[1]
        for at in [len(dat['y'])//4,len(dat['y'])//2,3*len(dat['y'])//4]:
            y=mp.mpf(float(dat['y'][at]));ph=[mp.exp(-1j*freq*y*j) for j in range(1,Jnum+1)]
            for row in range(len(ob.keys)):
                cc=[mp.mpc(float(v.real),float(v.imag)) for v in C[row]]
                val=mpv(mass[row].mid())*y/8+2*mp.fsum(v.real for v in cc)-2*mp.fsum((v*p).real for v,p in zip(cc,ph))
                assert mp.mpf(float(dat['L'][row,at]))<=val<=mp.mpf(float(dat['V'][row,at])),(m,tag,row,at)
                fourier+=1
        print('numeric diagnostics passed',m,tag,flush=True)
# Exact finite-law check of appended tags and constant-tag implementation.
xs=[F(0),F(1,5),F(3,7)];probs=[F(1,4),F(1,4),F(1,2)]
keys=[(),(2,),(3,),(2,2),(2,3),(4,),(2,2,2)]
for n in range(2,6):
    for phase in [[F(1)]*3,[F(1),F(1,2),F(-1,3)]]:
        mu=[sum(p*x**j*z for x,p,z in zip(xs,probs,phase)) for j in range(20)]
        for tag in [(3,),(4,),(2,2)]:
            kk=[tuple(sorted(key+tag)) for key in keys];computed=weights(n,mu,kk);direct=[F(0)]*len(keys)
            for choice in itertools.product(range(3),repeat=n):
                yy=[xs[i] for i in choice];weight=math.prod(probs[i]*phase[i] for i in choice)
                vv={p:sum(y**p for y in yy) for p in range(1,5)}
                for j,key in enumerate(kk):direct[j]+=weight*math.prod(vv[p] for p in key)
            assert computed==direct;finite+=len(keys)
            # A constant 1/n labelled tag must leave the transform unchanged.
            nu=[v/n for v in mu];constant=tagged_weights(n,mu,nu,kk)
            assert constant==direct;finite+=len(keys)
out=dict(passed=True,integral_comparisons=integ,finite_Fourier_comparisons=fourier,exact_finite_law_comparisons=finite,mp_digits=mp.mp.dps,interval_bits=ctx.prec,scope='Supplementary diagnostics; analytic tails, alias and rounding bounds inherited.')
(O/'moment_diagnostics.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
