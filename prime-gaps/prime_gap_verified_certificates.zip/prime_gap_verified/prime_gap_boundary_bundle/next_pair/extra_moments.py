"""Fresh positive-moment CDF enclosures.
V4 uses the inherited single-tag recurrence. V2^2 is obtained by replacing
P by P Z2 and using a constant labelled tag (1/k), with factor (T/sigma)^4.
This gives exactly V2^2 P^2, not a probabilistic approximation.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib,copy
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'next_pair'
sys.path.insert(0,str(B/'continued'))
from power_mean import PowerCDF,CappedMeanCDF,single_moments,ar,ctx,up
class SquareCDF(CappedMeanCDF):
    def __init__(self,tr,sigma):
        self.original=tr
        tr2=copy.deepcopy(tr);tr2['basis']=[b+[2] for b in tr['basis']]
        super().__init__(tr2,sigma)
    def moments(self,kind='zero',value=0):
        mu=single_moments(self.S,self.jmax,kind,value)
        fac=(self.S['T']/ar(self.sigma))**4/self.k
        return mu,[fac*u for u in mu]

def run(m,tag):
    ctx.prec=256;start=time.time();tp=B/{2:'trials/m2_final.json',3:'focus23/m3_fine.json'}[m]
    tr=json.load(open(tp));sigma=1+F(tr['delta'])*tr['eps_cells']
    if tag=='22':o=SquareCDF(tr,sigma)
    else:o=PowerCDF(tr,sigma,int(tag))
    o.run_setup();nl,nu,components=o.evaluate()
    keys=o.keys
    if tag=='22':
        keys=[]
        for kk in o.keys:
            kk=list(kk);kk.remove(2);kk.remove(2);keys.append(tuple(kk))
    prefix=O/f'm{m}_power{tag}'
    out=dict(m=m,k=tr['k'],tag='V2 squared' if tag=='22' else 'V'+tag,
        weighted_numerator_lower=nl,weighted_numerator_upper=nu,moment_keys=keys,
        internal_moment_keys=o.keys,cdf_errors=o.errors,fourier_frequencies=o.J,
        fourier_tail=o.tail,alias=list(map(up,o.alias)),components=components,
        precision_bits=ctx.prec,seconds=time.time()-start,trial=str(tp.relative_to(B)),
        trial_sha256=hashlib.sha256(tp.read_bytes()).hexdigest(),sigma=[sigma.numerator,sigma.denominator])
    prefix.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    np.savez_compressed(str(prefix)+'_cdf.npz',C=o.C,y=o.y,L=o.L,V=o.V)
    print(json.dumps({k:v for k,v in out.items() if not isinstance(v,list)}),flush=True)
if __name__=='__main__':
    for tag in sys.argv[2:]:run(int(sys.argv[1]),tag)
