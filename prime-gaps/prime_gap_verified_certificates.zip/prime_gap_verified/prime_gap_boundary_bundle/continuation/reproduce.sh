#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
 echo 'Usage: bash continuation/reproduce.sh --checks-only|--full' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
if [[ "$mode" == --full ]]; then
 python continuation/test_support.py 4 10 9
 python continuation/test_support.py 5 4 3
 python continuation/capped_mean_general.py 4 10
 python continuation/capped_mean_general.py 5 4
fi
python continuation/finite_sampling.py
python continuation/deduce_caps.py
python continuation/check_new.py
bash continuation/prepare_tuples.sh
python continuation/select_tuples.py
python continuation/final_check.py
