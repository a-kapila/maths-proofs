"""New strict-support and tagged-moment endpoints; exact finite-sampling bound."""
from pathlib import Path
from fractions import Fraction as F
import json,math,sys,hashlib
from finite_sampling import coefficient
B=Path(__file__).resolve().parents[1]
def calc(m,r):
    old={x['m']:x for x in json.load(open(B/'accurate/deductions.json'))}[m]
    tr=json.load(open(B/f'accurate/m{m}.json'))
    cert=json.load(open(B/f'accurate/m{m}.interval_certificate.json'))
    su=json.load(open(B/f'continuation/support_m{m}_{r}_{r-1}.json'))
    me=json.load(open(B/f'continuation/mean_m{m}_r{r}.json'))
    k=tr['k'];A=F(r,r-1);rho=F(1,4)+F(tr['omega']);target=F(m)/rho
    sigma=1+F(tr['delta'])*tr['eps_cells']
    kap=(F(1,4)+F(tr['smooth_delta'])/2)/rho-F(1,10000)
    assert A*F(su['new_ufrac'])<=F(tr['ufrac'])
    assert A*F(su['new_kappa'])<=kap
    assert 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3 and 2*rho*sigma<1
    assert su['k']==me['k']==k and F(*me['h'])==F(1,r) and F(*me['sigma'])==sigma
    base=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
    assert me['trial_sha256']==hashlib.sha256(base.read_bytes()).hexdigest()
    src=json.load(open(base))
    for field in ['k','m','theta','beta','relative_shift','basis','profiles','smooth_delta','omega','ufrac']:assert tr[field]==src[field]
    assert [F(tr['delta'])*e for e in tr['E']]==[F(src['delta'])*e for e in src['E']]
    correction=F(su['amplitude_upper'])**2*F(su['support_bad_probability_upper'])
    exactlo=(F(me['weighted_numerator_lower'])-correction)/F(cert['den_upper'])
    exacthi=F(me['weighted_numerator_upper'])/(F(cert['den_lower'])-correction)
    l=F(math.nextafter(float(exactlo),-math.inf));u=F(math.nextafter(float(exacthi),math.inf))
    assert 0<l<=exactlo<=exacthi<=u<1
    q=F(cert['Q_lower'])-F(su['restriction']['loss_upper'])
    def beta(d):return l*coefficient(k,d,r)
    def margin(d):return F(k-d,k)*q-target*(1-beta(d))
    lo=0;hi=k-r
    while lo+1<hi:
        mid=(lo+hi)//2
        if margin(mid)>0:lo=mid
        else:hi=mid
    assert margin(lo)>0>=margin(lo+1)
    eff=margin(lo)/(1-beta(lo));ceiling=F(k)*(q-target)/(q-target*u)
    return dict(m=m,trial_k=k,A=[r,r-1],h=[1,r],dimension=k-lo,deleted=lo,previous_dimension=old['dimension'],
                additional_deleted=lo-old['deleted'],quotient_lower_before_restriction=cert['Q_lower'],
                restriction_loss_upper=su['restriction']['loss_upper'],mean_lower=float(l),mean_upper=float(u),
                beta_lower=[beta(lo).numerator,beta(lo).denominator],raw_margin=[margin(lo).numerator,margin(lo).denominator],
                effective_margin=[eff.numerator,eff.denominator],effective_margin_display=float(eff),next_raw_margin=float(margin(lo+1)),
                optimistic_maximum_deletions=(ceiling.numerator-1)//ceiling.denominator,
                same_physical_trial_checked=True,strict_support_geometry_checked=True,
                trace=dict(trial='accurate/m%d.json'%m,quotient='accurate/m%d.interval_certificate.json'%m,
                           support=f'continuation/support_m{m}_{r}_{r-1}.json',mean=f'continuation/mean_m{m}_r{r}.json'))
if __name__=='__main__':
    params=[(int(sys.argv[1]),int(sys.argv[2]))] if len(sys.argv)>1 else [(4,10),(5,4)]
    rows=[calc(m,r) for m,r in params]
    for row in rows:
        (B/f'continuation/deduction_m{row["m"]}.json').write_text(json.dumps(row,indent=2)+'\n')
        print(json.dumps({k:v for k,v in row.items() if k not in ['beta_lower','raw_margin','effective_margin']}),flush=True)
