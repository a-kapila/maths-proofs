"""Reuse the tagged-moment Fourier enclosure with an explicitly specified cap.
For h*sigma >= T the cap is inactive on each coordinate and the inserted
statistic is S/sigma. All quadrature, Fourier-tail and rounding bounds are
inherited from direct_mean/capped_mean.py without loosening them.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'direct_mean'))
from capped_mean import CappedMeanCDF,ar,up,down,ctx
from multi_core import single_moments

class GeneralCappedMean(CappedMeanCDF):
    def __init__(self,tr,sigma,h):
        super().__init__(tr,sigma)
        self.h=F(h);self.w=ar(sigma*self.h)
        self.inactive=bool(self.w>=self.S['T'])
        if not self.inactive:self.lowS['T']=self.w
    def moments(self,kind='zero',value=0):
        if not self.inactive:return super().moments(kind,value)
        mu=single_moments(self.S,self.jmax,kind,value)
        nu=[self.S['T']/ar(self.sigma)*mu[j+1] for j in range(self.jmax)]
        return mu,nu

def run(m,r,trial_path=None,tag=None):
    t=time.time();ctx.prec=256
    path=Path(trial_path) if trial_path else B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
    label=tag or f'mean_m{m}_r{r}'
    tr=json.load(open(path));sigma=1+F(tr['delta'])*tr['eps_cells']
    obj=GeneralCappedMean(tr,sigma,F(1,r));obj.run_setup();nl,nu,components=obj.evaluate()
    out=dict(m=m,k=tr['k'],h=[1,r],sigma=[sigma.numerator,sigma.denominator],coordinate_cap_inactive=obj.inactive,
        weighted_numerator_lower=nl,weighted_numerator_upper=nu,moment_keys=obj.keys,cdf_errors=obj.errors,
        fourier_frequencies=obj.J,fourier_tail=obj.tail,alias=list(map(up,obj.alias)),components=components,
        precision_bits=ctx.prec,seconds=time.time()-t,trial_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        method='Inherited direct tagged-moment Fourier enclosure at a new cap')
    (B/f'continuation/{label}.json').write_text(json.dumps(out,indent=2)+'\n')
    np.savez_compressed(B/f'continuation/{label}_cdf.npz',C=obj.C,y=obj.y,L=obj.L,V=obj.V)
    print(json.dumps({a:b for a,b in out.items() if not isinstance(b,list)}),flush=True)
    return out
if __name__=='__main__':
    run(int(sys.argv[1]),int(sys.argv[2]),*(sys.argv[3:]))
