"""Exact rational improved finite-subset bound from the saved mean certificates.
For cap h=1/r, a symmetric concave subset average is minimized by concentrating
mass into coordinates of size h. Chording the resulting piecewise-linear
function between total mass 0 and 1 gives beta >= E[U]*(1-(k-d)_r/(k)_r)/r.
No scalar or Fourier computation is repeated in this module.
"""
from pathlib import Path
from fractions import Fraction as F
from math import prod
import json
B=Path(__file__).resolve().parents[1]

def coefficient(k:int,d:int,r:int)->F:
    assert 1<=r<=k and 0<=d<=k-r
    return (1-prod(F(k-d-i,k-i) for i in range(r)))/r

def calculate():
    rows=[]
    prior=json.load(open(B/'accurate/deductions.json'))
    for old in prior:
        m=old['m']; k=old['trial_k']
        tr=json.load(open(B/f'accurate/m{m}.json'))
        ce=json.load(open(B/f'accurate/m{m}.interval_certificate.json'))
        su=json.load(open(B/f'rescaled/integrated_m{m}.json'))
        q=F(ce['Q_lower'])-F(su['restriction']['loss_upper'])
        target=F(m)/(F(1,4)+F(tr['omega']))
        l=F(old['mean_lower']);r=11
        def beta(d):return l*coefficient(k,d,r)
        def margin(d):return F(k-d,k)*q-target*(1-beta(d))
        low=0;high=k-r
        while low+1<high:
            mid=(low+high)//2
            if margin(mid)>0:low=mid
            else:high=mid
        assert margin(low)>0>=margin(low+1)
        eff=margin(low)/(1-beta(low))
        rows.append(dict(m=m,trial_k=k,cap=[1,r],deleted=low,dimension=k-low,
                         previous_dimension=old['dimension'],additional_deleted=low-old['deleted'],
                         mean_lower=old['mean_lower'],beta_lower=[beta(low).numerator,beta(low).denominator],
                         effective_margin=[eff.numerator,eff.denominator],effective_margin_display=float(eff),
                         next_raw_margin=float(margin(low+1))))
    return rows
if __name__=='__main__':
    result=calculate(); (B/'continuation/finite_sampling_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
