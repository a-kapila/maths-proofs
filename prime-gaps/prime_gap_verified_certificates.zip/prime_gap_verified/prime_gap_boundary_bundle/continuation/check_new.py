"""Independent exact finite-sampling tests and supplementary numerical diagnostics."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations_with_replacement,product
from math import comb,prod
import sys,json
import numpy as np
import mpmath as mp
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'continuation'))
from finite_sampling import coefficient
from capped_mean_general import GeneralCappedMean,ctx
from capped_mean import tagged_weights
ctx.prec=256;mp.mp.dps=90

def moment_bounds(z):
    a,b=z.x._mpi_;return mp.make_mpf(a),mp.make_mpf(b)
def mid(z):
    a,b=moment_bounds(z);return (a+b)/2

# Exhaustive rational vectors on a capped grid, up to permutation.
finite=0;equalities=0
for k in range(2,11):
  for r in range(1,min(k,6)+1):
    for qgrid in (2,3):
      for vec in combinations_with_replacement(range(qgrid+1),k):
        mass=sum(vec)
        if mass>r*qgrid:continue
        # DP counts subsets by cardinality and saturated selected sum.
        tab=[[0]*(qgrid+1) for _ in range(k+1)];tab[0][0]=1
        used=0
        for value in vec:
          for d in range(used,-1,-1):
            for s,count in enumerate(tab[d]):tab[d+1][min(qgrid,s+value)]+=count
          used+=1
        for d in range(k+1):
          num=sum(s*count for s,count in enumerate(tab[d]))
          miss=comb(k-r,d) if d<=k-r else 0
          assert r*num>=mass*(comb(k,d)-miss),(k,r,qgrid,vec,d)
          finite+=1
      vec=(0,)*(k-r)+(qgrid,)*r
      for d in range(k-r+1):
        c=coefficient(k,d,r)
        assert c==F(comb(k,d)-comb(k-r,d),r*comb(k,d))
        equalities+=1

# Tagged moment identity on an independent finite three-point law.
identity_tests=0
keys=[(),(2,),(3,),(4,),(2,2),(2,3),(2,4),(3,3),(3,4),(4,4),(2,2,2),(2,2,3),(2,2,4),(2,2,2,2)]
xs=[F(0),F(1,4),F(3,4)];probs=[F(1,5),F(2,5),F(2,5)];n=5
for cap in [F(1,4),F(1,2),F(1)]:
 for tilt in [F(1),F(3,4)]:
  # All 4*x are integers; enforce rational exponentiation explicitly.
  mu=[sum(p*x**j*tilt**int(4*x) for x,p in zip(xs,probs)) for j in range(10)]
  nu=[sum(p*min(x,cap)*x**j*tilt**int(4*x) for x,p in zip(xs,probs)) for j in range(10)]
  result=tagged_weights(n,mu,nu,keys)
  exact=[F(0) for _ in keys]
  for inds in product(range(3),repeat=n):
   vv=[xs[i] for i in inds];weight=prod(probs[i] for i in inds)*tilt**int(4*sum(vv));u=sum(min(x,cap) for x in vv)
   z={j:sum(x**j for x in vv) for j in [2,3,4]}
   for at,key in enumerate(keys):exact[at]+=weight*u*prod(z[j] for j in key)
  assert exact==result
  identity_tests+=len(keys)

quadrature_tests=0;fourier_tests=0;maxratio=mp.mpf(0)
for m,r in [(4,10),(5,4)]:
 path=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json');tr=json.load(open(path))
 sigma=1+F(tr['delta'])*tr['eps_cells'];obj=GeneralCappedMean(tr,sigma,F(1,r))
 out=json.load(open(B/f'continuation/mean_m{m}_r{r}.json'))
 # Independent high-precision integrals on a geometrically split interval.
 k=tr['k'];c=mp.mpf(tr['theta'])/mp.log(k);T=mp.mpf(tr['beta'])/mp.log(k);b=k-1
 A=mp.mpf(tr['relative_shift'])/(c+b*T);sig=mp.mpf(sigma.numerator)/sigma.denominator;h=mp.mpf(1)/r
 m2=(1/c-1/(c+b*T))/b+2*A*mp.log((c+b*T)/c)/b+A*A*T
 edges=[mp.mpf(0),min(T,h*sig),T];p=c/b
 while p<T:edges.append(p);p*=16
 edges=sorted(set(edges))
 for xi in [0,F(7,3)]:
  from capped_mean import ar
  mu,nu=obj.moments('zero' if xi==0 else 'fourier',ar(xi))
  xx=mp.mpf(F(xi).numerator)/F(xi).denominator
  for j in [0,4,8]:
   val=mp.quad(lambda t: min(t/sig,h)*(t/T)**j*(1/(c+b*t)+A)**2*mp.exp(1j*xx*t)/m2,edges)
   z=nu[j]
   if xi!=0:
    from flint import acb
    z=acb(z)
   if xi==0:
    lo,hi=moment_bounds(z);assert lo<=val.real<=hi
   else:
    lo,hi=moment_bounds(z.real);assert lo<=val.real<=hi
    lo,hi=moment_bounds(z.imag);assert lo<=val.imag<=hi
   quadrature_tests+=1
 # High-precision finite-series evaluation at three stored profile boundaries.
 z=np.load(B/f'continuation/mean_m{m}_r{r}_cdf.npz');C=z['C'];ys=z['y']
 mu,nu=obj.moments();masses=tagged_weights(k,mu,nu,obj.keys);phase=obj.phases();J=out['fourier_frequencies']
 for ix in [1,len(ys)//2,len(ys)-1]:
  yy=mp.mpf(float(ys[ix]));step=mp.exp(-2j*mp.pi*yy/8);ph=mp.mpc(1);sums=[mp.mpf(0)]*len(obj.keys)
  for j in range(J):
   ph*=step
   for a in range(len(obj.keys)):
    cc=mp.mpc(float(C[a,j].real),float(C[a,j].imag));sums[a]+=2*mp.re(cc*(1-ph))
  for a in range(len(obj.keys)):
   ref=mid(masses[a])*yy/8+sums[a]
   acc=0.
   for j in range(J):acc=acc+(float(C[a,j].real)*float(phase[ix,j].real)-float(C[a,j].imag)*float(phase[ix,j].imag))
   c0=float(mp.fsum(2*mp.mpf(float(cc.real)) for cc in C[a]));approx=float(mid(masses[a]))*(float(yy)/8)+c0-2*acc
   ratio=abs(mp.mpf(approx)-ref)/mp.mpf(out['cdf_errors'][a]);assert ratio<=1
   maxratio=max(maxratio,ratio);fourier_tests+=1
result=dict(status='passed',finite_subset_cases=finite,extremal_coefficient_equalities=equalities,
 exact_tagged_moment_identities=identity_tests,independent_quadrature_checks=quadrature_tests,
 direct_fourier_checks=fourier_tests,max_fourier_error_ratio=mp.nstr(maxratio,15))
(B/'continuation/diagnostics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
