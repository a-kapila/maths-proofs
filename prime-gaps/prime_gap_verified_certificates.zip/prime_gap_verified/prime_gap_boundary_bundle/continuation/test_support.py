from pathlib import Path
from fractions import Fraction as F
import sys,json,time
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'rescaled'),str(B/'baseline/inherited/analysis')]
from scaled_slicing import bad_probability,up,down
from loss_joint import restriction_loss
from shifted_core import setup
from flint import arb,ctx
ctx.prec=256
m=int(sys.argv[1]); anum=int(sys.argv[2]) if len(sys.argv)>2 else 7; aden=int(sys.argv[3]) if len(sys.argv)>3 else 5
p=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
d=json.load(open(p));old=json.load(open(p.with_suffix('.interval_certificate.json')))
rho=arb(1)/4+arb(d['omega']);sig=1+arb(d['delta'])*d['eps_cells'];Am=arb(anum)/aden
kap=(arb(1)/4+arb(d['smooth_delta'])/2)/rho-arb('0.0001');kp=down(kap/Am);uf=down(arb(d['ufrac'])/Am)
S=setup(d['k'],d['theta'],d['beta'],d['relative_shift']);h=1-1/Am
print(json.dumps(dict(stage='start',m=m,A=[anum,aden],T=float(S['T']),h=float(h),kappa=kp)),flush=True)
assert 0<h<1
t=time.time()
loss=restriction_loss(d['k'],d['theta'],d['beta'],d['smooth_delta'],d['omega'],old['scaled_den_lower'],ufrac=uf,sum_cap=float(sig),region_kappa=kp,relative_shift=d['relative_shift'],inner_cap=float(2-sig))
print(json.dumps(dict(stage='loss',m=m,loss=loss,seconds=time.time()-t)),flush=True)
pbad,ncells=bad_probability(d,uf,kp)
C=arb(old['amplitude_upper']);DR=arb(old['den_lower'])-C*C*arb(pbad)
positive_denominator=bool(DR>0)
out=dict(positive_denominator=positive_denominator,m=m,k=d['k'],A=[anum,aden],h=[anum-aden,anum],new_ufrac=uf,new_kappa=kp,original_quotient_lower=old['Q_lower'],restriction=loss,support_bad_probability_upper=pbad,support_bad_cells=ncells,restricted_den_lower=down(DR),amplitude_upper=old['amplitude_upper'],seconds=time.time()-t,coordinate_cutoff_upper=up(S['T']),sigma=float(sig))
(B/f'continuation/support_m{m}_{anum}_{aden}.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out),flush=True)
