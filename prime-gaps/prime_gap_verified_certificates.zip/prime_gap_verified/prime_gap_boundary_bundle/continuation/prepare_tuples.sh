#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p continuation/recomputed
g++ -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o continuation/recomputed/verify_tuple
g++ -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o continuation/recomputed/verify_h5
python baseline/inherited/tuples/decode_h5.py continuation/recomputed/old_unpatched.bin
python baseline/h5/apply_patches.py continuation/recomputed/old_unpatched.bin continuation/recomputed/previous_h5.bin
python new/apply_new_h5_patches.py continuation/recomputed/previous_h5.bin continuation/recomputed/current_h5.bin
