"""Check exact inequalities, source identity, and complete verifier outputs."""
from pathlib import Path
from fractions import Fraction as F
from math import prod
import json,hashlib
B=Path(__file__).resolve().parents[1]
rows=[]
previous={4:82258824,5:4831267356}
for m,r in [(4,10),(5,4)]:
 d=json.load(open(B/f'continuation/deduction_m{m}.json'))
 cert=json.load(open(B/f'accurate/m{m}.interval_certificate.json'))
 tr=json.load(open(B/f'accurate/m{m}.json'))
 su=json.load(open(B/f'continuation/support_m{m}_{r}_{r-1}.json'))
 me=json.load(open(B/f'continuation/mean_m{m}_r{r}.json'))
 k=tr['k'];n=d['deleted'];K=k-n;target=F(m)/(F(1,4)+F(tr['omega']))
 q=F(cert['Q_lower'])-F(su['restriction']['loss_upper'])
 den=prod(k-j for j in range(r));num=prod(k-n-j for j in range(r))
 beta=F(d['mean_lower'])*(1-F(num,den))/r
 assert beta==F(*d['beta_lower'])
 effective=F(K,k)*q/(1-beta)-target
 assert effective==F(*d['effective_margin']) and effective>0
 bnext=F(d['mean_lower'])*(1-F(prod(k-n-1-j for j in range(r)),den))/r
 assert F(K-1,k)*q-target*(1-bnext)<=0
 c=F(su['amplitude_upper'])**2*F(su['support_bad_probability_upper'])
 assert F(d['mean_lower'])<=(F(me['weighted_numerator_lower'])-c)/F(cert['den_upper'])
 assert F(d['mean_upper'])>=F(me['weighted_numerator_upper'])/(F(cert['den_lower'])-c)
 tup=json.load(open(B/f'continuation/h{m}_verified.json'))
 assert tup['verified'] is True and tup['k']==K and tup['last']-tup['first']==tup['diameter']
 if m==5:
  assert tup['failures']==0 and tup['certificate_prime_count']==12204094
  assert hashlib.sha256((B/'continuation/recomputed/current_h5.bin').read_bytes()).hexdigest()=='f223f9823aef305e4eeeec4f64c933ba20e1dd42872408c557e5a3011cd4c191'
 else:
  sel=json.load(open(B/'continuation/h4_selection.json'))
  for field in ['k','first','last','diameter']:assert sel[field]==tup[field]
 row=dict(m=m,previous_bound=previous[m],bound=tup['diameter'],reduction=previous[m]-tup['diameter'],dimension=K,deleted=n,A=[r,r-1],mean_lower=d['mean_lower'],mean_upper=d['mean_upper'],effective_margin=float(effective),first=tup['first'],last=tup['last'],candidate_windows=tup.get('candidate_windows',sel.get('candidate_windows') if m==4 else None))
 rows.append(row)
diag=json.load(open(B/'continuation/diagnostics.json'));assert diag['status']=='passed'
failed=json.load(open(B/'continuation/m4_degree6_fine.interval_certificate.json'))
assert failed['Q_lower']<failed['target_upper'] and failed['margin_lower']<0
out=dict(status='passed',results=rows,unchanged={"H2":19920,"H3":1359754},diagnostics=diag,failed_degree6=dict(Q_lower=failed['Q_lower'],target_upper=failed['target_upper'],margin_lower=failed['margin_lower'],direct_fourier_checks=len(failed['direct_fourier_checks']),used_in_results=False),dependencies='Inherited sieve criterion, arithmetic distribution input, successful quotient certificates and numerical enclosure arguments; no independent expert review.')
(B/'continuation/RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
