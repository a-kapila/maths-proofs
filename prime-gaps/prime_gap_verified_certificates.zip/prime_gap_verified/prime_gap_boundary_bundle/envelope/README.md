# Polynomial Laplace bounds and convex-Jensen coordinate slicing

This continuation reuses the fixed Fourier quotient and stricter support certificates
from `rescaled/`. It recomputes weighted one-coordinate Laplace transforms,
constructs a coefficientwise polynomial majorant with exact rational arithmetic,
and checks a new convex-Jensen implication and the resulting integer tuples.

The final results are in `envelope/RESULTS.json` and `envelope/proof_note.pdf`.
The older root-level RESULTS.json and notes describe earlier continuations.

Run from the bundle root:

```bash
bash envelope/reproduce.sh --checks-only
bash envelope/reproduce.sh --full
```

The first command reevaluates the two chosen scalar certificates at 384-bit interval
precision, checks their inequalities exactly, runs diagnostics, reconstructs and
checks both tuples, and repeats the fixed-universe relaxation. The second also
repeats the new parameter search. Neither command reruns the inherited Fourier
quotients or the stricter-support losses. Those reproduction commands remain under
`rescaled/` and the preceding directories.

The current tuple and scalar checks were executed. This is not an independent
expert audit of the sieve implication, inherited numerical enclosures, or their
arithmetic model. The scalar library is the documented mpmath.iv compatibility
backend, NOT FLINT or Arb. The name flint.py is inherited compatibility naming.
Python 3, NumPy, SciPy, mpmath, and a C++17 compiler with OpenMP are needed.
Do not disable C++ assertions. Complete tuple checks use roughly 1.5 GB RAM.

## Final inputs and outputs

- `final_m4.json`, `final_m5.json`: exact rational slicing endpoints and selected tilts.
- `majorant_m4.json`, `majorant_m5.json`: exact rational coefficients of the majorants.
- `final_scalar_checks.json`: selected-certificate recheck and exact inequalities.
- `h4_selection.json`, `h4_verified.json`, `h5_verified.json`: complete integer checks.
- `h5_relaxation.json`: optimistic relaxation, NOT an admissible-tuple upper bound.
- `weighted_mgf.py`: exact transform recurrences and coefficient construction.
- `verify_final.py`: fresh selected-scalar evaluations and exact dimension implications.
- `check_diagnostics.py`, `diagnostics.json`: supplementary finite-law/quad tests.

## Exploratory and intermediate methods

`compute_envelope.py` combines older constant-amplitude Chernoff bounds; it yields
only a small gain. `compute_weighted.py` uses absolute profile-coefficient maxima.
`compute_rank.py` tests a finite-rank majorant, but does not improve the final result.
`compute_tight.py` collects signed square coefficients before taking maxima.
`jensen_slicing.py` applies Jensen to the looser weighted bounds;
`final_slicing.py` applies it to the tighter bounds used in the reported results.
`refine_lambda.py` chooses tilts numerically, then reevaluates every retained value
with interval arithmetic. No optimizer score is accepted as a proof endpoint.

All original source attribution and prior proofs/certificates remain in the bundle.
The decoded H5 binary, reconstructed H4 text tuple, executables, and transient
Python caches are regenerated rather than distributed redundantly.
