"""Direct exponential-moment/Jensen improvement to capped slicing.
Inputs are saved outward enclosures from compute_weighted.py.
No floating-point optimizer output is accepted as a proof endpoint.
"""
from pathlib import Path
from fractions import Fraction as F
import json
B=Path(__file__).resolve().parents[1]

def run(m):
    old=json.load(open(B/f'rescaled/integrated_m{m}.json'))
    tr=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
    lines=json.load(open(B/f'envelope/tight_m{m}_lines.json'))
    sig=1+F(tr['delta'])*tr['eps_cells'];k=tr['k'];cap=F(1,11)
    rho=F(1,4)+F(tr['omega']);target=F(m)/rho
    q=F(old['original_quotient_lower'])-F(old['restriction']['loss_upper'])
    def point(r):return -F(r['log_B_upper'])/(F(r['lambda_value'])*sig)
    row=max(lines,key=point);x=point(row);ell=F(row['lambda_value'])*sig
    assert 0<x<1
    def ab(n):return F(n,k),F(n*(n-1),2*k*(k-1))/cap
    def beta(n):
        a,b=ab(n);return a*x-b*x*x
    def margin(n):return F(k-n,k)*q-target*(1-beta(n))
    lo=0;hi=int(cap*(k-1))
    while lo+1<hi:
        mid=(lo+hi)//2
        if margin(mid)>0:lo=mid
        else:hi=mid
    a,b=ab(lo)
    assert a-2*b>0 and ell*(a-2*b)>=2*b
    assert margin(lo)>0 and margin(lo+1)<=0
    out=dict(m=m,k=k,dimension=k-lo,coordinates_deleted=lo,previous_dimension=old['dimension'],j=row['j'],lambda_value=row['lambda_value'],log_B_upper=row['log_B_upper'],mean_parameter_lower=[x.numerator,x.denominator],mean_parameter_display=float(x),beta_lower_exact=[beta(lo).numerator,beta(lo).denominator],raw_margin_exact=[margin(lo).numerator,margin(lo).denominator],effective_margin_display=float(margin(lo)/(1-beta(lo))),next_margin_display=float(margin(lo+1)),convexity_margin_exact=[(ell*(a-2*b)-2*b).numerator,(ell*(a-2*b)-2*b).denominator],method='polynomial Laplace majorant and direct convex-Jensen slicing')
    (B/f'envelope/final_m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({a:b for a,b in out.items() if not isinstance(b,list)}),flush=True)
    return out
if __name__=='__main__':
    for m in [4,5]:run(m)
