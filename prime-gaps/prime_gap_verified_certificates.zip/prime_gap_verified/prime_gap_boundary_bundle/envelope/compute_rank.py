"""Interval-evaluated lower-envelope Chernoff integration for capped slicing.
Reuses the saved quotient and stricter support certificate; no new Fourier call.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,time,math
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from flint import arb,ctx
from shifted_core import setup,mgf_negative
from weighted_mgf import FiniteRankMGF
ctx.prec=256
up=lambda z:float(np.nextafter(float(z.upper()),np.inf))
down=lambda z:float(np.nextafter(float(z.lower()),-np.inf))
def ar(x):
    x=F(x);return arb(x.numerator)/x.denominator

def lower_hull(lines):
    # x -> b + l*x, decreasing slopes; exact intersections and duplicates.
    uniq={}
    for l,b,meta in lines:
        if l not in uniq or b<uniq[l][0]:uniq[l]=(b,meta)
    out=[]
    for l,(b,meta) in sorted(uniq.items(),reverse=True):
        start=None
        while out:
            ll,bb,_,ss=out[-1]
            start=(b-bb)/(ll-l)
            if ss is not None and start<=ss:out.pop()
            else:break
        if not out:start=None
        out.append((l,b,meta,start))
    seg=[]
    for i,(l,b,meta,st) in enumerate(out):
        a=max(F(0),st) if st is not None else F(0)
        z=min(F(1),out[i+1][3]) if i+1<len(out) else F(1)
        if a<z:seg.append((a,z,l,b,meta))
    return seg

def run(m):
    t=time.time();d=json.load(open(B/f'rescaled/integrated_m{m}.json'))
    tr=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
    k=tr['k'];rho=F(1,4)+F(tr['omega']);sig=1+F(tr['delta'])*tr['eps_cells']
    S=setup(k,tr['theta'],tr['beta'],tr['relative_shift']);w=ar(sig)/11
    C=arb(d['amplitude_upper']);DR=arb(d['restricted_den_lower'])
    weighted=FiniteRankMGF(S,tr,w)
    lines=[(F(0),F(0),{'lambda':0.0})];rows=[]
    for j in range(-32,833):
        lam=float(2**(j/64));ll=arb(lam)
        logbound,detail=weighted.eval_log(lam)
        intercept=up(logbound-DR.log())
        slope=up(ll*ar(sig))
        row=dict(j=j,lambda_value=lam,log_B_upper=intercept,slope_upper=slope,**detail)
        rows.append(row);lines.append((F(slope),F(intercept),row))
    seg=lower_hull(lines);mu1=arb(0);mu2=arb(0);active=[]
    for aa,zz,lf,bf,meta in seg:
        a,z,l,b=map(ar,(aa,zz,lf,bf))
        if lf==0:assert bf==0;continue
        ea=(b+l*a).exp();ez=(b+l*z).exp()
        I0=(ez-ea)/l
        I1=((l*z-1)*ez-(l*a-1)*ea)/(l*l)
        mu1+=z-a-I0
        mu2+=z*z-a*a-2*I1
        active.append(dict(left=[aa.numerator,aa.denominator],right=[zz.numerator,zz.denominator],**meta))
    a1=F(down(mu1));a2=F(up(mu2));cap=F(1,11)
    q=F(d['original_quotient_lower'])-F(d['restriction']['loss_upper']);target=F(m)/rho
    def beta(n):return F(n,k)*a1-F(n*(n-1),2*k*(k-1))*a2/cap
    def margin(n):return F(k-n,k)*q-target*(1-beta(n))
    lo=0;hi=int(cap*(k-1))
    assert margin(lo)>0 and margin(hi)<=0
    while lo+1<hi:
        mid=(lo+hi)//2
        if margin(mid)>0:lo=mid
        else:hi=mid
    assert margin(lo)>0 and margin(lo+1)<=0
    out=dict(m=m,k=k,source=f'rescaled/integrated_m{m}.json',mu1_lower=float(a1),mu2_upper=float(a2),old_mu1_lower=d['mu1_lower'],coordinates_deleted=lo,dimension=k-lo,previous_dimension=d['dimension'],effective_margin_lower=down(ar(margin(lo)/(1-beta(lo)))),next_margin_upper=up(ar(margin(lo+1))),active_lines=active,line_count=len(rows),seconds=time.time()-t)
    (B/f'envelope/rank_m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
    (B/f'envelope/rank_m{m}_lines.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(json.dumps({a:b for a,b in out.items() if a!='active_lines'}),flush=True)
    return out
if __name__=='__main__':
    for m in map(int,sys.argv[1:] or [4,5]):run(m)
