from pathlib import Path
import json,numpy as np
B=Path(__file__).resolve().parents[1]
d=json.load(open(B/'envelope/h4_selection.json'));k=d['k']
h=np.loadtxt(B/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
assert len(h)==d['parent_cardinality'] and np.all(np.diff(h)>0)
w=h[k-1:]-h[:len(h)-k+1];j=int(np.argmin(w));v=h[j:j+k]
assert j==d['start_index'] and len(w)==d['candidate_windows']
assert int(v[0])==d['first'] and int(v[-1])==d['last'] and int(w[j])==d['diameter']
o=B/'envelope/recomputed';o.mkdir(exist_ok=True)
np.savetxt(o/'h4.csv',v,fmt='%d');print(json.dumps(d),flush=True)
