"""Polynomial-majorant Laplace transforms under the capped-coordinate law.
All scalar integrals are interval evaluated using the inherited backend.
"""
from pathlib import Path
import sys
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from flint import arb
from multi_core import single_moments
from polynomial_core import weights
from collections import defaultdict

def truncated_moments(S,jmax,w,lam=None):
    # Integral_0^w (t/T)^j exp(-lam*t) g(t)^2 dt / m2.
    c,b,T,A,m2=(S[x] for x in ('c','b','T','A','m2'));u=c+b*w
    if lam is None:
        J=[(u/c).log()/b];K=[(1/c-1/u)/b]
        P=[w**(j+1)/(j+1) for j in range(jmax+1)]
    else:
        z=-arb(lam);a=z/b;end=(z*w).exp()
        E=(a*u).ei()-(a*c).ei()
        J=[(-a*c).exp()*E/b];K=[(1/c-end/u)/b+z/b*J[0]]
        P=[(end-1)/z]
        for j in range(1,jmax+1):P.append(end*w**j/z-j*P[-1]/z)
    for j in range(1,jmax+1):
        J.append(P[j-1]/b-c/b*J[-1]);K.append(J[j-1]/b-c/b*K[-1])
    return [(K[j]+2*A*J[j]+A*A*P[j])/(m2*T**j) for j in range(jmax+1)]

def polynomial_coefficients(tr):
    basis=[tuple(x) for x in tr['basis']]
    amps=[max(map(abs,hs)) for hs in tr['profiles']]
    co=defaultdict(lambda:arb(0))
    for a,ma in enumerate(basis):
        for b,mb in enumerate(basis):
            key=tuple(sorted(ma+mb));co[key]+=arb(amps[a])*arb(amps[b])
    return dict(co),amps

class WeightedMGF:
    def __init__(self,S,tr,w):
        self.S,self.tr,self.w=S,tr,w
        self.co,self.amps=polynomial_coefficients(tr)
        self.keys=sorted(self.co,key=lambda x:(len(x),x));self.jmax=max(map(sum,self.keys))
        self.full=single_moments(S,self.jmax)
        self.low=truncated_moments(S,self.jmax,w)
        self.tail=[a-b for a,b in zip(self.full,self.low)]
        assert all(t>0 for t in self.tail)
    def eval(self,lam):
        low=truncated_moments(self.S,self.jmax,self.w,lam)
        e=(-arb(lam)*self.w).exp()
        mu=[a+e*b for a,b in zip(low,self.tail)]
        assert all(a>0 for a in mu)
        vals=weights(self.tr['k'],mu,self.keys)
        result=sum(self.co[key]*v for key,v in zip(self.keys,vals))
        return result,mu

class FiniteRankMGF(WeightedMGF):
    """E P(S,Z)^2 e^-lambda sum min(X,w) <= r max_j E P_j(Z)^2 e^-... ."""
    def __init__(self,S,tr,w):
        super().__init__(S,tr,w)
        import numpy as np
        from fractions import Fraction as F
        self.np=np;self.rank_bound=len(tr['basis'])
        basis=[tuple(x) for x in tr['basis']];nc=len(tr['profiles'][0]);keys=self.keys
        cc=[[F(0) for _ in range(nc)] for _ in keys];ki={key:i for i,key in enumerate(keys)}
        hs=[[F(v) for v in h] for h in tr['profiles']]
        for a,ma in enumerate(basis):
            for b,mb in enumerate(basis):
                r=ki[tuple(sorted(ma+mb))]
                for j in range(nc):cc[r][j]+=hs[a][j]*hs[b][j]
        self.clo=np.array([[np.nextafter(float(c),-np.inf) for c in row] for row in cc])
        self.chi=np.array([[np.nextafter(float(c),np.inf) for c in row] for row in cc])
        self.nonzero_cells=nc
    def eval_log(self,lam):
        np=self.np
        low=truncated_moments(self.S,self.jmax,self.w,lam)
        e=(-arb(lam)*self.w).exp()
        mu=[a+e*b for a,b in zip(low,self.tail)];assert all(a>0 for a in mu)
        phi=mu[0];nu=[x/phi for x in mu];nu[0]=arb(1)
        vals=weights(self.tr['k'],nu,self.keys)
        q_upper=np.zeros(self.nonzero_cells)
        for coL,coU,v in zip(self.clo,self.chi,vals):
            vl=float(np.nextafter(float(v.lower()),-np.inf));vu=float(np.nextafter(float(v.upper()),np.inf))
            assert vl>0
            term=np.maximum.reduce([coL*vl,coL*vu,coU*vl,coU*vu]);term=np.nextafter(term,np.inf)
            q_upper=np.nextafter(q_upper+term,np.inf)
        max_idx=int(np.argmax(q_upper));maxq=float(q_upper[max_idx]);assert maxq>0
        naive=sum(self.co[key]*v for key,v in zip(self.keys,vals))
        bound=min(arb(self.rank_bound)*arb(maxq),naive.upper())
        return self.tr['k']*phi.log()+bound.log(),dict(max_cell=max_idx,max_norm_upper=maxq,rank_bound=self.rank_bound,naive_upper=float(naive.upper()))

class TightCoefficientMGF(WeightedMGF):
    """Majorize each coefficient of P(S,Z)^2 after collecting like monomials.
    Includes the zero profile outside support. Coefficients use exact fractions.
    """
    def __init__(self,S,tr,w):
        super().__init__(S,tr,w)
        from fractions import Fraction as F
        basis=[tuple(x) for x in tr['basis']];nc=len(tr['profiles'][0]);keys=self.keys
        cc=[[F(0) for _ in range(nc)] for _ in keys];ki={key:i for i,key in enumerate(keys)}
        hs=[[F(v) for v in h] for h in tr['profiles']]
        for a,ma in enumerate(basis):
            for b,mb in enumerate(basis):
                r=ki[tuple(sorted(ma+mb))]
                for j in range(nc):cc[r][j]+=hs[a][j]*hs[b][j]
        self.coefficient_fractions={key:max(F(0),max(row)) for key,row in zip(keys,cc)}
        self.co={key:arb(c.numerator)/c.denominator for key,c in self.coefficient_fractions.items()}
