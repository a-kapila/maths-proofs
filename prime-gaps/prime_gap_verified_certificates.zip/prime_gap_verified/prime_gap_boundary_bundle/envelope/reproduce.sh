#!/usr/bin/env bash
# New work only; inherits saved Fourier and stricter-support certificates.
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
 echo 'usage: bash envelope/reproduce.sh [--checks-only|--full]' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
mkdir -p envelope/recomputed
if [[ "$mode" == --full ]]; then
 python envelope/compute_tight.py 4 5
 python envelope/final_slicing.py
 python envelope/refine_lambda.py
 python envelope/final_slicing.py
fi
python rescaled/verify_scalar.py
python envelope/verify_final.py
python envelope/check_diagnostics.py
python envelope/rebuild_h4.py
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o envelope/recomputed/verify_tuple
envelope/recomputed/verify_tuple envelope/recomputed/h4.csv baseline/inherited/tuples/h4_witness.csv 5089472 >envelope/recomputed/h4_verified.json
python baseline/inherited/tuples/decode_h5.py envelope/recomputed/old_unpatched.bin
python baseline/h5/apply_patches.py envelope/recomputed/old_unpatched.bin envelope/recomputed/previous_h5.bin
python new/apply_new_h5_patches.py envelope/recomputed/previous_h5.bin envelope/recomputed/current_h5.bin
"$cxx" -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o envelope/recomputed/verify_h5
envelope/recomputed/verify_h5 234360000 232481772 10000000 2432107459 envelope/recomputed/current_h5.bin >envelope/recomputed/h5_verified.json
"$cxx" -O3 -std=c++17 limits/optimistic_h5.cpp -o envelope/recomputed/optimistic_h5
envelope/recomputed/optimistic_h5 232481772 >envelope/recomputed/h5_relaxation.json
python - <<'PY'
from pathlib import Path
import json
p=Path('envelope')
for name in ['h4_verified.json','h5_verified.json','h5_relaxation.json']:
 old=json.loads((p/name).read_text());new=json.loads((p/'recomputed'/name).read_text())
 for key,value in old.items():
  if key!='seconds':assert new[key]==value,(name,key,new[key],value)
 print(name,'all mathematical fields match')
print('New scalar, algebra and integer checks completed; inherited Fourier/support calculations not rerun.')
PY
