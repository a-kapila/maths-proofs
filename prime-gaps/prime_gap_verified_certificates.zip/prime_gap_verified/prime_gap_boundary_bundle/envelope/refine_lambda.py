"""Exploratory scalar choice, with interval reevaluation of every retained line."""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import numpy as np
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'envelope'),str(B/'baseline/inherited/analysis')]
from compute_envelope import ar,up
from weighted_mgf import TightCoefficientMGF
from shifted_core import setup
from flint import arb,ctx
ctx.prec=256
for m in [4,5]:
    tr=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
    old=json.load(open(B/f'rescaled/integrated_m{m}.json'));best=json.load(open(B/f'envelope/final_m{m}.json'))
    sig=1+F(tr['delta'])*tr['eps_cells'];S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift'])
    f=TightCoefficientMGF(S,tr,ar(sig)/11);DR=arb(old['restricted_den_lower'])
    rows=[]
    def objective(x):
        logB=up((f.eval(float(x))[0]/DR).log())
        rows.append(dict(j='scalar-refinement',lambda_value=float(x),log_B_upper=logB,slope_upper=up(arb(float(x))*ar(sig))))
        return float(F(logB)/(F(float(x))*sig))
    lam=best['lambda_value'];res=minimize_scalar(objective,bounds=(lam*.96,lam*1.04),method='bounded',options={'xatol':1e-9})
    path=B/f'envelope/tight_m{m}_lines.json';lines=json.load(open(path));lines+=rows;path.write_text(json.dumps(lines,indent=2)+'\n')
    print(m,res.x,-res.fun,len(rows),flush=True)
