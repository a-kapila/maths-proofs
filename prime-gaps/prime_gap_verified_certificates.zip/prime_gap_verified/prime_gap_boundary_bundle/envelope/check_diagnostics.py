"""Independent quadrature, finite-law identities, and exact majorant tests.
These are diagnostics, not substitutes for the interval/proof argument.
"""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from math import prod
import random,json,sys
import mpmath as mp
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'envelope'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from weighted_mgf import TightCoefficientMGF,truncated_moments
from shifted_core import setup
from polynomial_core import weights
from flint import arb,ctx
ctx.prec=384;mp.mp.dps=95
rng=random.Random(2026110418)

def ar(x):
    x=F(x);return arb(x.numerator)/x.denominator

def mpr(x):
    x=F(x);return mp.mpf(x.numerator)/x.denominator

out=dict(exact_coefficient_majorant_tests=0,exact_weighted_moment_identities=0,convexity_tests=0,jensen_diagnostics=0,integral_comparisons=[])
for m in [4,5]:
    tr=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
    row=json.load(open(B/f'envelope/final_m{m}.json'));sig=1+F(tr['delta'])*tr['eps_cells'];k=tr['k']
    S=setup(k,tr['theta'],tr['beta'],tr['relative_shift']);mf=TightCoefficientMGF(S,tr,ar(sig)/11)
    # Exact arithmetic pointwise comparison at varied nonnegative vectors.
    hs=[[F(x) for x in v] for v in tr['profiles']];basis=[tuple(z) for z in tr['basis']]
    for _ in range(1000):
        xs=[F(rng.randrange(0,17),16) for _ in range(rng.randrange(1,9))]
        zs={p:sum(x**p for x in xs) for p in [2,3,4]};j=rng.randrange(len(hs[0]))
        P=sum(hs[a][j]*prod(zs[p] for p in ma) for a,ma in enumerate(basis))
        R=sum(c*prod(zs[p] for p in key) for key,c in mf.coefficient_fractions.items())
        assert P*P<=R;out['exact_coefficient_majorant_tests']+=1
    # Numerical scalar formula check by independent log-coordinate quadrature.
    L=mp.log(k);c=mpr(tr['theta'])/L;T=mpr(tr['beta'])/L;b=mp.mpf(k-1)
    A=mpr(tr['relative_shift'])/(c+b*T);lam=mpr(row['lambda_value']);w=mpr(sig)/11
    m2=(1/c-1/(c+b*T))/b+2*A*mp.log((c+b*T)/c)/b+A*A*T
    sw=mp.log(1+b*w/c);st=mp.log(1+b*T/c)
    _,mus=mf.eval(row['lambda_value'])
    maxerr=mp.mpf(0)
    for p in [0,1,2,3,4,6,8]:
        def f(s):
            t=c*mp.expm1(s)/b
            return (t/T)**p*mp.exp(-lam*min(t,w))*(1/(c*mp.exp(s))+A)**2*c*mp.exp(s)/b/m2
        val=mp.quad(f,[0,sw/3,2*sw/3,sw,(sw+st)/2,st])
        got=mpr(float(mus[p].mid())) # displayed double is not used for the high precision check
        lo=mp.make_mpf(mus[p].x._mpi_[0]);hi=mp.make_mpf(mus[p].x._mpi_[1]);mid=(lo+hi)/2
        err=abs(val-mid)/max(abs(val),mp.mpf('1e-90'));maxerr=max(maxerr,err)
        assert err<mp.mpf('1e-70'),(m,p,mp.nstr(err,20))
        out['integral_comparisons'].append(dict(m=m,power=p,relative_discrepancy=mp.nstr(err,12)))
    print('quadrature',m,mp.nstr(maxerr,10),flush=True)
# Independent finite product-law check; marked Laplace weights may be arbitrary positive rationals.
keys=list(mf.keys)
for n in [4,5,6]:
    xs=[F(0),F(1,3),F(1)];pr=[F(1,2),F(1,3),F(1,6)];tilt=[F(1),F(2,3),F(1,7)]
    mu=[sum(p*t*x**r for p,t,x in zip(pr,tilt,xs)) for r in range(9)]
    formula=weights(n,mu,keys);exact=[F(0) for _ in keys]
    for ix in product(range(3),repeat=n):
        mass=prod(pr[j]*tilt[j] for j in ix);z={r:sum(xs[j]**r for j in ix) for r in [2,3,4]}
        for j,key in enumerate(keys):exact[j]+=mass*prod(z[r] for r in key)
    assert formula==exact;out['exact_weighted_moment_identities']+=len(keys)
# Verify the transformed second derivative with exact rational arithmetic.
for _ in range(2000):
    k=rng.randrange(20,200);h=F(rng.randrange(2,9),10);d=rng.randrange(1,max(2,int(h*(k-1))))
    a=F(d,k);bb=F(d*(d-1),2*h*k*(k-1));ell=F(rng.randrange(1,100))
    if ell*(a-2*bb)<2*bb:continue
    u=F(rng.randrange(1001),1000)
    assert ell*a-2*bb*(1+ell*u)>=0;out['convexity_tests']+=1
# Separate high-precision Jensen checks for mixed finite laws on [0,1].
for _ in range(200):
    ell=mp.mpf(rng.randrange(2,80));a=mp.mpf('0.1');bb=mp.mpf('0.002')
    us=[mp.mpf(rng.randrange(1001))/1000 for _ in range(4)];ww=[rng.randrange(1,100) for _ in range(4)];tot=sum(ww)
    ee=sum(w*mp.exp(-ell*u) for w,u in zip(ww,us))/tot;x=-mp.log(ee)/ell
    lhs=sum(w*(a*u-bb*u*u) for w,u in zip(ww,us))/tot;rhs=a*x-bb*x*x
    assert lhs>=rhs-mp.mpf('1e-85');out['jensen_diagnostics']+=1
(B/'envelope/diagnostics.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='integral_comparisons'}),flush=True)
