"""Recompute each selected moment enclosure and check final implications exactly.
This verifies new scalar work, not the inherited Fourier quotient certificates.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'envelope'),str(B/'baseline/inherited/analysis')]
from weighted_mgf import TightCoefficientMGF
from shifted_core import setup
from flint import arb,ctx
ctx.prec=384

def ar(x):
    x=F(x);return arb(x.numerator)/x.denominator
out=[]
for m in [4,5]:
    old=json.load(open(B/f'rescaled/integrated_m{m}.json'))
    trial_path=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
    tr=json.load(open(trial_path));orig=json.load(open(trial_path.with_suffix('.interval_certificate.json')))
    row=json.load(open(B/f'envelope/final_m{m}.json'));k=tr['k'];h=F(1,11)
    sig=1+F(tr['delta'])*tr['eps_cells'];rho=F(1,4)+F(tr['omega']);target=F(m)/rho
    assert old['original_quotient_lower']==orig['Q_lower']
    assert 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3 and 2*rho*sig<1
    cap=(F(1,4)+F(tr['smooth_delta'])/2)/rho-F(1,10000)
    assert F(11,10)*F(old['new_kappa'])<=cap
    assert F(11,10)*F(old['new_ufrac'])<=F(tr['ufrac'])
    assert F(old['restricted_den_lower'])<=F(orig['den_lower'])-F(old['amplitude_upper'])**2*F(old['support_bad_probability_upper'])
    S=setup(k,tr['theta'],tr['beta'],tr['relative_shift']);mf=TightCoefficientMGF(S,tr,ar(sig*h))
    laplace,mu=mf.eval(row['lambda_value']);assert laplace>0
    logB=(laplace/arb(old['restricted_den_lower'])).log()
    assert logB.upper()<=arb(row['log_B_upper'])
    ell=F(row['lambda_value'])*sig;x=-F(row['log_B_upper'])/ell
    assert 0<x<1 and x==F(*row['mean_parameter_lower'])
    n=row['coordinates_deleted'];a=F(n,k);b=F(n*(n-1),2*k*(k-1)*h)
    assert ell*(a-2*b)>=2*b and a-2*b>0
    beta=a*x-b*x*x;q=F(old['original_quotient_lower'])-F(old['restriction']['loss_upper'])
    margin=F(k-n,k)*q-target*(1-beta)
    nn=n+1;aa=F(nn,k);bb=F(nn*(nn-1),2*k*(k-1)*h)
    next_margin=F(k-nn,k)*q-target*(1-(aa*x-bb*x*x))
    assert margin>0 and next_margin<=0 and margin==F(*row['raw_margin_exact'])
    assert beta==F(*row['beta_lower_exact']) and row['dimension']==k-n
    # Save conservative outward endpoint for the effective quotient surplus.
    eff=ar(margin/(1-beta));efflo=float(np.nextafter(float(eff.lower()),-np.inf))
    coeffs={str(key):[c.numerator,c.denominator] for key,c in mf.coefficient_fractions.items()}
    (B/f'envelope/majorant_m{m}.json').write_text(json.dumps(coeffs,indent=2)+'\n')
    result=dict(m=m,k=k,dimension=k-n,deleted=n,lambda_value=row['lambda_value'],log_bound_verified=True,majorant_coefficients=len(coeffs),scalar_precision_bits=ctx.prec,exact_geometry_checked=True,exact_Jensen_convexity_checked=True,exact_positive_margin_checked=True,effective_margin_lower=efflo,next_sufficient_inequality_fails=True,trial_sha256=hashlib.sha256(trial_path.read_bytes()).hexdigest())
    out.append(result);print(json.dumps(result),flush=True)
(B/'envelope/final_scalar_checks.json').write_text(json.dumps(out,indent=2)+'\n')
