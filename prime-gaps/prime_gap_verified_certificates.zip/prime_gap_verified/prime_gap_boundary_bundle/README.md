# Exact finite-sampling bounds and larger rescaling caps

Completed new bounds, within the inherited sieve framework:

- H2 <= 19,920 (unchanged).
- H3 <= 1,359,754 (unchanged).
- H4 <= 82,258,490, from DHL[5,087,755,5].
- H5 <= 4,831,230,984, from DHL[232,424,891,6].

The successful trial functions and their `accurate/` quotient enclosures are
unchanged. This continuation proves an exact finite-sampling lower bound,
computes new stricter-support losses for dilation caps 10/9 and 4/3, and
computes fresh capped-coordinate means by tagged-moment Fourier inversion.
It then verifies the exact endpoint inequalities and the complete tuples.

For cap h=1/r, nonnegative coordinates with total at most one satisfy

    average_D min(sum_{i in D} x_i, 1/r)
      >= (sum_i min(x_i,1/r))/r * (1 - (k-d)_r/(k)_r).

The proof and the precise scope of sharpness are in `proof_note.pdf`.
All final inequalities use exact fractions, not printed decimal approximations.

## Reproduce

Run from the bundle root with Python 3, NumPy, SciPy, mpmath and a C++17
compiler with OpenMP. Do not disable C++ assertions.

    bash continuation/reproduce.sh --checks-only
    bash continuation/reproduce.sh --full

`--checks-only` reevaluates exact saved endpoint deductions, checks the
finite-sampling lemma on rational grids, runs independent finite-law and
high-precision numerical diagnostics, reconstructs the complete large-tuple
witness file with SHA-256 verification, and reruns both integer verifiers.
`--full` also recomputes the selected new support losses and tagged-moment
Fourier enclosures. It does not rerun inherited quotient certificates; their
source, inputs, proof notes and reproduction commands remain under `accurate/`
and the historical directories. This is not an independent mathematical audit.

The successful selected inputs are `support_m4_10_9.json`,
`support_m5_4_3.json`, `mean_m4_r10.json`, `mean_m5_r4.json`. The moment code
uses the previous explicit error bounds, not an unbounded normal approximation.
The scalar compatibility backend is mpmath.iv, not FLINT/Arb.

## Failed and nonfinal experiments

The nine-component sixth-degree trial `m4_degree6_fine.json` was actually
evaluated. Its saved quotient lower bound 15.235352696205247 is below the
threshold 15.238097269841541. Its exploratory score is not certified, and
neither that score nor its additional weighted-moment calculation is used
in a claimed improvement. Its 192 direct Fourier diagnostics do not change
this failure. To rerun it, first compile the native libraries as in
`accurate/reproduce.sh`, then run:

    python accurate/run_certificate.py continuation/m4_degree6_fine.json

Support experiments for H4 at caps 9/8, 8/7 and 6/5 failed. H5 at cap 6/5
passed but is not the selected final cap. Intermediate finite-sampling-only
results with the old cap are retained separately. These statuses are explicit
in the proof note and RESULTS.json.

The checks establish the stated computational implications under the retained
analytic and numerical assumptions. They are not external peer review, formal
verification, a globally optimal tuple result, or a claim of a published record.
