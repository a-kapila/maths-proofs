# Latest continuation

Current results: H2 <= 19,844; H3 <= 1,357,780; H4 <= 82,234,788; H5 <= 4,830,355,416.

Read continuation_next/README.md and continuation_next/proof_note.pdf. The authoritative latest result is continuation_next/RESULTS.json. Previous directories are retained dependencies.
