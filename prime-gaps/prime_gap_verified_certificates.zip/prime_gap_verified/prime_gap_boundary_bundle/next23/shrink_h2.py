from pathlib import Path
import numpy as np,subprocess,json,time
B=Path(__file__).resolve().parents[1];out=B/'next23'
base=out/'h2_new_local_13_witness.csv';diam=19892;history=[];t0=time.time()
for stage in range(10):
 found=False
 for offset,seed in [(0,13),(2,2026),(0,17),(2,23),(0,31),(2,37)]:
  w=np.loadtxt(base,delimiter=',',skiprows=1,dtype=np.int64);w[:,1]=(w[:,1]-offset)%w[:,0]
  wp=out/f'shrink_{stage}_{seed}_input.csv';np.savetxt(wp,w,fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
  pref=out/f'shrink_{stage}_{seed}';cmd=[str(out/'tuple_local'),str(diam-2),'2304',str(wp),'200000',str(pref),str(seed)]
  with open(str(pref)+'.log','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  fp=Path(str(pref)+'.csv')
  if fp.exists():
   a=np.loadtxt(fp,dtype=np.int64)
   if len(a)>=2304:
    assert len(a)==2304
    wp=Path(str(pref)+'_witness.csv');raw=subprocess.check_output([str(B/'focus23/verify_tuple'),str(fp),str(wp),'2304'],text=True);v=json.loads(raw);assert v['verified']
    record=dict(**v,tuple=str(fp.relative_to(B)),witnesses=str(wp.relative_to(B)),seconds=time.time()-t0)
    history.append(record);(out/'h2_shrink_results.json').write_text(json.dumps(history,indent=2)+'\n');print(json.dumps(record),flush=True)
    base=wp;diam=v['diameter'];found=True;break
 if not found:break
print(json.dumps(dict(final_diameter=diam,steps=len(history),seconds=time.time()-t0)),flush=True)
