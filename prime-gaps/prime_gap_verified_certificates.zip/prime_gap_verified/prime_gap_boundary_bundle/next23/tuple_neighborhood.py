"""Finite exact-integer tuple output from a heuristic MILP neighborhood search.
Optimization failures do not prove global impossibility. The final tuple and
all missing-residue witnesses are independently checked by integer arithmetic.
"""
from pathlib import Path
import sys,time,json
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix
root=Path(__file__).resolve().parents[1]
w=np.loadtxt(root/'next23/h2_shifted_witness.csv',delimiter=',',skiprows=1,dtype=np.int64)
ps=w[1:,0]; rs=(w[1:,1]*((ps+1)//2))%ps
N=19906//2+1; xx=np.arange(N); target=2304
rng=np.random.default_rng(20261105)
cnt=np.zeros(N,dtype=np.int64)
for p,r in zip(ps,rs):cnt[r::p]+=1
best=int(np.sum(cnt==0));start=time.time()
print(json.dumps(dict(initial=best)),flush=True)
for iteration in range(150):
 size=[16,24,32,48][iteration%4]
 pool=np.flatnonzero(ps>=31)
 group=rng.choice(pool,min(size,len(pool)),replace=False)
 c=cnt.copy()
 for i in group:c[rs[i]::ps[i]]-=1
 eligible=xx[c==0]; budget=len(eligible)-target
 if budget<0:continue
 choices=[];hits=[]; groupvars=[]
 for i in group:
  p=ps[i];values=eligible%p;freq=np.bincount(values,minlength=p)
  mn=int(freq.min())
  if mn==0:
   choices.append((int(i),int(np.flatnonzero(freq==0)[0]),True));continue
  cap=min(mn+2,budget)
  opts=np.flatnonzero(freq<=cap)
  if rs[i] not in opts:opts=np.unique(np.append(opts,rs[i]))
  ids=[]
  for r in opts:
   ids.append(len(hits));hits.append(np.flatnonzero(values==r));choices.append((int(i),int(r),False))
  groupvars.append(ids)
 nz=len(hits);touched=np.unique(np.concatenate(hits)) if hits else np.array([],int)
 # Retention variables only for points hit by a candidate residue.
 pos={int(v):j for j,v in enumerate(touched)};nv=nz+len(touched)
 rr=[];cc=[];vv=[];lb=[];ub=[];row=0
 for ids in groupvars:
  rr.extend([row]*len(ids));cc.extend(ids);vv.extend([1.]*len(ids));lb.append(1.);ub.append(1.);row+=1
 for z,pts in enumerate(hits):
  for pnt in pts:
   rr.extend([row,row]);cc.extend([z,nz+pos[int(pnt)]]);vv.extend([1.,1.]);lb.append(-np.inf);ub.append(1.);row+=1
 # seek at least target entries, so feasibility is enough
 required=target-(len(eligible)-len(touched))
 rr.extend([row]*len(touched));cc.extend(range(nz,nv));vv.extend([1.]*len(touched));lb.append(required);ub.append(np.inf);row+=1
 A=coo_matrix((vv,(rr,cc)),shape=(row,nv)).tocsc()
 obj=np.zeros(nv);obj[nz:]=-1
 res=milp(obj,integrality=np.ones(nv),bounds=Bounds(np.zeros(nv),np.ones(nv)),constraints=LinearConstraint(A,np.array(lb),np.array(ub)),options={'time_limit':1.,'mip_rel_gap':0.,'presolve':True})
 print(json.dumps(dict(iteration=iteration,free=size,eligible=len(eligible),variables=nv,status=int(res.status),objective=None if res.fun is None else float(res.fun),seconds=time.time()-start)),flush=True)
 if res.x is None:continue
 zidx=0;newrs=rs.copy()
 for i,r,fixed in choices:
  if fixed:newrs[i]=r
  else:
   if res.x[zidx]>.5:newrs[i]=r
   zidx+=1
 nc=np.zeros(N,dtype=np.int64)
 for p,r in zip(ps,newrs):nc[r::p]+=1
 got=xx[nc==0]*2
 if len(got)>best:
  best=len(got);rs=newrs;cnt=nc
  np.savetxt(root/'next23/h2_candidate.csv',got,fmt='%d')
  ws=np.column_stack((np.r_[2,ps],np.r_[1,(2*newrs)%ps]));np.savetxt(root/'next23/h2_candidate_witness.csv',ws,fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
  print(json.dumps(dict(IMPROVED=best,diameter=int(got[-1]-got[0]),seconds=time.time()-start)),flush=True)
  if best>=target:break
