"""Heuristic residue-coordinate descent; every retained improvement verified.
No search failure is an impossibility certificate.
"""
from pathlib import Path
import sys,subprocess,json,time,numpy as np
B=Path(__file__).resolve().parents[1];O=B/'next23';m=int(sys.argv[1]);k=2304 if m==2 else 110050
if m==2:tp=O/'h2_final.csv';wp=O/'h2_final_witness.csv';sweeps=1000;pmax=k
else:tp=O/'h3_cover.csv';wp=O/'h3_cover_witness.csv';sweeps=120;pmax=60000
hist=[];t0=time.time()
for stage in range(4):
 a=np.loadtxt(tp,dtype=np.int64);lo=int(a[0]);hi=int(a[-1])-2;old=int(a[-1]-a[0]);pref=O/f'cover_polish_m{m}_{stage}'
 cmd=[str(O/'cover_descent'),str(k),str(lo),str(hi),str(wp),str(sweeps),str(pref),str(616+stage*31),str(pmax)]
 with open(str(pref)+'.log','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 candidate=Path(str(pref)+'.csv');cw=Path(str(pref)+'_witness.csv')
 if not candidate.exists():break
 v=json.loads(subprocess.check_output([str(B/'focus23/verify_tuple'),str(candidate),str(cw),str(k)],text=True));assert v['verified'] and v['diameter']<old
 r=dict(**v,tuple=str(candidate.relative_to(B)),witnesses=str(cw.relative_to(B)),seconds=time.time()-t0);hist.append(r);print(json.dumps(r),flush=True)
 (O/f'cover_polish_m{m}_results.json').write_text(json.dumps(hist,indent=2)+'\n');tp=candidate;wp=cw
print(json.dumps(dict(m=m,stages=len(hist),best_tuple=str(tp.relative_to(B)),best_witnesses=str(wp.relative_to(B)),seconds=time.time()-t0)),flush=True)
