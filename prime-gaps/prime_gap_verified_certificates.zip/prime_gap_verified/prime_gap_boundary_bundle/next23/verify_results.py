"""Recheck exact endpoint implications and complete finite tuples.
This does not independently audit the inherited analytic theorem/error analysis.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,subprocess,sys,math
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'next23'

def primes(n):
 a=np.ones(n+1,dtype=bool);a[:2]=False
 for p in range(2,math.isqrt(n)+1):
  if a[p]:a[p*p::p]=False
 return np.flatnonzero(a)

def verify_tuple(tp,wp,k):
 a=np.loadtxt(tp,dtype=np.int64);w=np.loadtxt(wp,delimiter=',',skiprows=1,dtype=np.int64)
 assert len(a)==k and np.all(np.diff(a)>0)
 wd={int(p):int(r) for p,r in w};ps=primes(k)
 present=np.zeros(int(a[-1]-a[0])+1,dtype=bool);present[a-a[0]]=True
 for p in ps:
  assert int(p) in wd
  r=wd[int(p)];assert 0<=r<p
  assert not present[(r-int(a[0]))%p::p].any(),(p,r)
 cpp=json.loads(subprocess.check_output([str(B/'focus23/verify_tuple'),str(tp),str(wp),str(k)],text=True))
 own=dict(verified=True,k=k,first=int(a[0]),last=int(a[-1]),diameter=int(a[-1]-a[0]),checked_primes=len(ps))
 assert cpp==own
 return dict(**own,independent_python_check=True,tuple_sha256=hashlib.sha256(tp.read_bytes()).hexdigest(),witness_sha256=hashlib.sha256(wp.read_bytes()).hexdigest())

def main():
 old=json.load(open(B/'focus23/RESULTS.json'));r2=old['results'][0]
 tr2=json.load(open(B/r2['trial']));q2=F(r2['component_quotient_lower']);loss2=F(r2['restriction_loss_upper']);rho2=F(1,4)+F(tr2['omega'])
 assert 240*F(tr2['omega'])+80*F(tr2['smooth_delta'])<3
 assert q2-loss2>2/rho2
 v2=verify_tuple(O/'h2_final.csv',O/'h2_final_witness.csv',2304)
 tr=json.load(open(O/'m3_k110040.json'));cf=json.load(open(O/'m3_k110040.interval_certificate.json'))
 assert cf['m']==tr['m']==3 and cf['k']==tr['k']==110040
 assert len(cf['direct_fourier_checks'])==108
 rho=F(1,4)+F(tr['omega']);eps=F(tr['delta'])*tr['eps_cells']
 assert 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3 and 2*rho*(1+eps)<1
 q=F(cf['Q_lower']);loss=F(cf['restriction']['loss_upper']);margin=q-loss-3/rho
 assert margin<0
 # The fresh dimension is not guessed by extrapolation; ordinary slicing cannot delete one more.
 assert F(tr['k']-1,tr['k'])*(q-loss)<=3/rho
 oldtr=json.load(open(B/'focus23/m3_k110050.json'))
 assert tr['profiles']==oldtr['profiles'] and tr['basis']==oldtr['basis']
 assert [F(x)*F(tr['delta']) for x in tr['E']]==[F(x)*F(oldtr['delta']) for x in oldtr['E']]
 assert eps==F(oldtr['delta'])*oldtr['eps_cells']
 assert all(tr[x]==oldtr[x] for x in ['theta','beta','relative_shift','omega','smooth_delta'])
 candidate=verify_tuple(O/'h3_k110040_candidate.csv',B/'baseline/inherited/tuples/h3_witness.csv',110040)
 r3=old['results'][1];old3=json.load(open(B/r3['trial']));qold3=F(r3['component_quotient_lower'])-F(r3['restriction_loss_upper']);assert qold3>3/(F(1,4)+F(old3['omega']))
 v3=verify_tuple(O/'h3_final.csv',O/'h3_final_witness.csv',110050)
 new3=v3['diameter']<1359440
 res=dict(scope='Computer-assisted deductions in the inherited framework; no independent analytic audit claimed.',H2=dict(bound=v2['diameter'],previous_bound=19908,saving=19908-v2['diameter'],analytic_dimension=2304,analytic_certificate='Inherited, not recomputed this round',tuple=v2),H3=dict(bound=v3['diameter'],previous_bound=1359440,saving=1359440-v3['diameter'],analytic_dimension=110050,analytic_certificate='Inherited, not recomputed this round',new_tuple=new3,tuple=v3),failed_H3_evaluation=dict(passed=False,trial_dimension=110040,quotient_lower=cf['Q_lower'],restriction_loss_upper=cf['restriction']['loss_upper'],target_upper=cf['target_upper'],margin_fraction=[str(margin.numerator),str(margin.denominator)],margin_float=float(margin),fine_spacing=tr['delta'],direct_checks=108,candidate_tuple=candidate,warning='The candidate tuple does not imply a new H3 bound because the smaller-dimensional analytic inequality failed.'),unchanged=dict(H4=82258490,H5=4831230984))
 (O/'RESULTS.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2))
if __name__=='__main__':main()
