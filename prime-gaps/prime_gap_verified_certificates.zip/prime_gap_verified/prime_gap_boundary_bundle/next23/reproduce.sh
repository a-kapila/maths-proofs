#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
  echo 'usage: bash next23/reproduce.sh --checks-only|--full' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o focus23/verify_tuple
"$cxx" -O3 -std=c++17 next23/recover_tuple.cpp -o next23/recover_tuple
if [[ "$mode" == --full ]]; then
  "$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
  "$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
  # This is intentionally a FAILED sufficient inequality, retained for transparency.
  python next23/run_certificate.py next23/m3_k110040.json | tee next23/m3_k110040_recheck.log
fi
python next23/verify_results.py
next23/recover_tuple 2304 -1000000 1000000 baseline/inherited/tuples/h2_witness.csv next23/h2_reconstruction_recheck.csv > next23/h2_reconstruction_recheck.json
python - <<'PY'
import json
old=json.load(open('next23/h2_recovered_1000000.json'))
new=json.load(open('next23/h2_reconstruction_recheck.json'))
assert old==new
print('Full fixed-witness reconstruction and all-window minimum rechecked.')
PY
