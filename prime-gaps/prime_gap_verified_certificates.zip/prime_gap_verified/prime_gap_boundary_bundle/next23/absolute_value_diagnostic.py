"""Exploratory Monte Carlo + fixed quadrature only, NOT a certificate.
Estimates the unrestricted quotient gain from taking |F| for the saved H2 trial.
Independent remaining coordinates have the reference g^2/m2 density.
"""
from pathlib import Path
import json,math,time,sys
import numpy as np
from scipy.special import roots_legendre
B=Path(__file__).resolve().parents[1]
tr=json.load(open(B/'focus23/m2_k2304.json'));cf=json.load(open(B/'focus23/m2_k2304.interval_certificate.json'))
k=tr['k'];c=tr['theta']/math.log(k);T=tr['beta']/math.log(k);b=k-1;v=c+b*T;A=tr['relative_shift']/v
w2=(1/c-1/v)/b;w1=2*A/b*math.log(v/c);w0=A*A*T;m2=w0+w1+w2
E=np.array(tr['E'])*tr['delta'];H=np.array(tr['profiles']);eps=tr['eps_cells']*tr['delta'];rng=np.random.default_rng(1142026)
u,w=roots_legendre(256);u=(u+1)/2;w=w/2
nodes=np.r_[(c*np.exp(u*math.log(v/c))-c)/b,T*u];weights=np.r_[w*math.log(v/c)/b,w*A*T]
xn=nodes/T;pows={p:xn**p for p in [2,3,4]}
N=40000;step=100;gains=[];signfibers=0;negmass=0.;den=0.;t0=time.time()
for lo in range(0,N,step):
 n=min(step,N-lo);u=rng.random((n,k-1));z=rng.random((n,k-1));x=(1/(1/c-u*(1/c-1/v))-c)/b
 mask=(z>w2/m2)&(z<(w2+w1)/m2);x[mask]=(c*np.exp(u[mask]*math.log(v/c))-c)/b
 mask=z>=(w2+w1)/m2;x[mask]=T*u[mask]
 ss=x.sum(axis=1);z2=((x/T)**2).sum(axis=1);z3=((x/T)**3).sum(axis=1);z4=((x/T)**4).sum(axis=1)
 s=ss[:,None]+nodes[None,:];ix=np.searchsorted(E,s,side='right')-1;valid=(ix>=0)&(ix<H.shape[1])&(ss[:,None]<=1-eps)
 ix=np.clip(ix,0,H.shape[1]-1);zz2=z2[:,None]+pows[2];zz3=z3[:,None]+pows[3];zz4=z4[:,None]+pows[4]
 p=H[0,ix]+H[1,ix]*zz2+H[2,ix]*zz3+H[3,ix]*zz4+H[4,ix]*zz2**2;p=np.where(valid,p,0)
 pos=np.maximum(p,0)@weights;neg=np.maximum(-p,0)@weights
 gains.extend((4*k/m2*pos*neg/cf['den_lower']).tolist());signfibers+=int(np.count_nonzero((pos>0)&(neg>0)))
gains=np.array(gains)
out=dict(scope='Exploratory only: Monte Carlo plus fixed quadrature; unrestricted trial; not an interval certificate',samples=N,nodes_per_component=256,seed=1142026,gain_mean=float(gains.mean()),gain_standard_error=float(gains.std(ddof=1)/math.sqrt(N)),positive_sample_count=int(np.count_nonzero(gains)),sign_changing_fibers=signfibers,maximum_sample_gain=float(gains.max()),seconds=time.time()-t0)
(B/'next23/absolute_value_diagnostic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
