from pathlib import Path
import json
B=Path(__file__).resolve().parents[1];O=B/'next23';r=json.load(open(O/'RESULTS.json'))
def num(x):return f'{x:,}'.replace(',',r'\,')
a=r['H2'];b=r['H3'];t2=a['tuple'];t3=b['tuple'];fail=r['failed_H3_evaluation']
text=r'''\documentclass[11pt]{article}
\usepackage[margin=0.8in]{geometry}
\usepackage{amsmath,amssymb,booktabs,hyperref,microtype}
\hypersetup{colorlinks=true,linkcolor=black,urlcolor=blue}
\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}
\title{Residue-witness completion and further finite prime-gap reductions}
\author{Computational research continuation prepared in ChatGPT}
\date{4 November 2026}
\begin{document}\maketitle
\begin{abstract}
New admissible tuples improve both $H_2$ and $H_3$ using the previously obtained sieve dimensions. A fresh numerical trial in a smaller dimension for $H_3$ fails its sufficient inequality and is excluded from the results. The inherited analytic framework and numerical certificates have not undergone an independent expert audit. The new finite tuples are checked by separate C++ and Python integer verifiers.
\end{abstract}
\section{Results and exact scope}
Write $H_m=\liminf_{n\to\infty}(p_{n+m}-p_n)$. The new deductions, within the inherited framework, are:
\begin{center}\begin{tabular}{rrrr}
\toprule & Previous bound & New bound & Saving\\\midrule
$H_2$ & $19\,908$ & $@H2@$ & $@SAVE2@$\\
$H_3$ & $1\,359\,440$ & $@H3@$ & $@SAVE3@$\\
$H_4$ & $82\,258\,490$ & unchanged & 0\\
$H_5$ & $4\,831\,230\,984$ & unchanged & 0\\\bottomrule
\end{tabular}\end{center}
Both improvements in this note are \emph{combinatorial}. They reuse
\[
\mathrm{DHL}[2304,3],\qquad \mathrm{DHL}[110050,4]
\]
from the preceding continuation [1]. Neither successful analytic certificate is recomputed here. A fresh attempt at $\mathrm{DHL}[110040,4]$ does not pass.

\section{Complete the residue constraints before restricting the parent}
Given one missing residue $r_p$ for each prime $p\le K$, form the entire set
\[
\mathcal A_{L,R}=\{x\in [L,R]\cap\mathbb Z:x\not\equiv r_p\pmod p\text{ for all primes }p\le K\}.
\]
Every $K$-element subset of this set is admissible: the recorded residues handle primes at most $K$, and a larger prime has more residue classes than the tuple has elements.

The saved $H_2$ parent contained only 2,307 points. Reconstructing every permitted integer in $[-10^6,10^6]$ using its existing relevant witnesses gives 141,233 points. The shortest 2,304-element window has endpoints 190 and 20,088, of diameter 19,898. Thus the stored parent's earlier minimum was not the minimum among all points satisfying those same residue constraints.

Further local changes of missing residues yield the final tuple. These searches are heuristic; their output is not accepted until full integer verification. Coordinate-descent refinements similarly improve the $H_3$ tuple without changing its analytic dimension.
\newpage
\section{Final finite certificates}
\begin{center}\begin{tabular}{rrrrr}
\toprule & Cardinality & First & Last & Diameter\\\midrule
$H_2$ & $2\,304$ & $@FIRST2@$ & $@LAST2@$ & $@H2@$\\
$H_3$ & $110\,050$ & $@FIRST3@$ & $@LAST3@$ & $@H3@$\\\bottomrule
\end{tabular}\end{center}
Each checker verifies strict ordering, distinctness, cardinality, and an omitted residue at every prime up to the cardinality. There are 342 relevant primes for $H_2$ and 10,456 for $H_3$. The Python checker generates its own prime list and checks the residue progressions in a membership bitmap. Its results agree with the separate C++ verifier.

Combining these finite admissibility certificates with the inherited DHL statements gives the displayed prime-gap bounds. No globally minimum-diameter tuple is asserted.

\section{A completed analytic attempt that does not improve $H_3$}
The inherited six-profile trial uses
\[
F(t)=\bigl[\psi_0(S)+\psi_2(S)Z_2+\psi_3(S)Z_3+\psi_4(S)Z_4
+\psi_{22}(S)Z_2^2+\psi_{23}(S)Z_2Z_3\bigr]\prod_i g(t_i),
\]
where $S=\sum_i t_i$ and $Z_j=\sum_i(t_i/T)^j$. The same exact dyadic profiles and physical cell boundaries were reevaluated at $k=110040$. The one-coordinate factor changes with the dimension. The integration spacing is $2^{-24}$, half the preceding spacing; this refinement does not alter the physical profile boundaries.

The evaluation computes fresh weighted distribution functions, a quotient enclosure, and the support-loss bound. It uses the inherited component-wise numerator lower bound only. The optional Hilbert-space bound and its unnecessary arrays were omitted; the component-wise arithmetic is unchanged, as recorded in \texttt{component\_only.diff}.

The saved numerical endpoints are
\begin{align*}
 Q^-&=11.428571128165588,\\
 L^+&\approx 4.051517922322939\times10^{-45},\\
 (3/\rho)^+&=11.428585984599039.
\end{align*}
The corrected sufficient margin is approximately $-1.485643345\times10^{-5}$. It is negative even before the essentially negligible support loss is deducted. Therefore this computation does \emph{not} establish $\mathrm{DHL}[110040,4]$. The 108 direct Fourier diagnostic checks passed, but diagnostic agreement cannot replace the failed sufficient inequality.

This is not an upper bound on the trial's true quotient. It therefore does not prove that the trial is inadequate, nor establish a method-wide limit. A checked 110,040-element candidate tuple of diameter 1,359,306 is retained, but is not used to claim a prime-gap bound.
\newpage
\section{Other experiments and remaining limits}
A six-term exploratory $H_2$ optimization at $k=2302$ returned a floating-point quotient of about 7.6187700972, below the working target of about 7.6193862875 before support deductions. This is an exploratory score, not an interval upper bound or an impossibility result. It is not used in either new result.

An unrestricted $H_2$ diagnostic sampled 40,000 remaining-coordinate vectors and used fixed quadrature along the integrated coordinate to estimate the effect of replacing $F$ by $|F|$. It found 24 sampled fibres with both signs and an estimated quotient gain of about $2.07\times10^{-5}$, with an empirical standard error of about $6.55\times10^{-6}$. Rare events, quadrature error, and arithmetic support removal are not rigorously controlled by this diagnostic. No prime-gap conclusion uses it.

The earlier strict inequality $Q(|F|)>Q(F)$ remains a nonoptimality observation, not a quantified improvement sufficient to remove a coordinate. Likewise, unsuccessful residue searches do not establish an optimum. This continuation demonstrates remaining combinatorial room but supplies no sharp terminal bound for $H_2$ or $H_3$.

\section{Reproduction and dependencies}
The complete archive contains the inherited certificates and their source, the final explicit tuples and witnesses, the new failed analytic evaluation, and the exploratory outputs. From its root:
\begin{verbatim}
bash next23/reproduce.sh --checks-only
bash next23/reproduce.sh --full
\end{verbatim}
The check workflow verifies the exact endpoint deductions, both final tuples in C++ and Python, the smaller-dimensional failed inequality, and the full fixed-witness $H_2$ reconstruction. The full workflow also reevaluates the failed $H_3$ numerical attempt. Search is unnecessary for checking a fixed tuple.

\texttt{next23/RESULTS.json} separates successful inherited-dimension deductions from the failed smaller-dimensional computation. The complete proof still depends on the original prime-distribution input [2], the inherited enlarged-support implication, scalar/Fourier error analysis, implementation, and arithmetic model. The scalar backend remains the documented \texttt{mpmath.iv} compatibility implementation, not FLINT/Arb. The new finite integer checks are not an independent review of that analytic chain.

\begin{thebibliography}{9}
\bibitem{previous} Further $H_2$ and $H_3$ reductions and a strict nonoptimality test, computational continuation, 4 November 2026. Retained under \texttt{focus23/} with its dependencies.
\bibitem{base} Improved bounds on $H_m$ for $2\le m\le5$, Hexagon 2610.00419v1, 20 October 2026. \url{https://hexagonmath.org/2610.00419v1}.
\end{thebibliography}
\end{document}
'''
vals={'H2':a['bound'],'H3':b['bound'],'SAVE2':a['saving'],'SAVE3':b['saving'],'FIRST2':t2['first'],'LAST2':t2['last'],'FIRST3':t3['first'],'LAST3':t3['last']}
for k,v in vals.items():text=text.replace('@'+k+'@',num(v))
(O/'note.tex').write_text(text)
