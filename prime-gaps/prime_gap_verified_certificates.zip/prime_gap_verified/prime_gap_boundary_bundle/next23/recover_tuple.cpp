// Reconstruct every survivor of the relevant missing-residue constraints.
// All calculations are integer. Extra constraints above K are unnecessary.
#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
 if(argc!=6){cerr<<"K lo hi witnesses output.csv\n";return 2;}
 long K=stol(argv[1]),lo=stol(argv[2]),hi=stol(argv[3]);if(lo%2)++lo;
 long N=(hi-lo)/2+1;vector<unsigned char>blocked(N,0);ifstream f(argv[4]);string s;getline(f,s);
 long count=0;while(getline(f,s)){replace(s.begin(),s.end(),',',' ');istringstream ss(s);long p,r;ss>>p>>r;
  if(p>K)continue;if(p==2){assert(r==1);continue;}
  long v=(r-lo)%p;if(v<0)v+=p;long a=v*((p+1)/2)%p;
  for(long i=a;i<N;i+=p)blocked[i]=1;++count;
 }
 vector<long>a;for(long i=0;i<N;i++)if(!blocked[i])a.push_back(lo+2*i);
 if(a.size()<(size_t)K){cout<<"{\"enough\":false,\"survivors\":"<<a.size()<<"}\n";return 0;}
 long best=LONG_MAX;size_t ix=0;for(size_t j=0;j+K<=a.size();j++)if(a[j+K-1]-a[j]<best){best=a[j+K-1]-a[j];ix=j;}
 ofstream out(argv[5]);for(size_t j=ix;j<ix+K;j++)out<<a[j]<<'\n';
 cout<<"{\"k\":"<<K<<",\"survivors\":"<<a.size()<<",\"first\":"<<a[ix]<<",\"last\":"<<a[ix+K-1]<<",\"diameter\":"<<best<<",\"windows\":"<<a.size()-K+1<<",\"primes_used\":"<<count+1<<"}\n";
}
