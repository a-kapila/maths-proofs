from pathlib import Path
import sys,json,time
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import optimize
D=json.load(open(B/'focus23/m2_k2304.json'));D['k']=2302
basis=[(),(2,),(3,),(4,),(2,2),(2,3)]
r=optimize(D,basis,ncell=400,N=2**20,ng=40,spacing=2**-23,tol=1e-12)
d={**{k:v for k,v in D.items() if not k.startswith('h')},**r}
d['note']='Exploratory reoptimization with Z2Z3 added. No certified numerical result yet.'
(B/'next23/m2_mixed_k2302.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ['E','profiles']}),flush=True)
