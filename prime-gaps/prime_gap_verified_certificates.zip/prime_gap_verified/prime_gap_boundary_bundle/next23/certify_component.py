"""Fixed-trial interval evaluation of polynomial power-sum profiles.
Inherits the previously documented FFT and support-loss enclosure argument.
"""
from pathlib import Path
import sys,json,time,math
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE/'baseline'/'inherited'/'analysis'
sys.path[:0]=[str(ROOT),str(BASE/'baseline'/'polynomial'),str(BASE/'analysis')]
import numpy as np
from flint import arb,ctx
from polynomial_core import marginal_terms
from streaming_cdf import StreamingCDF as PolynomialCDF, direct_check
from amplitude_envelope import profile_amplitude
from fast_profile import profile_bounds as fast_profile_bounds
from certify_multi import make_tables
from certify_lifted import D,H,U,const,add,sub,mul,square,inv,scale,integrate_bound,profile_bounds
from loss_joint import restriction_loss

def amplitude(hs,basis,E,spacing,S):
    C=arb(0)
    for j in range(len(hs[0])):
        z=arb(int(E[j+1]))*arb(spacing)/S['T']; c=arb(0)
        for h,mon in zip(hs,basis): c+=arb(abs(float(h[j])))*z**len(mon)
        if c.upper()>C: C=c.upper()
    return float(H(float(C)))

def run(path):
    d=json.loads(Path(path).read_text());t=time.time();ctx.prec=256
    k,m=d['k'],d['m'];spacing=d['delta'];eps=spacing*d['eps_cells'];one=round(1/spacing)
    basis=[tuple(x) for x in d['basis']];E=np.array(d['E'],dtype=np.int64);hs=[np.array(h,float) for h in d['profiles']]
    assert len(basis)==len(hs) and basis[0]==() and E[0]==0 and E[-1]==one+d['eps_cells'] and np.all(np.diff(E)>0)
    assert all(all(p>=2 for p in mon) for mon in basis)
    for h in hs: assert len(h)==len(E)-1 and max(abs(h))<=1 and np.all(h*2**40==np.round(h*2**40))
    global profile_bounds
    profile_bounds=fast_profile_bounds
    cdf=PolynomialCDF(k,d['theta'],d['beta'],d['relative_shift'],basis=basis,DELTA=spacing,P=d.get('period',8.),ymax=1.125)
    tdata=dict(d);maxp=max(map(sum,basis));tdata['powers']=list(range(1,maxp+1))
    tabs,m2,S=make_tables(tdata,cdf)
    print(json.dumps(dict(stage='antiderivative_tables',seconds=time.time()-t)),flush=True)
    ki={key:i for i,key in enumerate(cdf.moment_keys)}
    dc={key:(np.zeros(len(hs[0])),np.zeros(len(hs[0]))) for key in cdf.moment_keys}
    for a,ma in enumerate(basis):
        for b in range(a,len(basis)):
            key=tuple(sorted(ma+basis[b])); co=square((hs[a],hs[a])) if a==b else scale(mul((hs[a],hs[a]),(hs[b],hs[b])),2.)
            dc[key]=add(dc[key],co)
    denlo=arb(0);denhi=arb(0)
    for key in cdf.moment_keys:
        co=dc[key];L,V=cdf.bounds(k,ki[key],E*spacing)
        denlo+=arb(integrate_bound(co[0],L,V,-1));denhi+=arb(integrate_bound(co[1],L,V,1))
    dl=float(D(float(denlo.lower())));dh=float(H(float(denhi.upper())));assert dl>0
    ilo=int(E[1]);itop=one-d['eps_cells'];I=np.arange(ilo,itop,dtype=np.int64)
    AA={key:(np.zeros(len(I)),np.zeros(len(I))) for key in cdf.marginal_basis}
    for h,mon in zip(hs,basis):
        for keep,power,co in marginal_terms(mon):
            AA[keep]=add(AA[keep],scale(profile_bounds(h,tabs[power],E,I),float(co)))
    pairs={key:[] for key in cdf.moment_keys}
    for a,ma in enumerate(cdf.marginal_basis):
        for b in range(a,len(cdf.marginal_basis)):
            mb=cdf.marginal_basis[b]
            pairs[tuple(sorted(ma+mb))].append((ma,mb,1 if a==b else 2))
    oldnum=arb(0)
    points=np.arange(ilo,itop+1)*spacing;components=[]
    for key in cdf.moment_keys:
        # Accumulate only one moment's coefficient arrays at a time.
        co=(np.zeros(len(I)),np.zeros(len(I)))
        for ma,mb,factor in pairs[key]:
            co=add(co,scale(square(AA[ma]) if ma==mb else mul(AA[ma],AA[mb]),float(factor)))
        L,V=cdf.bounds(k-1,ki[key],points)
        ov=integrate_bound(co[0],L,V,-1)
        oldnum+=arb(ov)
        components.append(ov)
    oldlo=oldnum.lower()
    best=oldlo
    nl=float(D(float(best)));assert nl>0
    q=arb(k)/m2*arb(nl)/arb(dh);ql=float(D(float(q.lower())))
    Cup,naiveCup=profile_amplitude(hs,basis,E,spacing,S);scaled_den=float(D(float((arb(dl)/arb(Cup)**2).lower())))
    print(json.dumps(dict(stage='quotient',k=k,Q_lower=ql,den_lower=dl,den_upper=dh,num_lower=nl,amplitude_upper=Cup,seconds=time.time()-t)),flush=True)
    rc=restriction_loss(k,d['theta'],d['beta'],d['smooth_delta'],d['omega'],scaled_den,ufrac=d['ufrac'],sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=1-eps)
    target=arb(m)/(arb(1)/4+arb(d['omega']));tu=float(H(float(target.upper())));margin=float(D(float((arb(ql)-arb(rc['loss_upper'])-arb(tu)).lower())))
    assert 240*arb(d['omega'])+80*arb(d['smooth_delta'])<3
    assert 2*(arb(1)/4+arb(d['omega']))*(1+arb(eps))<1
    out=dict(m=m,k=k,trial=str(path),basis=basis,Q_lower=ql,restriction=rc,target_upper=tu,margin_lower=margin,epsilon=eps,den_lower=dl,den_upper=dh,num_lower=nl,num_components_lower=components,num_original_lower=float(oldlo),amplitude_upper=Cup,amplitude_naive_upper=naiveCup,scaled_den_lower=scaled_den,moment_keys=cdf.moment_keys,cdf=dict(J=cdf.J,N=cdf.N,error={str(key):v for key,v in cdf.error.items()},alias={str(key):v for key,v in cdf.alias.items()},series_tail={str(key):v for key,v in cdf.tail.items()}),elapsed=time.time()-t,backend='inherited mpmath.iv bounded scalar and Fourier/FFT routines')
    Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    out['direct_fourier_checks']=direct_check(cdf)
    out['new_enclosures']={'amplitude':'exact rational quadratic envelope','numerator':'inherited component-wise bound only; optional Hilbert calculation omitted','memory':'CDF grids streamed with direct-check samples retained','profile_evaluation':'C++ same IEEE operation order; no fast-math or FMA'}
    Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({a:out[a] for a in ['m','k','Q_lower','target_upper','margin_lower','elapsed','num_original_lower','amplitude_upper','amplitude_naive_upper']}),flush=True)
    return out
if __name__=='__main__':
    for p in sys.argv[1:]:run(p)
