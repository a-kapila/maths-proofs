from pathlib import Path
import sys,json,time
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis'),str(B/'analysis')]
from flint import arb,ctx
from loss_tagged import restriction_loss
ctx.prec=256
d=json.load(open(B/'trials/m2_final.json'));c=json.load(open(B/'trials/m2_final.interval_certificate.json'))
t=time.time();eps=d['delta']*d['eps_cells'];ratio=float(sys.argv[1])
r=restriction_loss(d['k'],d['theta'],d['beta'],d['smooth_delta'],d['omega'],c['scaled_den_lower'],eta=1e-8,ufrac=d['ufrac'],ratio=ratio,sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=1-eps)
r['seconds']=time.time()-t
(B/f'focus23/m2_tagged_ratio{ratio}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
