"""Tagged support loss retaining both heavy mass and heavy count.
For Y=sum_{X_i>=w}X_i, R=sum_{X_i<w}X_i, N=#heavy,
P(Y>H,R<B,N>=r) <= exp(-alpha H+lambda B)*(a+d)^n*
   P(Bin(n,a/(a+d))>=r),
a=E[e^(alpha X)1_{X>=w}], d=E[e^(-lambda X)1_{X<w}].
Nonnegative alpha,lambda; exploratory choices are reevaluated in interval arithmetic.
The alpha=0 case is the inherited bound. All bounds remain valid if optimization fails.
"""
from pathlib import Path
import sys,json,math,time
BUNDLE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BUNDLE/'baseline/inherited/analysis'),str(BUNDLE/'analysis')]
import numpy as np
from scipy.special import expi, betainc
from scipy.optimize import minimize
from flint import arb,ctx
from shifted_core import setup,mgf_negative,mgf_positive
from loss_joint import sharp_tail,joint_tail
from loss_shifted import mgf_trunc_f


def choose_tilts(n,r,H,B,w,S,lams):
 c,b,T,A,m2=(float(S[x].mid()) for x in ('c','b','T','A','m2'))
 p=float((1-S['F'](arb(w))).mid())
 def heavy(alpha):
  if alpha<1e-9:return p
  aa=alpha/b;lo=c+b*w;hi=c+b*T
  ehi=np.exp(alpha*T);elo=np.exp(alpha*w)
  f1=np.exp(-aa*c)*(expi(aa*hi)-expi(aa*lo))/b
  f2=(elo/lo-ehi/hi)/b+aa*f1
  f0=elo*np.expm1(alpha*(T-w))/alpha
  return (f2+2*A*f1+A*A*f0)/m2
 def objective(z):
  alpha,loglam=z;lam=np.exp(loglam)
  with np.errstate(all='ignore'):
   a=heavy(alpha);d=float(mgf_trunc_f(lam,c,b,w,A))/m2
   total=a+d;q=a/total
   if not (a>0 and d>0 and 0<q<1 and np.isfinite(total)):return 1e100
   if r<=0:logtail=0.
   elif r>n:return 1e100
   else:
    tail=betainc(r,n-r+1,q)
    if tail<=0:return 1e100
    logtail=np.log(tail)
   return -alpha*H+lam*B+n*np.log(total)+logtail
 # Reuse coarse one-dimensional choices as the alpha=0 baseline.
 df=mgf_trunc_f(lams,c,b,w,A)/m2;mass=p+df;q=p/mass
 with np.errstate(all='ignore'):
  tails=betainc(r,n-r+1,q) if r>0 else np.ones_like(q)
  scores=lams*B+n*np.log(mass)+np.log(tails)
 scores=np.where((df>0)&np.isfinite(scores),scores,np.inf)
 ix=int(np.argmin(scores));ll=math.log(float(lams[ix]))
 best=(objective([0.,ll]),0.,math.exp(ll))
 for a0 in [0.,10.]:
  res=minimize(objective,[a0,ll],method='Nelder-Mead',bounds=[(0.,500./T),(math.log(1e-5),math.log(1e7))],options={'maxiter':100,'xatol':1e-4,'fatol':1e-8})
  if np.isfinite(res.fun) and res.fun<best[0]:best=(float(res.fun),float(res.x[0]),float(np.exp(res.x[1])))
 return best

def bound(n,r,H,B,w,S,lams):
 if r>n or B<=0:return arb(0),{}
 baseline=joint_tail(n,r,B,w,S,lams)
 best=baseline
 score,alpha,lam=choose_tilts(n,r,float(H.lower()),float(B.upper()),float(w.mid()),S,lams)
 if alpha>0:
  h=mgf_positive(arb(alpha),S)-mgf_positive(arb(alpha),dict(S,T=w))
 else:h=1-S['F'](w)
 d=mgf_negative(arb(lam),S['c'],S['b'],w,S['A'])/S['m2']
 assert h>0 and d>0
 mass=h+d
 val=(-arb(alpha)*H+arb(lam)*B+arb(n)*mass.log()).exp()*sharp_tail(n,r,h/mass)
 if val.upper()<best.upper():best=val
 return best,dict(n=n,r=r,H=float(H.mid()),B=float(B.mid()),w=float(w.mid()),alpha=alpha,lam=lam,old=float(baseline.upper()),new=float(best.upper()),score=score)

def run(trial,outfile,ratio=1.03):
 t0=time.time();ctx.prec=256
 tr=json.load(open(trial));ce=json.load(open(Path(trial).with_suffix('.interval_certificate.json')))
 k=tr['k'];theta=tr['theta'];beta=tr['beta'];delta=tr['smooth_delta'];omega=tr['omega'];eps=tr['delta']*tr['eps_cells'];eta=1e-8
 S=setup(k,theta,beta,tr['relative_shift']);T=S['T'];rho=arb(1)/4+arb(omega)
 u0=arb(tr['ufrac'])*arb(delta)/rho;kappa=(arb(1)/4+arb(delta)/2)/rho-arb(eta)
 cv=arb(1.5);A=arb(1-eps);B=arb(1+eps);n=k-1
 F,G=S['F'],S['G'];GT=G(T)
 grid=[u0]
 while grid[-1]*arb(ratio)<T:grid.append(grid[-1]*arb(ratio))
 grid.append(T)
 lams=np.exp(np.linspace(math.log(1e-3),math.log(1e7),900))
 up=lambda x:float(np.nextafter(float(x.upper()),np.inf))
 rc=lambda H:int(math.floor(np.nextafter(float((H/T).lower()),-np.inf)))+1
 sums=[arb(0),arb(0),arb(0)];rows=[]
 for j,(w,v) in enumerate(zip(grid[:-1],grid[1:])):
  mark=F(v)-F(w);H=kappa-(cv+1)*v;r=rc(H)
  bt=arb(min(up(A-H+arb(eta)),up(B-kappa+cv*v+arb(eta)),up(A-arb(r)*w+arb(eta)),up(B-arb(r+1)*w+arb(eta))))
  ba=arb(min(up(A-kappa+cv*v+arb(eta)),up(A-arb(r+1)*w+arb(eta))))
  H2=H-T;r2=rc(H2)
  bb=arb(min(up(A-w-H2+arb(eta)),up(B-kappa+cv*v+arb(eta)),up(A-arb(r2+1)*w+arb(eta)),up(B-arb(r2+2)*w+arb(eta))))
  vals=[]
  for nn,rr,hh,bb_,factor in [(n,r,H,bt,G(v)-G(w)),(n-1,r,H,ba,arb(n)*mark*G(v)),(n-1,r2,H2,bb,arb(n)*mark*(GT-G(w)))]:
   val,info=bound(nn,rr,hh,bb_,w,S,lams);vals.append(val*factor);info['factor']=up(factor);rows.append(info)
  sums=[s+x for s,x in zip(sums,vals)]
  if j%20==0:print(json.dumps(dict(stage='tagged_mass',cell=j,cells=len(grid)-1,seconds=time.time()-t0)),flush=True)
 C=arb(ce['amplitude_upper']);den=arb(ce['den_lower'])/C**2
 loss=arb(2*k)*GT*sum(sums)/(S['m2']*den)
 out=dict(m=tr['m'],k=k,trial=trial,loss_upper=up(loss),ratio=ratio,eta=eta,cells=len(grid)-1,components=list(map(up,sums)),rows=rows,seconds=time.time()-t0,precision_bits=ctx.prec,method='joint heavy-mass, light-mass and binomial-count exponential bound')
 Path(outfile).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({a:b for a,b in out.items() if a!='rows'}),flush=True)
if __name__=='__main__':run(*sys.argv[1:3],*(map(float,sys.argv[3:])))
