"""Directed binary64 enclosure of G(w), with no reliance on libm log accuracy.
Range-reduced log uses z=(m-1)/(m+1), m in [1,2), 20 positive
atanh-series terms and a uniform explicit remainder. Every arithmetic
operation is widened by nextafter. Inputs c,T,A are interval constants.
"""
from pathlib import Path
import sys,math,json
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup
from certify_lifted import const,add,mul,inv
D=lambda x:np.nextafter(x,-np.inf)
H=lambda x:np.nextafter(x,np.inf)

def log_point(x):
 x=np.asarray(x,dtype=float);assert np.all(np.isfinite(x)) and np.all(x>=1)
 m,e=np.frexp(x);m=m*2;e=e-1
 # Range reduction is exact for finite normal binary64 x.
 zlo=np.maximum(0,D(D(m-1)/H(m+1)));zhi=H(H(m-1)/D(m+1))
 slo=np.maximum(0,D(zlo*zlo));shi=H(zhi*zhi)
 n=20
 qlo,qhi=const(arb(1)/(2*n-1));lo=np.full(x.shape,qlo);hi=np.full(x.shape,qhi)
 for j in range(n-2,-1,-1):
  cl,ch=const(arb(1)/(2*j+1));lo=D(D(lo*slo)+cl);hi=H(H(hi*shi)+ch)
 lo=D(2*D(zlo*lo));hi=H(2*H(zhi*hi))
 rem=const(2*(arb(1)/3)**(2*n+1)/(arb(2*n+1)*(1-arb(1)/9)))[1]
 hi=H(hi+rem)
 l2,h2=const(arb(2).log());lo=D(lo+D(e*l2));hi=H(hi+H(e*h2))
 return np.maximum(0,lo),hi

def gtable(k,theta,beta,nmax,DELTA,relative_shift=0.):
 ctx.prec=256
 S=setup(k,theta,beta,relative_shift)
 c,b,T,A=(const(S[x]) for x in ('c','b','T','A'))
 grid=np.arange(nmax+1,dtype=float)*DELTA
 assert nmax<2**52 and math.frexp(DELTA)[0]==.5
 w=(np.minimum(grid,T[0]),np.minimum(grid,T[1]))
 x=add((1.,1.),mul(mul(b,w),inv(c)))
 xl=np.maximum(1.,x[0]);xh=np.maximum(1.,x[1])
 ll,_=log_point(xl);_,lh=log_point(xh)
 lo,hi=add(mul((ll,lh),inv(b)),mul(A,w))
 lo=np.maximum(0,lo);lo[0]=0.;hi[0]=0.
 return lo,hi,S['m2'],S['G'](S['T'])

if __name__=='__main__':
 from fractions import Fraction
 rng=np.random.default_rng(321);ctx.prec=256
 vals=np.r_[1.,2.,np.nextafter(1.,np.inf),np.nextafter(2.,-np.inf),np.exp(rng.uniform(0,40,1000))]
 l,h=log_point(vals)
 for x,a,b in zip(vals,l,h):
  y=arb(float(x)).log();assert arb(float(a))<=y and y<=arb(float(b))
 count=0
 for k,theta,beta,r in [(2305,.9911024435950565,2.9489955673549337,.05041776295285341),(110070,1.0078753919466732,4.407650476075757,.24352577574567524)]:
  S=setup(k,theta,beta,r);step=2**-15;N=math.ceil(float(S['T'].upper())/step)+2
  lo,hi,_,_=gtable(k,theta,beta,N,step,r)
  for i in np.unique(np.r_[0,N,np.arange(0,N+1,19)]):
   w=arb(int(i))*arb(step)
   if w>S['T']:w=S['T']
   exact=S['G'](w);assert arb(float(lo[i]))<=exact and exact<=arb(float(hi[i]));count+=1
 out={'log_point_cases':len(vals),'primitive_cases':count,'all_enclosed':True,'terms':20}
 (B/'focus23/fast_gtable_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
