"""Scan every consecutive window of a saved admissible parent, then verify
all missing residues for the selected tuple using the separate C++ checker.
"""
from pathlib import Path
import json,subprocess,sys,numpy as np
B=Path(__file__).resolve().parents[1]
m,K=map(int,sys.argv[1:]);prefix=B/'focus23'/f'h{m}_k{K}';p=B/f'baseline/inherited/tuples/h{m}.csv';w=B/f'baseline/inherited/tuples/h{m}_witness.csv'
a=np.loadtxt(p,dtype=np.int64);assert len(a)>=K and np.all(np.diff(a)>0)
widths=a[K-1:]-a[:len(a)-K+1];i=int(widths.argmin());s=a[i:i+K]
np.savetxt(prefix.with_suffix('.csv'),s,fmt='%d')
r=dict(k=K,first=int(s[0]),last=int(s[-1]),diameter=int(s[-1]-s[0]),window_index=i,windows_examined=len(widths),parent_size=len(a),parent=str(p.relative_to(B)),witnesses=str(w.relative_to(B)))
prefix.with_name(prefix.name+'_selection.json').write_text(json.dumps(r,indent=2)+'\n')
ver=subprocess.check_output([str(B/'focus23/verify_tuple'),str(prefix.with_suffix('.csv')),str(w),str(K)],text=True)
v=json.loads(ver);assert all(v[x]==r[x] for x in ['k','first','last','diameter'])
prefix.with_name(prefix.name+'_verified.json').write_text(json.dumps(v,indent=2)+'\n');print(r);print(v)
