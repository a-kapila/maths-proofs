"""Find and interval-verify opposite signs on one admissible marginal fibre.
This proves strict variational improvement by |F|, not a numerical H_m bound.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup

def ar(x):
 x=F(x);return arb(x.numerator)/x.denominator

def run(path,outfile):
 tr=json.load(open(path));k=tr['k'];T=tr['beta']/math.log(k);eps=tr['delta']*tr['eps_cells'];rho=.25+tr['omega'];u0=tr['ufrac']*tr['smooth_delta']/rho;kap=(.25+tr['smooth_delta']/2)/rho-1e-4
 edges=np.array(tr['E'])*tr['delta'];H=np.array(tr['profiles']);basis=tr['basis'];maxp=max(max(a) if a else 0 for a in basis)
 def evalf(rb,b,a,t):
  n=k-1-rb;s=rb*b+n*a+t
  if s>=1+eps or s<=edges[1]:return None
  if max(b,t)>=T:return None
  vals=[(b,rb),(t,1),(a,n)]
  if any(1.5*v+sum(y*c for y,c in vals if y>=v)>=kap for v,c in vals if c and v>u0):return None
  j=int(np.searchsorted(edges,s,side='right')-1)
  z={p:rb*(b/T)**p+n*(a/T)**p+(t/T)**p for p in range(2,maxp+1)}
  pp=sum(H[ii,j]*math.prod(z[p] for p in mon) for ii,mon in enumerate(basis))
  return pp,j,s
 found=None
 for rb in [2,3,1,4,0]:
  for bi in range(12,28):
   b=F(bi,100)
   for ai in range(1,20):
    a=F(ai,2**(17 if k<10000 else 23));n=k-1-rb
    if float(a)>=u0 or float(rb*b+n*a)>=1-eps:continue
    pos=neg=None
    for ti in list(range(1,32)):
     t=F(ti,100);r=evalf(rb,float(b),float(a),float(t))
     if r is None:continue
     if r[0]>1e-4:pos=(t,r)
     if r[0]<-1e-4:neg=(t,r)
     if pos and neg:found=(rb,b,a,pos,neg);break
    if found:break
   if found:break
  if found:break
 if not found:print('no sign pair');return
 ctx.prec=256;S=setup(k,tr['theta'],tr['beta'],tr['relative_shift']);tb=S['T'];rhov=arb(1)/4+arb(tr['omega']);u0v=arb(tr['ufrac'])*arb(tr['smooth_delta'])/rhov;kv=(arb(1)/4+arb(tr['smooth_delta'])/2)/rhov-arb('0.0001')
 rb,b,a,pos,neg=found;n=k-1-rb;sprime=rb*b+n*a
 assert ar(sprime)<1-ar(F(tr['delta'])*tr['eps_cells'])
 assert ar(a)<u0v
 records=[]
 for sign,(t,rr) in [(1,pos),(-1,neg)]:
  ss=sprime+t;j=rr[1];assert F(tr['E'][j])*F(tr['delta'])<ss<F(tr['E'][j+1])*F(tr['delta'])
  vals=[(b,rb),(t,1),(a,n)]
  for v,c in vals:
   if not c:continue
   assert ar(v)>0 and ar(v)<tb
   if ar(v)>u0v:assert ar(F(3,2)*v+sum(y*cnt for y,cnt in vals if y>=v))<kv
  z={p:rb*(ar(b)/tb)**p+n*(ar(a)/tb)**p+(ar(t)/tb)**p for p in range(2,maxp+1)}
  pp=arb(0)
  for ii,mon in enumerate(basis):
   term=arb(tr['profiles'][ii][j])
   for p in mon:term*=z[p]
   pp+=term
  assert (pp>0) if sign==1 else (pp<0)
  records.append(dict(sign=sign,t=[t.numerator,t.denominator],cell=j,total_sum=[ss.numerator,ss.denominator],polynomial_lower=float(np.nextafter(float(pp.lower()),-np.inf)),polynomial_upper=float(np.nextafter(float(pp.upper()),np.inf))))
 out=dict(k=k,m=tr['m'],trial=path,remaining_large_coordinates=rb,large_value=[b.numerator,b.denominator],remaining_small_coordinates=n,small_value=[a.numerator,a.denominator],marginal_sum=[sprime.numerator,sprime.denominator],points=records,precision_bits=ctx.prec,meaning='Strict gain in quotient by absolute value; no quantified new prime-gap bound')
 Path(outfile).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
if __name__=='__main__':run(*sys.argv[1:])
