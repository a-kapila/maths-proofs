# H2/H3 continuation, 4 November 2026

## Result and scope

The completed computations give DHL[2304,3] and DHL[110050,4] within the inherited sieve framework. Independently checked tuples give H2 <= 19,908 and H3 <= 1,359,440. H4 and H5 are not improved here. These are computer-assisted research deductions, not independently reviewed published records.

The full inherited bundle is retained. The current work is in `focus23/`; no previous download is required. The original root README and earlier reproduction scripts concern earlier continuations. This continuation does not independently reprove or audit the external distribution theorem, enlarged-support implication, or all inherited Fourier and restriction arguments.

## Reproduce

From the archive root:

```
bash focus23/reproduce.sh --checks-only
bash focus23/reproduce.sh --full
```

Python 3, NumPy, SciPy, mpmath, and a C++17/OpenMP compiler are required. Leave assertions enabled. The inherited compatibility module named `flint.py` uses **mpmath.iv, not FLINT or Arb**. Full numerical evaluation uses several GB of working memory. Work is sequential in the reproduction script to limit memory use.

The first command recomputes the scalar amplitude enclosure, tests the directed primitive table and exact algebra, rechecks strict opposite signs on allowed marginal fibres, checks exact endpoint implications, selects the full tuples and verifies every relevant prime. It uses saved Fourier quotient endpoints. The second also recomputes all three new Fourier evaluations and the final H2 support bound. Neither is an independent expert review of the complete analytic argument.

## Important numerical distinctions

`m2_k2304.interval_certificate.json` includes the optional Hilbert-space numerator bound. **The final result in RESULTS.json does not use it.** `verify_focus.py` sums the component-wise lower endpoints exactly and computes the smaller component-wise quotient, then deducts the freshly recomputed support loss in `m2_k2304.support_1.01.json`. The coarser ratio-1.03 component-only calculation fails; the selected ratio-1.01 calculation passes. The stronger Hilbert alternative is not necessary for the result.

For H3, `m3_fine.json` is the same physical trial as the preceding 110070-dimensional one, evaluated on a finer integration grid. `m3_k110050.json` preserves the same exact profiles and physical profile edges but changes k and therefore the dimension-dependent coordinate factor. Its quotient and support loss were evaluated anew; it is not an extrapolation.

The new fast primitive table replaces repeated scalar log evaluations with a directed, range-reduced 20-term positive atanh series and an explicit remainder. The multirate Fourier enclosure and polynomial marginal machinery are inherited. `fast_gtable.py` documents the new primitive calculation.

## Nonoptimality result

The two `*_sign_change.json` files provide opposite-sign interior points on the same allowed marginal fibre. The elementary identity J_i(|F|)-J_i(F)=4 int A_i B_i >= 0, with strictness here, shows that each tested signed trial is not a variational maximizer. This is **not** a quantified improvement to H_m or a proof that another integer dimension is attainable. The witnesses may lie in very low-weight regions. The argument does not provide a terminal bound for H2 or H3.

## Searches not used as proofs

`h2_milp.log`, `h3_search.log`, `h2_parameter_scout.*`, and `m2_heavy_loss.*` record exploratory or unsuccessful directions. Restricted MILP infeasibility is not a proof of globally optimal tuples. No global tuple optimum is claimed. `method_barriers.json` records loose necessary dimension barriers; these are not attainable targets and not lower bounds on H_m.

`RESULTS.json`, the fixed trial files, selected support output, all complete tuples and prime witnesses, and `MANIFEST.json` identify the actual result. Mathematical fields, rather than timing fields, are compared in repeat runs.
