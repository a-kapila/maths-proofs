"""Mass-aware pointwise amplitude bound for five-profile nonlinear trials.
Let z bound sum x_i, U=sum x_i^2, 0<=x_i<=1. For any real b,
 a=max(0,max_{0<=x<=1} x*(h2+h3*x+h4*x*x-b))
implies sum x_i^2*(h2+h3*x_i+h4*x_i*x_i) <= a*z+b*U.
Thus P <= h0+a*z+max_{0<=U<=Umax}(b*U+h22*U^2).
Apply to P and -P. Optimizer merely chooses b; retained endpoints are
interval/rational reevaluations. No probability assumption is used.
"""
from pathlib import Path
import sys,json,math,time,hashlib
from fractions import Fraction as F
import numpy as np
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup

def cubic_max_float(b,h2,h3,h4):
 vals=[0.,h2+h3+h4-b]
 if abs(h4)>1e-40:
  disc=4*h3*h3-12*h4*(h2-b)
  if disc>=0:
   for x in [(-2*h3-math.sqrt(disc))/(6*h4),(-2*h3+math.sqrt(disc))/(6*h4)]:
    if 0<x<1:vals.append(x*((h2-b)+x*(h3+x*h4)))
 elif abs(h3)>1e-40:
  x=-(h2-b)/(2*h3)
  if 0<x<1:vals.append(x*((h2-b)+x*h3))
 return max(vals)

def quad_float(b,c,U):
 vals=[0.,b*U+c*U*U]
 if c<0:
  x=-b/(2*c)
  if 0<x<U:vals.append(b*x+c*x*x)
 return max(vals)

def qmax(b,c,U):
 vals=[F(0),b*U+c*U*U]
 if c<0:
  x=-b/(2*c)
  if 0<x<U:vals.append(b*x+c*x*x)
 return max(vals)

def amax_interval(b,h2,h3,h4):
 b,h2,h3,h4=map(arb,[b,h2,h3,h4]);vals=[arb(0),(h2+h3+h4-b).upper()]
 if h4!=0:
  disc=4*h3*h3-12*h4*(h2-b)
  if disc>=0:
   sq=disc.sqrt()
   for x in [(-2*h3-sq)/(6*h4),(-2*h3+sq)/(6*h4)]:
    if x.upper()>=0 and x.lower()<=1:vals.append((x*((h2-b)+x*(h3+x*h4))).upper())
  elif not disc<0:raise ArithmeticError('ambiguous discriminant')
 elif h3!=0:
  x=-(h2-b)/(2*h3)
  if x.upper()>=0 and x.lower()<=1:vals.append((x*((h2-b)+x*h3)).upper())
 return arb(max(float(np.nextafter(float(v.upper()),np.inf)) for v in vals))

def run(path,outfile):
 ctx.prec=256;t0=time.time();tr=json.load(open(path));assert tr['basis']==[[],[2],[3],[4],[2,2]]
 S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift']);bounds=[];globalC=0.
 for j in range(len(tr['E'])-1):
  zball=arb(tr['E'][j+1])*arb(tr['delta'])/S['T'];z=float(np.nextafter(float(zball.upper()),np.inf));zf=F(z)
  q=zf.numerator//zf.denominator;U=min(F(tr['k']),q+(zf-q)**2);Uf=float(U)
  hs=[p[j] for p in tr['profiles']];records=[]
  for sign in [1,-1]:
   h0,h2,h3,h4,h22=[sign*x for x in hs]
   def f(b):return h0+z*cubic_max_float(b,h2,h3,h4)+quad_float(b,h22,Uf)
   scale=max(1.,abs(h2)+abs(h3)+abs(h4)+2*abs(h22)*Uf)
   res=minimize_scalar(f,bounds=(-4*scale,4*scale),method='bounded',options={'xatol':1e-12})
   candidates=[float(res.x),float(h2),0.,-2*h22*Uf]
   best=None
   for b in candidates:
    aa=amax_interval(b,h2,h3,h4)
    v=arb(h0)+arb(z)*aa+arb(qmax(F(b),F(h22),U).numerator)/qmax(F(b),F(h22),U).denominator
    upper=float(np.nextafter(float(v.upper()),np.inf))
    if best is None or upper<best['upper']:best=dict(sign=sign,b=b,a_upper=float(np.nextafter(float(aa.upper()),np.inf)),upper=upper)
   records.append(best)
  upper=max(r['upper'] for r in records);globalC=max(globalC,upper)
  bounds.append(dict(cell=j,z_upper=z,Umax=[U.numerator,U.denominator],signs=records,absolute_upper=upper))
 out=dict(trial=path,trial_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),k=tr['k'],amplitude_upper=globalC,cells=bounds,seconds=time.time()-t0,precision_bits=ctx.prec)
 Path(outfile).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({a:b for a,b in out.items() if a!='cells'}),flush=True)
if __name__=='__main__':run(*sys.argv[1:])
