"""Exploratory only: fast floating-point tagged-loss parameter scan."""
import sys,json,math,time
from pathlib import Path
import numpy as np
from scipy.special import exp1,betainc
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from loss_shifted import mgf_trunc_f

def scout(tr,sm,C,den,ratio=1.01):
 k=tr['k'];c=tr['theta']/math.log(k);T=tr['beta']/math.log(k);b=k-1;A=tr['relative_shift']/(c+b*T)
 m2=(1/c-1/(c+b*T))/b+2*A/b*math.log((c+b*T)/c)+A*A*T
 F=lambda w:((1/c-1/(c+b*w))/b+2*A/b*math.log((c+b*w)/c)+A*A*w)/m2
 G=lambda w:math.log1p(b*w/c)/b+A*w
 omega=(3-80*sm)/240-1e-9;rho=.25+omega;kap=(.25+sm/2)/rho-1e-8;u0=tr['ufrac']*sm/rho
 ep=tr['delta']*tr['eps_cells'];Acap=1-ep;Bcap=1+ep;n=k-1;GT=G(T);eta=1e-8
 lams=np.exp(np.linspace(math.log(1e-3),math.log(1e7),900))
 def joint(n,r,bnd,w):
  if r>n or bnd<=0:return 0.
  p=max(0.,1-F(w))
  d=mgf_trunc_f(lams,c,b,w,A)/m2;mass=p+d;pp=p/mass
  with np.errstate(all='ignore'):
   tail=betainc(r,n-r+1,pp) if r>0 else np.ones(len(pp))
   logval=lams*bnd+n*np.log(mass)+np.log(tail)
  logval=np.where((d>0)&(tail>0)&np.isfinite(logval),logval,np.inf)
  old=betainc(r,n-r+1,p) if r>0 else 1.
  return min(old,math.exp(min(0.,float(logval.min()))))
 sums=np.zeros(3);w=u0;cells=0
 while w<T:
  v=min(T,w*ratio);H=kap-2.5*v;r=math.floor(H/T)+1;H2=H-T;r2=math.floor(H2/T)+1
  bt=min(Acap-H,Bcap-kap+1.5*v,Acap-r*w,Bcap-(r+1)*w)+eta
  ba=min(Acap-kap+1.5*v,Acap-(r+1)*w)+eta
  bb=min(Acap-w-H2,Bcap-kap+1.5*v,Acap-(r2+1)*w,Bcap-(r2+2)*w)+eta
  sums[0]+=(G(v)-G(w))*joint(n,r,bt,w)
  sums[1]+=n*(F(v)-F(w))*G(v)*joint(n-1,r,ba,w)
  sums[2]+=n*(F(v)-F(w))*(GT-G(w))*joint(n-1,r2,bb,w)
  w=v;cells+=1
 loss=2*k*GT*sum(sums)/(m2*(den/C**2))
 return dict(k=k,delta=sm,omega=omega,target=tr['m']/rho,loss=loss,total_requirement=tr['m']/rho+loss,cells=cells,ratio=ratio)
if __name__=='__main__':
 t=time.time();tr=json.load(open(B/'focus23/m2_k2304.json'));am=json.load(open(B/'focus23/m2_k2304_amplitude.json'));den=json.load(open(B/'trials/m2_final.interval_certificate.json'))['den_lower'];rows=[]
 for sm in [1e-5,1.5e-5,2e-5,2.5e-5,3e-5,3.5e-5,4e-5,4.5e-5,5e-5]:
  r=scout(tr,sm,am['amplitude_upper'],den);rows.append(r);print(json.dumps(r),flush=True)
 json.dump(dict(rows=rows,seconds=time.time()-t,exploratory=True),open(B/'focus23/h2_parameter_scout.json','w'),indent=2)
