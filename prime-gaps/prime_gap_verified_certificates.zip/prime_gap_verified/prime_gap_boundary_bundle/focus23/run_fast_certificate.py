from pathlib import Path
import sys,json,hashlib
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'focus23'),str(B/'accurate'),str(B/'analysis'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from fast_gtable import gtable
import certify_multi
certify_multi.gtable=gtable
from interpolated_cdf import InterpolatedCDF
import certify_centered as C
from certify_polynomial import amplitude
C.PolynomialCDF=InterpolatedCDF
tr=json.load(open(sys.argv[1]))
if any(tuple(m) not in [(),(2,),(3,),(4,),(2,2)] for m in tr['basis']):
 def generic(hs,basis,E,spacing,S):
  v=amplitude(hs,basis,E,spacing,S);return v,v
 C.profile_amplitude=generic
if tr['m']==2:
 from loss_tagged import restriction_loss
 C.restriction_loss=restriction_loss
 amplitude_data=json.load(open(B/'focus23'/f"m2_k{tr['k']}_amplitude.json"))
 assert amplitude_data.get('trial_sha256')==hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest()
 upper=amplitude_data['amplitude_upper']
 def mass_bound(hs,basis,E,spacing,S):
  return upper,amplitude(hs,basis,E,spacing,S)
 C.profile_amplitude=mass_bound
out=C.run(sys.argv[1])
out['new_enclosures']['amplitude']='mass-aware interval/rational dual envelope' if tr['m']==2 else 'inherited absolute polynomial envelope'
out['new_enclosures']['primitive']='20-term range-reduced atanh series; explicit remainder; every binary64 operation directed outward'
out['new_enclosures']['cdf']='inherited multirate Fourier enclosure'
Path(sys.argv[1]).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
