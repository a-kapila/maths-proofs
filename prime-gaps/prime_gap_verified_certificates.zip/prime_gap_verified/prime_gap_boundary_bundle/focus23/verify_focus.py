"""Recheck exact endpoint implications and all final integer tuples.
This does not independently reprove the inherited analytic distribution theorem,
Fourier remainder bounds, or the computation of the saved component endpoints.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup
ctx.prec=256

def exact_input_checks(p):
 t=json.loads(p.read_text());r=F(1,4)+F(t['omega']);eps=F(t['delta'])*t['eps_cells']
 assert t['k']>1 and t['smooth_delta']>0 and t['omega']>0
 assert 240*F(t['omega'])+80*F(t['smooth_delta'])<3
 assert 2*r*(1+eps)<1 and F(0)<F(t['ufrac'])<1
 source=B/t['source_fixed_trial'];assert hashlib.sha256(source.read_bytes()).hexdigest()==t['source_sha256']
 old=json.loads(source.read_text());assert t['profiles']==old['profiles'] and t['basis']==old['basis']
 assert [F(e)*F(t['delta']) for e in t['E']]==[F(e)*F(old['delta']) for e in old['E']]
 assert eps==F(old['delta'])*old['eps_cells']
 return t,r

def check_certificate(name,support=None):
 p=B/'focus23'/f'{name}.json';t,r=exact_input_checks(p);c=json.loads(p.with_suffix('.interval_certificate.json').read_text())
 assert c['k']==t['k'] and c['m']==t['m']
 S=setup(t['k'],t['theta'],t['beta'],t['relative_shift'])
 # Always use the inherited component-wise lower numerator; exclude the optional
 # Hilbert-space improvement even when it is larger.
 num=sum((F(x) for x in c['num_components_lower']),F(0));assert num>0
 qiv=arb(t['k'])*(arb(num.numerator)/num.denominator)/S['m2']/arb(c['den_upper'])
 qminus=min(float(np.nextafter(float(qiv.lower()),-np.inf)),c['Q_lower']);assert qminus>0
 loss=json.loads((B/support).read_text()) if support else c['restriction'];assert loss['k']==t['k']
 q=F(qminus)-F(loss['loss_upper']);target=F(t['m'])/r
 assert F(c['target_upper'])>=target
 nchecks=len(c['direct_fourier_checks']);assert nchecks==6*len(c['moment_keys'])
 for v in c['direct_fourier_checks']:
  # Diagnostic finite-series comparisons use their displayed high-precision
  # reference values; the analytic remainder bounds are a separate dependency.
  assert abs(F(v['direct'])-F(v['raw_fft']))<=F(v['raw_error'])
 minimum=int(F(t['k'])*target/q)+1
 K=min(minimum,t['k']);margin=F(K,t['k'])*q-target
 return dict(m=t['m'],trial_k=t['k'],final_k=K,passed=margin>0,component_quotient_lower=qminus,restriction_loss_upper=loss['loss_upper'],target_upper=c['target_upper'],margin_lower=float(np.nextafter(float(margin),-np.inf)),margin_fraction=[str(margin.numerator),str(margin.denominator)],one_more_deletion_fails=(F(K-1,t['k'])*q<=target),trial=str(p.relative_to(B)),certificate=str(p.with_suffix('.interval_certificate.json').relative_to(B)),support=support or 'restriction field in certificate',direct_checks=nchecks,selected_numerator='component-wise; Hilbert alternative excluded')

h2=check_certificate('m2_k2304','focus23/m2_k2304.support_1.01.json');assert h2['passed']
control=check_certificate('m3_fine');assert control['passed']
h3=check_certificate('m3_k110050')
if not h3['passed']:h3=control
rows=[h2,h3]
for row in rows:
 m,K=row['m'],row['final_k']
 subprocess.run([sys.executable,str(B/'focus23/select_verify.py'),str(m),str(K)],cwd=B,check=True)
 pref=B/'focus23'/f'h{m}_k{K}'
 row['tuple']=json.loads(pref.with_name(pref.name+'_verified.json').read_text())
 row['selection']=json.loads(pref.with_name(pref.name+'_selection.json').read_text())
 row['H_bound']=row['tuple']['diameter']
 row['previous_H_bound']={2:19920,3:1359754}[m]
 row['saving']=row['previous_H_bound']-row['H_bound'];assert row['saving']>0
checks={'scope':'Research deductions in the inherited analytic framework; no independent expert review claimed.','results':rows,'H3_same_trial_finer_evaluation':control,'unchanged_H4':82258490,'unchanged_H5':4831230984,'precision_bits':256}
(B/'focus23/RESULTS.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
