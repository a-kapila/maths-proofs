from pathlib import Path
import sys,json,time
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis'),str(B/'analysis')]
from flint import ctx
from loss_tagged import restriction_loss
ctx.prec=256
p=Path(sys.argv[1]);d=json.loads(p.read_text());c=json.loads(p.with_suffix('.interval_certificate.json').read_text());ratio=float(sys.argv[2]);t=time.time();eps=d['delta']*d['eps_cells']
r=restriction_loss(d['k'],d['theta'],d['beta'],d['smooth_delta'],d['omega'],c['scaled_den_lower'],eta=1e-8,ufrac=d['ufrac'],ratio=ratio,sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=1-eps)
r.update(seconds=time.time()-t,trial=str(p),denominator_source=str(p.with_suffix('.interval_certificate.json')))
p.with_name(p.stem+f'.support_{ratio}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
