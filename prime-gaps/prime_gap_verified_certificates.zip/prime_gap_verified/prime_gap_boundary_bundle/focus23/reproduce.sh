#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
 echo 'usage: bash focus23/reproduce.sh --checks-only|--full' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
"$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o focus23/verify_tuple
python focus23/fast_gtable.py
python focus23/moment_amplitude.py focus23/m2_k2304.json focus23/m2_k2304_amplitude_recheck.json
python - <<'PY'
import json
x=json.load(open('focus23/m2_k2304_amplitude.json'));y=json.load(open('focus23/m2_k2304_amplitude_recheck.json'))
# The fixed saved certificate remains the input to the quotient evaluator.
# Each independently repeated envelope must be at least as strong as its saved upper endpoint.
assert y['trial_sha256']==x['trial_sha256'] and y['amplitude_upper']<=x['amplitude_upper']
print('Mass-aware amplitude enclosure rechecked.')
PY
python focus23/check_amplitude.py focus23/m2_k2304.json focus23/m2_k2304_amplitude.json
python focus23/sign_change.py focus23/m2_k2304.json focus23/m2_k2304_sign_change.json
python focus23/sign_change.py focus23/m3_k110050.json focus23/m3_k110050_sign_change.json
if [[ "$mode" == --full ]]; then
 python focus23/run_fast_certificate.py focus23/m2_k2304.json | tee focus23/m2_k2304.log
 python focus23/recompute_support.py focus23/m2_k2304.json 1.01 | tee focus23/m2_k2304_support_1.01.log
 python focus23/run_fast_certificate.py focus23/m3_fine.json | tee focus23/m3_fine.log
 python focus23/run_fast_certificate.py focus23/m3_k110050.json | tee focus23/m3_k110050.log
fi
python focus23/verify_focus.py
