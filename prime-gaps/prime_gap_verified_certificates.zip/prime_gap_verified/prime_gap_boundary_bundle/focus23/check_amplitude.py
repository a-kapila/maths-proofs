"""Exact-rational diagnostics for the mass-aware amplitude certificate.
The analytic inequality in moment_amplitude.py is the proof; these tests check
its implementation against explicit coordinate vectors and saved cell data.
"""
from pathlib import Path
from fractions import Fraction as F
import json,random,sys
B=Path(__file__).resolve().parents[1]
def run(trial,certificate):
 t=json.load(open(trial));c=json.load(open(certificate));rng=random.Random(45207)
 assert c['k']==t['k'];C=F(c['amplitude_upper']);cnt=0;dual=0
 for zc in c['cells']:
  j=zc['cell']; z=F(zc['z_upper']); Ucap=F(*zc['Umax'])
  # The rational maximizer Ucap is valid even when sum x is strictly below z.
  for signrecord in zc['signs']:
   sig=signrecord['sign']; b=F(signrecord['b']); a=F(signrecord['a_upper'])
   h=[sig*F(p[j]) for p in t['profiles']]
   for r in [F(0),F(1),F(rng.randrange(1,10000),10000)]:
    assert r*((h[1]-b)+r*(h[2]+r*h[3]))<=a
    dual+=1
  for _ in range(4):
   n=rng.randrange(1,12);xs=[F(rng.randrange(0,10001),10000) for i in range(n)];s=sum(xs)
   if s>z:xs=[x*z/s for x in xs]
   U=sum(x*x for x in xs); assert U<=Ucap
   vals=[F(1),U,sum(x**3 for x in xs),sum(x**4 for x in xs),U*U]
   P=sum(F(t['profiles'][i][j])*v for i,v in enumerate(vals))
   assert abs(P)<=C
   # Check both signed dual inequalities directly with exact rationals.
   for rec in zc['signs']:
    sig=rec['sign'];b=F(rec['b']);a=F(rec['a_upper']);h=[sig*F(p[j]) for p in t['profiles']]
    assert sig*P<=h[0]+a*z+b*U+h[4]*U*U
   cnt+=1
 out=dict(trial=trial,certificate=certificate,exact_vector_tests=cnt,exact_single_coordinate_dual_tests=dual,passed=True)
 (B/'focus23/amplitude_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
if __name__=='__main__':run(*sys.argv[1:])
