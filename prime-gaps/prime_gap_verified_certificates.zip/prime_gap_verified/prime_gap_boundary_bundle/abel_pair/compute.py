"""Boundary-correlated (Abel) post-processing of saved weighted CDF enclosures.
No Fourier transform or arithmetic support calculation is re-evaluated.
Each polynomial cell majorant is the previous Hermite majorant. Only the
integration of its exact signed coefficients against the SAME CDF is changed.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,hashlib,time
import numpy as np
B=Path(__file__).resolve().parents[1];O=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'next_pair'))
import hermite_pair as hp
I=hp.I;J=hp.J;rad=hp.rad;base=hp.base

def frac(v):
    if isinstance(v,dict): return F(int(v['numerator']),int(v['denominator']))
    return F(v)

def load_cdfs(m):
    cdfs={}
    for tag in [1,2,3,4,22]:
        folder=B/('continued' if tag==2 else 'next_pair')
        stem=folder/f'm{m}_power{tag}'
        meta=json.load(open(stem.with_suffix('.json')));tp=B/meta['trial'];tr=json.load(open(tp))
        assert hashlib.sha256(tp.read_bytes()).hexdigest()==meta['trial_sha256']
        data=np.load(str(stem)+'_cdf.npz')
        keys=[tuple(a) for a in meta['moment_keys']]
        edges=[F(tr['delta'])*i for i in tr['E']]
        assert all(F(float(y))==e for y,e in zip(data['y'],edges))
        cdfs[tag]=(keys, [[F(float(x)) for x in row] for row in data['L']], [[F(float(x)) for x in row] for row in data['V']])
        if tag==1: trial=tr; all_edges=edges
        else: assert edges==all_edges and tr['basis']==trial['basis'] and tr['profiles']==trial['profiles']
    coeff=defaultdict(lambda:[F(0)]*(len(all_edges)-1))
    for hi,bi in zip(trial['profiles'],trial['basis']):
        for hj,bj in zip(trial['profiles'],trial['basis']):
            key=tuple(sorted(bi+bj))
            for i,(a,b) in enumerate(zip(hi,hj)): coeff[key][i]+=F(a)*F(b)
    for keys,ls,us in cdfs.values(): assert set(keys)==set(coeff)
    return cdfs,coeff,all_edges

def abel_lower(c, lo, hi):
    """Lower enclosure of sum c[j]*(CDF[j+1]-CDF[j]); all inputs exact."""
    assert len(c)+1==len(lo)==len(hi)
    assert all(l<=u for l,u in zip(lo,hi))
    acc=I(0)
    # Endpoint coefficients after exact summation by parts.
    t=-c[0]
    acc+=I(t*(lo[0] if t>=0 else hi[0]))
    for j in range(1,len(lo)-1):
        t=c[j-1]-c[j]
        acc+=I(t*(lo[j] if t>=0 else hi[j]))
    t=c[-1];acc+=I(t*(lo[-1] if t>=0 else hi[-1]))
    return acc.lo

def difference_lower(c,lo,hi):
    acc=I(0)
    for j,t in enumerate(c):
        lower=max(F(0),lo[j+1]-hi[j]); upper=hi[j+1]-lo[j]
        acc+=I(t*(lower if t>=0 else upper))
    return acc.lo

def coefficient_rows(v,eta,zeta):
    """Exact cellwise coefficient lower bound for radial improvement + Hermite correction.
    Smooth factors are bounded while the full squared polynomial is still intact.
    It is then expanded and integrated as a signed linear combination of CDFs.
    """
    k=v['k'];sig=v['sigma'];R1=(eta/(1-zeta))**2
    cs={tag:[] for tag in [1,2,3,4,22]}; used=0
    for j,(left,right) in enumerate(zip(v['edges'][:-1],v['edges'][1:])):
        l=left/sig;r=right/sig
        assert 0<=l<r<=1
        # R1^2-R(x)^2 >= phi(r)*x; phi is decreasing.
        radial=(R1-((1+(eta-1)*r)/(1-zeta*r))**2)/r
        # The preceding exact moment coefficients, without prematurely
        # integrating each cell independently.
        a0=F(2,k)*((1-r)**2+eta*F(k,k-1)*(1-r)*l)
        a2=(2*eta*(k-2)*(1-l)+eta**2*(2*k-1)*l)/(k-1)
        a3=eta**2*k/(k-1)
        b0=2*(1-l)**2*r/(k*(k-1))
        b2=2*(1-l)**2*(k-2)/(k*(k-1))+6*(1-l)*eta*r/(k-1)
        b3=(2*eta*(k-4)*(1-r)+2*eta**2*k*r)/(k-1)
        b22=eta**2*(2*k-1)/(k-1)
        b4=3*eta**2*k/(k-1)
        t1=hp.m1_lower(k,eta,l,r,v['lo1'][j],v['lows'][j],v['hi3'][j])
        t2=hp.m2_upper(k,eta,l,r,v['hi1'][j],v['highs'][j],v['hi3'][j],v['hi22'][j],v['lo4'][j])
        alpha=I(zeta*t1/(1-zeta*l)**3).lo
        gamma=I(zeta*zeta*t2/(1-zeta*r)**4).hi
        if alpha>0:
            theta=gamma/alpha
            # A_low*T1 - B_high*T2 is a lower bound since T1,T2>=0.
            A=I(2*(1+3*theta+theta**2)/(1+theta)**3).lo
            BB=I((3+theta)/(1+theta)**3).hi
            aa=I(A*zeta/(1-zeta*l)**3).lo
            bb=I(BB*zeta*zeta/(1-zeta*r)**4).hi
            used+=1
        else: aa=bb=F(0)
        cs[1].append(radial+aa*a0-bb*b0)
        cs[2].append(aa*a2-bb*b2)
        cs[3].append(-aa*a3-bb*b3)
        cs[22].append(-bb*b22)
        cs[4].append(bb*b4)
    return cs,used

def estimate(v,raw,eta,zeta):
    cdfs,polynomial,edges=raw
    cs,used=coefficient_rows(v,eta,zeta)
    abel=I(0); naive=I(0);by_tag={}
    for tag in [1,2,3,4,22]:
        keys,lower,upper=cdfs[tag];at=I(0);nt=I(0)
        for key,lo,hi in zip(keys,lower,upper):
            c=[t*h for t,h in zip(cs[tag],polynomial[key])]
            a=abel_lower(c,lo,hi);n=difference_lower(c,lo,hi)
            # Both enclosures are valid; preserving the better one prevents
            # losing the positivity improvement at tiny CDF increments.
            at+=I(max(a,n));nt+=I(n)
        abel+=at;naive+=nt
        by_tag[str(tag)]={'lower':at.lo,'independent_difference_lower':nt.lo}
    den=F(*v['src']['den_upper']);bad=F(*v['src']['removed_square_mass_upper'])
    R1=(eta/(1-zeta))**2
    removal=(R1+4*zeta*v['U']*eta**2/(1-zeta)**3)*bad
    # Each pointwise cell expression is <= radial improvement + actual
    # Hermite correction, whose positive part has this same removed-mass cap.
    assert abel.lo-removal>0
    M=R1-(abel.lo-removal)/den
    jj=J(v['k'],v['k']*eta)
    pair=2*zeta*zeta*jj.hi*M
    return dict(pair_upper=pair,moment_upper=M,total_improvement_lower=abel.lo,
        independent_difference_lower=naive.lo,removed_improvement_upper=removal,
        den_upper=den,J_lower=jj.lo,J_upper=jj.hi,nonzero_hermite_cells=used,by_tag=by_tag)

def compute(m,select=True):
    started=time.time();v=hp.inputs(m);raw=load_cdfs(m)
    old=json.load(open(B/f'next_pair/hermite_m{m}_result.json'))
    eta=frac(old['eta']);rho=v['rho'];sig=v['sigma'];z=2*rho*sig
    calc=estimate(v,raw,eta,z);pair=calc['pair_upper'];sur=rho*v['q']-m
    ratio=sur/pair;budget=(ratio.numerator-1)//ratio.denominator
    lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);zs=lam*sig/b
    strict=estimate(v,raw,eta,zs)
    out=dict(m=m,k=v['k'],eta=eta,rho=rho,sigma=sig,q_lower=v['q'],surplus=sur,
      pair_upper=pair,budget=budget,ratio=ratio,old_pair_upper=frac(old['pair_upper']),
      calculation=calc,strict_calculation=strict,previous_bound={2:19844,3:1358006}[m])
    if select:
        w=base.load_witness(v['witness']);arr=base.allowed(w,-v['extent'],v['extent']);sub,sel=base.choose(arr,v['k'],budget)
        for p in base.primes_up_to(v['k']):
            if int(p) not in w:
                missing=np.flatnonzero(np.bincount(sub%p,minlength=int(p))==0);assert len(missing);w[int(p)]=int(missing[0])
        cnt=sel['long_pairs'];margin=sur-cnt*pair;sm=lam*v['q']-m-cnt*strict['pair_upper']
        assert margin>0 and sm>0
        np.savetxt(O/f'm{m}_tuple.txt',sub,fmt='%d')
        np.savetxt(O/f'm{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
        pairs=base.enumerate_long_pairs(sub,sel['D']);assert len(pairs)==cnt
        np.savetxt(O/f'm{m}_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
        out.update(selection=sel,first=int(sub[0]),last=int(sub[-1]),margin=margin,strict_margin=sm,tuple_diameter=int(sub[-1]-sub[0]))
    (O/f'm{m}_result.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
    print(json.dumps(dict(m=m,seconds=time.time()-started,old_pair=float(out['old_pair_upper']),pair=float(pair),ratio=float(ratio),budget=budget,selection=out.get('selection'),margin=float(out.get('margin',0)))),flush=True)
    return out

if __name__=='__main__':
    for arg in sys.argv[1:]:compute(int(arg))
