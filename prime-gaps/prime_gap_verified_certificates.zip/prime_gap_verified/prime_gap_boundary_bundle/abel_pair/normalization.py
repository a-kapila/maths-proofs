"""Use total squared norm jointly with radial cell first moments.
For convex g and 0<l<=x<=r, g(x)<=a+b*x where
b=max((g(l)-a)/l,(g(r)-a)/r), for ANY real a.
Choosing a is heuristic; acceptance is exact rational post-processing.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time
import numpy as np
from scipy.optimize import minimize_scalar
sys.path.insert(0,str(Path(__file__).resolve().parent))
import compute as ab
hp=ab.hp;I=ab.I;J=ab.J;rad=ab.rad;base=ab.base;B=ab.B;O=ab.O

def coeff_rows(v,eta,zeta,intercept):
    cs,used=ab.coefficient_rows(v,eta,zeta)
    sig=v['sigma'];R1=(eta/(1-zeta))**2
    for j,(left,right) in enumerate(zip(v['edges'][:-1],v['edges'][1:])):
        l=left/sig;r=right/sig
        g=lambda x:((1+(eta-1)*x)/(1-zeta*x))**2
        old=(R1-g(r))/r
        if l==0:
            assert all(F(profile[j])==0 for profile in v['tr']['profiles'])
            # All coefficients of P^2 vanish on this cell.
            slope=F(0)
        else:slope=max((g(l)-intercept)/l,(g(r)-intercept)/r)
        cs[1][j]+= -slope-old
    return cs,used

def norm_endpoints(v):
    trial=json.load(open(B/v['quotient_source'].replace('.interval_certificate.json','.json')))
    old=v['tr']
    for key in ['k','theta','beta','relative_shift','profiles','basis']:
        assert trial[key]==old[key],key
    assert [F(trial['delta'])*e for e in trial['E']]==[F(old['delta'])*e for e in old['E']]
    assert F(trial['delta'])*trial['eps_cells']==F(old['delta'])*old['eps_cells']
    cert=json.load(open(B/v['quotient_source']))
    return F(cert['den_lower']), min(F(cert['den_upper']), F(*v['src']['den_upper']))

def choose_intercept(v,eta,zeta):
    sig=v['sigma'];l=np.array(list(map(float,[x/sig for x in v['edges'][:-1]])));r=np.array(list(map(float,[x/sig for x in v['edges'][1:]])))
    active=l>0;l=l[active];r=r[active]
    lo=np.array(list(map(float,v['lo1'])))[active];hi=np.array(list(map(float,v['hi1'])))[active]
    dlow,dup=norm_endpoints(v);den=float((dlow+dup)/2);e=float(eta);z=float(zeta)
    gl=((1+(e-1)*l)/(1-z*l))**2;gr=((1+(e-1)*r)/(1-z*r))**2
    def objective(a):
        c=np.maximum((gl-a)/l,(gr-a)/r)
        return a+np.sum(c*np.where(c>=0,hi,lo))/den
    res=minimize_scalar(objective,bounds=(-30,10),method='bounded',options={'xatol':1e-9})
    return F(round(float(res.x)*10**8),10**8), float(res.fun)

def estimate(v,raw,eta,zeta,intercept):
    cs,used=coeff_rows(v,eta,zeta,intercept)
    cdfs,polynomial,edges=raw;total=I(0);naive=I(0);by_tag={}
    for tag in [1,2,3,4,22]:
        at=I(0);nt=I(0);keys,lower,upper=cdfs[tag]
        for key,lo,hi in zip(keys,lower,upper):
            c=[t*h for t,h in zip(cs[tag],polynomial[key])]
            aa=ab.abel_lower(c,lo,hi);nn=ab.difference_lower(c,lo,hi)
            at+=I(max(aa,nn));nt+=I(nn)
        total+=at;naive+=nt;by_tag[str(tag)]={'lower':at.lo,'independent_difference_lower':nt.lo}
    bad=F(*v['src']['removed_square_mass_upper'])
    removal=(max(F(0),intercept-1)+4*zeta*v['U']*eta**2/(1-zeta)**3)*bad
    num=total.lo-removal
    dlow,dup=norm_endpoints(v)
    assert dlow>bad
    # E restricted improvement >= num/den. Use upper norm when num>=0,
    # lower norm when num<0. This sign is essential.
    denom=dup if num>=0 else dlow-bad
    M=intercept-num/denom
    jj=J(v['k'],v['k']*eta);pair=2*zeta*zeta*jj.hi*M
    assert M>0 and pair>0
    return dict(pair_upper=pair,moment_upper=M,intercept=intercept,total_improvement_lower=total.lo,
        independent_difference_lower=naive.lo,removed_improvement_upper=removal,
        unrestricted_den_lower=dlow,unrestricted_den_upper=dup,denominator_used=denom,
        numerator_after_removal=num,J_lower=jj.lo,J_upper=jj.hi,nonzero_hermite_cells=used,by_tag=by_tag)

def compute(m,select=True,eta=None,intercept=None):
    start=time.time();v=hp.inputs(m);raw=ab.load_cdfs(m)
    old=json.load(open(B/f'next_pair/hermite_m{m}_result.json'))
    if eta is None:eta=ab.frac(old['eta'])
    rho=v['rho'];sig=v['sigma'];z=2*rho*sig
    if intercept is None:intercept,_=choose_intercept(v,eta,z)
    calc=estimate(v,raw,eta,z,intercept);pair=calc['pair_upper'];sur=rho*v['q']-m
    ratio=sur/pair;budget=(ratio.numerator-1)//ratio.denominator
    lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);zs=lam*sig/b
    strict=estimate(v,raw,eta,zs,intercept)
    out=dict(m=m,k=v['k'],eta=eta,intercept=intercept,rho=rho,sigma=sig,q_lower=v['q'],surplus=sur,
        pair_upper=pair,budget=budget,ratio=ratio,old_pair_upper=ab.frac(old['pair_upper']),
        calculation=calc,strict_calculation=strict,previous_bound={2:19844,3:1358006}[m])
    if select:
        w=base.load_witness(v['witness']);arr=base.allowed(w,-v['extent'],v['extent']);sub,sel=base.choose(arr,v['k'],budget)
        for p in base.primes_up_to(v['k']):
            if int(p) not in w:
                missing=np.flatnonzero(np.bincount(sub%p,minlength=int(p))==0);assert len(missing);w[int(p)]=int(missing[0])
        cnt=sel['long_pairs'];margin=sur-cnt*pair;sm=lam*v['q']-m-cnt*strict['pair_upper']
        assert margin>0 and sm>0
        np.savetxt(O/f'norm_m{m}_tuple.txt',sub,fmt='%d')
        np.savetxt(O/f'norm_m{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
        pairs=base.enumerate_long_pairs(sub,sel['D']);assert len(pairs)==cnt
        np.savetxt(O/f'norm_m{m}_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
        out.update(selection=sel,first=int(sub[0]),last=int(sub[-1]),margin=margin,strict_margin=sm,tuple_diameter=int(sub[-1]-sub[0]))
    (O/f'norm_m{m}_result.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
    print(json.dumps(dict(m=m,seconds=time.time()-start,intercept=float(intercept),pair=float(pair),ratio=float(ratio),budget=budget,selection=out.get('selection'),margin=float(out.get('margin',0)))),flush=True)
    return out
if __name__=='__main__':
    for arg in sys.argv[1:]:compute(int(arg))
