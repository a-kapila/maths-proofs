"""Re-evaluate exact deductions, independently check integer tuples and pair lists."""
from pathlib import Path
import sys,subprocess,json,hashlib,math
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import normalization as n
B=n.B;O=n.O
for source,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
    subprocess.run(['g++','-O3','-std=c++17',str(B/source),'-o',str(O/name)],check=True)
rows=[]
for m in [2,3]:
    old=json.load(open(O/f'norm_m{m}_result.json'))
    result=n.compute(m,eta=n.ab.frac(old['eta']),intercept=n.ab.frac(old['intercept']))
    assert n.rad.old.encode(result)==old, 'Exact endpoint rerun differs'
    k=result['k'];D=result['selection']['D']
    ap=O/f'norm_m{m}_tuple.txt';wp=O/f'norm_m{m}_witness.csv'
    def run(args,name):
        p=subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True,cwd=B)
        (O/name).write_text(p.stdout);return json.loads(p.stdout)
    cpp=run([O/'verify_tuple',ap,wp,k],f'm{m}_cpp_verified.json')
    cpairs=run([O/'check_pairs','tuple',ap,D],f'm{m}_cpp_pairs.json')
    a=np.loadtxt(ap,dtype=np.int64);assert len(a)==k and np.all(a[1:]>a[:-1])
    witnesses=dict(map(tuple,np.loadtxt(wp,dtype=np.int64,delimiter=',',skiprows=1)))
    sieve=np.ones(k+1,dtype=bool);sieve[:2]=False
    for p in range(2,math.isqrt(k)+1):
        if sieve[p]:sieve[p*p::p]=False
    primes=np.flatnonzero(sieve)
    for p in primes:
        r=witnesses[int(p)];assert 0<=r<p and np.all(a%p!=r)
    # Independent binary-search pair enumeration (the C++ checker uses two pointers).
    pairlist=[]
    for i,ai in enumerate(a):
        j=int(np.searchsorted(a,int(ai)+D,side='right'))
        for q in range(j,k):pairlist.append((i,q,int(ai),int(a[q]),int(a[q]-ai)))
    saved=np.loadtxt(O/f'norm_m{m}_long_pairs.csv',dtype=np.int64,delimiter=',',skiprows=1).reshape(-1,5)
    assert np.array_equal(np.array(pairlist,dtype=np.int64).reshape(-1,5),saved)
    assert cpairs['long_pairs']==len(pairlist)==result['selection']['long_pairs']
    assert cpp['checked_primes']==len(primes) and cpp['verified']
    assert result['margin']>0 and result['strict_margin']>0
    row=dict(m=m,k=k,previous_bound=result['previous_bound'],new_bound=D,
      reduction=result['previous_bound']-D,first=int(a[0]),last=int(a[-1]),
      full_diameter=int(a[-1]-a[0]),pair_budget=result['budget'],long_pairs=len(pairlist),
      old_pair_upper=float(result['old_pair_upper']),pair_upper=float(result['pair_upper']),
      ratio=float(result['ratio']),surplus=float(result['surplus']),margin=float(result['margin']),
      strict_margin=float(result['strict_margin']),eta=float(result['eta']),
      intercept=float(result['intercept']),checked_primes=len(primes),
      next_span=D-2,next_minimum_pair_count=result['selection']['previous_even_min_count'],
      pair_reduction_percent=float((1-result['pair_upper']/result['old_pair_upper'])*100),
      next_needed_pair_cost_reduction_percent=100*(1-float(result['ratio'])/result['selection']['previous_even_min_count']),
      sha256=hashlib.sha256(ap.read_bytes()).hexdigest())
    (O/f'm{m}_python_verified.json').write_text(json.dumps(row,indent=2)+'\n')
    rows.append(row);print('VERIFIED',json.dumps(row),flush=True)
results={'status':'passed','bounds':{'H2':rows[0]['new_bound'],'H3':rows[1]['new_bound'],'H4':82234788,'H5':4830355416},
  'results':rows,'scope':'New exact Abel/CDF-boundary post-processing and convex-chord normalization. All Fourier/CDF, quotient, arithmetic support, and sieve inputs inherited. Both finite tuples and pair lists independently checked. No end-to-end analytic audit or new Fourier computation claimed.'}
(O/'RESULTS.json').write_text(json.dumps(results,indent=2)+'\n')
