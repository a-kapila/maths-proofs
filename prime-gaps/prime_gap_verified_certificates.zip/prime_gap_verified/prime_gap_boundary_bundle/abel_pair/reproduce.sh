#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
cd "$ROOT"
export OPENBLAS_NUM_THREADS=1
python abel_pair/check_new.py
python abel_pair/verify.py
