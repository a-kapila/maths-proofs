"""Exact finite diagnostics for the new post-processing argument.
The proofs, not these randomized finite checks, justify the general inequalities.
"""
from pathlib import Path
from fractions import Fraction as F
import random,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import compute as ab
R=random.Random(20261105)
counts={}
# Check summation-by-parts identity and both interval lower enclosures.
for it in range(1500):
    n=R.randint(2,24)
    jumps=[F(R.randrange(100),1000) for _ in range(n)]
    cdf=[F(0)]
    for d in jumps:cdf.append(cdf[-1]+d)
    c=[F(R.randrange(-200,201),100) for _ in range(n)]
    lo=[];hi=[]
    for z in cdf:
        e=F(R.randrange(50),100000)
        lo.append(max(F(0),z-e));hi.append(z+e)
    exact=sum(a*b for a,b in zip(c,jumps))
    rearranged=-c[0]*cdf[0]+c[-1]*cdf[-1]+sum((c[j-1]-c[j])*cdf[j] for j in range(1,n))
    assert exact==rearranged
    assert ab.abel_lower(c,lo,hi)<=exact
    assert ab.difference_lower(c,lo,hi)<=exact
counts['exact_signed_abel_cases']=1500
# Any line whose endpoint values dominate a convex g dominates the whole cell.
for it in range(3000):
    eta=F(R.randrange(100,180),100);zeta=F(R.randrange(20,76),100)
    l=F(R.randrange(1,99),100);r=F(R.randrange(int(100*l)+1,101),100)
    x=l+(r-l)*F(R.randrange(101),100);a=F(R.randrange(-300,100),10)
    g=lambda t:((1+(eta-1)*t)/(1-zeta*t))**2
    b=max((g(l)-a)/l,(g(r)-a)/r)
    assert g(x)<=a+b*x
counts['exact_convex_chord_cases']=3000
# Independent pair enumeration checks the moment formula and the lower cell majorant.
for it in range(1000):
    k=R.randint(5,14);ints=[R.randrange(100) for _ in range(k)];total=sum(ints) or 1
    x=F(R.randrange(1,100),100);ys=[x*F(n,total) for n in ints]
    # Handle the vanishingly unlikely all-zero draw explicitly.
    if sum(ys)==0:ys[0]=x
    assert sum(ys)==x
    l=F(max(0,int(x*100)-1),100);r=min(F(1),F(int(x*100)+1,100))
    eta=F(R.randrange(100,160),100);zeta=F(R.randrange(20,76),100);a=k*eta
    theta=F(R.randrange(1,200),100)
    W=[];sums=[]
    for i in range(k):
        for j in range(i+1,k):
            w=(1-x+a*ys[i])*(1-x+a*ys[j])+a*a*F(1,2*k)*(ys[i]-ys[j])**2
            W.append(w);sums.append(ys[i]+ys[j])
    np=k*(k-1)//2
    assert sum(W)/np==(1-x+eta*x)**2
    t1=sum(w*u for w,u in zip(W,sums))/np
    t2=sum(w*u*u for w,u in zip(W,sums))/np
    v2=sum(y**2 for y in ys);v3=sum(y**3 for y in ys);v4=sum(y**4 for y in ys)
    e1=2*(1-x)**2*x/k+2*(1-x)*eta/(k-1)*(x*x+(k-2)*v2)+eta**2/(k-1)*((2*k-1)*x*v2-k*v3)
    e2=2*(1-x)**2/(k*(k-1))*(x*x+(k-2)*v2)+2*(1-x)*eta/(k-1)*((k-4)*v3+3*x*v2)+eta**2/(k-1)*(2*k*x*v3+(2*k-1)*v2*v2-3*k*v4)
    assert t1==e1 and t2==e2
    a0=F(2,k)*((1-r)**2+eta*F(k,k-1)*(1-r)*l)
    a2=(2*eta*(k-2)*(1-l)+eta**2*(2*k-1)*l)/(k-1)
    a3=eta**2*k/(k-1)
    lower=a0*x+a2*v2-a3*v3
    b0=2*(1-l)**2*r/(k*(k-1))
    b2=2*(1-l)**2*(k-2)/(k*(k-1))+6*(1-l)*eta*r/(k-1)
    b3=(2*eta*(k-4)*(1-r)+2*eta**2*k*r)/(k-1)
    upper=b0*x+b2*v2+b3*v3+eta**2*(2*k-1)/(k-1)*v2*v2-3*eta**2*k/(k-1)*v4
    assert lower<=t1
    assert t2<=upper
    A=2*(1+3*theta+theta**2)/(1+theta)**3;BB=(3+theta)/(1+theta)**3
    actual=A*zeta*t1/(1-zeta*x)**3-BB*zeta*zeta*t2/(1-zeta*x)**4
    envelope=A*zeta*lower/(1-zeta*l)**3-BB*zeta*zeta*upper/(1-zeta*r)**4
    assert envelope<=actual
counts['exact_pair_and_cell_cases']=1000
# Correct denominator direction after removed mass, for either sign of numerator.
for it in range(1500):
    n=R.randint(2,20);w=[F(R.randrange(1,100),100) for _ in range(n)]
    h=[F(R.randrange(-200,101),20) for _ in range(n)]
    removed=[R.randrange(2)==0 for _ in range(n)]
    if all(removed):removed[-1]=False
    D=sum(w);DR=sum(wi for wi,ri in zip(w,removed) if not ri)
    bad=sum(wi for wi,ri in zip(w,removed) if ri)
    cap=max(F(0),max(h));un=sum(wi*hi for wi,hi in zip(w,h))
    N=un-cap*bad
    denom=D if N>=0 else D-bad
    actual=sum(wi*hi for wi,hi,ri in zip(w,h,removed) if not ri)/DR
    assert N/denom<=actual
counts['exact_removed_mass_normalization_cases']=1500
out={'status':'passed','diagnostics_only':True,**counts}
(Path(__file__).resolve().parent/'algebra_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
