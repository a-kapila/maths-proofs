# Boundary-aware post-processing (5 November 2026)

Current results within the inherited analytic framework:

- H2 <= 19,844 (unchanged).
- H3 <= 1,358,004 (improved by 2).
- H4 <= 82,234,788 and H5 <= 4,830,355,416 (unchanged).

The authoritative new results are `abel_pair/RESULTS.json` and
`abel_pair/norm_m{2,3}_result.json`. Historical result files elsewhere remain
unchanged for provenance.

## Reproduce the new work

From the archive root:

```sh
bash abel_pair/reproduce.sh
python abel_pair/check_manifest.py
```

Requirements: Python 3, NumPy, SciPy, mpmath, and a C++17 compiler. Assertions
must remain enabled. The new work uses saved CDF/norm/quotient enclosures, not
new Fourier computations. The current runtime's complete workflow has been
executed successfully. Search is not needed to verify the explicitly selected
tuples, but the workflow also repeats the finite window scans.

`compute.py` implements the intermediate Abel-only improvement, already enough
for H3 <= 1,358,004. `normalization.py` adds convex-chord bounds and correct
normalization of signed integrals. `verify.py` reevaluates the final inequalities
at the exact recorded parameters, rather than rerunning candidate optimization.
`check_new.py` contains finite exact diagnostics. Their role is supplementary;
the argument is in `proof_note.pdf` and `proof_note.tex`.

The same CDF value at a shared boundary is collected algebraically before its
interval is used. No stochastic independence between numerical errors is assumed.
A changed algebraic lower estimate is NOT a rerun of the inherited Fourier or
support-loss computation. The source's unweighted Selberg second-moment theorem,
the enlarged-support implication, support-removal bounds, numerical remainder
arguments, and their implementation remain dependencies. These computations do
not constitute independent expert review or a publication-priority claim.

## New outputs

`norm_m2_tuple.txt`, `norm_m3_tuple.txt`: complete ordered tuples.
`norm_m2_witness.csv`, `norm_m3_witness.csv`: one omitted residue per relevant prime.
`norm_m*_long_pairs.csv`: every long pair at the claimed cluster span.
`m*_cpp_verified.json` and `m*_python_verified.json`: separate finite checks.
`m*_cpp_pairs.json`: independent C++ pair counts.
`algebra_checks.json`: 7,000 exact finite diagnostics.
`PROVENANCE.json`: hash of the preceding cumulative archive.
`MANIFEST.json`: hashes of all archived files except the manifest itself.

The cumulative archive retains all earlier sources and certificate inputs. It
does not include container font files or newly built platform-specific binaries.
