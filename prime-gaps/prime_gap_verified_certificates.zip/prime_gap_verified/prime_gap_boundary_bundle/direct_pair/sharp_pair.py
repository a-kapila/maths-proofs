"""Exact scalar certificate for a direct symmetric two-coordinate bound.
All transcendental bounds are reduced to rational series and integer square roots.
"""
from fractions import Fraction as F
from pathlib import Path
import json, math, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'continuation2'))
from pair_penalty import constants, fractions_json

def log_fraction(x, terms=80):
    x=F(x)
    if x<=0: raise ValueError('positive logarithm argument required')
    e=x.numerator.bit_length()-x.denominator.bit_length()
    pow2=F(2)**e
    while x<pow2: e-=1; pow2/=2
    while x>=2*pow2: e+=1; pow2*=2
    def series(z):
        pw=z; zz=z*z; s=F(0)
        for j in range(terms):
            s+=2*pw/F(2*j+1);pw*=zz
        return s,s+2*pw/(F(2*terms+1)*(1-zz))
    l2,u2=series(F(1,3));u=x/pow2
    lo,hi=series((u-1)/(u+1))
    return (lo+e*l2,hi+e*u2) if e>=0 else (lo+e*u2,hi+e*l2)

def root_integer(n,bits=220):
    if n<0: raise ValueError('nonnegative radicand required')
    q=1<<bits;v=math.isqrt(n*q*q)
    lo,hi=F(v,q),F(v+1,q)
    assert lo*lo<=n<=hi*hi
    return lo,hi

def double_constant(k):
    if k<3: raise ValueError('k >= 3 required')
    a,b=root_integer(k*(k-2))
    ll,lh=log_fraction(F(k,2))
    ml=log_fraction(k-1+a)[0];mh=log_fraction(k-1+b)[1]
    return ll*ml/((k-2)*b),lh*mh/((k-2)*a)

def sharp_constants(trial,certificate,arithmetic=None):
    v=constants(trial,certificate,arithmetic)
    k=v['k'];s=v['rho']*v['sigma'];cl,ch=double_constant(k)
    old=v['pair'];v['old_pair']=old
    v['double_constant_lower']=cl;v['double_constant_upper']=ch
    v['pair']=2*s*s/(F(1,2)-s)**2*ch
    v['budget']=(v['surplus'].numerator*v['pair'].denominator-1)//(v['surplus'].denominator*v['pair'].numerator)
    assert v['surplus']-v['budget']*v['pair']>0
    assert v['surplus']-(v['budget']+1)*v['pair']<=0
    assert v['pair']<old
    return v

SOURCES={
 3:('focus23/m3_fine.json','focus23/m3_fine.interval_certificate.json'),
 4:('accurate/m4.json','accurate/m4.interval_certificate.json'),
 5:('accurate/m5.json','accurate/m5.interval_certificate.json')}
if __name__=='__main__':
    sys.set_int_max_str_digits(0)
    out={}
    for m,args in SOURCES.items():
        v=sharp_constants(*args);out[str(m)]=fractions_json(v)
        print('m',m,'k',v['k'],'budget',v['budget'],'penalty',float(v['pair']),'relative improvement',float(1-v['pair']/v['old_pair']),flush=True)
    (ROOT/'direct_pair/constants.json').write_text(json.dumps(out,indent=2)+'\n')
