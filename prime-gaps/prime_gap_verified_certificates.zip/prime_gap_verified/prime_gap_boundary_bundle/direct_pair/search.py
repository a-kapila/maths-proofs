import sys, json, struct
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'continuation2'))
from pair_penalty import load_witness,allowed,choose,primes_up_to,fractions_json,enumerate_long_pairs
from sharp_pair import sharp_constants,SOURCES
sys.set_int_max_str_digits(0)
out=ROOT/'direct_pair'
def small(m):
    v=sharp_constants(*SOURCES[m],arithmetic='direct_pair/m3_arithmetic.json' if m==3 else None);k=v['k']
    if m==3:
        w=load_witness('onward/h3_completed_witness.csv');a=allowed(w,-2000000,2000000)
    else:
        a=np.loadtxt(ROOT/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
        w=load_witness('baseline/inherited/tuples/h4_witness.csv')
    subset,r=choose(a,k,v['budget'])
    for p in primes_up_to(k):
        if int(p) not in w:
            used=np.bincount(subset%p,minlength=int(p));missing=np.flatnonzero(used==0)
            assert len(missing);w[int(p)]=int(missing[0])
    r.update(first=int(subset[0]),last=int(subset[-1]),diameter=int(subset[-1]-subset[0]),points=len(a),k=k,m=m)
    r['margin']=fractions_json({'value':v['surplus']-r['long_pairs']*v['pair']})['value']
    np.savetxt(out/f'h{m}_tuple.txt',subset,fmt='%d')
    np.savetxt(out/f'h{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
    if m==3:
        pairs=enumerate_long_pairs(subset,r['D']);assert len(pairs)==r['long_pairs']
        np.savetxt(out/'h3_long_pairs.csv',np.array(pairs),fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
    (out/f'h{m}_result.json').write_text(json.dumps(r,indent=2)+'\n')
    print(m,{k:v for k,v in r.items() if k!='margin'},'margin',r['margin']['display'],flush=True)

def large():
    with open(ROOT/'continuation2/recomputed/h5_tail.bin','rb') as f:
        rank0,N=struct.unpack('<QQ',f.read(16));a=np.fromfile(f,dtype='<u4').astype(np.int64)
    assert len(a)==N-rank0+1 and np.all(np.diff(a)>0)
    v=sharp_constants(*SOURCES[5]);k=v['k'];nmin=k-N
    def counts(D):
        assert D-int(a[-1])>=int(a[0])
        r=np.searchsorted(a,D-a,side='right')+rank0-1
        first=int(np.maximum(0,N-r[:nmin-rank0+1]).sum())
        n=np.arange(nmin,N,dtype=np.int64);m=k-n
        remove=np.maximum(0,n-r[m-rank0]);add=np.maximum(0,m-1-r[n+1-rank0])
        result=np.empty(N-nmin+1,dtype=np.int64);result[0]=first;result[1:]=first+np.cumsum(add-remove)
        assert result.min()>=0
        return result
    lo,hi=4820000000//2,4830609154//2
    while lo<hi:
        md=(lo+hi)//2
        if int(counts(md*2).min())<=v['budget']:hi=md
        else:lo=md+1
    D=lo*2;cs=counts(D);ix=int(cs.argmin());neg=nmin+ix;pos=k-neg
    cnt=int(np.maximum(0,pos-(np.searchsorted(a,D-a[:neg-rank0+1],side='right')+rank0-1)).sum())
    assert cnt==int(cs[ix])
    r=dict(m=5,k=k,D=D,long_pairs=cnt,previous_even_min_count=int(counts(D-2).min()),windows=len(cs),negative_count=neg,positive_count=pos,first=-int(a[neg-rank0]),last=int(a[pos-rank0]),tail_first_rank=rank0,parent_positive_count=N,tail_first=int(a[0]))
    r['diameter']=r['last']-r['first'];r['margin']=fractions_json({'value':v['surplus']-cnt*v['pair']})['value']
    (out/'h5_result.json').write_text(json.dumps(r,indent=2)+'\n')
    print(5,{k:v for k,v in r.items() if k!='margin'},'margin',r['margin']['display'],flush=True)
if __name__=='__main__':
    m=int(sys.argv[1])
    if m==5:large()
    else:small(m)
