# Direct two-coordinate bound and joint slicing/pair deductions

## Authoritative results

H2 <= 19,860 (unchanged), H3 <= 1,358,092, H4 <= 82,237,930,
H5 <= 4,830,451,598, within the retained analytic framework.
Read `proof_note.pdf` (or its LaTeX source) for the new elementary theorem,
the symmetry observation allowing the two deductions to be combined, and the
precise inherited dependencies. These are research deductions, not independently
reviewed published records or formalized proofs.

`RESULTS.json` and `final_m3.json`, `final_m4.json`, `final_m5.json` are the
new authoritative outputs. Earlier result files are historical.

## Reproduction

From the extracted bundle root:

```bash
bash direct_pair/reproduce.sh --checks-only
bash direct_pair/reproduce.sh --full
```

The default workflow checks hashes, regenerates the entire H5 residue certificate,
checks all 12,204,094 witnesses, reconstructs the selected H4 tuple, verifies the
smaller tuples, independently recounts all three long-pair totals, and checks the
new exact rational deductions and algebra diagnostics. It also checks that the
saved H2 calculation fails. No inherited successful Fourier integral is rerun.

`--full` additionally recomputes the new H3 arithmetic-support estimate, H2
amplitude estimate, and unsuccessful H2 interval evaluation. Recomputing the
inherited successful Fourier calculations uses their retained reproduction scripts
under `focus23/` and `accurate/`.

Python 3, NumPy, SciPy, mpmath, a C++17/OpenMP compiler and several GB of working
memory/storage are required for full numerical reconstruction. Keep assertions
enabled. The module named `flint.py` is a documented mpmath.iv compatibility layer,
not FLINT/Arb. No font files are required or supplied.

## New files

- `sharp_pair.py`: rational logarithm and square-root enclosures; exact direct
  double-marginal constant. Its proof is in the note, not inferred from diagnostics.
- `combine.py`: use capped symmetric slicing and the new pair bound together.
  It rechecks the saved mean/support inputs through the inherited scalar code.
- `search.py`: direct-pair comparison and H3 tuple selection.
- `combined_m*_d*.json`: tested choices of deleted dimension; this is a finite
  search, not a proof of globally optimal deletion count.
- `verify_final.py`: independent scalar deductions and final C++/Python checks.
- `h3_tuple.txt`, `h3_witness.csv`, `h3_long_pairs.csv`: full finite H3 data.
  The H4 tuple is regenerated from the retained parent instead of duplicated.
- `m3_arithmetic.json`: newly computed loss at changed arithmetic parameters.
- `m2_trial.json`, `m2_amplitude.json`, `m2_trial.interval_certificate.json`:
  completed unsuccessful H2 attempt; it is excluded from successful deductions.
- `run_h2.py`: inherited component-wise enclosure with m=2, tagged support loss,
  and the new amplitude hook. The physical trial and its hash are checked.
- `diagnostics.py`: exact weight identities and independent numerical checks.

A second verification of a selected tuple is independent of its search, but is not
an independent expert review of the inherited sieve and interval-error proofs.
`PROVENANCE.json` records the source archive checksum. The original source archive's
files are retained without requiring previous downloads. Generated binary prime
tables, native executables, large temporary arrays and the regenerated H4 text
file are omitted and reconstructed by the scripts.
