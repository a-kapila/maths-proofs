"""Recompute scalar deductions; independently check explicit tuples and long pairs."""
from pathlib import Path
import sys,json,subprocess,math,csv,hashlib
import numpy as np
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'direct_pair'
sys.set_int_max_str_digits(0)
from sharp_pair import sharp_constants,SOURCES
from combine import joint_constants
sys.path.insert(0,str(ROOT/'continuation2'))
from pair_penalty import fractions_json

def run_capture(args,dest):
    p=subprocess.run(args,check=True,capture_output=True,text=True)
    dest.write_text(p.stdout);return json.loads(p.stdout)

results=[]
old={3:1358106,4:82240686,5:4830609154}
for m,d in [(3,0),(4,1025),(5,39000)]:
    if m==3:
        row=json.load(open(OUT/'h3_result.json'))
        v=sharp_constants(*SOURCES[3],arithmetic='direct_pair/m3_arithmetic.json')
    else:
        src=json.load(open(OUT/f'combined_m{m}_d{d}.json'));row=src['selection'];v=joint_constants(m,d)
    assert row['long_pairs']<=v['budget']<row['previous_even_min_count']
    margin=v['surplus']-row['long_pairs']*v['pair'];assert margin>0
    assert F(row['margin']['num'],row['margin']['den'])==margin
    # Make the strict physical support parameter explicit at a rational lambda<rho.
    lam=v['rho']-F(1,2**60);s=lam*v['sigma']
    from sharp_pair import double_constant
    physical_pair=2*s*s/(F(1,2)-s)**2*double_constant(v['k'])[1]
    assert lam*v['q']-m-row['long_pairs']*physical_pair>0
    if m in (3,4):
        if m==3:
            tup=OUT/'h3_tuple.txt';wit=OUT/'h3_witness.csv'
        else:
            parent=np.loadtxt(ROOT/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
            a=parent[row['index']:row['index']+v['k']]
            assert int(a[0])==row['first'] and int(a[-1])==row['last']
            tup=OUT/'h4_selected.txt';np.savetxt(tup,a,fmt='%d')
            wit=ROOT/'baseline/inherited/tuples/h4_witness.csv'
        tcheck=run_capture([str(OUT/'verify_tuple'),str(tup),str(wit),str(v['k'])],OUT/f'h{m}_tuple_verified.json')
        pcheck=run_capture([str(OUT/'check_pair_counts'),'tuple',str(tup),str(row['D'])],OUT/f'h{m}_pairs_verified.json')
        assert tcheck['verified'] and tcheck['k']==v['k']
        assert tcheck['first']==row['first'] and tcheck['last']==row['last']
    else:
        parent=json.load(open(OUT/'h5_parent_verified.json'))
        assert parent['verified'] and parent['failures']==0 and parent['parent_cardinality']==233950978
        assert row['negative_count']+row['positive_count']==v['k']
        pcheck=run_capture([str(OUT/'check_pair_counts'),'signed',str(ROOT/'continuation2/recomputed/h5_tail.bin'),str(row['D']),str(row['negative_count']),str(row['positive_count'])],OUT/'h5_pairs_verified.json')
    assert pcheck['long_pairs']==row['long_pairs'] and pcheck['k']==v['k']
    result=dict(m=m,old_bound=old[m],bound=row['D'],reduction=old[m]-row['D'],dimension=v['k'],original_dimension=v.get('original_k',v['k']),deleted=d,first=row['first'],last=row['last'],full_diameter=row['diameter'],long_pairs=row['long_pairs'],budget=v['budget'],prime_count_margin=float(margin),windows=row['windows'])
    if m==5:result.update(negative_count=row['negative_count'],positive_count=row['positive_count'])
    if m in (3,4):result['checked_primes']=tcheck['checked_primes']
    (OUT/f'final_m{m}.json').write_text(json.dumps(dict(constants=fractions_json(v),selection=row),indent=2)+'\n')
    results.append(result);print(result,flush=True)
# Independent direct modular check for H3, not the arithmetic progression verifier.
a=np.loadtxt(OUT/'h3_tuple.txt',dtype=np.int64);k=len(a)
s=bytearray(b'\x01')*(k+1);s[0]=s[1]=0
for p in range(2,math.isqrt(k)+1):
    if s[p]:s[p*p::p]=b'\x00'*(((k-p*p)//p)+1)
ps=[p for p in range(2,k+1) if s[p]]
w={int(r['prime']):int(r['missing_residue']) for r in csv.DictReader(open(OUT/'h3_witness.csv'))}
assert sorted(w)==ps
for p in ps:assert not np.any(a%p==w[p])
pycheck=dict(verified=True,k=k,checked_primes=len(ps),method='independent byte sieve; direct modular reduction of every entry')
(OUT/'h3_python_verified.json').write_text(json.dumps(pycheck,indent=2)+'\n')
res=dict(status='passed',results=results,scope='Inherited successful Fourier quotients and cap/mean certificates are not reevaluated. New exact two-coordinate inequality and combination with symmetric slicing. H3 arithmetic loss recomputed. New tuple and pair counts checked.',H2_status=json.load(open(OUT/'h2_attempt.json')))
(OUT/'RESULTS.json').write_text(json.dumps(res,indent=2)+'\n')
