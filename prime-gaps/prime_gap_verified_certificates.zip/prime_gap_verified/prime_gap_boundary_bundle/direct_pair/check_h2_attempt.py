from pathlib import Path
from fractions import Fraction as F
import hashlib,json
B=Path(__file__).resolve().parents[1];O=B/'direct_pair'
t=json.load(open(O/'m2_trial.json'));c=json.load(open(O/'m2_trial.interval_certificate.json'));a=json.load(open(O/'m2_amplitude.json'))
assert a['trial_sha256']==c['trial_sha256']==hashlib.sha256((O/'m2_trial.json').read_bytes()).hexdigest()
assert c['k']==2303 and c['m']==2
assert F(240)*F(t['omega'])+F(80)*F(t['smooth_delta'])<3
rho=F(1,4)+F(t['omega']);margin=F(c['Q_lower'])-F(c['restriction']['loss_upper'])-2/rho
assert margin<0 and F(c['Q_lower'])<2/rho
assert c['amplitude_upper']==a['amplitude_upper']
r=dict(k=c['k'],Q_lower=c['Q_lower'],loss_upper=c['restriction']['loss_upper'],target_upper=c['target_upper'],corrected_margin=float(margin),amplitude_upper=a['amplitude_upper'],chunks=c['chunks'],fourier_checks=len(c['direct_fourier_checks']),bitwise_checks=c['bitwise_CDF_checks'],status='failed sufficient inequality; not used in any successful bound')
(O/'h2_attempt.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
