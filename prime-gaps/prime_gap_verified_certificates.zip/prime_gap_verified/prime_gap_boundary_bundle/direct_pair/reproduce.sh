#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
case "${1:---checks-only}" in --checks-only|--full) ;; *) echo 'Use --checks-only (default) or --full' >&2; exit 2;; esac
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
CXX="${CXX:-g++}"
python direct_pair/verify_manifest.py
"$CXX" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o direct_pair/verify_tuple
"$CXX" -O3 -std=c++17 continuation2/check_pair_counts.cpp -o direct_pair/check_pair_counts
# Reconstruct the complete large-tuple witnesses and recheck every one.
bash continuation2/prepare_h5.sh
cp continuation2/h5_parent_verified.json direct_pair/h5_parent_verified.json
if [[ "${1:---checks-only}" == --full ]]; then
  "$CXX" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
  "$CXX" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off progress/profile_parallel.cpp -o progress/profile_parallel.so
  "$CXX" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
  python direct_pair/retune_m3.py
  python continuation2/mixed_amplitude.py direct_pair/m2_trial.json direct_pair/m2_amplitude.json 32
  python direct_pair/run_h2.py direct_pair/m2_trial.json
fi
python direct_pair/check_h2_attempt.py
python direct_pair/diagnostics.py
python direct_pair/verify_final.py
