"""Algebraic checks and independent quadrature for the new theorem.
These checks supplement the symbolic proof; they do not certify inherited Fourier work.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,random,math,itertools
import mpmath as mp
from sharp_pair import double_constant,log_fraction,root_integer
ROOT=Path(__file__).resolve().parents[1]
mp.mp.dps=75
rng=random.Random(4637);algebra=0
for k in range(3,24):
    for _ in range(40):
        raw=[rng.randint(0,100) for j in range(k)];den=sum(raw)+rng.randint(1,100)
        xs=[F(t,den) for t in raw];slack=1-sum(xs)
        total=F(0)
        for i,j in itertools.combinations(range(k),2):
            x,y=xs[i],xs[j]
            A=(slack+k*x)*(slack+x+(k-1)*y)
            B=(slack+k*y)*(slack+y+(k-1)*x)
            W=(A+B)/2
            explicit=slack**2+k*slack*(x+y)+F(k,2)*(x*x+y*y)+k*(k-1)*x*y
            assert W==explicit and W>0
            assert 1/W <= (1/A+1/B)/2
            total+=W
        assert total==F(k*(k-1),2)
        algebra+=1

quads=[]
for k in [3,4,5,10,50,2304,110070,5088950,232460500]:
    kk=mp.mpf(k);s=mp.sqrt(kk*(kk-2));p=kk-2
    def integrand(t):return 4*mp.atanh(s*t/(2+p*t))/(s*(2+p*t)) if t else mp.mpf(0)
    breaks=[mp.mpf(0)]+[mp.mpf(10)**j for j in range(-12,0)]+[mp.mpf(1)]
    val=mp.quad(integrand,breaks)
    formula=mp.log(kk/2)*mp.log(kk-1+s)/(p*s)
    assert abs(val-formula)<mp.mpf('1e-65')*abs(formula)
    lo,hi=double_constant(k)
    conv=lambda q:mp.mpf(q.numerator)/q.denominator
    assert conv(lo)<=formula<=conv(hi)
    old=mp.log(kk)*mp.log(kk-1)/((kk-1)*(kk-2))
    assert hi < log_fraction(k)[0]*log_fraction(k-1)[0]/((k-1)*(k-2))
    quads.append(dict(k=k,value=mp.nstr(formula,32),relative_saving=mp.nstr(1-formula/old,20),quad_relative_error=mp.nstr(abs(val-formula)/formula,5)))
mp.mp.dps=160
logtests=0
for _ in range(100):
    x=F(rng.randint(1,10**12),rng.randint(1,10**10))
    lo,hi=log_fraction(x);v=mp.log(conv(x));assert conv(lo)<=v<=conv(hi);logtests+=1
result=dict(passed=True,rational_weight_identities=algebra,independent_quadratures=quads,log_enclosure_tests=logtests)
(ROOT/'direct_pair/diagnostics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
