from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parents[1]
m=json.load(open(B/'direct_pair/MANIFEST.json'))
for p,h in m['sha256'].items():
    assert hashlib.sha256((B/p).read_bytes()).hexdigest()==h, p
print('Manifest inputs checked:',len(m['sha256']))
