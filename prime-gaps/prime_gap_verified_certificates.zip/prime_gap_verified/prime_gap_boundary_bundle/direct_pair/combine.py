"""Combine capped symmetric slicing with the new pair penalty.
The search selects candidates; scalar deductions are exact rational inequalities.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,struct,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'direct_pair'
sys.path.insert(0,str(ROOT/'continuation'))
sys.path.insert(0,str(ROOT/'continuation2'))
from finite_sampling import coefficient
from deduce_caps import calc
from pair_penalty import counts_windows,choose,load_witness,fractions_json
from sharp_pair import sharp_constants,SOURCES,double_constant
sys.set_int_max_str_digits(0)

_CACHE={}
def joint_constants(m,d):
    if m not in _CACHE:
        r={4:10,5:4}[m];row=calc(m,r)
        base=sharp_constants(*SOURCES[m]);base['q']=F(row['quotient_lower_before_restriction'])-F(row['restriction_loss_upper'])
        _CACHE[m]=(r,row,base)
    r,row,base=_CACHE[m];v=dict(base);k=base['k'];K=k-d
    mu=F(row['mean_lower']);beta=mu*coefficient(k,d,r)
    q=F(K,k)*base['q']/(1-beta);s=base['rho']*base['sigma']
    cl,cc=double_constant(K);pair=2*s*s/(F(1,2)-s)**2*cc
    sur=base['rho']*q-m
    assert sur>0
    budget=(sur.numerator*pair.denominator-1)//(sur.denominator*pair.numerator)
    v.update(k=K,original_k=k,deleted=d,mu_lower=mu,r=r,beta_lower=beta,q=q,pair=pair,surplus=sur,budget=budget,double_constant_lower=cl,double_constant_upper=cc)
    v['old_pair_for_original_dimension']=v.pop('old_pair')
    assert sur-budget*pair>0>=sur-(budget+1)*pair
    return v

class Search:
    def __init__(self,m):
        self.m=m
        if m==4:
            self.a=np.loadtxt(ROOT/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
        else:
            with open(ROOT/'continuation2/recomputed/h5_tail.bin','rb') as f:
                self.rank0,self.N=struct.unpack('<QQ',f.read(16));self.a=np.fromfile(f,dtype='<u4').astype(np.int64)
            assert len(self.a)==self.N-self.rank0+1
    def counts(self,K,D):
        a=self.a
        if self.m==4:return counts_windows(a,K,D)
        rank0,N=self.rank0,self.N;nmin=K-N
        assert D-int(a[-1])>=int(a[0]) and nmin>=rank0
        r=np.searchsorted(a,D-a,side='right')+rank0-1
        first=int(np.maximum(0,N-r[:nmin-rank0+1]).sum())
        n=np.arange(nmin,N,dtype=np.int64);p=K-n
        rem=np.maximum(0,n-r[p-rank0]);add=np.maximum(0,p-1-r[n+1-rank0])
        out=np.empty(N-nmin+1,dtype=np.int64);out[0]=first;out[1:]=first+np.cumsum(add-rem)
        assert out.min()>=0
        return out
    def run(self,d):
        v=joint_constants(self.m,d);K=v['k'];budget=v['budget']
        lo,hi=({4:(82190000,82250000),5:(4829500000,4830700000)}[self.m]);lo//=2;hi//=2
        assert self.counts(K,hi*2).min()<=budget
        assert self.counts(K,lo*2).min()>budget
        while lo<hi:
            md=(lo+hi)//2
            if int(self.counts(K,md*2).min())<=budget:hi=md
            else:lo=md+1
        D=2*lo;cs=self.counts(K,D);idx=int(cs.argmin());cnt=int(cs[idx]);a=self.a
        r=dict(m=self.m,deleted=d,k=K,D=D,long_pairs=cnt,budget=budget,windows=len(cs),index=idx,previous_even_min_count=int(self.counts(K,D-2).min()))
        if self.m==4:r.update(first=int(a[idx]),last=int(a[idx+K-1]))
        else:
            neg=K-self.N+idx;pos=K-neg
            r.update(negative_count=neg,positive_count=pos,first=-int(a[neg-self.rank0]),last=int(a[pos-self.rank0]),tail_first_rank=self.rank0,parent_positive_count=self.N)
        r['diameter']=r['last']-r['first'];r['margin']=fractions_json({'value':v['surplus']-cnt*v['pair']})['value']
        (OUT/f'combined_m{self.m}_d{d}.json').write_text(json.dumps(dict(constants=fractions_json(v),selection=r),indent=2)+'\n')
        print({k:v for k,v in r.items() if k!='margin'},'margin',r['margin']['display'],flush=True)
        return r

if __name__=='__main__':
    m=int(sys.argv[1]);ds=list(map(int,sys.argv[2:]))
    s=Search(m)
    for d in ds:s.run(d)
