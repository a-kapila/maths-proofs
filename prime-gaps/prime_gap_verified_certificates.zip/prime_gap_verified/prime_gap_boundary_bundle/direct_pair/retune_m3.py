from pathlib import Path
import sys,json,time
from fractions import Fraction as F
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from flint import ctx
from loss_joint import restriction_loss
ctx.prec=256
j=json.load(open(B/'focus23/m3_fine.json'));c=json.load(open(B/'focus23/m3_fine.interval_certificate.json'))
delta=6e-7;omega=0.012499799999
assert 240*F(omega)+80*F(delta)<3
st=time.time();eps=j['delta']*j['eps_cells']
r=restriction_loss(j['k'],j['theta'],j['beta'],delta,omega,c['scaled_den_lower'],ufrac=j['ufrac'],sum_cap=1+eps,relative_shift=j['relative_shift'],inner_cap=1-eps)
row=dict(delta=delta,omega=omega,support=r,trial='focus23/m3_fine.json',quotient='focus23/m3_fine.interval_certificate.json',seconds=time.time()-st)
(B/'direct_pair/m3_arithmetic.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row),flush=True)
