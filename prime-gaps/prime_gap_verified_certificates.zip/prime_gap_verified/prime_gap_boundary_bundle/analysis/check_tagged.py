"""Exact rational diagnostics of tagged-coordinate necessary conditions."""
from fractions import Fraction as F
from random import Random
from pathlib import Path
import json
rng=Random(20261103);cv=F(3,2);T=F(1);counts={'integrated':0,'remaining_small':0,'remaining_large':0};trials=6000
for _ in range(trials):
    n=rng.randrange(3,9);xs=[F(rng.randrange(17),16) for i in range(n)];t=F(rng.randrange(17),16)
    vec=xs+[t];u0=F(1,32);kap=F(rng.randrange(81,177),32) # kap>2.5 T
    A=sum(xs)+F(1,64);B=A+t
    critical=[v for v in vec if v>u0]
    probes=[u0+F(1,4096)]+critical+[(a+b)/2 for a,b in zip(sorted(set([u0]+critical))[:-1],sorted(set([u0]+critical))[1:])]
    bad=lambda v: cv*v+sum(x for x in vec if x>=v)>kap
    assert not any(bad(v) for v in probes if u0<v<=max(vec)) or any(bad(v) for v in critical)
    for mark,v in enumerate(vec):
        if v<=u0 or not bad(v):continue
        wl=F((64*v).numerator//(64*v).denominator,64);wn=wl+F(1,64)
        rest=xs if mark==n else xs[:mark]+xs[mark+1:]
        N=sum(x>=wl for x in rest);R=sum(x for x in rest if x<wl)
        H=kap-(cv+1)*wn;r=H.numerator//H.denominator+1
        if mark==n:
            caps=[A-H,B-kap+cv*wn,A-r*wl,B-(r+1)*wl];name='integrated'
        elif t<v:
            caps=[A-kap+cv*wn,A-(r+1)*wl];name='remaining_small'
        else:
            H-=T;r=H.numerator//H.denominator+1
            caps=[A-wl-H,B-kap+cv*wn,A-(r+1)*wl,B-(r+2)*wl];name='remaining_large'
        assert N>=r and R<=min(caps),(name,N,r,R,caps)
        counts[name]+=1
out={'exact_vector_tests':trials,'verified_trigger_cases':counts,'seed':20261103}
Path(__file__).with_name('tagged_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
