#include <cmath>
#include <cstdint>
extern "C" void profile_bounds_raw(const double* h, const double* lo, const double* hi,
 const int64_t* E, const int64_t* I, int64_t nh, int64_t nt, int64_t ni,
 double* al, double* au, double* absl, double* absu) {
 for(int64_t j=0;j<nh;j++) {
  const double z=(j+1<nh?h[j]-h[j+1]:h[j]); if(z==0.0)continue;
  const int64_t edge=E[j+1];
  for(int64_t i=0;i<ni;i++) {
   int64_t l=edge-I[i]-1,u=l+1;
   double lv=l<0?0.0:lo[l<nt?l:nt-1];
   double uv=u<0?0.0:hi[u<nt?u:nt-1];
   const double vl=z*(z>0?lv:uv), vu=z*(z>0?uv:lv);
   al[i]+=vl;au[i]+=vu;absl[i]+=std::abs(vl);absu[i]+=std::abs(vu);
  }
 }
}
