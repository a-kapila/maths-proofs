"""Memory-only change: discard each grid after its bounded integrations.
Save the three raw grid values used by independent direct-Fourier diagnostics.
"""
import numpy as np
from polynomial_cdf import PolynomialCDF
class StreamingCDF(PolynomialCDF):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.samples={}
 def bounds(self,n,r,ys):
  ans=super().bounds(n,r,ys);key=(n,r)
  if key not in self.samples:
   pts=np.array([.5,.75,1.]);L,V=super().bounds(n,r,pts)
   self.samples[key]=[(float(y),float(self.tables[key][int(round(y/self.DELTA))]),float(L[j]),float(V[j])) for j,y in enumerate(pts)]
  del self.tables[key]
  return ans

def direct_check(cdf):
 import mpmath as mp
 mp.mp.dps=70;out=[]
 for key in cdf.keys:
  for y,raw,L,U in cdf.samples[key]:
   zsum=mp.mpf(0)
   for j,z in enumerate(cdf.coeffs[key],1):
    zz=mp.mpc(float(z.real),float(z.imag));phase=mp.exp(-2j*mp.pi*j*mp.mpf(y)/mp.mpf(cdf.P));zsum+=2*mp.re(zz*phase)
   direct=mp.mpf(cdf.zero[key])*mp.mpf(y)/mp.mpf(cdf.P)+mp.mpf(cdf.const[key])-zsum
   err=float(cdf.error[key])
   assert abs(direct-mp.mpf(raw))<=mp.mpf(err),(key,y)
   assert direct+err>=0 and direct-err<=mp.mpf(float(cdf.mass[key].upper()))
   out.append(dict(n=key[0],moment=key[1],y=y,direct=mp.nstr(direct,25),lower=L,upper=U,raw_fft=raw,raw_error=err))
 return out
