"""Rigorous amplitude envelope for 1, Z2, Z3, Z4, Z2^2.
All polynomial extrema are computed with exact rational arithmetic.
Only the conversion from the interval T to a rational upper bound on S/T
uses the inherited interval backend. No optimizer values enter the bound.
"""
from fractions import Fraction
import math

def rational(x):
    return Fraction.from_float(float(x))

def extrema_quadratic(a,b,c,right):
    """Exact range of a+b*x+c*x*x, 0<=x<=right."""
    vals=[a,a+b*right+c*right*right]
    if c:
        vertex=-b/(2*c)
        if 0<vertex<right:
            vals.append(a-b*b/(4*c))
    return min(vals),max(vals)

def upfloat(q):
    f=float(q)
    return math.nextafter(f,math.inf) if rational(f)<q else f

def profile_amplitude(hs,basis,E,spacing,S):
    from flint import arb
    allowed={(),(2,),(3,),(4,),(2,2)}
    assert set(map(tuple,basis))<=allowed
    vals={tuple(key):h for key,h in zip(basis,hs)}
    C=Fraction(0)
    naive=Fraction(0)
    for j in range(len(hs[0])):
        coeff=lambda key: rational(vals[key][j]) if key in vals else Fraction(0)
        h0,h2,h3,h4,h22=(coeff(k) for k in [(),(2,),(3,),(4,),(2,2)])
        z_ball=arb(int(E[j+1]))*arb(spacing)/S['T']
        z_float=math.nextafter(float(z_ball.upper()),math.inf)
        z=rational(z_float)
        # For x_i in [0,1] and sum x_i<=z, sum x_i^2<=floor(z)+frac(z)^2.
        # The looser sum x_i^2<=z is enough but the sharp version is free.
        n=z.numerator//z.denominator
        u=min(Fraction(S['k']),Fraction(n)+(z-n)**2)
        qlo,qhi=extrema_quadratic(h2,h3,h4,Fraction(1))
        lo=extrema_quadratic(h0,qlo,h22,u)[0]
        hi=extrema_quadratic(h0,qhi,h22,u)[1]
        C=max(C,abs(lo),abs(hi))
        naive=max(naive,abs(h0)+(abs(h2)+abs(h3)+abs(h4))*z+abs(h22)*z*z)
    return upfloat(C),upfloat(naive)

if __name__=='__main__':
    import sys,json
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]/'baseline'
    sys.path.insert(0,str(root/'inherited/analysis'))
    from shifted_core import setup
    for name in sys.argv[1:]:
        d=json.load(open(name));S=setup(d['k'],d['theta'],d['beta'],d['relative_shift'])
        C,old=profile_amplitude(d['profiles'],d['basis'],d['E'],d['delta'],S)
        print(json.dumps({'trial':name,'amplitude_upper':C,'naive_upper':old,'loss_multiplier_reduction':(old/C)**2}))
