"""Finite exact-fraction diagnostics for the new envelopes; proofs are in the note."""
from fractions import Fraction as F
from random import Random
from pathlib import Path
import json
from amplitude_envelope import extrema_quadratic
rng=Random(20261103)
for _ in range(2000):
 k=rng.randrange(1,20);xs=[F(rng.randrange(17),16) for j in range(k)]
 z=sum(xs)+F(rng.randrange(9),16)
 h=[F(rng.randrange(-1024,1025),1024) for j in range(5)]
 h0,h2,h3,h4,h22=h;U=sum(x*x for x in xs)
 n=z.numerator//z.denominator;umax=min(F(k),F(n)+(z-n)**2)
 assert U<=umax
 qlo,qhi=extrema_quadratic(h2,h3,h4,F(1))
 low=extrema_quadratic(h0,qlo,h22,umax)[0]
 high=extrema_quadratic(h0,qhi,h22,umax)[1]
 val=h0+sum(h2*x*x+h3*x**3+h4*x**4 for x in xs)+h22*U*U
 assert low<=val<=high
for _ in range(2000):
 M=F(0);E=F(0);N=F(0)
 for j in range(rng.randrange(1,15)):
  weights=[F(1)]+[F(rng.randrange(17),16) for t in range(4)]
  coeff=[F(rng.randrange(-32,33),16) for t in range(5)]
  rad=[F(rng.randrange(9),1024) for t in range(5)]
  changes=[r*F(rng.randrange(-16,17),16) for r in rad]
  w=F(rng.randrange(1,17),16)
  center=sum(a*z for a,z in zip(coeff,weights))
  true=sum((a+d)*z for a,d,z in zip(coeff,changes,weights))
  err=sum(r*z for r,z in zip(rad,weights))
  M+=w*center*center;E+=w*err*err;N+=w*true*true
 if M>E and N<M+E:assert (M+E-N)**2<=4*M*E
out={'seed':20261103,'exact_rational_amplitude_tests':2000,'exact_rational_Hilbert_bound_tests':2000}
Path(__file__).with_name('enclosure_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
