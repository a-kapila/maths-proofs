"""Finalize H2 with the inherited component numerator and tagged support loss.
The completed full Fourier calculation is reused unchanged; only its support-loss
bound is replaced. The optional midpoint/Hilbert numerator is not used.
"""
from pathlib import Path
import sys,json,hashlib,numpy as np
BASE=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(BASE/'baseline'/'inherited'/'analysis'),str(BASE/'analysis')]
from flint import arb,ctx
from shifted_core import setup
from amplitude_envelope import profile_amplitude
from loss_tagged import restriction_loss

def run(source,destination):
    p=Path(source);outp=Path(destination);d=json.loads(p.read_text());c=json.loads(p.with_suffix('.interval_certificate.json').read_text())
    ctx.prec=256;S=setup(d['k'],d['theta'],d['beta'],d['relative_shift'])
    C_exact,_=profile_amplitude(d['profiles'],d['basis'],d['E'],d['delta'],S)
    C=3.622;assert C_exact<C
    # The stored nearest-binary64 component endpoint is widened down by one ulp.
    nl=float(np.nextafter(c['num_original_lower'],-np.inf))
    q=arb(d['k'])*arb(nl)/(S['m2']*arb(c['den_upper']))
    ql=float(np.nextafter(float(q.lower()),-np.inf))
    scaled=float(np.nextafter(float((arb(c['den_lower'])/arb(C)**2).lower()),-np.inf))
    eps=d['delta']*d['eps_cells'];eta=1e-8;ratio=1.03
    rc=restriction_loss(d['k'],d['theta'],d['beta'],d['smooth_delta'],d['omega'],scaled,eta=eta,ratio=ratio,ufrac=d['ufrac'],relative_shift=d['relative_shift'],sum_cap=1+eps,inner_cap=1-eps)
    target=arb(d['m'])/(arb(1)/4+arb(d['omega']));tu=float(np.nextafter(float(target.upper()),np.inf))
    margin=float(np.nextafter(float((arb(ql)-arb(rc['loss_upper'])-arb(tu)).lower()),-np.inf))
    assert margin>0
    assert 240*arb(d['omega'])+80*arb(d['smooth_delta'])<3
    dd=dict(d,loss_eta=eta,loss_ratio=ratio,amplitude_bound=C,source_trial_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_quotient_trial=p.name)
    outp.write_text(json.dumps(dd,indent=2)+'\n')
    cc=dict(c,trial=str(outp),Q_lower=ql,num_lower=nl,target_upper=tu,restriction=rc,margin_lower=margin,amplitude_upper=C,amplitude_envelope_upper=C_exact,scaled_den_lower=scaled,numerator_choice='inherited component bound, not optional Hilbert bound',source_quotient_certificate_sha256=hashlib.sha256(p.with_suffix('.interval_certificate.json').read_bytes()).hexdigest())
    outp.with_suffix('.interval_certificate.json').write_text(json.dumps(cc,indent=2)+'\n')
    print(json.dumps({key:cc[key] for key in ['k','Q_lower','target_upper','margin_lower','amplitude_upper','numerator_choice']}));print(json.dumps(rc))
if __name__=='__main__':run(sys.argv[1],sys.argv[2])
