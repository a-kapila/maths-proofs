"""Tail-support deletion by the coordinate attaining a bad threshold.
For a finite vector, cv*v+sum_{x_i>=v}x_i increases between coordinate values.
Thus a violation above u0 occurs at one of the coordinates above u0.
This function bounds the expected absolute deleted marginal by a tagged-coordinate
union bound, under the law g^2/m2 for the remaining coordinates and g(t)dt for
the integrated coordinate. Signed loss is <=2*GT*expected deleted envelope.
"""
import math,numpy as np
from flint import arb,ctx
from shifted_core import setup
from loss_joint import joint_tail

def restriction_loss(k,theta,beta,delta,omega,Eh2_lower,eta=1e-8,ufrac=.999,ratio=1.03,cv=1.5,sum_cap=1.,relative_shift=0.,inner_cap=None):
    assert k>=3 and delta>0 and omega>0 and Eh2_lower>0 and 0<ufrac<1 and ratio>1 and eta>0
    S=setup(k,theta,beta,relative_shift);T=S['T'];rho=arb(1)/4+arb(omega)
    u0=arb(ufrac)*arb(delta)/rho;kappa=(arb(1)/4+arb(delta)/2)/rho-arb(eta)
    s=arb(cv);B=arb(sum_cap);A=arb(inner_cap) if inner_cap is not None else B
    assert u0<T and (s+1)*T<kappa
    F,G=S['F'],S['G'];GT=G(T);n=k-1
    grid=[u0]
    while grid[-1]*arb(ratio)<T:grid.append(grid[-1]*arb(ratio))
    grid.append(T)
    lams=np.exp(np.linspace(math.log(1e-3),math.log(1e7),900))
    upward=lambda x:float(np.nextafter(float(x.upper()),np.inf))
    rcount=lambda H:int(math.floor(np.nextafter(float((H/T).lower()),-np.inf)))+1
    add=arb(0);small=arb(0);large=arb(0)
    for wl,wn in zip(grid[:-1],grid[1:]):
        markmass=F(wn)-F(wl)
        H=kappa-(s+1)*wn;r=rcount(H)
        bound=arb(min(upward(A-H+arb(eta)),upward(B-kappa+s*wn+arb(eta)),upward(A-arb(r)*wl+arb(eta)),upward(B-arb(r+1)*wl+arb(eta))))
        pt=joint_tail(n,r,bound,wl,S,lams)
        add+=(G(wn)-G(wl))*pt
        # Mark one of the n remaining coordinates; integrated t is below v.
        ba=arb(min(upward(A-kappa+s*wn+arb(eta)),upward(A-arb(r+1)*wl+arb(eta))))
        pa=joint_tail(n-1,r,ba,wl,S,lams)
        small+=arb(n)*markmass*G(wn)*pa
        # Integrated t is at least v; use t<=T to bound the required heavy count.
        H2=H-T;r2=rcount(H2)
        bb=arb(min(upward(A-wl-H2+arb(eta)),upward(B-kappa+s*wn+arb(eta)),upward(A-arb(r2+1)*wl+arb(eta)),upward(B-arb(r2+2)*wl+arb(eta))))
        pb=joint_tail(n-1,r2,bb,wl,S,lams)
        large+=arb(n)*markmass*(GT-G(wl))*pb
    deleted=add+small+large
    loss=arb(2*k)*GT*deleted/(S['m2']*arb(Eh2_lower))
    return dict(k=k,theta=theta,beta=beta,relative_shift=relative_shift,delta=delta,omega=omega,cv=cv,kappa=float(kappa.mid()),cells=len(grid)-1,method='tagged critical-coordinate union bound',inner_cap=inner_cap,eta=eta,ratio=ratio,tagged_integrated_upper=upward(add),tagged_remaining_small_upper=upward(small),tagged_remaining_large_upper=upward(large),loss_upper=upward(loss))
