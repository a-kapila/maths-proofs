"""Operation-order regression test; not a substitute for the error proof."""
from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'baseline'/'inherited'/'analysis'))
import numpy as np
from certify_lifted import profile_bounds as reference
from fast_profile import profile_bounds as accelerated
rng=np.random.default_rng(20261103)
for _ in range(300):
    nh=int(rng.integers(2,45));nt=int(rng.integers(3,130));ni=int(rng.integers(1,250))
    h=rng.integers(-1000,1001,size=nh)/1024
    E=np.concatenate(([0],np.cumsum(rng.integers(1,8,size=nh)))).astype(np.int64)
    I=np.sort(rng.integers(0,int(E[-1])+8,size=ni)).astype(np.int64)
    mid=np.cumsum(rng.random(nt))/nt
    tab=(np.maximum(0,mid-1e-10),mid+1e-10)
    old=reference(h,tab,E,I);new=accelerated(h,tab,E,I)
    assert all(np.array_equal(x,y) for x,y in zip(old,new))
out={'bitwise_identical_tests':300,'seed':20261103,'fast_math':False,'fp_contract':False}
(BASE/'verification'/'fast_profile_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
