# Latest continuation — 5 November 2026

The latest authoritative results are in `radial23/RESULTS.json`: H2 <= 19,850; H3 <= 1,358,016; H4 <= 82,234,788 and H5 <= 4,830,355,416 remain inherited and unchanged. Older result files are historical.

Read `radial23/proof_note.pdf` and `radial23/README.md`. Run `bash radial23/reproduce.sh --checks-only` from this root. `--full` additionally recomputes the new tagged-Fourier, amplitude and support-loss inputs; it does not recompute inherited unrestricted quotient integrals.

These are computer-assisted deductions within the retained sieve framework, not independently peer-reviewed records or formally verified proofs. The latest source archive checksum is in `radial23/PROVENANCE.json`. No prior download is required.
