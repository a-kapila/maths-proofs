"""Fresh interval Fourier enclosure of E[S/sigma] for the saved fixed trials.
No new quotient computation. All capped-rescaling inputs and reuse are explicit.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'direct_mean'),str(B/'baseline/inherited/analysis')]
from capped_mean import CappedMeanCDF,tagged_weights,ar,up,down
from multi_core import single_moments
from flint import arb,ctx

class RadialMeanCDF(CappedMeanCDF):
    def moments(self,kind='zero',value=0):
        mu=single_moments(self.S,self.jmax,kind,value)
        nu=[self.S['T']/ar(self.sigma)*mu[j+1] for j in range(self.jmax)]
        return mu,nu

def run(m):
    t=time.time();ctx.prec=256
    p=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
    tr=json.load(open(p));orig=json.load(open(p.with_suffix('.interval_certificate.json')))
    support=json.load(open(B/f'uncapped/support_m{m}_7_5.json'))
    sigma=1+F(tr['delta'])*tr['eps_cells'];h=F(2,7)
    cdf=RadialMeanCDF(tr,sigma);assert ar(h*sigma)>cdf.S['T']
    cdf.run_setup();nl,nu,components=cdf.evaluate()
    corr=arb(support['amplitude_upper'])**2*arb(support['support_bad_probability_upper'])
    meanlo=down((arb(nl)-corr)/arb(orig['den_upper']))
    meanhi=min(1.,up(arb(nu)/arb(support['restricted_den_lower'])))
    assert 0<meanlo<meanhi<=1
    k=tr['k'];q=F(orig['Q_lower'])-F(support['restriction']['loss_upper']);target=F(m)/(F(1,4)+F(tr['omega']))
    # Since U=S/sigma is bounded by 1 on the restricted support, U^2<=U.
    def beta(d):return F(d,k)*F(meanlo)-F(d*(d-1),2*k*(k-1)*h)*F(meanhi)
    def margin(d):return F(k-d,k)*q-target*(1-beta(d))
    l=0;r=int(h*(k-1));assert margin(0)>0
    while l+1<r:
        d=(l+r)//2
        if margin(d)>0:l=d
        else:r=d
    assert margin(l)>0 and margin(l+1)<=0
    ceiling=F(k)*(q-target)/(q-target*F(meanhi))
    ideal=(ceiling.numerator-1)//ceiling.denominator
    out=dict(m=m,k=k,dimension=k-l,deleted=l,radial_mean_lower=meanlo,radial_mean_upper=meanhi,weighted_numerator_lower=nl,weighted_numerator_upper=nu,unrestricted_den_upper=orig['den_upper'],restricted_den_lower=support['restricted_den_lower'],bad_mean_correction_upper=up(corr),beta_lower=[beta(l).numerator,beta(l).denominator],raw_margin=[margin(l).numerator,margin(l).denominator],effective_margin_lower=down(ar(margin(l)/(1-beta(l)))),next_raw_margin_upper=up(ar(margin(l+1))),moment_keys=cdf.keys,cdf_errors=cdf.errors,fourier_frequencies=cdf.J,fourier_tail=cdf.tail,alias=list(map(up,cdf.alias)),components=components,precision_bits=ctx.prec,seconds=time.time()-t,method='Uncapped coordinate statistic S/sigma with a*=7/5; inherited quotient and fresh stricter support',optimistic_maximum_deletions=ideal)
    (B/f'uncapped/m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
    np.savez_compressed(B/f'uncapped/m{m}_cdf_data.npz',C=cdf.C,y=cdf.y,L=cdf.L,V=cdf.V)
    print(json.dumps({a:b for a,b in out.items() if not isinstance(b,list)}),flush=True)
    return cdf,out
if __name__=='__main__':
    for m in map(int,sys.argv[1:] or [4,5]):run(m)
