# Unsuccessful larger-cap experiment

`check_support.py` was executed for m=4 and m=5 with a*=7/5.
Both runs failed their restricted-denominator test after the available
support-loss estimate became too large. The logged failures support no new
prime-gap bound. This is a failure of the sufficient numerical estimate, not
an impossibility theorem for this cap or for a different proof.

`radial_mean.py` is an unexecuted prototype for a follow-on calculation. It
was not run because its support prerequisites failed. It is not included in
any final reproduction or bound.
