# Latest continuation: completed residue sets and narrower admissible tuples

Date: 4 November 2026.

## Results and scope

| Quantity | Previous bound | New bound | Analytic dimension |
|---|---:|---:|---:|
| H2 | 19,908 | 19,886 | 2,304 (inherited) |
| H3 | 1,359,440 | 1,359,284 | 110,050 (inherited) |
| H4 | 82,258,490 | unchanged | unchanged |
| H5 | 4,831,230,984 | unchanged | unchanged |

Both new bounds come from new finite admissible tuples, not new successful analytic certificates. The prior analytic framework and successful certificates are retained unchanged. The new integer checks do not independently audit that analytic chain. These are computer-assisted research deductions, not independently reviewed published records.

Read `next23/note.pdf` (or its TeX source) and `next23/RESULTS.json` first. All inherited files are byte-for-byte the same as the preceding archive. Their earlier README files describe earlier stages, not the latest result.

## Checking the result

From this directory:

```bash
bash next23/reproduce.sh --checks-only
```

This compiles two C++ tools, verifies the inherited successful endpoint inequalities using exact fractions, checks both final tuples in separate C++ and Python implementations, checks the new failed analytic inequality, and repeats the complete fixed-witness H2 reconstruction over [-1,000,000, 1,000,000].

Required for checks-only: Python 3, NumPy, and a C++17 compiler (g++ by default; set CXX to override). Assertions must remain enabled. The checker rewrites next23/RESULTS.json deterministically and writes reconstruction output.

```bash
bash next23/reproduce.sh --full
```

This additionally repeats the freshly evaluated **failed** H3 trial at k=110040. It requires the inherited numerical dependencies (NumPy, SciPy, mpmath, C++17/OpenMP) and substantially more memory and computation. It does not rerun the older successful Fourier certificates; their reproduction scripts remain in the inherited directories.

## Authoritative finite data

- `next23/h2_final.csv`: all 2,304 entries, endpoints 4 and 19,890.
- `next23/h2_final_witness.csv`: omitted residues for all required primes.
- `next23/h3_final.csv`: all 110,050 entries, endpoints -626,716 and 732,568.
- `next23/h3_final_witness.csv`: omitted residues for all required primes.
- `next23/verify_results.py`: exact endpoint checks and independent Python admissibility checker.
- `baseline/inherited/tuples/verify_tuple.cpp`: separate C++ checker.
- `next23/recover_tuple.cpp`: reconstructs every integer obeying specified missing-residue constraints, then checks all consecutive windows of the desired cardinality.
- `next23/MANIFEST.json`: SHA-256 checksums for the final data, source, and failed analytic output.
- `next23/PROVENANCE.json`: preceding archive identifier and hash.

CSV tuple files contain one integer per line. Witness files have prime/residue columns. Integers larger in magnitude than the tuple cardinality cause no difficulty; admissibility is verified at all primes up to the cardinality, and larger primes are automatic.

## Unsuccessful and exploratory calculations

The completed evaluation in `next23/m3_k110040.interval_certificate.json` has Q_lower=11.428571128165588, below the target. Its corrected sufficient margin is negative. It does **not** prove DHL[110040,4]. The separately checked `h3_k110040_candidate.csv` therefore supplies no additional prime-gap bound. Failure of a lower enclosure is not an upper bound on the actual quotient.

`m2_mixed_k2302.json` is an exploratory optimizer output, not an interval certificate. `absolute_value_diagnostic.json` is a sampling/quadrature diagnostic, not a certified gain. No conclusion relies on either. Search logs document successful and unsuccessful heuristic searches; checking the final tuples requires no search.

The duplicate large H4 search tuple and compiled binaries are omitted from the new directory; H4 was unchanged. All necessary inherited H4 data and compilation sources are retained. The unexecuted mixed-amplitude prototype is excluded. The archive contains no font files.
