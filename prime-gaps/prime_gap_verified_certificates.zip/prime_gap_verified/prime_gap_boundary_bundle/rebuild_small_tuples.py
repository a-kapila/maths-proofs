"""Reconstruct exact selected windows, then compare saved endpoints and sizes."""
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parent
for m in (2,4):
    meta_path=ROOT/'verification'/f'h{m}_selection.json'
    if not meta_path.exists():
        continue
    meta=json.loads(meta_path.read_text())
    parent=np.loadtxt(ROOT/'baseline'/'inherited'/'tuples'/f'h{m}.csv',dtype=np.int64)
    n=meta['k'];i=meta['start_index']
    selected=parent[i:i+n]
    assert len(selected)==n and np.all(np.diff(selected)>0)
    assert int(selected[0])==meta['first'] and int(selected[-1])==meta['last']
    assert int(selected[-1]-selected[0])==meta['diameter']
    output=ROOT/'verification'/f'h{m}.csv'
    np.savetxt(output,selected,fmt='%d')
    print(json.dumps({'m':m,'tuple':str(output),'k':n,'diameter':meta['diameter']}))
