"""Certify the improvement from retaining selected-coordinate denominator mass.
All final inequalities use Fraction / outward fixed-point rational intervals.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,hashlib
import numpy as np
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1];O=B/'continued'
sys.path.insert(0,str(B/'radial23'))
import final_compute as inherited
base=inherited.base;rad=inherited.rad;J=inherited.J
from intervals import I,log

def power_cells(m):
    meta=json.load(open(O/f'm{m}_power2.json')); tp=B/meta['trial'];tr=json.load(open(tp));zz=np.load(O/f'm{m}_power2_cdf.npz')
    assert meta['trial_sha256']==hashlib.sha256(tp.read_bytes()).hexdigest()
    keys=[tuple(x) for x in meta['moment_keys']];hs=[[F(x) for x in h] for h in tr['profiles']];nc=len(hs[0]);co=defaultdict(lambda:[F(0)]*nc)
    for h,bi in zip(hs,tr['basis']):
        for g,bj in zip(hs,tr['basis']):
            key=tuple(sorted(bi+bj));co[key]=[a+x*y for a,x,y in zip(co[key],h,g)]
    assert set(keys)==set(co)
    edges=[F(tr['delta'])*e for e in tr['E']];assert all(F(float(x))==e for x,e in zip(zz['y'],edges))
    lows=[F(0)]*nc;highs=[F(0)]*nc
    for i,key in enumerate(keys):
        lo=list(map(F,map(float,zz['L'][i])));hi=list(map(F,map(float,zz['V'][i])))
        for j,c in enumerate(co[key]):
            ml=max(F(0),lo[j+1]-hi[j]);mu=hi[j+1]-lo[j];assert 0<=ml<=mu
            lows[j]+=c*(ml if c>=0 else mu);highs[j]+=c*(mu if c>=0 else ml)
    lows=[max(F(0),v) for v in lows];assert all(l<=u for l,u in zip(lows,highs))
    return tr,edges,lows,highs

def inputs(m,updated=True):
    if m==2:
        tp=B/'trials/m2_final.json';tr=json.load(open(tp));su=json.load(open(B/'radial23/m2_k2305_support.json'))
        qp=O/'m2_fine.interval_certificate.json' if updated else tp.with_suffix('.interval_certificate.json')
        c=json.load(open(qp));k=2305;rho=F(1,4)+F(tr['omega']);sigma=1+F(tr['delta'])*tr['eps_cells'];q=F(c['Q_lower'])-F(su['restriction']['loss_upper'])
        src=json.load(open(B/'radial23/m2_k2305_cell_masses.json'));witness='progress/h2_final_witness.csv';extent=1000000
    else:
        k,rho,sigma,q=base.get_inputs(3);src=json.load(open(B/'radial23/m3_cell_masses.json'));witness='onward/h3_completed_witness.csv';extent=5000000
        qp=B/'focus23/m3_fine.interval_certificate.json'
    rad._CELLS[m]=src;rad._MOM.clear()
    tr,edges,lows,highs=power_cells(m)
    U=(I(F(tr['beta']))/log(k)/sigma).hi
    assert 0<U<1
    return dict(k=k,rho=rho,sigma=sigma,q=q,src=src,tr=tr,edges=edges,lows=lows,highs=highs,U=U,witness=witness,extent=extent,quotient_source=str(qp.relative_to(B)))

def hfun(k,eta,zeta,U,x):
    # c2 and the secant slope are nonnegative and increasing in x, for eta>=1.
    assert eta>=1 and 0<=x<=1
    c2=(2*eta*(k-2)*(1-x)+eta**2*((2*k-1)*x-k*U))/(k-1)
    d=1-zeta*x;L=min(2*U,x)
    slope=zeta*(2*d+zeta*L)/(d*d*(d+zeta*L)**2)
    assert c2>=0 and d>0
    return slope*c2

def correction(v,eta,zeta):
    k=v['k'];U=v['U'];sigma=v['sigma'];src=v['src'];den=F(*src['den_upper']);bad=F(*src['removed_square_mass_upper'])
    tot=I(0)
    for x,mass in zip(v['edges'][:-1],v['lows']):
        if mass:tot+=I(mass)*hfun(k,eta,zeta,U,x/sigma)
    loss=hfun(k,eta,zeta,U,F(1))*U*bad
    lower=(tot.lo-loss)/den
    assert lower>0
    return dict(correction_lower=lower,uncorrected_integral_lower=tot.lo,removed_correction_upper=loss,den_upper=den,coordinate_cap_upper=U)

def compute(m,updated=True,eta=None):
    v=inputs(m,updated);k=v['k'];rho=v['rho'];sig=v['sigma'];zeta=2*rho*sig
    # Float candidate selection only; all results are reevaluated with fractions.
    src=v['src'];xx=np.array([float(F(*c['right'])/sig) for c in src['cells']]);mass=np.array([float(F(*c['mass_lower'])) for c in src['cells']]);mask=xx>0;xx=xx[mask];mass=mass[mask]
    left=np.array([float(x/sig) for x in v['edges'][:-1]]);p2mass=np.array(list(map(float,v['lows'])));uf=float(v['U']);zf=float(zeta);den=float(F(*src['den_upper']));bad=float(F(*src['removed_square_mass_upper']))
    def approx_h(e,x):
        c2=(2*e*(k-2)*(1-x)+e*e*((2*k-1)*x-k*uf))/(k-1);d=1-zf*x;L=np.minimum(2*uf,x)
        return zf*(2*d+zf*L)/(d*d*(d+zf*L)**2)*c2
    def obj(e):
        r1=(e/(1-zf))**2;rr=(1+(e-1)*xx)/(1-zf*xx)
        mom=r1-((mass*(r1-rr*rr)/xx).sum()-r1*bad)/den
        corr=((p2mass*approx_h(e,left)).sum()-approx_h(e,1)*uf*bad)/den
        return 2*zf*zf*base.jf(k,k*e)*(mom-corr)
    opt=minimize_scalar(obj,bounds=(1.0,1.7),method='bounded',options={'xatol':1e-9})
    if eta is None:eta=F(round(float(opt.x)*10**6),10**6)
    assert eta>=1 and 2*(k-2)-eta*k*v['U']>=0
    mo=rad.radial_moment(m,eta,zeta);cr=correction(v,eta,zeta);jj=J(k,k*eta)
    pold=2*zeta*zeta*jj.hi*mo['moment_upper'];pair=2*zeta*zeta*jj.hi*(mo['moment_upper']-cr['correction_lower']);assert 0<pair<pold
    surplus=rho*v['q']-m;rat=surplus/pair;budget=(rat.numerator-1)//rat.denominator
    lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);zs=lam*sig/b
    mos=rad.radial_moment(m,eta,zs);crs=correction(v,eta,zs);pairs=2*zs*zs*jj.hi*(mos['moment_upper']-crs['correction_lower']);surs=lam*v['q']-m
    w=base.load_witness(v['witness']);arr=base.allowed(w,-v['extent'],v['extent']);sub,sel=base.choose(arr,k,budget)
    for p in base.primes_up_to(k):
        if int(p) not in w:
            missing=np.flatnonzero(np.bincount(sub%p,minlength=int(p))==0);assert len(missing);w[int(p)]=int(missing[0])
    cnt=sel['long_pairs'];margin=surplus-cnt*pair;strict=surs-cnt*pairs
    assert margin>0 and strict>0
    name=f'm{m}' if updated else f'm{m}_oldquotient'
    np.savetxt(O/f'{name}_tuple.txt',sub,fmt='%d');np.savetxt(O/f'{name}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
    plist=base.enumerate_long_pairs(sub,sel['D']);assert len(plist)==cnt
    np.savetxt(O/f'{name}_long_pairs.csv',plist,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
    out=dict(m=m,k=k,eta=eta,rho=rho,sigma=sig,quotient_lower_after_loss=v['q'],quotient_source=v['quotient_source'],J_lower=jj.lo,J_upper=jj.hi,radial=mo,correction=cr,pair_upper=pair,uncorrected_pair_upper_same_eta=pold,surplus=surplus,budget=budget,selection=sel,first=int(sub[0]),last=int(sub[-1]),tuple_diameter=int(sub[-1]-sub[0]),margin=margin,strict_margin=strict,strict_pair_upper=pairs,strict_correction=crs,strict_radial=mos,previous_bound={2:19850,3:1358016}[m])
    (O/f'{name}_result.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
    print(name,sel,'eta',float(eta),'pair',float(pair),'surplus',float(surplus),'correction factor',1-float(pair/pold),'margin',float(margin),flush=True)
    return out
if __name__=='__main__':
    for arg in sys.argv[1:]:
        if arg!='--old':compute(int(arg),updated=not ('--old' in sys.argv))
