"""Independent supplementary checks for the new tagged Fourier computations.
These are diagnostics; inherited analytic remainder bounds remain the proof.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math,time
import numpy as np
import mpmath as mp
B=Path(__file__).resolve().parents[1];O=B/'continued'
sys.path[:0]=[str(B/'continued'),str(B/'direct_mean'),str(B/'fused_pair')]
from power_mean import PowerCDF,ctx
from capped_mean import tagged_weights,acb
from intervals import J
mp.mp.dps=80;ctx.prec=256

def mpv(a):return mp.make_mpf(a.x._mpi_[0])
count=0;worst=mp.mpf(0)
for m in [2,3]:
 path=B/('trials/m2_final.json'if m==2 else 'focus23/m3_fine.json');tr=json.load(open(path));sig=1+F(tr['delta'])*tr['eps_cells'];ob=PowerCDF(tr,sig,2);me=json.load(open(O/f'm{m}_power2.json'));z=np.load(O/f'm{m}_power2_cdf.npz')
 mu,nu=ob.moments();mass=tagged_weights(tr['k'],mu,nu,ob.keys)
 # Verify exact integral recurrences against independent high-precision quadrature.
 k=tr['k'];theta=mp.mpf(tr['theta']);beta=mp.mpf(tr['beta']);rr=mp.mpf(tr['relative_shift']);c=theta/mp.log(k);T=beta/mp.log(k);b=k-1;A=rr/(c+b*T)
 g=lambda x:1/(c+b*x)+A
 m2=(1/c-1/(c+b*T))/b+2*A*mp.log((c+b*T)/c)/b+A*A*T
 for xi in [0,3,30]:
  terms=ob.moments('zero')if xi==0 else ob.moments('fourier',xi)
  mm,nn=terms
  for j in [0,2,ob.jmax-2]:
   # Independent log-coordinate substitution resolves the narrow mass near zero.
   L=mp.log(1+b*T/c)
   def integrand(y):
    x=c*mp.expm1(y)/b;dx=c*mp.exp(y)/b
    return (x/mp.mpf(float(sig)))**2*(x/T)**j*g(x)**2*mp.exp(1j*xi*x)*dx/m2
   val=mp.quad(integrand,[0,L/4,L/2,3*L/4,L]);enc=nn[j]
   if xi==0:
    lo,hi=mpv(enc.lower()),mpv(enc.upper());assert lo<=val.real<=hi
   else:
    enc=acb(enc)
    assert mpv(enc.real.lower())<=val.real<=mpv(enc.real.upper())
    assert mpv(enc.imag.lower())<=val.imag<=mpv(enc.imag.upper())
   count+=1
 # Independently sum the saved finite Fourier polynomial at three profile boundaries.
 C=z['C'];freq=2*mp.pi/8;Jnum=C.shape[1]
 for at in [len(z['y'])//4,len(z['y'])//2,3*len(z['y'])//4]:
  y=mp.mpf(float(z['y'][at]));ph=[mp.exp(-1j*freq*y*j)for j in range(1,Jnum+1)]
  for r in range(len(ob.keys)):
   cc=[mp.mpc(float(v.real),float(v.imag))for v in C[r]]
   finite=mpv(mass[r].mid())*y/8+2*mp.fsum(v.real for v in cc)-2*mp.fsum((v*p).real for v,p in zip(cc,ph))
   assert mp.mpf(float(z['L'][r,at]))<=finite<=mp.mpf(float(z['V'][r,at])),(m,r,at)
   count+=1
 print('moment diagnostics passed',m,flush=True)
result=dict(passed=True,integral_comparisons=18,finite_Fourier_comparisons=96,total_comparisons=count,mp_digits=mp.mp.dps,interval_bits=ctx.prec,scope='Independent quadrature and finite-series diagnostics; not substitutes for certified tails and rounding bounds.')
(O/'moment_diagnostics.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
