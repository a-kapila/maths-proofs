#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
mode="${1:---checks-only}"
case "$mode" in --checks-only|--full) ;; *) echo 'usage: bash continued/reproduce.sh --checks-only|--full' >&2; exit 2;; esac
python continued/check_manifest.py
if [[ "$mode" == --full ]]; then
 g++ -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
 g++ -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off progress/profile_parallel.cpp -o progress/profile_parallel.so
 g++ -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
 python -u continued/run_quotient.py continued/m2_fine.json
 python -u continued/power_mean.py 2 2
 python -u continued/power_mean.py 3 2
fi
python continued/check_math.py
python continued/check_moments.py
python -u continued/verify.py
