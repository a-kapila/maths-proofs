from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parents[1]
d=json.load(open(B/'continued/MANIFEST.json'))
for p,h in d['files'].items():
 assert hashlib.sha256((B/p).read_bytes()).hexdigest()==h,p
print('Manifest passed:',len(d['files']),'files')
