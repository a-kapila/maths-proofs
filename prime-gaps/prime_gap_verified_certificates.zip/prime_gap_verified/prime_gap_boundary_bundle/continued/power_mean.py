"""Positive tagged-power Fourier enclosure, reusing the previous error bounds.
Tag is sum_i (t_i/sigma)^p. The base moment identities, alias and tail
arguments are unchanged: one labelled nonnegative factor is inserted.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'direct_mean'))
from capped_mean import CappedMeanCDF,ar,ctx,up
from multi_core import single_moments
class PowerCDF(CappedMeanCDF):
    def __init__(self,tr,sigma,p):
        super().__init__(tr,sigma)
        assert p>=1
        self.power=p
        self.jmax += p-1
    def moments(self,kind='zero',value=0):
        mu=single_moments(self.S,self.jmax,kind,value)
        fac=(self.S['T']/ar(self.sigma))**self.power
        nu=[fac*mu[j+self.power] for j in range(self.jmax-self.power+1)]
        return mu,nu

def run(m,p):
    ctx.prec=256;start=time.time()
    tp=B/({2:'trials/m2_final.json',3:'focus23/m3_fine.json',4:'accurate/m4.json',5:'accurate/m5.json'}[m])
    tr=json.load(open(tp));sigma=1+F(tr['delta'])*tr['eps_cells']
    o=PowerCDF(tr,sigma,p);o.run_setup();nl,nu,components=o.evaluate()
    prefix=B/f'continued/m{m}_power{p}'
    out=dict(m=m,k=tr['k'],power=p,sigma=[sigma.numerator,sigma.denominator],tag='sum (t_i/sigma)^p',
        weighted_numerator_lower=nl,weighted_numerator_upper=nu,moment_keys=o.keys,cdf_errors=o.errors,
        fourier_frequencies=o.J,fourier_tail=o.tail,alias=list(map(up,o.alias)),components=components,
        precision_bits=ctx.prec,seconds=time.time()-start,trial=str(tp.relative_to(B)),trial_sha256=hashlib.sha256(tp.read_bytes()).hexdigest())
    prefix.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    np.savez_compressed(str(prefix)+'_cdf.npz',C=o.C,y=o.y,L=o.L,V=o.V)
    print(json.dumps({k:v for k,v in out.items() if not isinstance(v,list)}),flush=True)
if __name__=='__main__':run(int(sys.argv[1]),int(sys.argv[2]))
