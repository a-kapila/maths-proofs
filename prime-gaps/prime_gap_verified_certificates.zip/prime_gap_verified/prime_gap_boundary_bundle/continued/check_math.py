"""Exact finite checks of the new algebra. Diagnostics supplement the proof."""
from pathlib import Path
from fractions import Fraction as F
import random,itertools,json
B=Path(__file__).resolve().parent;rng=random.Random(501107)
counts=dict(weight_identity=0,weighted_pair_mass_identity=0,secant_inequality=0,final_pointwise_bound=0,monotonicity=0,tagged_moments=0)
for z in range(1000):
    k=rng.randint(4,22);ys=[F(rng.randrange(0,15),100) for _ in range(k)];scale=max(F(1),sum(ys));ys=[y/scale for y in ys]
    x=sum(ys);U=max(max(ys),F(2,5));U=min(U,F(1));eta=F(rng.randint(100,130),100);zeta=F(rng.randint(40,58),100);a=k*eta;r=1-x;d=1-zeta*x
    w=[];actual=[];M=[]
    for i,j in itertools.combinations(range(k),2):
        yi,yj=ys[i],ys[j];u=yi+yj
        W=(r+a*yi)*(r+a*yj)+a*a*F(1,2*k)*(yi-yj)**2
        w.append(W);M.append(W*u);actual.append(W/(d+zeta*u)**2)
    n=F(k*(k-1),2);P2=sum(y*y for y in ys);P3=sum(y**3 for y in ys)
    assert sum(w)/n==(r+eta*x)**2;counts['weight_identity']+=1
    identity=2*r*r*x/k+2*r*a*(x*x+(k-2)*P2)/(k*(k-1))+a*a*((2*k-1)*x*P2-k*P3)/(k*k*(k-1))
    assert sum(M)/n==identity;counts['weighted_pair_mass_identity']+=1
    c2=(2*eta*(k-2)*(1-x)+eta*eta*((2*k-1)*x-k*U))/(k-1)
    assert sum(M)/n>=c2*P2
    L=min(2*U,x)
    if L==0:continue
    slope=zeta*(2*d+zeta*L)/(d*d*(d+zeta*L)**2)
    for u in [F(i,10)*L for i in range(11)]:
        assert 1/(d+zeta*u)**2<=1/d**2-slope*u;counts['secant_inequality']+=1
    assert sum(actual)/n<=((r+eta*x)/d)**2-slope*c2*P2;counts['final_pointwise_bound']+=1
    # Here c2 is increasing because eta>=1; verify the full product on a grid.
    vals=[]
    for j in range(11):
        xx=F(j,10);dd=1-zeta*xx;LL=min(2*U,xx)
        cc=(2*eta*(k-2)*(1-xx)+eta*eta*((2*k-1)*xx-k*U))/(k-1)
        vals.append(zeta*(2*dd+zeta*LL)/(dd*dd*(dd+zeta*LL)**2)*cc)
    assert all(v<=w for v,w in zip(vals,vals[1:]));counts['monotonicity']+=1
# Exact tagged moment partition checks against all finite product-law outcomes.
import sys
R=B.parent;sys.path[:0]=[str(R/'direct_mean')]
from capped_mean import tagged_weights
support=[F(0),F(1,5),F(3,5)];prob=[F(1,4),F(1,2),F(1,4)]
keys=[(),(2,),(3,),(4,),(2,2),(2,3),(2,2,2),(2,2,2,2)]
for n in [5,6]:
    mu=[sum(p*x**j for p,x in zip(prob,support)) for j in range(16)]
    for tag in [2,3]:
        nu=[mu[j+tag] for j in range(11)]
        expr=tagged_weights(n,mu,nu,keys);brute=[F(0) for _ in keys]
        for inds in itertools.product(range(3),repeat=n):
            xs=[support[i] for i in inds];pr=F(1)
            for i in inds:pr*=prob[i]
            sums={j:sum(x**j for x in xs) for j in range(1,5)};t=sum(x**tag for x in xs)
            for ii,key in enumerate(keys):
                v=t
                for j in key:v*=sums[j]
                brute[ii]+=pr*v
        assert expr==brute;counts['tagged_moments']+=len(keys)
result=dict(passed=True,**counts)
(B/'math_checks.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
