"""Interval/exact pointwise amplitude envelope for basis 1,Z2,Z3,Z4,Z2^2,Z2Z3.
Each U=Z2 range is treated separately; no probabilistic assumptions.
Floating optimization selects b only. Retained bounds use interval arithmetic
and exact rational quadratic maxima.
"""
from pathlib import Path
import sys,json,time,hashlib,math
from fractions import Fraction as F
import numpy as np
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'focus23'),str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup
from moment_amplitude import cubic_max_float,amax_interval

def qmax(b,c,L,R):
 vals=[b*L+c*L*L,b*R+c*R*R]
 if c<0:
  x=-b/(2*c)
  if L<x<R:vals.append(b*x+c*x*x)
 return max(vals)

def run(path,outfile,bins=32):
 ctx.prec=256;t=time.time();tr=json.load(open(path));assert tr['basis']==[[],[2],[3],[4],[2,2],[2,3]]
 S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift']);records=[];C=0.
 for j in range(len(tr['E'])-1):
  z=float(np.nextafter(float((arb(tr['E'][j+1])*arb(tr['delta'])/S['T']).upper()),np.inf));zf=F(z);n=zf.numerator//zf.denominator;Umax=min(F(tr['k']),n+(zf-n)**2)
  hs=[F(p[j]) for p in tr['profiles']]
  if all(x==0 for x in hs):records.append(dict(cell=j,upper=0.));continue
  rec=[]
  for sign in (1,-1):
   h0,h2,h3,h4,h22,h23=[sign*x for x in hs]
   for u in range(bins):
    L=Umax*u/bins;R=Umax*(u+1)/bins
    h3top=h3+h23*(R if h23>=0 else L)
    # Rounding this coefficient upward preserves an upper bound since Z3>=0.
    h3f=float(np.nextafter(float(h3top),np.inf));lf,rf=float(L),float(R);h0f,h2f,h4f,h22f=map(float,(h0,h2,h4,h22))
    def obj(b):
     quad=max(b*lf+h22f*lf*lf,b*rf+h22f*rf*rf)
     if h22f<0:
      v=-b/(2*h22f)
      if lf<v<rf:quad=max(quad,b*v+h22f*v*v)
     return h0f+z*cubic_max_float(b,h2f,h3f,h4f)+quad
    scale=max(1.,abs(h2f)+abs(h3f)+abs(h4f)+2*abs(h22f)*rf)
    res=minimize_scalar(obj,bounds=(-4*scale,4*scale),method='bounded',options={'xatol':1e-10})
    b=float(res.x);a=amax_interval(b,h2f,h3f,h4f);quad=qmax(F(b),h22,L,R)
    val=arb(h0.numerator)/h0.denominator+arb(z)*a+arb(quad.numerator)/quad.denominator
    upper=float(np.nextafter(float(val.upper()),np.inf));C=max(C,upper)
    rec.append(dict(sign=sign,U=[str(L),str(R)],b=b,h3_upper=h3f,a_upper=float(np.nextafter(float(a.upper()),np.inf)),upper=upper))
  records.append(dict(cell=j,z_upper=z,Umax=str(Umax),upper=max(x['upper'] for x in rec),pieces=rec))
 out=dict(trial=str(path),trial_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),k=tr['k'],basis=tr['basis'],bins=bins,amplitude_upper=C,cells=records,seconds=time.time()-t,precision_bits=ctx.prec)
 Path(outfile).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='cells'}),flush=True);return out
if __name__=='__main__':run(sys.argv[1],sys.argv[2],int(sys.argv[3]) if len(sys.argv)>3 else 32)
