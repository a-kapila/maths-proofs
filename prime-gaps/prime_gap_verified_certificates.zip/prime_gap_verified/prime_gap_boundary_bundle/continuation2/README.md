# Long-pair penalty continuation

Latest results, conditional only on the inherited analytic/certificate chain:
H2 <= 19860 (unchanged); H3 <= 1358106; H4 <= 82240686; H5 <= 4830609154.

Read proof_note.pdf for the new mathematical argument. It uses an elementary
cluster/long-edge inequality and an auxiliary two-coordinate Selberg square,
together with the published unweighted second moment and the bound
M_k <= k log(k)/(k-1). No prime-pair asymptotic is assumed.

The new certificate is NOT a smaller-dimensional DHL statement. The explicit
tuples have larger diameters than the certified cluster lengths. Symmetric
trials at k=110070, 5090000 and 232500000 supply a prime-count surplus that
pays for a rigorously bounded number of prime pairs with separation > D.

## Reproduce all new finite calculations
From the archive root:

    bash continuation2/reproduce.sh

Requires Python 3 with NumPy/mpmath, and a C++17/OpenMP compiler. Assertions
must stay enabled. The complete H5 sieve needs about 1.5 GB RAM. Source and
compressed residue data are included; no network download is needed.

The script reconstructs the H5 witness sequence with checksum checks, checks
all 12,204,094 witnesses, regenerates the high-prime tail, repeats all
long-pair window scans, repeats the integer tuple checks and C++ pair counts,
and reevaluates the exact rational inequalities. The H3 direct-reduction
Python check is separate from the C++ arithmetic-progression checker.

No earlier Fourier quotients or arithmetic loss bounds are reevaluated by
this command. Those inputs are retained in focus23/ and accurate/, with the
original reproduction commands and all their inherited dependencies. The
new argument remains dependent on the validity of those certificates and
the underlying sieve implication. No independent expert review is claimed.

## Principal new files
- pair_penalty.py: rational logarithm bounds, scalar criterion, H3 selection.
- pair_h4.py, pair_h5.py: complete consecutive-window scans at fixed K.
- check_pair_counts.cpp: separate exact pair counts (no floating arithmetic).
- verify_h5_export.cpp: inherited independent byte sieve/witness verifier,
  with additional export of the required prime tail.
- h3_pair_tuple.csv, h3_pair_witness.csv, h3_long_pairs.csv: explicit finite data.
- h{3,4,5}_pair_result.json: exact rational constants and selected windows.
- h{3,4}_tuple_verified.json, h5_parent_verified.json: full integer checks.
- h{3,4,5}_pairs_verified.json: separate pair counts.
- check_new.py, diagnostics.json: exact deductions and supplementary tests.
- RESULTS.json and MANIFEST.json: authoritative summary and source hashes.

The large H4 selected tuple is regenerated from its included parent. The H5
selected tuple is represented by the complete parent witness sequence and
negative/positive rank counts; a 232-million-line text file is unnecessary.

## Exploratory/unsuccessful files
scout.py, refine.py, regularized.py and their logs/trials record non-rigorous
optimization. m2_regularized_600.json has no new interval certificate and is
not used in the reported bounds. pair_descent.cpp and its logs record two-
residue local searches that did not improve either target. mixed_amplitude.py
is an unexecuted proposed refinement and is not part of any certificate.

No global tuple optimum, optimal variational value, terminal prime-gap bound,
new distribution exponent, or publication-priority claim is made.
