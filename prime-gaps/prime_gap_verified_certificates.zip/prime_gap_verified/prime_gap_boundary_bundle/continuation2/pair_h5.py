from pair_penalty import *
import struct,sys
sys.set_int_max_str_digits(0)
p=ROOT/'continuation2/recomputed/h5_tail.bin'
with open(p,'rb') as f:
 rank0,N=struct.unpack('<QQ',f.read(16));a=np.fromfile(f,dtype='<u4').astype(np.int64)
assert len(a)==N-rank0+1 and np.all(np.diff(a)>0)
v=constants('accurate/m5.json','accurate/m5.interval_certificate.json');K=v['k'];nmin=K-N
print({k:float(x) if isinstance(x,F) else x for k,x in v.items()},flush=True)

def counts(D):
 # All potentially long pairs have both positive magnitudes in the saved tail.
 assert D-int(a[-1])>=int(a[0])
 # r[i] = number of all retained positive primes q <= D-a[i].
 r=np.searchsorted(a,D-a,side='right')+rank0-1
 first=int(np.maximum(0,N-r[:nmin-rank0+1]).sum())
 n=np.arange(nmin,N,dtype=np.int64);m=K-n
 remove=np.maximum(0,n-r[m-rank0]);add=np.maximum(0,m-1-r[n+1-rank0])
 out=np.empty(N-nmin+1,dtype=np.int64);out[0]=first;out[1:]=first+np.cumsum(add-remove)
 assert out.min()>=0
 return out
hi=4832855872//2;lo=hi-5000000
while lo<hi:
 mid=(lo+hi)//2;c=counts(mid*2)
 if int(c.min())<=v['budget']:hi=mid
 else:lo=mid+1
D=lo*2;c=counts(D);ix=int(c.argmin());neg=nmin+ix;pos=K-neg
# Independent direct count in this one window, summing over negative magnitudes.
count2=int(np.maximum(0,pos-(np.searchsorted(a,D-a[:neg-rank0+1],side='right')+rank0-1)).sum())
assert count2==int(c[ix])
res=dict(D=D,long_pairs=count2,previous_even_min_count=int(counts(D-2).min()),windows=len(c),negative_count=neg,positive_count=pos,first=-int(a[neg-rank0]),last=int(a[pos-rank0]),tail_first_rank=rank0,parent_positive_count=N,tail_first=int(a[0]),trial='accurate/m5.json',certificate='accurate/m5.interval_certificate.json')
res['diameter']=res['last']-res['first'];res['remaining_margin']=fractions_json({'value':v['surplus']-res['long_pairs']*v['pair']})['value']
print({k:x for k,x in res.items() if k!='remaining_margin'},flush=True);print('remaining',res['remaining_margin']['display'],flush=True)
(ROOT/'continuation2/h5_pair_result.json').write_text(json.dumps(dict(constants=fractions_json(v),selection=res),indent=2)+'\n')
