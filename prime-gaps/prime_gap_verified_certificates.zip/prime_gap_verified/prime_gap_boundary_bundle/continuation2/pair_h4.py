from pair_penalty import *
import time
v=constants('accurate/m4.json','accurate/m4.interval_certificate.json');print({k:float(x) if isinstance(x,F) else x for k,x in v.items()},flush=True)
a=np.loadtxt(ROOT/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
subset,res=choose(a,v['k'],v['budget']);res.update(first=int(subset[0]),last=int(subset[-1]),diameter=int(subset[-1]-subset[0]),points=len(a),trial='accurate/m4.json',certificate='accurate/m4.interval_certificate.json',tuple_source='baseline/inherited/tuples/h4.csv')
res['remaining_margin']=fractions_json({'value':v['surplus']-res['long_pairs']*v['pair']})['value']
print({k:x for k,x in res.items() if k!='remaining_margin'},flush=True);print('margin',res['remaining_margin']['display'],flush=True)
out=ROOT/'continuation2';np.savetxt(out/'h4_pair_tuple.csv',subset,fmt='%d')
(out/'h4_pair_result.json').write_text(json.dumps(dict(constants=fractions_json(v),selection=res),indent=2)+'\n')
