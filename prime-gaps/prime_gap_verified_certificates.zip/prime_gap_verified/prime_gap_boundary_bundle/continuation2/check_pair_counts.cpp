#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
int main(int argc,char**argv){
 assert(argc>=4);std::string mode=argv[1];uint64_t D=std::stoull(argv[3]),count=0;
 if(mode=="tuple"){
  std::ifstream f(argv[2]);std::vector<int64_t>a;int64_t x;while(f>>x)a.push_back(x);assert(a.size()>2);
  size_t j=1;for(size_t i=0;i<a.size();++i){j=std::max(j,i+1);while(j<a.size()&&a[j]-a[i]<=int64_t(D))++j;count+=a.size()-j;}
  std::cout<<"{\"mode\":\"tuple\",\"k\":"<<a.size()<<",\"D\":"<<D<<",\"long_pairs\":"<<count<<"}\n";
 }else{
  assert(mode=="signed"&&argc==6);uint64_t neg=std::stoull(argv[4]),pos=std::stoull(argv[5]),r0,N;
  std::ifstream f(argv[2],std::ios::binary);assert(f);f.read((char*)&r0,8);f.read((char*)&N,8);
  std::vector<uint32_t>a;uint32_t q;while(f.read((char*)&q,4))a.push_back(q);assert(a.size()==N-r0+1&&neg<=N&&pos<=N);
  assert(D-a.back()>=a.front());uint64_t endneg=neg-r0+1,endpos=pos-r0+1,j=endpos;
  for(uint64_t i=0;i<endneg;i++){while(j>0&&uint64_t(a[i])+a[j-1]>D)j--;count+=endpos-j;}
  std::cout<<"{\"mode\":\"signed\",\"k\":"<<neg+pos<<",\"D\":"<<D<<",\"long_pairs\":"<<count<<",\"negative_count\":"<<neg<<",\"positive_count\":"<<pos<<"}\n";
 }
}
