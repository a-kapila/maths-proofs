"""Refine exploratory trial; not a rigorous certificate."""
from pathlib import Path
import sys,json,time
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import optimize
m=int(sys.argv[1]);n=int(sys.argv[2]) if len(sys.argv)>2 else 400
D=json.load(open(B/f'continuation2/m{m}_scout_best.json'))
basis=[tuple(x) for x in D['basis']]
r=optimize(D,basis,ncell=n,N=2**20,ng=48,spacing=2**-23,tol=1e-12)
D.update(r);D['status']='exploratory only; no interval certificate'
(B/f'continuation2/m{m}_refined{n}.json').write_text(json.dumps(D,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ['E','profiles']}),flush=True)
