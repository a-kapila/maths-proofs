"""Independent finite tests plus exact saved endpoint checks."""
from pair_penalty import *
import itertools,random,mpmath as mp,hashlib
mp.mp.dps=120
rng=random.Random(385081)
# Cross-check rational log enclosures using a separate high-precision implementation.
logcases=[2,110070,110069,5090000,5089999,232500000,232499999]+[rng.randrange(2,10**12) for _ in range(93)]
for n in logcases:
 lo,hi=log_rational(n);v=mp.log(n)
 assert mp.mpf(lo.numerator)/lo.denominator<=v<=mp.mpf(hi.numerator)/hi.denominator
# Exhaustive subsets of random finite ordered point sets check cluster/penalty lemma.
graph_cases=0
for _ in range(70):
 a=sorted(rng.sample(range(70),9));D=rng.randrange(1,70);m=rng.randrange(1,6)
 for bits in range(1<<len(a)):
  z=[x for i,x in enumerate(a) if bits>>i&1];X=len(z)
  Y=sum(b-a>D for a,b in itertools.combinations(z,2))
  maxcluster=max([sum(y-x<=D and y>=x for y in z) for x in z]+[0])
  if maxcluster<=m:assert X-m<=Y
  if X-m-Y>0:assert maxcluster>=m+1
  graph_cases+=1
# All window counts compared with independent double loops on small arrays.
window_cases=0
for _ in range(300):
 a=np.array(sorted(rng.sample(range(400),rng.randrange(4,35))),dtype=np.int64);k=rng.randrange(2,len(a)+1);D=rng.randrange(1,400)
 got=counts_windows(a,k,D)
 for st,x in enumerate(got):
  sub=a[st:st+k];want=sum(int(y-x)>D for x,y in itertools.combinations(sub,2));assert int(x)==want;window_cases+=1
# Signed-prime-tail recurrence checked on arbitrary finite positive lists.
signed_cases=0
for _ in range(200):
 a=np.array(sorted(rng.sample(range(1,200),rng.randrange(10,35))),dtype=np.int64);N=len(a);K=rng.randrange(N+1,2*N+1);n0=K-N;D=rng.randrange(1,400)
 r=np.searchsorted(a,D-a,side='right')
 first=int(np.maximum(0,N-r[:n0]).sum());counts=[first]
 for n in range(n0,N):
  m=K-n;counts.append(counts[-1]-max(0,n-int(r[m-1]))+max(0,m-1-int(r[n])))
 for n,c in zip(range(n0,N+1),counts):
  m=K-n;want=sum(int(x)+int(y)>D for x in a[:n] for y in a[:m]);assert c==want;signed_cases+=1
# Every reported inequality is evaluated anew with rational endpoint data.
rows=[]
for m in (3,4,5):
 rec=json.load(open(ROOT/f'continuation2/h{m}_pair_result.json'));sel=rec['selection'];v=constants(sel['trial'],sel['certificate'])
 for field,val in v.items():
  saved=rec['constants'][field]
  if isinstance(val,F):assert val==F(saved['num'],saved['den'])
  else:assert val==saved
 margin=v['surplus']-sel['long_pairs']*v['pair'];assert margin>0
 assert v['surplus']-sel['previous_even_min_count']*v['pair']<=0
 # An explicit strict shrink still preserves the positive first-moment margin.
 assert margin-F(1,2**60)*v['q']>0
 verify=json.load(open(ROOT/f'continuation2/h{m}_pairs_verified.json'))
 assert verify['long_pairs']==sel['long_pairs'] and verify['D']==sel['D'] and verify['k']==v['k']
 rows.append(dict(m=m,k=v['k'],D=sel['D'],long_pairs=sel['long_pairs'],margin=float(margin)))
report=dict(log_comparisons=len(logcases),cluster_subset_checks=graph_cases,window_pair_checks=window_cases,signed_tail_checks=signed_cases,exact_deductions=rows)
(ROOT/'continuation2/diagnostics.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
