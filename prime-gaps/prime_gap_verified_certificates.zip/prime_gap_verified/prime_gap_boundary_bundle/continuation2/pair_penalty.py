"""Exact scalar checks and integer long-pair search. No new Fourier calculation."""
from fractions import Fraction as F
from pathlib import Path
import json, math, numpy as np
ROOT=Path(__file__).resolve().parents[1]
def log_rational(n, terms=70):
    assert n>=1
    def atanh_series(z):
        z2=z*z; pw=z; s=F(0)
        for j in range(terms):
            s+=2*pw/(2*j+1);pw*=z2
        return s, s+2*pw/((2*terms+1)*(1-z2))
    lo2,hi2=atanh_series(F(1,3)); e=n.bit_length()-1
    z=F(n-(1<<e),n+(1<<e));lo,hi=atanh_series(z)
    return e*lo2+lo,e*hi2+hi

def constants(trial,certificate, arithmetic=None):
    t=json.load(open(ROOT/trial));c=json.load(open(ROOT/certificate));k=t['k'];m=t['m']
    omega=t['omega']; loss=c['restriction']['loss_upper']
    if arithmetic:
        ar=json.load(open(ROOT/arithmetic));omega=ar['omega'];loss=ar['support']['loss_upper']
    rho=F(1,4)+F(omega);sig=1+F(t['delta'])*t['eps_cells']
    q=F(c['Q_lower'])-F(loss);s=rho*sig
    assert 0<s<F(1,2)
    assert 240*F(omega)+80*F(t['smooth_delta'] if not arithmetic else ar['delta'])<3
    lk=log_rational(k);lm=log_rational(k-1)
    pair=2*s*s/(F(1,2)-s)**2*lk[1]*lm[1]/((k-1)*(k-2))
    surplus=rho*q-m; budget=(surplus.numerator*pair.denominator-1)//(surplus.denominator*pair.numerator)
    assert surplus-budget*pair>0 and surplus-(budget+1)*pair<=0
    return dict(k=k,m=m,rho=rho,sigma=sig,q=q,pair=pair,surplus=surplus,budget=budget)

def load_witness(p):
    return dict(map(tuple,np.loadtxt(ROOT/p,delimiter=',',skiprows=1,dtype=np.int64)))
def primes_up_to(n):
    a=np.ones(n+1,dtype=bool);a[:2]=False
    for p in range(2,math.isqrt(n)+1):
        if a[p]:a[p*p::p]=False
    return np.flatnonzero(a)
def allowed(w,L,R):
    mask=np.ones(R-L+1,dtype=bool)
    for p,r in w.items():mask[(int(r)-L)%int(p)::int(p)]=False
    return np.flatnonzero(mask).astype(np.int64)+L

def counts_windows(a,k,D):
    n=len(a);r=np.searchsorted(a,a+D,side='right');l=np.searchsorted(a,a-D,side='left')
    first=int(np.maximum(0,k-r[:k]).sum())
    idx=np.arange(n-k,dtype=np.int64)
    remove=np.maximum(0,idx+k-r[:n-k]);add=np.maximum(0,l[k:]-(idx+1))
    counts=np.empty(n-k+1,dtype=np.int64);counts[0]=first;counts[1:]=first+np.cumsum(add-remove)
    assert np.min(counts)>=0
    return counts

def choose(a,k,budget):
    hi=int(np.min(a[k-1:]-a[:len(a)-k+1]))//2
    lo=max(0,hi-100000)
    while lo<hi:
        mid=(lo+hi)//2;counts=counts_windows(a,k,2*mid)
        if int(counts.min())<=budget:hi=mid
        else:lo=mid+1
    D=2*lo;cnt=counts_windows(a,k,D);idx=int(cnt.argmin());old=counts_windows(a,k,D-2)
    return a[idx:idx+k],dict(D=D,long_pairs=int(cnt[idx]),previous_even_min_count=int(old.min()),windows=len(cnt),index=idx)

def enumerate_long_pairs(a,D):
    out=[]
    for i in range(len(a)):
        j=int(np.searchsorted(a,int(a[i])+D,side='right'))
        if j==len(a):break
        out.extend((i,q,int(a[i]),int(a[q]),int(a[q]-a[i])) for q in range(j,len(a)))
    return out

def fractions_json(d):
    return {k:({'num':v.numerator,'den':v.denominator,'display':float(v)} if isinstance(v,F) else v) for k,v in d.items()}

def main():
    t='focus23/m3_fine.json';c='focus23/m3_fine.interval_certificate.json';v=constants(t,c)
    w=load_witness('onward/h3_completed_witness.csv')
    a=allowed(w,-2000000,2000000)
    subset,res=choose(a,v['k'],v['budget'])
    # Search first with inherited witnesses; then supply every additional prime.
    for p in primes_up_to(v['k']):
        if int(p) not in w:
            used=np.bincount(subset%p,minlength=int(p));missing=np.flatnonzero(used==0)
            assert len(missing);w[int(p)]=int(missing[0])
    res.update(first=int(subset[0]),last=int(subset[-1]),diameter=int(subset[-1]-subset[0]),points=len(a),trial=t,certificate=c,search_note='Search uses old witnesses up to 110037; extra witnesses selected and fully checked afterward.')
    res['remaining_margin']=fractions_json({'value':v['surplus']-res['long_pairs']*v['pair']})['value']
    out=ROOT/'continuation2'
    np.savetxt(out/'h3_pair_tuple.csv',subset,fmt='%d',header='h',comments='')
    np.savetxt(out/'h3_pair_tuple.txt',subset,fmt='%d')
    np.savetxt(out/'h3_pair_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
    pairs=enumerate_long_pairs(subset,res['D']);assert len(pairs)==res['long_pairs']
    np.savetxt(out/'h3_long_pairs.csv',np.array(pairs),fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
    (out/'h3_pair_result.json').write_text(json.dumps(dict(constants=fractions_json(v),selection=res),indent=2)+'\n')
    print(json.dumps({k:x for k,x in res.items() if k!='remaining_margin'}));print('margin',res['remaining_margin']['display'])
if __name__=='__main__':main()
