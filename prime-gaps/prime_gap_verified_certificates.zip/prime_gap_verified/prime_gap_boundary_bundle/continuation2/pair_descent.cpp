// Heuristic pair selection; exact minimization for each selected prime pair.
// All final tuples must be independently checked.
#include <bits/stdc++.h>
using namespace std;
using ll=long long;
int main(int argc,char**argv){
 if(argc!=9){cerr<<"K lo hi witness seconds seed out maxmoves\n";return 2;}
 int K=stoi(argv[1]);ll lo=stoll(argv[2]),hi=stoll(argv[3]);double secs=stod(argv[5]);mt19937_64 rng(stoull(argv[6]));string out=argv[7];int maxmoves=stoi(argv[8]);
 ll first=lo+(lo%2!=0);int N=(hi-first)/2+1; vector<int> ps,aa;
 ifstream in(argv[4]);string line;getline(in,line);while(getline(in,line)){replace(line.begin(),line.end(),',',' ');istringstream is(line);int p,r;is>>p>>r;if(p==2||p>K)continue;ps.push_back(p);ll v=(r-first)%p;if(v<0)v+=p;aa.push_back(v*((p+1)/2)%p);}
 const int M=ps.size();vector<int>cover(N),ownerSum(N);vector<ll>ownerSq(N);
 auto change=[&](int i,int a,int delta){ll id=i+1;for(int j=a;j<N;j+=ps[i]){cover[j]+=delta;ownerSum[j]+=delta*id;ownerSq[j]+=delta*id*id;}};
 for(int i=0;i<M;i++)change(i,aa[i],1);
 int cur=count(cover.begin(),cover.end(),0),best=cur;ll bestD=LLONG_MAX;auto start=chrono::steady_clock::now();
 auto save=[&](){if(cur<K)return;vector<ll> h;for(int j=0;j<N;j++)if(!cover[j])h.push_back(first+2LL*j);ll D=LLONG_MAX;size_t at=0;for(size_t i=0;i+K<=h.size();i++){ll d=h[i+K-1]-h[i];if(d<D){D=d;at=i;}}if(D>=bestD)return;bestD=D;ofstream f(out+".csv");for(int j=0;j<K;j++)f<<h[at+j]<<'\n';ofstream w(out+"_witness.csv");w<<"prime,missing_residue\n2,1\n";for(int i=0;i<M;i++){ll r=(first+2LL*aa[i])%ps[i];if(r<0)r+=ps[i];w<<ps[i]<<','<<r<<'\n';}cerr<<"SAVED current="<<cur<<" diameter="<<D<<" first="<<h[at]<<" last="<<h[at+K-1]<<"\n";};
 save();vector<int> cp(K+1),cq(K+1),joint;
 int iteration=0,gains=0,plateaus=0;
 while(iteration<maxmoves && chrono::duration<double>(chrono::steady_clock::now()-start).count()<secs){
  int i=-1,j=-1;
  if(iteration%4!=0){for(int a=0;a<80;a++){int v=rng()%N;if(cover[v]!=2)continue;ll s=ownerSum[v],disc=2*ownerSq[v]-s*s;if(disc<0)continue;ll root=llround(sqrt((double)disc));if(root*root!=disc)continue;i=(s-root)/2-1;j=(s+root)/2-1;break;}}
  if(i<0){i=rng()%M;j=rng()%M;}
  if(i==j)continue;
  int p=ps[i],q=ps[j],oldA=aa[i],oldB=aa[j];change(i,oldA,-1);change(j,oldB,-1);
  fill(cp.begin(),cp.begin()+p,0);fill(cq.begin(),cq.begin()+q,0);ll pq=(ll)p*q;int total=0;
  if(pq<=N){joint.assign(pq,0);for(int v=0;v<N;v++)if(!cover[v]){int a=v%p,b=v%q;cp[a]++;cq[b]++;joint[(ll)a*q+b]++;total++;}}
  else for(int v=0;v<N;v++)if(!cover[v]){cp[v%p]++;cq[v%q]++;total++;}
  int A=oldA,B=oldB,mincost=INT_MAX,nt=0;
  if(pq<=N){for(int a=0;a<p;a++)for(int b=0;b<q;b++){int cost=cp[a]+cq[b]-joint[(ll)a*q+b];if(cost<mincost){mincost=cost;A=a;B=b;nt=1;}else if(cost==mincost&&rng()%++nt==0){A=a;B=b;}}}
  else{
   int mp=*min_element(cp.begin(),cp.begin()+p),mq=*min_element(cq.begin(),cq.begin()+q);mincost=mp+mq;int ct=0;for(int a=0;a<p;a++)if(cp[a]==mp&&rng()%++ct==0)A=a;ct=0;for(int b=0;b<q;b++)if(cq[b]==mq&&rng()%++ct==0)B=b;
   nt=0;for(int v=0;v<N;v++)if(!cover[v]){int a=v%p,b=v%q;if(cp[a]==mp&&cq[b]==mq){if(rng()%++nt==0){A=a;B=b;}mincost=mp+mq-1;}}
  }
  int next=total-mincost;assert(next>=cur);int gain=next-cur;
  aa[i]=A;aa[j]=B;change(i,A,1);change(j,B,1);cur=next;iteration++;
  if(gain){gains+=gain;cerr<<"gain="<<gain<<" primes="<<p<<','<<q<<" current="<<cur<<" iteration="<<iteration<<"\n";if(cur>best){best=cur;save();}}
  else if(A!=oldA||B!=oldB)plateaus++;
  if(iteration%2000==0)cerr<<"iter="<<iteration<<" best="<<best<<" current="<<cur<<" secs="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";
 }
 cerr<<"DONE iterations="<<iteration<<" gains="<<gains<<" plateaus="<<plateaus<<" best="<<best<<"\n";
 ofstream st(out+"_state_witness.csv");st<<"prime,missing_residue\n2,1\n";for(int i=0;i<M;i++){ll r=(first+2LL*aa[i])%ps[i];if(r<0)r+=ps[i];st<<ps[i]<<','<<r<<'\n';}
}
