"""Exploratory parameter optimization; outputs are NOT rigorous certificates."""
from pathlib import Path
import sys,json,time,math
import numpy as np
from scipy.optimize import minimize
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import optimize
m=int(sys.argv[1]); d=json.load(open(B/('focus23/m2_k2304.json' if m==2 else 'onward/m3_k110037.json')))
d['k']=2303 if m==2 else 110000
basis=[(),(2,),(3,),(4,),(2,2),(2,3)]
eps0=d['delta']*d['eps_cells']; x0=np.array([d['theta'],d['beta'],d['relative_shift'],eps0*1000])
bounds=[(.96,1.04),(2.7,2.949) if m==2 else (3.8,4.408),(0.,2.),(2,9) if m==2 else (.1,2.)]
rows=[];best=-1;start=time.time();out=B/'continuation2'
def fun(x):
 global best
 if time.time()-start>220:raise TimeoutError
 if any(v<a or v>b for v,(a,b) in zip(x,bounds)):return 100+sum(max(a-v,0)+max(v-b,0) for v,(a,b) in zip(x,bounds))
 dd=d.copy();dd.update(theta=float(x[0]),beta=float(x[1]),relative_shift=float(x[2]));dd['eps_cells']=round(x[3]/1000/dd['delta'])
 r=optimize(dd,basis,ncell=140,N=2**18,ng=24,spacing=2**-23,tol=1e-12)
 q=r['Q_exploratory'];row=dict(x=list(x),Q=q,seconds=time.time()-start);rows.append(row)
 if q>best:
  best=q;z={**{k:v for k,v in dd.items() if not k.startswith('h')},**r,'status':'exploratory only; no interval certificate'}
  (out/f'm{m}_scout_best.json').write_text(json.dumps(z,indent=2)+'\n')
 print(m,len(rows),row,flush=True);(out/f'm{m}_scout_rows.json').write_text(json.dumps(rows,indent=2)+'\n')
 return -q
steps=[.004,-.025,.12,.3 if m==2 else .12]
simplex=np.tile(x0,(5,1))
for j,s in enumerate(steps):simplex[j+1,j]+=s
try:
 res=minimize(fun,x0,method='Nelder-Mead',options={'initial_simplex':simplex,'maxiter':85,'maxfev':110,'xatol':1e-4,'fatol':1e-6})
 print(res,flush=True)
except TimeoutError:print('Exploratory time budget reached',flush=True)
