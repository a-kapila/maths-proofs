from pathlib import Path
import json,hashlib
b=Path(__file__).resolve().parents[1];o=b/'continuation2';expected=json.load(open(o/'RESULTS.json'))
for row in expected['rows']:
 m=row['m'];j=json.load(open(o/f'h{m}_pair_result.json'));c=j['constants'];s=j['selection'];v=json.load(open(o/f'h{m}_pairs_verified.json'))
 assert row['k']==c['k']==v['k'] and row['D']==s['D']==v['D'] and row['long_pairs']==s['long_pairs']==v['long_pairs']
 for f in ['first','last','candidate_windows']:
  key='windows' if f=='candidate_windows' else f;assert row[f]==s[key]
 assert row['tuple_diameter']==s['diameter'] and row['pair_budget']==c['budget'] and row['prime_count_margin']==s['remaining_margin']['display']
if (o/'MANIFEST.json').exists():
 manifest=json.load(open(o/'MANIFEST.json'))
 for path,digest in manifest.items():assert hashlib.sha256((b/path).read_bytes()).hexdigest()==digest,path
 print('All',len(manifest),'manifest hashes match.')
print('All final mathematical result fields match.')
