from pathlib import Path
import sys,json
B=Path.cwd();sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import optimize
D=json.load(open(B/'continuation2/m2_scout_best.json'))
for n,tol in [(400,1e-9),(600,1e-10)]:
 r=optimize(D,[tuple(x) for x in D['basis']],ncell=n,N=2**20,ng=48,spacing=2**-23,tol=tol)
 out={**D,**r};(B/f'continuation2/m2_regularized_{n}.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items() if k not in ['E','profiles']}),flush=True)
