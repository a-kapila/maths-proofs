#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
# No inherited Fourier calculation is rerun by this script.
g++ -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o continuation2/verify_tuple
g++ -O3 -std=c++17 continuation2/check_pair_counts.cpp -o continuation2/check_pair_counts
python continuation2/pair_penalty.py
python continuation2/pair_h4.py
bash continuation2/prepare_h5.sh
python continuation2/pair_h5.py
python continuation2/verify_selected.py
python continuation2/check_h3_python.py
python continuation2/check_new.py
python continuation2/final_check.py
