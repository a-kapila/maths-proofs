from pathlib import Path
import json,subprocess
B=Path(__file__).resolve().parents[1];O=B/'continuation2'
for m in (3,4):
 r=json.load(open(O/f'h{m}_pair_result.json'));k=r['constants']['k'];s=r['selection']
 tup=O/('h3_pair_tuple.txt' if m==3 else 'h4_pair_tuple.csv')
 witness=O/'h3_pair_witness.csv' if m==3 else B/'baseline/inherited/tuples/h4_witness.csv'
 with open(O/f'h{m}_tuple_verified.json','w') as f:subprocess.run([str(O/'verify_tuple'),str(tup),str(witness),str(k)],check=True,stdout=f)
 with open(O/f'h{m}_pairs_verified.json','w') as f:subprocess.run([str(O/'check_pair_counts'),'tuple',str(tup),str(s['D'])],check=True,stdout=f)
 v=json.load(open(O/f'h{m}_tuple_verified.json'));assert v['verified'] and v['k']==k and v['first']==s['first'] and v['last']==s['last']
r=json.load(open(O/'h5_pair_result.json'));s=r['selection'];p=json.load(open(O/'h5_parent_verified.json'))
assert p['verified'] and p['failures']==0 and p['parent_cardinality']==233950978
with open(O/'h5_pairs_verified.json','w') as f:
 subprocess.run([str(O/'check_pair_counts'),'signed',str(O/'recomputed/h5_tail.bin'),str(s['D']),str(s['negative_count']),str(s['positive_count'])],check=True,stdout=f)
for m in (3,4,5):
 print(json.load(open(O/f'h{m}_pairs_verified.json')))
