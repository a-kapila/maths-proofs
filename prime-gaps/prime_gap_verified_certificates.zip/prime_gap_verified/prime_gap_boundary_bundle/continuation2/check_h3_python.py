"""Independent direct residue check; does not use the search bitmap."""
from pathlib import Path
import csv,json,math
import numpy as np
b=Path(__file__).resolve().parents[1];a=np.loadtxt(b/'continuation2/h3_pair_tuple.csv',skiprows=1,dtype=np.int64);k=len(a)
assert k==110070 and np.all(np.diff(a)>0)
s=bytearray(b'\x01')*(k+1);s[0]=s[1]=0
for p in range(2,math.isqrt(k)+1):
 if s[p]:s[p*p::p]=b'\x00'*(((k-p*p)//p)+1)
ps=[p for p in range(2,k+1) if s[p]]
w={int(r['prime']):int(r['missing_residue']) for r in csv.DictReader(open(b/'continuation2/h3_pair_witness.csv'))}
assert sorted(w)==ps
for p in ps:assert not np.any(a%p==w[p])
result=dict(verified=True,k=k,first=int(a[0]),last=int(a[-1]),checked_primes=len(ps),method='independent byte sieve and direct reduction of all entries')
(b/'continuation2/h3_python_verified.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
