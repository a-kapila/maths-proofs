"""Outward-rounded fixed-point rational interval arithmetic.
Every endpoint is a Fraction; rounding uses integer floor and ceiling only.
No binary floating-point operation is used to certify an inequality.
"""
from fractions import Fraction as F
from math import isqrt
BITS=256
SCALE=1<<BITS

def down(x):
    x=F(x);return F((x.numerator*SCALE)//x.denominator,SCALE)
def up(x):
    x=F(x);return F(-((-x.numerator*SCALE)//x.denominator),SCALE)
class I:
    __slots__=('lo','hi')
    def __init__(self,lo,hi=None):
        self.lo=down(lo);self.hi=up(lo if hi is None else hi)
        assert self.lo<=self.hi
    @staticmethod
    def get(x):return x if isinstance(x,I) else I(x)
    def __add__(self,x):
        x=I.get(x);return I(self.lo+x.lo,self.hi+x.hi)
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,x):return self+-I.get(x)
    def __rsub__(self,x):return I.get(x)+-self
    def __mul__(self,x):
        x=I.get(x);t=[a*b for a in (self.lo,self.hi) for b in (x.lo,x.hi)];return I(min(t),max(t))
    __rmul__=__mul__
    def inv(self):
        assert self.lo*self.hi>0
        return I(1/self.hi,1/self.lo)
    def __truediv__(self,x):return self*I.get(x).inv()
    def __rtruediv__(self,x):return I.get(x)*self.inv()
    def __pow__(self,n):
        assert isinstance(n,int) and n>=0
        z=I(1);a=self
        while n:
            if n&1:z=z*a
            a=a*a;n//=2
        return z
    def width(self):return self.hi-self.lo
    def display(self):return [float(self.lo),float(self.hi)]

def sqrt(x):
    x=I.get(x);assert x.lo>=0
    def low(y):return isqrt((y.numerator*SCALE*SCALE)//y.denominator)
    l=low(x.lo);h=low(x.hi)+1
    out=I(F(l,SCALE),F(h,SCALE));assert out.lo*out.lo<=x.lo and out.hi*out.hi>=x.hi
    return out

def _log_point(x,terms=100):
    x=F(x);assert x>0
    e=x.numerator.bit_length()-x.denominator.bit_length();u=x/F(2)**e
    if u<1:e-=1;u*=2
    assert 1<=u<2
    def series(z):
        z=I(z);zz=z*z;pw=z;total=I(0)
        for j in range(terms):total+=2*pw/(2*j+1);pw*=zz
        rem=2*pw/((2*terms+1)*(1-zz))
        return I(total.lo,total.hi+rem.hi)
    return series((u-1)/(u+1))+e*series(F(1,3))

def log(x):
    x=I.get(x);assert x.lo>0
    return I(_log_point(x.lo).lo,_log_point(x.hi).hi)

def pi():
    def atan(x,terms=180):
        x=I(x);total=I(0);pw=x;xx=x*x
        for n in range(terms):total+=((-1)**n)*pw/(2*n+1);pw*=xx
        tail=((-1)**terms)*pw/(2*terms+1)
        return I(total.lo+min(F(0),tail.lo),total.hi+max(F(0),tail.hi))
    return 16*atan(F(1,5))-4*atan(F(1,239))

_PI=pi()
def li2(x,terms=200):
    """Real dilogarithm on [0,1], with positive-series and reflection bounds."""
    x=I.get(x);assert 0<=x.lo<=x.hi<1
    if x.lo>F(1,2):return _PI*_PI/6-log(x)*log(1-x)-li2(1-x,terms)
    assert x.hi<F(3,4)
    total=I(0);pw=x
    for n in range(1,terms+1):total+=pw/(n*n);pw*=x
    rem=pw/((terms+1)**2*(1-x))
    return I(total.lo,total.hi+rem.hi)

def J(k,a):
    """Integral of reciprocal quadratic weight on the unit triangle.
    The closed form applies to a>2 and c=a*sqrt(1-2/k)/(a-2)>1.
    """
    a=I.get(a);assert k>=3 and a.lo>2
    g=sqrt(I(1)-F(2,k));c=a*g/(a-2);assert c.lo>1
    L0=log(c);L1=log(c-g)
    bracket=log(c+1)*(L0-L1)-(L0*L0-L1*L1)/2
    bracket+=li2((c-g)/(c+1))-li2(c/(c+1))
    bracket+=li2((c-1)/(c-g))-li2((c-1)/c)
    ans=2*bracket/(a*g*(a-2));assert ans.lo>0
    return ans

if __name__=='__main__':
    for k in [2304,110070,5090000,232500000]:
        v=J(k,F(19*k,40));print(k,v.display(),'width',float(v.width()))
