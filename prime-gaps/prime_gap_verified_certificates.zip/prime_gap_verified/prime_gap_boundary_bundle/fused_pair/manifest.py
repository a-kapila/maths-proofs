"""Hash selected mathematical inputs and current source, excluding regenerable outputs."""
from pathlib import Path
import json,hashlib,sys
R=Path(__file__).resolve().parents[1];O=R/'fused_pair'
paths=[
 'fused_pair/intervals.py','fused_pair/compute.py','fused_pair/verify.py','fused_pair/diagnostics.py','fused_pair/reproduce.sh','fused_pair/manifest.py','fused_pair/proof_note.tex',
 'focus23/m3_fine.json','focus23/m3_fine.interval_certificate.json','direct_pair/m3_arithmetic.json',
 'accurate/m4.json','accurate/m4.interval_certificate.json','accurate/m5.json','accurate/m5.interval_certificate.json',
 'continuation/support_m4_10_9.json','continuation/support_m5_4_3.json','continuation/mean_m4_r10.json','continuation/mean_m5_r4.json',
 'continuation/finite_sampling.py','continuation/deduce_caps.py','direct_pair/combine.py','direct_pair/sharp_pair.py','adaptive_pairs/adaptive_constant.py',
 'continuation2/pair_penalty.py','continuation2/verify_h5_export.cpp','continuation2/check_pair_counts.cpp','baseline/inherited/tuples/verify_tuple.cpp',
 'baseline/inherited/tuples/h4.csv','baseline/inherited/tuples/h4_witness.csv','onward/h3_completed_witness.csv',
 'fused_pair/m3_d0.json','fused_pair/m4_d910.json','fused_pair/m5_d36500.json']
actual={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths}
if '--check' in sys.argv:
 saved=json.loads((O/'MANIFEST.json').read_text());assert actual==saved
 print('Manifest checked:',len(actual),'files')
else:(O/'MANIFEST.json').write_text(json.dumps(actual,indent=2)+'\n')
