"""Supplementary independent checks; not a substitute for the written proofs."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,random,math,itertools
import numpy as np
import mpmath as mp
from intervals import I,log,li2,sqrt,pi,J
from compute import ROOT,OUT,Search,get_constants
sys.set_int_max_str_digits(0)
rng=random.Random(518735);mp.mp.dps=100
cv=lambda x:mp.mpf(x.numerator)/x.denominator
identity_cases=0
for k in range(3,23):
 for _ in range(20):
    raw=[rng.randrange(100) for _ in range(k)];den=sum(raw)+rng.randrange(1,100)
    t=[F(x,den) for x in raw];S=sum(t);r=1-S;a=F(k*rng.randrange(1,99),100)
    weights=[]
    for i,j in itertools.combinations(range(k),2):
        w=(r+a*t[i])*(r+a*t[j])+a*a/(2*k)*(t[i]-t[j])**2
        assert w>0 and w>=(r+a*t[i])*(r+a*t[j])
        weights.append(w)
    assert sum(weights)==F(k*(k-1),2)*(r+a*S/k)**2
    identity_cases+=1
# Outward elementary-function intervals against high-precision library evaluations.
elementary=0
for _ in range(80):
    x=F(rng.randrange(1,10**12),rng.randrange(1,10**10));z=log(I(x));v=mp.log(cv(x));assert cv(z.lo)<=v<=cv(z.hi);elementary+=1
    x=F(rng.randrange(1,999999),1000000);z=li2(I(x));v=mp.polylog(2,cv(x));assert cv(z.lo)<=v<=cv(z.hi);elementary+=1
z=pi();assert cv(z.lo)<=mp.pi<=cv(z.hi)
quads=[]
for k,a in [(3,F(3)),(4,F(4)),(10,F(5)),(100,F(50)),(2304,F(19*2304,40)),(110070,F(19*110070,40)),(5089090,F(19*5089090,40)),(232463500,F(19*232463500,40))]:
    x=cv(a);g=mp.sqrt(1-mp.mpf(2)/k)
    f=lambda t:4*mp.atanh(x*g*t/(2+(x-2)*t))/(x*g*(2+(x-2)*t))
    points=sorted(set([mp.mpf(0),1/x,mp.mpf('0.01'),mp.mpf('.1'),mp.mpf('.5'),mp.mpf(1)]))
    value=mp.quad(f,points);en=J(k,a)
    assert cv(en.lo)<=value<=cv(en.hi)
    quads.append(dict(k=k,value=mp.nstr(value,30),enclosure_width=float(en.width())))
# Check the optimized end-tail window counter against full pair enumeration.
windows=0
from pair_penalty import counts_windows
for _ in range(200):
    n=rng.randrange(10,90);a=np.array(sorted(rng.sample(range(-1000,1000),n)),dtype=np.int64)
    K=rng.randrange(3,n+1);D=rng.randrange(1,2001)
    obj=object.__new__(Search);obj.m=3;obj.a=a
    observed=obj.counts(K,D);full=counts_windows(a,K,D)
    brute=np.array([sum(int(a[j])-int(a[i])>D for i in range(s,s+K) for j in range(i+1,s+K)) for s in range(n-K+1)])
    assert np.array_equal(observed,brute) and np.array_equal(full,brute);windows+=len(brute)
# At selected parameters, the new bound is strictly below the adaptive product bound.
from adaptive_constant import triangular_integral
relative=[]
for m,d in [(3,0),(4,910),(5,36500)]:
    v=get_constants(m,d);s=v['rho']*v['sigma'];old=8*s*s*triangular_integral(v['a'])[1]
    assert v['pair']<old
    relative.append(dict(m=m,relative_reduction_vs_adaptive=float(1-v['pair']/old),pair_upper=float(v['pair'])))
r=dict(passed=True,exact_weight_identities=identity_cases,elementary_comparisons=elementary,pi_checked=True,
       independent_integrals=quads,brute_force_windows=windows,constant_comparisons=relative)
(OUT/'diagnostics.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2),flush=True)
