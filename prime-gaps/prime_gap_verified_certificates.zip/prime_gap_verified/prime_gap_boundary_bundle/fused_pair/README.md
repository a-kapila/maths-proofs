# Current continuation: quadratic adaptive pair bounds

Best deduced bounds within the inherited analytic framework:
H2 <= 19,860 (unchanged); H3 <= 1,358,042; H4 <= 82,235,890;
H5 <= 4,830,389,798.

The comparison baseline uses the strongest result from each preceding branch.
In particular, the adaptive branch's H3 <= 1,358,060 is retained instead of the
weaker H3 value in the immediately preceding joint-pair table.

Read `proof_note.pdf` for the new theorem, closed-form integral and numerical scope.
Run, from the bundle root:

    bash fused_pair/reproduce.sh

This checks the source/input manifest; reconstructs the full large-tuple witness
sequence and verifies every witness; repeats the selected window scans and exact
rational deductions; checks the smaller tuples and long-pair counts independently;
and repeats the supplementary diagnostics. It compares all final mathematical
fields to RESULTS.json. Python 3 with NumPy and mpmath, and a C++17/OpenMP compiler,
are required. Do not disable assertions. Reconstructible binary prime tables and
compiled binaries are intentionally omitted.

The new scalar enclosure backend is `intervals.py`: fixed-point rational
interval arithmetic, with outward rounding by integer floor/ceiling and explicit
series remainder bounds. No ordinary quadrature score decides a certificate.

Inherited successful Fourier quotient calculations, support-loss calculations
and capped moments are NOT rerun by this workflow. Their inputs, proofs, source
and earlier reproduction commands are retained in the full bundle. The prior
Fourier scalar backend is mpmath.iv with explicit remainder bounds, not FLINT/Arb.
The full analytic chain is not independently peer-reviewed or formally verified.

At each tested dimension the window scan is exhaustive for the specified parent.
Deletion counts were only sampled: no global optimum is claimed. `m*_d*.json`
records the tested choices; the selected ones are m3_d0, m4_d910, and m5_d36500.
No new H2 trial was evaluated in this continuation.

`verify.py` uses a C++ arithmetic-progression admissibility checker and a separate
C++ pair counter. It also directly reduces every H3 tuple entry modulo each prime
using an independently generated Python prime list. The large parent is verified
by the inherited separate segmented-byte sieve, not by sampling its witnesses.

Diagnostics supplement rather than replace the proofs. Record-level outputs
from old directories are historical; fused_pair/RESULTS.json is authoritative
for this continuation.
