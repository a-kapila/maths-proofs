"""Recompute exact scalar certificates and check all selected finite tuples/pairs."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,subprocess,math,csv,hashlib
import numpy as np
from compute import ROOT,OUT,get_constants,encode,Search
from intervals import J
sys.set_int_max_str_digits(0)

def run(args,dest):
    z=subprocess.run(list(map(str,args)),cwd=ROOT,check=True,capture_output=True,text=True)
    (OUT/dest).write_text(z.stdout);return json.loads(z.stdout)
for src,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
    subprocess.run(['g++','-O3','-std=c++17',str(ROOT/src),'-o',str(OUT/name)],check=True)
results=[]
for m,d in [(3,0),(4,910),(5,36500)]:
    obj=json.load(open(OUT/f'm{m}_d{d}.json'));row=obj['selection'];v=get_constants(m,d)
    assert encode(v)==obj['constants']
    assert row['long_pairs']<=v['budget']<row['previous_even_min_count']
    ma=v['surplus']-row['long_pairs']*v['pair'];st=v['strict_surplus']-row['long_pairs']*v['strict_pair']
    assert ma>0 and st>0 and encode(ma)==obj['margin'] and encode(st)==obj['strict_margin']
    if m in [3,4]:
        search=Search(m);a=search.a[row['index']:row['index']+v['k']]
        assert len(a)==v['k'] and int(a[0])==row['first'] and int(a[-1])==row['last']
        tup=OUT/f'h{m}_selected.txt';np.savetxt(tup,a,fmt='%d')
        if m==3:
            w=search.w
            from compute import primes_up_to,enumerate_long_pairs
            ps=primes_up_to(len(a))
            for p in ps:
                if int(p) not in w:
                    u=np.bincount(a%p,minlength=int(p));missing=np.flatnonzero(u==0);assert len(missing)
                    w[int(p)]=int(missing[0])
            wit=OUT/'h3_witness.csv'
            np.savetxt(wit,np.array([(int(p),int(w[p])) for p in ps]),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
            pairs=enumerate_long_pairs(a,row['D']);assert len(pairs)==row['long_pairs']
            np.savetxt(OUT/'h3_long_pairs.csv',np.array(pairs),fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
        else:wit=ROOT/'baseline/inherited/tuples/h4_witness.csv'
        tv=run([OUT/'verify_tuple',tup,wit,v['k']],f'h{m}_tuple_verified.json')
        pv=run([OUT/'check_pairs','tuple',tup,row['D']],f'h{m}_pairs_verified.json')
        assert tv['verified'] and tv['k']==v['k']
        row['checked_primes']=tv['checked_primes']
    else:
        parent=json.load(open(ROOT/'continuation2/h5_parent_verified.json'))
        assert parent['verified'] and parent['failures']==0 and parent['parent_cardinality']==233950978
        pv=run([OUT/'check_pairs','signed',ROOT/'continuation2/recomputed/h5_tail.bin',row['D'],row['negative_count'],row['positive_count']], 'h5_pairs_verified.json')
        (OUT/'h5_parent_verified.json').write_text(json.dumps(parent,indent=2)+'\n')
        assert row['negative_count']+row['positive_count']==v['k']
    assert pv['k']==v['k'] and pv['long_pairs']==row['long_pairs']
    previous={3:1358060,4:82237930,5:4830451598}[m]
    row.update(previous_best=previous,improvement=previous-row['D'])
    assert row['improvement']>0
    results.append(row)
    print('VERIFIED',row,flush=True)
# Independent Python direct modular verification for H3 (not AP scanning).
a=np.loadtxt(OUT/'h3_selected.txt',dtype=np.int64);n=len(a)
sieve=bytearray(b'\1')*(n+1);sieve[:2]=b'\0\0'
for p in range(2,math.isqrt(n)+1):
    if sieve[p]:sieve[p*p::p]=b'\0'*(((n-p*p)//p)+1)
ps=[i for i in range(2,n+1) if sieve[i]]
w={int(r['prime']):int(r['missing_residue']) for r in csv.DictReader(open(OUT/'h3_witness.csv'))}
assert sorted(w)==ps
for p in ps:assert not np.any(a%p==w[p])
(OUT/'h3_python_verified.json').write_text(json.dumps(dict(verified=True,k=n,primes_checked=len(ps),method='Independent Python byte sieve and direct modular reduction'),indent=2)+'\n')
# H2 remains insufficient even for a single long pair.
x=json.load(open(ROOT/'adaptive_pairs/h2_limit.json'))
a=F(x['a']['num'],x['a']['den']);sur=F(x['surplus']['num'],x['surplus']['den']);s=(1-a/2304)/2
cp=8*s*s*J(2304,a).hi;assert sur<cp
h2=dict(k=2304,surplus=float(sur),new_pair_upper=float(cp),covered_long_pairs=0,bound=19860)
(OUT/'h2_limit.json').write_text(json.dumps(encode(dict(h2,exact_surplus=sur,exact_pair_upper=cp)),indent=2)+'\n')
summary=dict(status='passed',results=results,H2=h2,scope='Inherited successful Fourier and support/moment inputs not rerun. New rational pair constants, full tuple admissibility and independent integer pair checks. H5 full parent verification rerun by reproduction script.')
(OUT/'RESULTS.json').write_text(json.dumps(summary,indent=2)+'\n')
