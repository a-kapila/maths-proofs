#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
python fused_pair/manifest.py --check
cp fused_pair/RESULTS.json fused_pair/RESULTS.before_reproduction.json
bash continuation2/prepare_h5.sh
python fused_pair/compute.py 3 0
python fused_pair/compute.py 4 910
python fused_pair/compute.py 5 36500
python fused_pair/diagnostics.py
python fused_pair/verify.py
python - <<'PY'
import json
from pathlib import Path
p=Path('fused_pair')
a=json.loads((p/'RESULTS.before_reproduction.json').read_text());b=json.loads((p/'RESULTS.json').read_text())
assert a==b
(p/'reproduction_comparison.json').write_text(json.dumps({'passed':True,'all_final_mathematical_fields_identical':True},indent=2)+'\n')
print('All final mathematical result fields reproduced.')
PY
