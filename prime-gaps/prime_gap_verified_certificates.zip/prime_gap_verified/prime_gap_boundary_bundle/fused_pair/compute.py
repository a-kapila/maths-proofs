"""Combine quadratic residual-support pair majorant with symmetric rescaled slicing.
Searches are exhaustive over windows at each tested deletion count, not over d.
All decisions accepting a bound use outward rational constants.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,struct,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'fused_pair'
sys.path[:0]=[str(OUT),str(ROOT/'direct_pair'),str(ROOT/'continuation2'),str(ROOT/'continuation'),str(ROOT/'adaptive_pairs')]
from intervals import J
from finite_sampling import coefficient
from deduce_caps import calc
from pair_penalty import constants as old_constants,counts_windows,choose,load_witness,allowed,primes_up_to,enumerate_long_pairs
from sharp_pair import SOURCES
from adaptive_constant import triangular_integral
from combine import Search as OldSearch
sys.set_int_max_str_digits(0)
_CACHE={}
def get_constants(m,d=0):
    if m not in _CACHE:
        v=old_constants(*SOURCES[m],arithmetic='direct_pair/m3_arithmetic.json' if m==3 else None)
        if m!=3:
            r={4:10,5:4}[m];row=calc(m,r)
            v['q']=F(row['quotient_lower_before_restriction'])-F(row['restriction_loss_upper'])
            v.update(r=r,mu_lower=F(row['mean_lower']))
        _CACHE[m]=v
    base=_CACHE[m];v=dict(base);k=base['k'];K=k-d
    beta=F(0) if d==0 else base['mu_lower']*coefficient(k,d,base['r'])
    q=F(K,k)*base['q']/(1-beta)
    s=base['rho']*base['sigma'];a=K*(1-2*s)
    j=J(K,a);pair=8*s*s*j.hi;sur=base['rho']*q-m
    assert sur>0
    rat=sur/pair;budget=(rat.numerator-1)//rat.denominator
    lam=base['rho']-F(1,2**60);b=F(1,2)-F(1,2**60);ss=lam*base['sigma']
    strict_pair=2*(ss/b)**2*J(K,K*(1-ss/b)).hi
    v.update(k=K,original_k=k,deleted=d,q=q,beta_lower=beta,pair=pair,surplus=sur,budget=budget,a=a,J_lower=j.lo,J_upper=j.hi,
             strict_pair=strict_pair,strict_surplus=lam*q-m)
    assert sur-budget*pair>0>=sur-(budget+1)*pair
    return v

def encode(x):
    if isinstance(x,F):return dict(numerator=str(x.numerator),denominator=str(x.denominator),display=float(x))
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,list):return [encode(v) for v in x]
    return x

class Search(OldSearch):
    def __init__(self,m):
        if m!=3:super().__init__(m)
        else:
            self.m=m;self.w=load_witness('onward/h3_completed_witness.csv');self.a=allowed(self.w,-2000000,2000000)
    def counts(self,K,D):
        if self.m!=5:
            # Only endpoints can form long pairs at these near-diameter targets.
            # searchsorted thresholds are still evaluated against the entire parent.
            a=self.a;n=len(a);W=n-K
            L=int(np.searchsorted(a,int(a[-1])-D,side='left'))
            rr=np.searchsorted(a,a[:L]+D,side='right')
            first=int(np.maximum(0,K-rr[:min(K,L)]).sum())
            inds=np.arange(W,dtype=np.int64)
            rem=np.maximum(0,inds+K-np.searchsorted(a,a[:W]+D,side='right'))
            add=np.maximum(0,np.searchsorted(a,a[K:]-D,side='left')-(inds+1))
            counts=np.empty(W+1,dtype=np.int64);counts[0]=first;counts[1:]=first+np.cumsum(add-rem)
            assert counts.min()>=0
            return counts
        return super().counts(K,D)
    def run(self,d):
        v=get_constants(self.m,d);K=v['k'];budget=v['budget']
        lo,hi={3:(1357000,1360000),4:(82190000,82300000),5:(4829500000,4831000000)}[self.m];lo//=2;hi//=2
        assert int(self.counts(K,hi*2).min())<=budget
        assert int(self.counts(K,lo*2).min())>budget
        while lo<hi:
            md=(lo+hi)//2
            if int(self.counts(K,md*2).min())<=budget:hi=md
            else:lo=md+1
        D=lo*2;cs=self.counts(K,D);idx=int(cs.argmin());cnt=int(cs[idx]);a=self.a
        row=dict(m=self.m,k=K,original_k=v['original_k'],deleted=d,D=D,long_pairs=cnt,budget=budget,windows=len(cs),index=idx,
                 previous_even_min_count=int(self.counts(K,D-2).min()))
        if self.m!=5:row.update(first=int(a[idx]),last=int(a[idx+K-1]))
        else:
            neg=K-self.N+idx;pos=K-neg
            row.update(negative_count=neg,positive_count=pos,first=-int(a[neg-self.rank0]),last=int(a[pos-self.rank0]),tail_first_rank=self.rank0,parent_positive_count=self.N)
        row['diameter']=row['last']-row['first']
        margin=v['surplus']-cnt*v['pair'];strict=v['strict_surplus']-cnt*v['strict_pair']
        assert margin>0 and strict>0
        row.update(prime_count_margin=float(margin),strict_margin=float(strict))
        file=OUT/f'm{self.m}_d{d}.json';file.write_text(json.dumps(encode(dict(constants=v,selection=row,margin=margin,strict_margin=strict)),indent=2)+'\n')
        print(row,flush=True)
        if self.m==3:
            np.savetxt(OUT/f'h{self.m}_d{d}_tuple.txt',a[idx:idx+K],fmt='%d')
        return row
if __name__=='__main__':
    m=int(sys.argv[1]);ds=list(map(int,sys.argv[2:]));search=Search(m)
    for d in ds:search.run(d)
