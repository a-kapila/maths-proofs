# Current continuation

The newest work is in **progress/**. Read **progress/README.md**, **progress/proof_note.pdf**, and **progress/RESULTS.json**.

The current deductions are H2 <= 19,860; H3 <= 1,358,724; H4 <= 82,258,490 (unchanged); H5 <= 4,831,230,984 (unchanged). These are computer-assisted research deductions within the retained framework, not independently audited published records.

From this directory run `bash progress/reproduce.sh --checks-only` or `bash progress/reproduce.sh --full`. Older root and subdirectory README/results files are retained historical material and do not describe the latest continuation. All preceding dependencies are included.
