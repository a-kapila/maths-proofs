# Capped rescaling: current prime-gap continuation

4 November 2026. Start with `rescaled/proof_note.pdf`, `rescaled/README.md`, and
`rescaled/RESULTS.json`. New bounds: H4 <= 82,290,802 and H5 <= 4,832,640,592.
H2 <= 19,920 and H3 <= 1,359,754 are unchanged.

The new argument strengthens coordinate slicing by capped dilation. It reuses
the earlier unrestricted Fourier quotient/denominator certificates and computes
fresh scalar support and moment bounds. Both new tuples were verified in full.
These are research derivations within inherited analytic assumptions, not
independently reviewed records.

From this directory:

```sh
bash rescaled/reproduce.sh --checks-only
bash rescaled/reproduce.sh --full
```

Full additionally recomputes the NEW support and scalar probability bounds;
neither command reruns inherited Fourier quotient calculations. Earlier scripts
remain available. The previous archive is included completely, so no earlier
download is needed. Root files outside `rescaled/` are inherited unless indicated
in the manifest; the older root `proof_note.pdf` is not this continuation.

The previous root README, RESULTS and manifest are preserved under names ending
in `_before_rescaling`. The new root manifest covers every distributed file.
Python 3, NumPy, SciPy, mpmath and a C++17 compiler with OpenMP are required.
Assertions must remain enabled. See rescaled/README.md for verification scope.
