# Latest continuation

Read `four_moment/README.md` and `four_moment/proof_note.pdf` first.

The current result is H3 <= 1,357,812, with H2 <= 19,844, H4 <= 82,234,788,
and H5 <= 4,830,355,416 unchanged. The authoritative results for this
continuation are `four_moment/RESULTS.json`. Earlier result files are historical.

Run `bash four_moment/reproduce.sh --checks-only` from this archive root.
Use `--full` to recompute the new moment tables and finer H3 quotient as well.
The complete inherited chain remains subject to independent expert review.
