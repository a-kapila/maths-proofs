"""Direct, bounded Fourier evaluation of the capped-sum first moment.
No new prime-distribution theorem or quotient certificate is asserted here.
The original independent-coordinate law is unchanged. A single labelled
capped-coordinate statistic is added to each positive moment measure.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from math import prod
import sys,json,time,math
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'envelope'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from flint import arb,acb,ctx
from shifted_core import setup,make_phi
from multi_core import single_moments
from polynomial_core import terms
from periodic_shifted import CDF as OrdinaryCDF,upper
from certify_lifted import integrate_bound

def ar(x):
    x=F(x);return arb(x.numerator)/x.denominator

def up(x):return float(np.nextafter(float(x.upper()),np.inf))
def down(x):return float(np.nextafter(float(x.lower()),-np.inf))

def tagged_weights(n,mu,nu,keys):
    """E[(sum_i u(X_i)) (prod_{p in A} Z_p) exp(i xi S_n)].
    Classify the untagged positions by coincidences, then place the tag
    in an existing block or in one new block. Indices are labelled.
    """
    rmax=max(map(len,keys))+1
    ph={r:mu[0]**(n-r) for r in range(rmax+1)}
    ff={r:prod(n-i for i in range(r)) for r in range(rmax+1)}
    out=[]
    for key in keys:
        v=0
        for blocks,mult in terms(tuple(key)):
            r=len(blocks)
            p=prod(mu[j] for j in blocks)
            v+=mult*ff[r+1]*ph[r+1]*nu[0]*p
            for at,j in enumerate(blocks):
                v+=mult*ff[r]*ph[r]*nu[j]*prod(mu[b] for i,b in enumerate(blocks) if i!=at)
        out.append(v)
    return out

class CappedMeanCDF:
    def __init__(self,tr,sigma,precision=256):
        self.tr=tr;self.k=tr['k'];self.sigma=sigma;self.h=F(1,11);self.w=ar(sigma*self.h)
        self.S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift'])
        self.lowS=dict(self.S);self.lowS['T']=self.w
        self.P=8.;self.freq=2*arb.pi()/8
        self.phi,_=make_phi(tr['k'],tr['theta'],tr['beta'],tr['relative_shift'])
        self.jmax=0
        basis=[tuple(v) for v in tr['basis']];nc=len(tr['profiles'][0]);hs=[[F(v) for v in row] for row in tr['profiles']]
        co=defaultdict(lambda:[F(0)]*nc)
        for i,mi in enumerate(basis):
            for j,mj in enumerate(basis):
                key=tuple(sorted(mi+mj));co[key]=[a+x*y for a,x,y in zip(co[key],hs[i],hs[j])]
        self.keys=sorted(co,key=lambda x:(len(x),x));self.co=co
        self.jmax=max(map(sum,self.keys))+1
        self.y=np.array([float(F(tr['delta'])*e) for e in tr['E']])
        self.J=128;self.nmin=self.k-max(map(len,self.keys))-1
        while True:
            z=self.phi(acb(self.freq*self.J))
            if z.abs_upper()<1 and self.nmin*z.abs_upper().log() < -140:break
            self.J=int(self.J*1.25)+1
            assert self.J<100000
    def moments(self,kind='zero',value=0):
        mu=single_moments(self.S,self.jmax,kind,value)
        low0=single_moments(self.lowS,self.jmax,kind,value)
        ratio=self.w/self.S['T']
        low=[v*ratio**j for j,v in enumerate(low0)]
        nu=[self.S['T']/ar(self.sigma)*low[j+1]+ar(self.h)*(mu[j]-low[j]) for j in range(self.jmax)]
        return mu,nu
    def run_setup(self):
        t=time.time();mu,nu=self.moments();self.mass=tagged_weights(self.k,mu,nu,self.keys)
        rlen=len(self.keys);J=self.J
        C=np.zeros((rlen,J),complex);constants=[arb(0) for _ in self.keys];norms=[arb(0) for _ in self.keys];errs=[arb(0) for _ in self.keys]
        for j in range(1,J+1):
            mu,nu=self.moments('fourier',self.freq*j)
            vals=tagged_weights(self.k,mu,nu,self.keys)
            for r,v in enumerate(vals):
                z=v/acb(0,2*arb.pi()*j);zr=float(z.real.mid());zi=float(z.imag.mid())
                assert z.is_finite() and z.real.rad()<arb('1e-35') and z.imag.rad()<arb('1e-35')
                C[r,j-1]=complex(zr,zi);constants[r]+=2*z.real;norms[r]+=2*z.abs_upper();errs[r]+=2*((arb(zr)-z.real).abs_upper()+(arb(zi)-z.imag).abs_upper())
            if j%400==0:print(json.dumps(dict(stage='coefficients',m=self.tr['m'],j=j,J=J,seconds=time.time()-t)),flush=True)
        self.C=C;self.constants=constants;self.norms=norms;self.errs=errs
        self.base_tail=OrdinaryCDF._series_tail(self,self.nmin)
        self.tail=[up(v*arb(self.base_tail)) for v in self.mass]
        self.alias=[v.upper() for v in self.mass]
        for lam in range(1,81):
            mu,nu=self.moments('positive',lam);vals=tagged_weights(self.k,mu,nu,self.keys)
            for r,v in enumerate(vals):
                candidate=((-arb(lam)*8).exp()*v).upper()
                if candidate<self.alias[r]:self.alias[r]=candidate
        print(json.dumps(dict(stage='setup',m=self.tr['m'],J=J,moments=rlen,seconds=time.time()-t,tail=self.tail,alias=list(map(up,self.alias)))),flush=True)
    def phases(self):
        # Block recurrence, as for the inherited FFT twiddles. At most 255
        # complex products from certified trigonometric bases. Error <=4096u.
        yy=self.y;J=self.J;block=256
        step=[];angles=[]
        for y in yy:
            a=-self.freq*arb(float(y));sn,cs=a.sin_cos()
            assert sn.rad()<arb(2)**-150 and cs.rad()<arb(2)**-150
            angles.append(a);step.append(complex(float(cs.mid()),float(sn.mid())))
        step=np.array(step);powers=np.ones((len(yy),block),complex)
        for j in range(1,block):powers[:,j]=powers[:,j-1]*step
        phase=np.empty((len(yy),J+1),complex)
        for j in range(0,J+1,block):
            bas=[]
            for a in angles:
                sn,cs=(a*j).sin_cos()
                assert sn.rad()<arb(2)**-150 and cs.rad()<arb(2)**-150
                bas.append(complex(float(cs.mid()),float(sn.mid())))
            n=min(block,J+1-j);phase[:,j:j+n]=np.array(bas)[:,None]*powers[:,:n]
        return phase[:,1:]
    def evaluate(self):
        phase=self.phases();C=self.C;u=arb(2)**-53
        acc=np.zeros((len(self.keys),len(self.y)))
        for j in range(self.J):
            # Deliberately separate multiplications and additions.
            a=C[:,j].real[:,None]*phase[:,j].real[None,:]
            b=C[:,j].imag[:,None]*phase[:,j].imag[None,:]
            acc=acc+(a-b)
        C0=np.array([float(x.mid()) for x in self.constants]);mass=np.array([float(x.mid()) for x in self.mass])
        val=mass[:,None]*(self.y[None,:]/self.P)+C0[:,None]-2*acc
        errors=[];Ls=[];Us=[]
        # Direct complex dot: phase error 4096u; real product/sum error
        # <=2 gamma_(J+3)(1+4096u), comfortably within (8192+8J)u.
        assert (self.J+3)*2**-53<1e-6
        for r in range(len(self.keys)):
            e_phase_dot=(8192+8*self.J)*u*self.norms[r]+2*self.errs[r]
            e_const=(arb(C0[r])-self.constants[r]).abs_upper()
            e_mass=(arb(mass[r])-self.mass[r]).abs_upper()*arb(max(self.y))/8
            e_combine=64*u*(abs(arb(mass[r]))*arb(max(self.y))/8+2*abs(arb(C0[r]))+self.norms[r]+e_phase_dot+1)
            err=up(e_phase_dot+e_const+e_mass+e_combine+arb(self.tail[r])+arb('1e-290'));errors.append(err)
            L=np.maximum(0,np.nextafter(val[r]-np.nextafter(err+up(self.alias[r]),np.inf),-np.inf))
            V=np.minimum(up(self.mass[r]),np.nextafter(val[r]+err,np.inf))
            assert np.all(L<=V)
            Ls.append(L);Us.append(V)
        self.L=np.array(Ls);self.V=np.array(Us);self.errors=errors
        lo=arb(0);hi=arb(0);components=[]
        for r,key in enumerate(self.keys):
            cc=self.co[key]
            clo=np.array([np.nextafter(float(c),-np.inf) for c in cc]);chi=np.array([np.nextafter(float(c),np.inf) for c in cc])
            ll=integrate_bound(clo,self.L[r],self.V[r],-1);hh=integrate_bound(chi,self.L[r],self.V[r],1)
            lo+=arb(ll);hi+=arb(hh);components.append(dict(key=key,lower=ll,upper=hh))
        return down(lo),up(hi),components

def run(m):
    t=time.time();ctx.prec=256
    tp=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
    tr=json.load(open(tp));old=json.load(open(B/f'rescaled/integrated_m{m}.json'));orig=json.load(open(tp.with_suffix('.interval_certificate.json')))
    sigma=1+F(tr['delta'])*tr['eps_cells'];cdf=CappedMeanCDF(tr,sigma);cdf.run_setup();nl,nu,com=cdf.evaluate()
    # On the original profile support U<=S/sigma<=1. Hence the removed
    # mean numerator is at most C^2 times the bad-set probability.
    correction=arb(old['amplitude_upper'])**2*arb(old['support_bad_probability_upper'])
    meanlo=down((arb(nl)-correction)/arb(orig['den_upper']))
    meanhi=up(arb(nu)/arb(old['restricted_den_lower']))
    assert 0<meanlo<meanhi<1
    k=tr['k'];h=F(1,11);q=F(old['original_quotient_lower'])-F(old['restriction']['loss_upper']);target=F(m)/(F(1,4)+F(tr['omega']))
    # Since 0<=U<=1, E U^2<= E U <= meanhi. Use both enclosures.
    def bet(d):return F(d,k)*F(meanlo)-F(d*(d-1),2*k*(k-1)*h)*F(meanhi)
    def margin(d):return F(k-d,k)*q-target*(1-bet(d))
    l=0;r=int(h*(k-1))
    while l+1<r:
        d=(l+r)//2
        if margin(d)>0:l=d
        else:r=d
    assert margin(l)>0 and margin(l+1)<=0
    out=dict(m=m,k=k,dimension=k-l,deleted=l,capped_mean_lower=meanlo,capped_mean_upper=meanhi,weighted_numerator_lower=nl,weighted_numerator_upper=nu,unrestricted_den_upper=orig['den_upper'],restricted_den_lower=old['restricted_den_lower'],bad_mean_correction_upper=up(correction),beta_lower=[bet(l).numerator,bet(l).denominator],raw_margin=[margin(l).numerator,margin(l).denominator],effective_margin_lower=down(ar(margin(l)/(1-bet(l)))),next_raw_margin_upper=up(ar(margin(l+1))),moment_keys=cdf.keys,cdf_errors=cdf.errors,fourier_frequencies=cdf.J,fourier_tail=cdf.tail,alias=list(map(up,cdf.alias)),components=com,precision_bits=ctx.prec,seconds=time.time()-t,method='Direct tagged capped-sum moment; inherited quotient and stricter-support certificates')
    (B/f'direct_mean/m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
    np.savez_compressed(B/f'direct_mean/m{m}_cdf_data.npz',C=cdf.C,y=cdf.y,L=cdf.L,V=cdf.V)
    print(json.dumps({a:b for a,b in out.items() if not isinstance(b,list)}),flush=True)
    return cdf,out

if __name__=='__main__':
    for m in map(int,sys.argv[1:] or [4,5]):run(m)
