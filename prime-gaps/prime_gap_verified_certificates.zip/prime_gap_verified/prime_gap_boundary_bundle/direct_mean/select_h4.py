from pathlib import Path
import numpy as np,json,subprocess
B=Path(__file__).resolve().parents[1]
r=json.load(open(B/'direct_mean/m4.json'));K=r['dimension']
h=np.loadtxt(B/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
assert np.all(np.diff(h)>0)
w=h[K-1:]-h[:len(h)-K+1];j=int(np.argmin(w));a=h[j:j+K]
out=dict(k=K,parent_cardinality=len(h),candidate_windows=len(w),start_index=j,first=int(a[0]),last=int(a[-1]),diameter=int(w[j]))
(B/'direct_mean/h4_selection.json').write_text(json.dumps(out,indent=2)+'\n')
np.savetxt(B/'direct_mean/recomputed/h4.csv',a,fmt='%d')
with open(B/'direct_mean/h4_verified.json','w') as f:
 subprocess.run([str(B/'direct_mean/recomputed/verify_tuple'),str(B/'direct_mean/recomputed/h4.csv'),str(B/'baseline/inherited/tuples/h4_witness.csv'),str(K)],stdout=f,check=True)
print(json.dumps(out),flush=True)
print((B/'direct_mean/h4_verified.json').read_text(),flush=True)
