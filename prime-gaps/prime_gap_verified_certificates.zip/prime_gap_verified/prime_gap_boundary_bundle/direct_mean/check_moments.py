"""Supplementary exact and high-precision tests for the new tagged statistic.
These are diagnostics, not replacements for the analytic enclosure proof.
"""
from pathlib import Path
import json,sys,random,itertools,math
from fractions import Fraction as F
import mpmath as mp
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'direct_mean'))
from capped_mean import tagged_weights,CappedMeanCDF,arb,ctx
from polynomial_core import needed_moments
keys=needed_moments(((),(2,),(3,),(4,),(2,2)))[0]
rng=random.Random(20261104);count=0
for case in range(12):
    n=2+case%3
    vals=[F(0),F(1,3),F(1)]
    probs=[F(1,4),F(1,2),F(1,4)]
    z=[F(rng.randrange(1,9),10) for _ in vals]
    u=[min(x,F(2,5)) for x in vals]
    mu=[sum(p*x**j*v for p,x,v in zip(probs,vals,z)) for j in range(9)]
    nu=[sum(p*x**j*v*w for p,x,v,w in zip(probs,vals,z,u)) for j in range(9)]
    got=tagged_weights(n,mu,nu,keys);ref=[F(0)]*len(keys)
    for seq in itertools.product(range(3),repeat=n):
        weight=math.prod(probs[i]*z[i] for i in seq);U=sum(u[i] for i in seq)
        power={j:sum(vals[i]**j for i in seq) for j in range(2,9)}
        for r,key in enumerate(keys):ref[r]+=weight*U*math.prod(power[j] for j in key)
    assert got==ref
    count+=len(keys)
subset=0
for case in range(120):
    k=5+case%4;d=1+case%min(k,4);aa=[F(rng.randrange(1,100)) for _ in range(k)];ss=sum(aa)*F(11,10)
    t=[x/ss for x in aa];h=F(1,11);U=sum(min(x,h) for x in t)
    avg=sum(min(sum(t[i] for i in ix),h) for ix in itertools.combinations(range(k),d))/math.comb(k,d)
    lower=F(d,k)*U-F(d*(d-1),2*h*k*(k-1))*U**2
    assert avg>=lower;subset+=1
mp.mp.dps=100;ctx.prec=320;quad_count=0;worst=mp.mpf(0)
for m in [4,5]:
    tr=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
    sigma=1+F(tr['delta'])*tr['eps_cells'];cdf=CappedMeanCDF(tr,sigma)
    k=tr['k'];b=mp.mpf(k-1);c=mp.mpf(tr['theta'])/mp.log(k);T=mp.mpf(tr['beta'])/mp.log(k);A=mp.mpf(tr['relative_shift'])/(c+b*T)
    m2=(1/c-1/(c+b*T))/b+2*A/b*mp.log((c+b*T)/c)+A*A*T
    sig=mp.mpf(sigma.numerator)/sigma.denominator;w=sig/11;L=mp.log(1+b*T/c);cut=mp.log(1+b*w/c)
    points=sorted(set([mp.mpf(0),L,cut]+[mp.mpf(j) for j in range(1,int(L)+1)]))
    def mid(z):
        if hasattr(z.x,'_mpci_'):
            re,im=z.x._mpci_
            return mp.mpc((mp.make_mpf(re[0])+mp.make_mpf(re[1]))/2,(mp.make_mpf(im[0])+mp.make_mpf(im[1]))/2)
        a,b=z.x._mpi_;return (mp.make_mpf(a)+mp.make_mpf(b))/2
    for freq in [0,7]:
        mus,nus=cdf.moments('zero',0) if freq==0 else cdf.moments('fourier',cdf.freq*freq)
        xi=2*mp.pi*freq/8
        for p in [0,2,8]:
            for tagged,got in [(False,mus[p]),(True,nus[p])]:
                def fn(y):
                    tt=c/b*mp.expm1(y);gg=1/(c*mp.exp(y))+A;dt=c/b*mp.exp(y)
                    return (tt/T)**p*mp.exp(1j*xi*tt)*gg**2*dt/m2*(min(tt/sig,mp.mpf(1)/11) if tagged else 1)
                ref=mp.quad(fn,points);err=abs(mid(got)-ref)/max(abs(ref),mp.mpf('1e-100'))
                assert err<mp.mpf('1e-60'),(m,freq,p,tagged,mp.nstr(err))
                worst=max(worst,err);quad_count+=1
out=dict(exact_tagged_moment_identities=count,exact_subset_inequalities=subset,independent_log_coordinate_integrals=quad_count,max_relative_quadrature_discrepancy=mp.nstr(worst,12),status='passed')
(B/'direct_mean/moment_diagnostics.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
