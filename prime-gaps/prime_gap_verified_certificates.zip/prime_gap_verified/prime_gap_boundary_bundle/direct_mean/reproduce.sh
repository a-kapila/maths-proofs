#!/usr/bin/env bash
# Reproduce this continuation. The older quotient and support bounds remain inherited.
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
  echo 'usage: bash direct_mean/reproduce.sh [--checks-only|--full]' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
mkdir -p direct_mean/recomputed
if [[ "$mode" == --full ]]; then
  python direct_mean/capped_mean.py 4 5
fi
python direct_mean/check_moments.py
python direct_mean/verify_direct.py
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o direct_mean/recomputed/verify_tuple
python direct_mean/select_h4.py
python baseline/inherited/tuples/decode_h5.py direct_mean/recomputed/old_unpatched.bin
python baseline/h5/apply_patches.py direct_mean/recomputed/old_unpatched.bin direct_mean/recomputed/previous_h5.bin
python new/apply_new_h5_patches.py direct_mean/recomputed/previous_h5.bin direct_mean/recomputed/current_h5.bin
"$cxx" -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o direct_mean/recomputed/verify_h5
K=$(python -c 'import json;print(json.load(open("direct_mean/m5.json"))["dimension"])')
direct_mean/recomputed/verify_h5 234360000 "$K" 10000000 2432107459 direct_mean/recomputed/current_h5.bin >direct_mean/recomputed/h5_verified.json
python - <<'PY'
import json
from pathlib import Path
p=Path('direct_mean')
old=json.load(open(p/'h5_verified.json'));new=json.load(open(p/'recomputed/h5_verified.json'))
for key,value in old.items():
    if key!='seconds':assert new[key]==value,(key,value,new[key])
result=json.load(open(p/'RESULTS.json'))
h4=json.load(open(p/'h4_verified.json'))
assert h4['verified'] and h4['diameter']==result['bounds']['H4']
assert new['verified'] and new['diameter']==result['bounds']['H5']
print('New deductions and complete integer tuple checks pass.')
print('The inherited quotient and stricter-support calculations were not rerun by this script.')
PY
