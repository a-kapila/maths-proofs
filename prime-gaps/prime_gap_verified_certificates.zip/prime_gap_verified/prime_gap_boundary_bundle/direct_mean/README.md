# Direct capped-sum moments: current continuation

The newest results in this bundle are in `direct_mean/RESULTS.json` and
`direct_mean/proof_note.pdf`. Older root-level notes and RESULT files describe
previous continuations and are retained as dependencies.

The resulting bounds are H2 <= 19,920 (inherited), H3 <= 1,359,754 (inherited),
H4 <= 82,276,636, and H5 <= 4,832,040,750.

## What was actually computed

This continuation evaluated 14 positive capped-sum-weighted CDFs for each of the
fixed H4 and H5 trials. It used interval-enclosed one-coordinate transforms,
explicit Fourier and periodization tails, and bounded direct Fourier summation
at the exact dyadic profile edges. The two existing quotient certificates and
the stricter-support certificates under `rescaled/` were reused, not recomputed.
The new exact dimension deductions, independent moment/quadrature diagnostics,
and complete tuple verification were executed.

These are computational research deductions, not independent peer review or a
formal proof-assistant verification of the entire inherited argument. The scalar
backend is the inherited `mpmath.iv` compatibility library, NOT FLINT/Arb.

## Reproduction

From the bundle root:

```bash
bash direct_mean/reproduce.sh --checks-only
bash direct_mean/reproduce.sh --full
```

`--checks-only` checks saved endpoint implications, geometry, the explicit direct-
summation error factor, exact finite-law and subset identities, independent
high-precision integrals and finite Fourier sums, and both full tuples.
`--full` additionally recomputes the two new weighted Fourier-moment enclosures.
Neither reruns the older quotient or stricter-support calculations; commands for
those remain in the preceding directories.

Python 3, NumPy, SciPy, mpmath, a C++17 compiler, and OpenMP are used. The complete
large-tuple checker uses approximately 1.5 GB of memory. Do not disable assertions.
Temporary reconstructed tuple files and binaries belong in `recomputed/` and are
not distributed. Full original data are retained, including the compressed
12,204,094-prime witness sequence and its patches.

## Files

- `capped_mean.py`: new tagged moment identity, one-coordinate transforms,
  positive weighted CDFs, explicit direct-summation error allowance, and deductions.
- `m4.json`, `m5.json`: fresh numerical enclosures and exact rational margins.
- `m4_cdf_data.npz`, `m5_cdf_data.npz`: rounded Fourier coefficients and CDF bounds
  used by supplementary independent finite-sum diagnostics.
- `verify_direct.py`: exact arithmetic, inherited-geometry checks, fixed-input
  rescaling ceilings, and high-precision finite Fourier comparisons.
- `check_moments.py`: exact finite-law and subset tests, plus independent
  log-coordinate quadrature.
- `h4_selection.json`, `h4_verified.json`, `h5_verified.json`: complete integer checks.
- `verification.json`, `moment_diagnostics.json`: passed checks and hashes.

The `radial/` directory records an exploratory exponential-envelope attempt; it
is NOT used in the final bounds. Initial diagnostic-harness error logs are kept
for provenance: one involved converting an interval complex wrapper, and another
compared a finite Fourier sum against a positivity-clipped CDF interval. The final
direct-sum diagnostic compares before positivity clipping. Neither altered the
computed transform coefficients or certificate endpoints.

## Limit statement

The 1,173 / 38,270 deletion ceilings apply only to the capped-rescaling deduction
with the SAME saved quotient lower bound, SAME trial, SAME stricter support, and
SAME cap h=1/11. They are not general sieve barriers or lower bounds for H_m.
