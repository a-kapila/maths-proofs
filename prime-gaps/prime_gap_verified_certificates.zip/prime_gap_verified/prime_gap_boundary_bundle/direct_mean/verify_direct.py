"""Check saved endpoint deductions exactly and finite Fourier sums independently.
Does not rerun the inherited quotient or stricter-support computation.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
import numpy as np
import mpmath as mp
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'direct_mean'))
from capped_mean import CappedMeanCDF,tagged_weights,ctx
mp.mp.dps=85;ctx.prec=320
checks=[];direct_tests=0;max_error_ratio=mp.mpf(0)
for m in [4,5]:
 path=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
 tr=json.load(open(path));orig=json.load(open(path.with_suffix('.interval_certificate.json')))
 old=json.load(open(B/f'rescaled/integrated_m{m}.json'));out=json.load(open(B/f'direct_mean/m{m}.json'))
 k=tr['k'];sig=1+F(tr['delta'])*tr['eps_cells'];h=F(1,11);rho=F(1,4)+F(tr['omega']);target=F(m)/rho
 assert old['original_quotient_lower']==orig['Q_lower']
 assert 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3 and 2*rho*sig<1
 kappa=(F(1,4)+F(tr['smooth_delta'])/2)/rho-F(1,10000)
 assert F(11,10)*F(old['new_kappa'])<=kappa
 assert F(11,10)*F(old['new_ufrac'])<=F(tr['ufrac'])
 C=F(old['amplitude_upper']);pb=F(old['support_bad_probability_upper']);corr=C*C*pb
 assert F(old['restricted_den_lower'])<=F(orig['den_lower'])-corr
 meanlo=F(out['capped_mean_lower']);meanhi=F(out['capped_mean_upper'])
 assert meanlo<=(F(out['weighted_numerator_lower'])-corr)/F(orig['den_upper'])
 assert meanhi>=F(out['weighted_numerator_upper'])/F(old['restricted_den_lower'])
 assert 0<meanlo<meanhi<1
 q=F(old['original_quotient_lower'])-F(old['restriction']['loss_upper'])
 def beta(d):return F(d,k)*meanlo-F(d*(d-1),2*h*k*(k-1))*meanhi
 def margin(d):return F(k-d,k)*q-target*(1-beta(d))
 d=out['deleted'];assert k-d==out['dimension']
 assert beta(d)==F(*out['beta_lower']) and margin(d)==F(*out['raw_margin'])
 assert margin(d)>0 and margin(d+1)<=0
 assert 0<F(out['effective_margin_lower'])<=margin(d)/(1-beta(d))
 bound=F(k)*(q-target)/(q-target*meanhi)
 ideal=(bound.numerator-1)//bound.denominator
 assert F(k-ideal,k)*q>target*(1-F(ideal,k)*meanhi)
 assert F(k-ideal-1,k)*q<=target*(1-F(ideal+1,k)*meanhi)
 # Exact sufficient error-factor comparison for the direct complex dot.
 J=out['fourier_frequencies'];u=F(1,2**53);ep=4096*u;gam=F(J+3)*u/(1-F(J+3)*u)
 assert ep+2*gam*(1+ep)<(8192+8*J)*u
 # Supplementary high-precision finite-sum comparisons against saved CDF bounds.
 z=np.load(B/f'direct_mean/m{m}_cdf_data.npz');cf=z['C'];ys=z['y'];L=z['L'];V=z['V']
 obj=CappedMeanCDF(tr,sig);mu,nu=obj.moments();mass=tagged_weights(k,mu,nu,obj.keys)
 def midreal(a):
     x,y=a.x._mpi_;return (mp.make_mpf(x)+mp.make_mpf(y))/2
 mm=list(map(midreal,mass)); phases=obj.phases()
 for ix in [1,len(ys)//2,len(ys)-1]:
     yy=mp.mpf(float(ys[ix]));step=mp.exp(-2j*mp.pi*yy/8);phase=mp.mpc(1)
     sums=[mp.mpf(0)]*len(obj.keys)
     for j in range(J):
         phase*=step
         for r in range(len(obj.keys)):
             c=mp.mpc(float(cf[r,j].real),float(cf[r,j].imag))
             sums[r]+=2*mp.re(c*(1-phase))
     for r in range(len(obj.keys)):
         ref=mm[r]*yy/8+sums[r]
         # Compare the finite Fourier sum BEFORE positivity clipping. The finite
         # series itself can be slightly negative where the true CDF is zero.
         acc=0.0
         for j in range(J):
             acc=acc+(float(cf[r,j].real)*float(phases[ix,j].real)-float(cf[r,j].imag)*float(phases[ix,j].imag))
         const=float(mp.fsum(2*mp.mpf(float(c.real)) for c in cf[r]))
         approximate=float(mm[r])*(float(yy)/8)+const-2*acc
         ratio=abs(mp.mpf(approximate)-ref)/mp.mpf(out['cdf_errors'][r])
         assert ratio<=1,(m,r,ix,mp.nstr(ratio))
         max_error_ratio=max(max_error_ratio,ratio);direct_tests+=1
 checks.append(dict(m=m,k=k,dimension=k-d,deleted=d,positive_exact_margin=True,next_deletion_fails=True,mean_lower=float(meanlo),mean_upper=float(meanhi),optimistic_maximum_deletions_with_same_quotient=ideal,remaining_possible_deletions=ideal-d,optimistic_bound_exact=[bound.numerator,bound.denominator],geometry_checked=True,error_factor_checked=True,trial_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),coefficient_data_sha256=hashlib.sha256((B/f'direct_mean/m{m}_cdf_data.npz').read_bytes()).hexdigest()))
result=dict(exact_checks=checks,high_precision_finite_fourier_tests=direct_tests,max_finite_sum_error_to_error_allowance=mp.nstr(max_error_ratio,12),status='passed')
(B/'direct_mean/verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
