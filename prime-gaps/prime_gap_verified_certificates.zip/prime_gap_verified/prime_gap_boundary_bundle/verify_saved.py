"""Exact rational checks of saved analytic endpoints, plus tuple output metadata.
This does not independently validate the inherited analytic/FFT arguments.
"""
from pathlib import Path
import sys,json
from fractions import Fraction as F
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'baseline'/'inherited'/'analysis'))
from exact_slicing import check
results=json.loads((ROOT/'RESULTS.json').read_text())['results']
checked=[]
for key,record in results.items():
    if not record['new_analytic_certificate']:
        continue
    trial=ROOT/record['trial']
    c=check(trial)
    assert c['final_K']==record['K'] and c['margin_float']>0
    v=json.loads((ROOT/record['tuple_verification']).read_text())
    assert v['verified'] and v['k']==record['K'] and v['diameter']==record['bound']
    assert v['last']-v['first']==record['bound']
    checked.append(c)
relax=json.loads((ROOT/'verification'/'h5_relaxation.json').read_text())
assert relax['k']==results['H5']['K']
assert relax['left']*-1+relax['right']==relax['diameter_lower_bound_for_restore_only']
D=results['H5']['bound'];R=relax['diameter_lower_bound_for_restore_only']
assert 0<R<D
out={'exact_slicing_checks':checked,'h5_restore_only_remaining_fraction_exact':str(F(D-R,D))}
(ROOT/'verification'/'saved_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verified_new_dimensions':{f"H{x['m']}":x['final_K'] for x in checked},'h5_restore_only_remaining_percent':float(100*F(D-R,D))}))
