# Latest continuation: quadratic Hermite pair bounds

The authoritative new result is in `next_pair/RESULTS.json` and the proof is
`next_pair/proof_note.pdf`. Earlier root and per-directory result files are
historical and may state weaker bounds.

Current bounds within the inherited analytic framework:
H2 <= 19,844; H3 <= 1,358,006; H4 <= 82,234,788; H5 <= 4,830,355,416.
Only H2 and H3 are improved here.

Run from the extracted archive root:

```bash
bash next_pair/reproduce.sh --checks-only
bash next_pair/reproduce.sh --full
```

The checks-only workflow recomputes exact rational deductions, independent
moment/algebra diagnostics, both complete integer tuple checks, and long-pair
lists. Full additionally recomputes six new weighted-CDF batches, totaling 96
positive distribution functions. Original successful quotient and arithmetic
support-loss calculations are inherited and are not rerun by either new command;
their original sources and reproduction scripts remain in the archive.

The final proof uses `hermite_pair.py`. `cubic_pair.py` records an intermediate
secant refinement; its results are not the final authoritative bounds.

Requirements: Python 3, NumPy, SciPy, mpmath, a C++17 compiler. Keep assertions
enabled. The documented local module called flint.py is an mpmath.iv
compatibility backend, NOT FLINT/Arb. The retained numerical tail and rounding
arguments remain dependencies. The complete analytic chain has not received
independent expert review or proof-assistant verification.

Timing fields are not mathematical outputs. Full reruns regenerate JSON timing
metadata; the input manifest is checked before regeneration. 