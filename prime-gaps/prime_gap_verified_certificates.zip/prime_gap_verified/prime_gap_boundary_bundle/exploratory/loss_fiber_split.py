"""Refined partial-fiber support loss. Every removed coordinate interval has
its own necessary heavy-count and light-sum conditions. The bins cover [wl,T]
and integrate g exactly through its primitive. The old whole-fiber case is
unchanged. All bounds are interval evaluated; proposed cut points are exact
binary64 numbers chosen below the critical count-change values.
"""
import sys,json,math
import numpy as np
from flint import arb,ctx
from rc_loss_rig import kl_tail
from shifted_core import setup
from loss_joint import joint_tail
def restriction_loss(k, theta, beta, delta, omega, Eh2_lower, eta=1e-4, ufrac=0.5, ratio=1.02, cv=1.5, sum_cap=1.0, region_kappa=None,relative_shift=0.,inner_cap=None):
    sum_cap = arb(sum_cap)
    assert k >= 2 and theta > 0 and beta > 0
    assert delta > 0 and omega > 0 and Eh2_lower > 0
    assert 0 < ufrac < 1 and eta > 0 and ratio > 1 and cv > 0
    kk = arb(k); L = kk.log(); c = arb(theta) / L; T = arb(beta) / L; b = kk - 1
    S=setup(k,theta,beta,relative_shift);m2=S["m2"];A=S["A"]
    rho = arb(1) / 4 + arb(omega)
    u0 = arb(ufrac) * arb(delta) / rho
    kappa = (arb(1) / 4 + arb(delta) / 2) / rho - arb(eta)
    if region_kappa is not None:
        kappa = arb(region_kappa)
    s = arb(cv)
    assert kappa > 0 and sum_cap > 0 and u0 < T
    assert (s + 1) * T < kappa, "need T < kappa/(s+1)"
    cf = float(c.mid()); bf = float(b.mid()); m2f = float(m2.mid()); Tf = float(T.mid())
    cdf = S["F"]
    G = S["G"]
    GT = G(T)
    grid = [u0]
    while True:
        nxt = grid[-1] * arb(ratio)
        if nxt < T:
            grid.append(nxt)
        else:
            grid.append(T)
            break
    upward = lambda x: float(np.nextafter(float(x.upper()), np.inf))
    lams = np.exp(np.linspace(math.log(1e-3), math.log(1e7), 900))
    K = k - 1
    Pa_tot = arb(0); Lb_tot = arb(0)
    for l in range(len(grid) - 1):
        wl, wn = grid[l], grid[l + 1]
        q = cdf(wl); p = 1 - q
        pf = float(p.mid())
        meanN = K * pf; sdN = math.sqrt(K * pf * (1 - pf))
        nmax = min(int(meanN + 14 * sdN + 20), K - 1)
        m = K - nmax
        tailNmax = kl_tail(K, nmax + 1, p)
        # case (a)
        A_a = kappa - s * wn
        n0a = int(math.floor(np.nextafter(float((A_a / T).lower()), -np.inf)))   # float() rounds to nearest: step down
        cap_a = sum_cap if inner_cap is None else min(sum_cap, arb(inner_cap))
        b_a = arb(min(upward(cap_a - A_a + arb(eta)), upward(cap_a - (n0a + 1) * wl + arb(eta))))
        Pa = joint_tail(K,n0a+1,b_a,wl,S,lams)
        # case (b): integrate the removed coordinate in count-change bins.
        # If t in [lo,hi], the other heavy coordinates have sum
        # > kappa-s*wn-hi, and count >= floor((kappa-s*wn-hi)/T)+1.
        cuts = [wl]
        for j in range(1, int(math.ceil(float((kappa/T).upper())))+1):
            edge = kappa-s*wn-arb(j)*T
            candidate = arb(float(np.nextafter(float(edge.lower()), -np.inf)))
            if candidate > wl and candidate < T:
                cuts.append(candidate)
        cuts.append(T)
        cuts.sort(key=lambda x: float(x.mid()))
        subtotal=arb(0)
        for lo,hi in zip(cuts[:-1],cuts[1:]):
            A_b = kappa-s*wn-hi
            n0b = int(math.floor(np.nextafter(float((A_b/T).lower()), -np.inf)))
            count = n0b+1
            caps=[upward(sum_cap-kappa+s*wn+arb(eta)),
                  upward(sum_cap-arb(count)*wl-lo+arb(eta))]
            if inner_cap is not None:
                caps += [upward(arb(inner_cap)-A_b+arb(eta)),
                         upward(arb(inner_cap)-arb(count)*wl+arb(eta))]
            b_b=arb(min(caps))
            Pb=joint_tail(K,count,b_b,wl,S,lams)
            subtotal += 2*GT*(G(hi)-G(lo))*Pb
        Pa_tot += Pa
        Lb_tot += subtotal
    Eloss = GT ** 2 * Pa_tot + Lb_tot
    loss = kk * Eloss / (m2 * arb(Eh2_lower))
    return dict(k=k, theta=theta, beta=beta, relative_shift=relative_shift, delta=delta, omega=omega, cv=cv, kappa=float(kappa.mid()), cells=len(grid) - 1,
                method='joint tilted-binomial with removed-coordinate count-change integration', inner_cap=inner_cap, Pa_upper=upward(Pa_tot), Lb_upper=upward(Lb_tot), loss_upper=upward(loss))
