"""Exact-rational dual amplitude bound, using cubic Bernstein enclosures.
The optimizer only proposes lambda; every candidate inequality is checked here.
"""
from fractions import Fraction as F
from pathlib import Path
import heapq,math,json,sys
from amplitude_envelope import extrema_quadratic,upfloat,rational

def cubic_upper(a,b,c,tolerance=F(1,2**36)):
    """Bound max_{0<=x<=1} a*x+b*x^2+c*x^3 by Bernstein subdivision."""
    bs=(F(0),a/3,2*a/3+b/3,a+b+c)
    lower=max(bs[0],bs[-1]);heap=[(-max(bs),0,bs)];serial=0
    for _ in range(256):
        upper=-heap[0][0]
        if upper<=lower+tolerance:return upper
        _,_,z=heapq.heappop(heap)
        x=[(z[i]+z[i+1])/2 for i in range(3)]
        y=[(x[i]+x[i+1])/2 for i in range(2)]
        mid=(y[0]+y[1])/2
        left=(z[0],x[0],y[0],mid);right=(mid,y[1],x[2],z[3])
        lower=max(lower,mid)
        for child in (left,right):
            serial+=1;heapq.heappush(heap,(-max(child),serial,child))
    # A looser valid bound remains available even if the refinement budget expires.
    return -heap[0][0]

def bound(d,proposals):
    from flint import arb,ctx
    from shifted_core import setup
    ctx.prec=256;S=setup(d['k'],d['theta'],d['beta'],d['relative_shift'])
    hs=d['profiles'];E=d['E'];assert d['basis']==[[],[2],[3],[4],[2,2]]
    C=F(0);records=[]
    assert len(proposals['cells'])==len(hs[0])
    for row in proposals['cells']:
        j=row['j'];zball=arb(int(E[j+1]))*arb(d['delta'])/S['T']
        z=rational(math.nextafter(float(zball.upper()),math.inf))
        n=z.numerator//z.denominator;umax=min(F(d['k']),F(n)+(z-n)**2)
        cell=[]
        for sign,name in [(1,'plus'),(-1,'minus')]:
            h0,h2,h3,h4,h22=[sign*rational(h[j]) for h in hs]
            lam=rational(row['lambda_'+name])
            M=cubic_upper(h2-lam,h3,h4)
            qmax=extrema_quadratic(F(0),lam,h22,umax)[1]
            value=h0+qmax+z*max(F(0),M)
            cell.append(upfloat(value));C=max(C,value)
        records.append({'j':j,'upper_plus':cell[0],'upper_minus':cell[1]})
    return {'amplitude_upper':upfloat(C),'exact_amplitude_bound':str(C),'cells':records,'cubic_tolerance_exact':'1/68719476736','method':'rational dual polynomial with Bernstein cubic bound'}

if __name__=='__main__':
    BASE=Path(__file__).resolve().parents[1]
    sys.path.insert(0,str(BASE/'inherited'/'analysis'))
    d=json.loads(Path(sys.argv[1]).read_text());p=json.loads(Path(sys.argv[2]).read_text())
    out=bound(d,p);Path(sys.argv[3]).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k not in ['cells','exact_amplitude_bound']}))
