# Latest continuation: 5 November 2026

Read continued/README.md and continued/proof_note.pdf.

H2 <= 19846; H3 <= 1358012. H4 and H5 unchanged from radial23/.

Run bash continued/reproduce.sh --checks-only (or --full).

All earlier files are historical inputs; the latest authoritative results are continued/RESULTS.json.
