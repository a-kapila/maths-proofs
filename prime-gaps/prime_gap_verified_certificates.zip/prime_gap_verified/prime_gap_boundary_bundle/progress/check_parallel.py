from pathlib import Path
import sys,json,numpy as np
B=Path(__file__).resolve().parents[1];sys.path[:0]=[str(B/'analysis'),str(B/'progress')]
from fast_profile import profile_bounds as old
from parallel_profile import profile_bounds as new
rng=np.random.default_rng(70004);count=0
for case in range(80):
 nh=int(rng.integers(2,80));nt=int(rng.integers(10,700));ni=int(rng.integers(1,20000))
 h=rng.integers(-2**20,2**20,size=nh).astype(float)*2**-20
 edges=np.r_[0,np.cumsum(rng.integers(1,50,size=nh))].astype(np.int64)
 I=np.sort(rng.integers(0,int(edges[-1])+20,size=ni)).astype(np.int64)
 mid=np.cumsum(rng.uniform(0,1e-4,size=nt));lo=np.nextafter(mid,-np.inf);hi=np.nextafter(mid,np.inf)
 a=old(h,(lo,hi),edges,I);b=new(h,(lo,hi),edges,I)
 assert np.array_equal(a[0],b[0]) and np.array_equal(a[1],b[1]);count+=ni
out={'cases':80,'pointwise_intervals':count,'bitwise_identical':True}
(B/'progress/parallel_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
