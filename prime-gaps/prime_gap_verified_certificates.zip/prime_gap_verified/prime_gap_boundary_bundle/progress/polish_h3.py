from pathlib import Path
import subprocess,json,time,numpy as np
B=Path(__file__).resolve().parents[1];O=B/'progress';tp=B/'next23/h3_final.csv';wp=B/'next23/h3_final_witness.csv';t=time.time();hist=[]
for stage in range(7):
 a=np.loadtxt(tp,dtype=np.int64);lo=int(a[0]);hi=int(a[-1])-2;old=hi-lo+2;pref=O/f'h3_cover_{stage}'
 with open(str(pref)+'.log','w') as f:
  subprocess.run([str(O/'cover_descent'),'110050',str(lo),str(hi),str(wp),'180',str(pref),str(7100+stage*17),'110050'],stdout=f,stderr=subprocess.STDOUT,check=True)
 nt=Path(str(pref)+'.csv');nw=Path(str(pref)+'_witness.csv')
 if not nt.exists():break
 v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(nt),str(nw),'110050'],text=True));assert v['verified'] and v['diameter']<old
 hist.append(dict(**v,tuple=str(nt.relative_to(B)),witnesses=str(nw.relative_to(B)),seconds=time.time()-t));tp=nt;wp=nw
 (O/'h3_search_results.json').write_text(json.dumps(hist,indent=2)+'\n');print(json.dumps(hist[-1]),flush=True)
print(json.dumps(dict(stages=len(hist),tuple=str(tp.relative_to(B)),witnesses=str(wp.relative_to(B)),seconds=time.time()-t)),flush=True)
