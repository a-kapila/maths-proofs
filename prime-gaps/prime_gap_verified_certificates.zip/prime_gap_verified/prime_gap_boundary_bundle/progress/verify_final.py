"""Exact deductions and independent full integer verification.
Does not independently audit the inherited analytic theorem or Fourier proof.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
B=Path(__file__).resolve().parents[1];O=B/'progress';sys.path.insert(0,str(O))
from check_tuples import verify

def main():
 inherited=json.load(open(B/'focus23/RESULTS.json'))['results'][0]
 t2=json.load(open(B/inherited['trial']));q2=F(inherited['component_quotient_lower'])-F(inherited['restriction_loss_upper']);rho2=F(1,4)+F(t2['omega'])
 assert q2>2/rho2 and 240*F(t2['omega'])+80*F(t2['smooth_delta'])<3
 v2=verify(O/'h2_final.csv',O/'h2_final_witness.csv',2304)
 t=json.load(open(O/'m3_k110040_finer.json'));old=json.load(open(B/'next23/m3_k110040.json'));c=json.load(open(O/'m3_k110040_finer.interval_certificate.json'))
 assert t['profiles']==old['profiles'] and t['basis']==old['basis']
 for key in ['k','theta','beta','relative_shift','omega','smooth_delta','ufrac','period']:assert t[key]==old[key]
 assert [F(x)*F(t['delta']) for x in t['E']]==[F(x)*F(old['delta']) for x in old['E']]
 eps=F(t['delta'])*t['eps_cells'];assert eps==F(old['delta'])*old['eps_cells'] and F(t['delta'])==F(1,2**25)
 assert c['trial_sha256']==hashlib.sha256((O/'m3_k110040_finer.json').read_bytes()).hexdigest()
 rho=F(1,4)+F(t['omega']);q=F(c['Q_lower'])-F(c['restriction']['loss_upper']);margin=q-3/rho
 assert 240*F(t['omega'])+80*F(t['smooth_delta'])<3 and 2*rho*(1+eps)<1
 assert margin>0 and F(t['k']-1,t['k'])*q<=3/rho
 assert len(c['direct_fourier_checks'])==108 and c['bitwise_CDF_checks']==[2002,2002,2002] and c['chunks']==47
 v3=verify(O/'h3_final.csv',O/'h3_final_witness.csv',110040)
 best_old=min(json.load(open(O/'h3_search_results.json')),key=lambda r:r['diameter'])
 v3old=verify(B/best_old['tuple'],B/best_old['witnesses'],110050)
 assert v3old['diameter']==best_old['diameter']
 out=dict(scope='Computer-assisted deductions within the inherited framework; no independent analytic audit or global optimality claimed.',
  H2=dict(previous_bound=19886,bound=v2['diameter'],saving=19886-v2['diameter'],analytic_dimension=2304,analytic_status='Inherited successful certificate, not recomputed in this continuation',tuple=v2),
  H3=dict(previous_bound=1359284,bound=v3['diameter'],saving=1359284-v3['diameter'],analytic_dimension=110040,previous_dimension=110050,Q_lower=c['Q_lower'],restriction_loss_upper=c['restriction']['loss_upper'],target_upper=c['target_upper'],margin_fraction=[str(margin.numerator),str(margin.denominator)],margin_float=float(margin),same_physical_function_as_failed_trial=True,ordinary_slicing_cannot_remove_another_coordinate=True,tuple=v3,
    intermediate_old_dimension_bound=v3old['diameter'],saving_at_old_dimension=1359284-v3old['diameter'],additional_saving_after_new_dimension=v3old['diameter']-v3['diameter']),
  unchanged=dict(H4=82258490,H5=4831230984),
  diagnostics=dict(direct_fourier_checks=108,requested_point_bitwise_comparisons=6006,parallel_profile=json.load(open(O/'parallel_checks.json')),chunked_abel=json.load(open(O/'chunked_abel_checks.json'))))
 (O/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
