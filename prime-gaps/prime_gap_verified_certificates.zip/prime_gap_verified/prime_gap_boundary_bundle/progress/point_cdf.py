"""Evaluate the inherited bounded Fourier interpolant only at requested points.
The arithmetic at each requested dyadic index and the error envelope are the
same as InterpolatedCDF.table. No full fine-grid array is constructed.
"""
from pathlib import Path
import sys,time,json
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'accurate'),str(B/'analysis'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from interpolated_cdf import InterpolatedCDF,short_fft
from flint import arb,acb,ctx
from periodic_shifted import upper
class PointCDF(InterpolatedCDF):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs); self.derivative_tables={};self.point_reports={}
 def prepare(self,key):
  if key in self.derivative_tables:return
  start=time.time();ctx.prec=256;M=self.coarse_N;R=self.order
  assert self.N>=M and self.N%M==0 and self.J<M//2
  factor=self.N//M;coarse_top=self.imax//factor
  norm=[arb(0) for _ in range(R)];errs=[arb(0) for _ in range(R)]
  derived=np.zeros((R,self.J),complex);rem=arb(0)
  for j,raw in enumerate(self.coeffs[key],1):
   z=acb(float(raw.real),float(raw.imag));a=acb(0,-2*arb.pi()*j/M)
   for p in range(R):
    zr,zi=float(z.real.mid()),float(z.imag.mid());derived[p,j-1]=complex(zr,zi)
    norm[p]+=2*z.abs_upper();errs[p]+=2*((arb(zr)-z.real).abs_upper()+(arb(zi)-z.imag).abs_upper())
    z=z*a/(p+1)
   rem+=2*z.abs_upper()
  D=np.empty((R,coarse_top+1));fft_errors=[]
  stages=M.bit_length()-1;u=arb(2)**-53;fac=(1+256*u)**stages
  for p in range(R):
   z=np.zeros(M,complex);z[1:self.J+1]=derived[p];z[-self.J:]=np.conj(derived[p,::-1])
   v=short_fft(z);ferr=(fac-1)*norm[p]+fac*errs[p]+arb('1e-290');fu=upper(ferr);fft_errors.append(fu)
   assert np.max(np.abs(v.imag))<=fu,(key,p,np.max(np.abs(v.imag)),fu)
   D[p]=v.real[:coarse_top+1]
  ffttotal=sum(map(arb,fft_errors));gam=4*R*u/(1-4*R*u)
  horn=gam*(sum(norm)+ffttotal)+arb('1e-290')
  ferr=upper(ffttotal+horn+rem+arb(self.input_err[key]))
  combine=upper(32*u*(abs(arb(self.zero[key]))*arb(self.ymax)/arb(self.P)+2*abs(arb(self.const[key]))+arb(self.norm[key])+arb(ferr)+1))
  err=upper(arb(ferr)+arb(self.const_err[key])+arb(self.zero_err[key])*arb(self.ymax)/arb(self.P)+arb(combine)+arb(self.tail[key])+arb('1e-290'))
  self.derivative_tables[key]=D;self.error[key]=err
  report=dict(key=list(key),coarse_N=M,order=R,fft_error_sum=upper(ffttotal),horner_error=upper(horn),taylor_remainder=upper(rem),total_error=err,seconds=time.time()-start)
  self.point_reports[str(key)]=report
  if self.verbose:print(json.dumps(dict(stage='requested_point_CDF',**report)),flush=True)
 def raw_at(self,key,ix):
  self.prepare(key);ix=np.asarray(ix,dtype=np.int64);factor=self.N//self.coarse_N
  base=ix//factor;x=(ix%factor)/float(factor);D=self.derivative_tables[key]
  value=D[-1,base].copy()
  for p in range(self.order-2,-1,-1):value=value*x+D[p,base]
  return self.zero[key]*(ix.astype(float)/self.N)+self.const[key]-value
 def bounds(self,n,r,ys):
  key=(n,r);ys=np.asarray(ys,float);assert np.all(ys>=0) and np.all(ys<=self.ymax)
  xx=ys/self.DELTA;lo=np.floor(xx).astype(np.int64);hi=np.ceil(xx).astype(np.int64)
  rawl=self.raw_at(key,lo);rawh=rawl if np.array_equal(lo,hi) else self.raw_at(key,hi);err=self.error[key]
  L=np.maximum(0,np.nextafter(rawl-np.nextafter(err+self.alias[key],np.inf),-np.inf))
  U=np.minimum(upper(self.mass[key]),np.nextafter(rawh+err,np.inf));assert np.all(L<=U)
  if key not in self.samples:
   pts=np.array([.5,.75,1.]);ix=np.rint(pts/self.DELTA).astype(np.int64);raw=self.raw_at(key,ix)
   ll=np.maximum(0,np.nextafter(raw-np.nextafter(err+self.alias[key],np.inf),-np.inf))
   uu=np.minimum(upper(self.mass[key]),np.nextafter(raw+err,np.inf))
   self.samples[key]=[(float(y),float(v),float(l),float(u)) for y,v,l,u in zip(pts,raw,ll,uu)]
  return L,U
 def bitwise_test(self,key):
  """Compare against the full-grid evaluator at a smaller logical grid."""
  saved=(self.N,self.imax,self.DELTA)
  try:
   self.N=2**20;self.DELTA=self.P/self.N;self.imax=int(self.ymax/self.DELTA)
   InterpolatedCDF.table(self,key)
   rng=np.random.default_rng(213);ix=np.r_[0,self.imax,rng.integers(0,self.imax+1,size=2000)].astype(np.int64)
   a=self.tables[key][ix];b=self.raw_at(key,ix)
   assert np.array_equal(a,b),(key,float(np.max(np.abs(a-b))))
   del self.tables[key]
   return len(ix)
  finally:self.N,self.imax,self.DELTA=saved
