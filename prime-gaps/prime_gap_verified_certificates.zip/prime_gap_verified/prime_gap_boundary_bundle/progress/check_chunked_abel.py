"""Exact-rational diagnostics for adding certified integrals over disjoint cells.
The proof is additivity of integration plus the inherited directed Abel bound.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json
import numpy as np
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from certify_lifted import integrate_bound
rng=np.random.default_rng(43299);chunks=0
for case in range(600):
 n=int(rng.integers(2,120));mi=rng.integers(0,1024,size=n);ci=rng.integers(-2**20,2**20,size=n)
 masses=mi.astype(float)*2**-20;coeff=ci.astype(float)*2**-20;cdf=np.r_[0,np.cumsum(masses)]
 err=rng.integers(1,50,size=n+1).astype(float)*2**-38
 L=np.maximum(0,np.nextafter(cdf-err,-np.inf));V=np.nextafter(cdf+err,np.inf)
 edges=np.unique(np.r_[0,n,rng.integers(0,n+1,size=int(rng.integers(1,n+1)))])
 lo=F(0);hi=F(0)
 for a,b in zip(edges[:-1],edges[1:]):
  lo+=F(integrate_bound(coeff[a:b],L[a:b+1],V[a:b+1],-1));hi+=F(integrate_bound(coeff[a:b],L[a:b+1],V[a:b+1],1));chunks+=1
 exact=sum(F(int(x)*int(y),2**40) for x,y in zip(mi,ci));assert lo<=exact<=hi,(case,lo,exact,hi)
out=dict(cases=600,chunks_checked=chunks,all_exact_integrals_enclosed=True)
(B/'progress/chunked_abel_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
