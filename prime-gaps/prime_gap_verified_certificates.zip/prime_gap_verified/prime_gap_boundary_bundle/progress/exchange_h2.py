"""Exact one-out/two-in neighborhood of a fixed admissible (K-1)-tuple.
This is a bounded local search, never a global impossibility certificate.
"""
from pathlib import Path
import itertools,json,math,time,sys
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'progress';start=time.time();K=2304;D=19858
s=np.ones(K+1,bool);s[:2]=False
for p in range(2,math.isqrt(K)+1):
 if s[p]:s[p*p::p]=False
ps=np.flatnonzero(s);base=np.loadtxt(O/'h2_stage0_b0_0.csv',dtype=np.int64)
records=[]
for shift in [10,12]:
 A=base-shift;A=A[(A>=0)&(A<=D)];assert len(A)==K-1
 freq=[np.bincount(A%p,minlength=p) for p in ps];missing=[np.flatnonzero(f==0) for f in freq];nm=np.array([len(x) for x in missing]);assert np.all(nm>0)
 cover=np.zeros(D+1,dtype=np.int16)
 for p,miss in zip(ps,missing):
  if len(miss)==1:cover[int(miss[0])::p]+=1
 present=np.zeros(D+1,bool);present[A]=True
 assert not np.any((cover==0)&~present)
 pairs_tested=0;good_removals=0;best_options=0;found=False
 for x in A:
  rx=x%ps;last=np.array([f[r]==1 for f,r in zip(freq,rx)]);released=np.flatnonzero(last&(nm==1))
  for j in released:cover[int(missing[j][0])::int(ps[j])]-=1
  # Exclude x itself: reinserting it would give an impossible one-point extension.
  candidates=np.flatnonzero((cover==0)&~present)
  best_options=max(best_options,len(candidates))
  if len(candidates)>=2:
   good_removals+=1;critical=np.flatnonzero(nm+last==2)
   for y,z in itertools.combinations(candidates,2):
    pairs_tested+=1;ok=True
    for j in critical:
     p=int(ps[j]);a=int(y%p);b=int(z%p)
     if a!=b and freq[j][a]-(a==rx[j])==0 and freq[j][b]-(b==rx[j])==0:
      ok=False;break
    if ok:
     out=np.sort(np.r_[A[A!=x],y,z]);w=[]
     for p in ps:
      miss=np.flatnonzero(np.bincount(out%p,minlength=p)==0);assert len(miss)>0;w.append((p,miss[0]))
     np.savetxt(O/'h2_exchange.csv',out,fmt='%d');np.savetxt(O/'h2_exchange_witness.csv',w,fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
     found=True;print(json.dumps({'found':True,'shift':shift,'removed':int(x),'added':[int(y),int(z)],'diameter':int(out[-1]-out[0])}),flush=True);break
  for j in released:cover[int(missing[j][0])::int(ps[j])]+=1
  if found:break
 rec=dict(shift=shift,found=found,removals_considered=int(np.searchsorted(A,x))+1,pairs_tested=pairs_tested,removals_with_multiple_candidates=good_removals,largest_candidate_count=best_options,seconds=time.time()-start);records.append(rec);print(json.dumps(rec),flush=True)
 if found:break
(O/'h2_exchange_results.json').write_text(json.dumps({'scope':'only the one-out/two-in neighborhoods of the two specified cropped parents','records':records},indent=2)+'\n')
