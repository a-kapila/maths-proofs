"""Bounded heuristic search. Only independently verified outputs are retained."""
from pathlib import Path
import subprocess,json,time,numpy as np
B=Path(__file__).resolve().parents[1];O=B/'progress';t=time.time()
base=O/'h2_local_2_witness.csv';D=19884;hist=[]
for stage in range(8):
 found=[]
 for batch in range(3):
  jobs=[]
  for idx in range(2):
   shift=[0,2,4,-2,6,-4][batch*2+idx];seed=260000+stage*211+batch*29+idx*7
   w=np.loadtxt(base,delimiter=',',skiprows=1,dtype=np.int64);w[:,1]=(w[:,1]-shift)%w[:,0]
   inp=O/f'h2_stage{stage}_b{batch}_{idx}_input.csv';np.savetxt(inp,w,delimiter=',',fmt='%d',header='prime,missing_residue',comments='')
   prefix=O/f'h2_stage{stage}_b{batch}_{idx}';log=open(str(prefix)+'.log','w')
   p=subprocess.Popen([str(O/'tuple_local'),str(D-2),'2304',str(inp),'700000',str(prefix),str(seed)],stdout=log,stderr=subprocess.STDOUT)
   jobs.append((p,prefix,log))
  for p,pref,log in jobs:
   assert p.wait()==0;log.close();tp=Path(str(pref)+'.csv');wp=Path(str(pref)+'_witness.csv')
   if not tp.exists():continue
   a=np.loadtxt(tp,dtype=np.int64)
   if len(a)<2304:continue
   j=int(np.argmin(a[2303:]-a[:len(a)-2303]));a=a[j:j+2304];np.savetxt(tp,a,fmt='%d')
   v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(tp),str(wp),'2304'],text=True));assert v['verified']
   found.append((v['diameter'],tp,wp,v))
  if found:break
 if not found:break
 _,tp,base,v=min(found,key=lambda x:x[0]);D=v['diameter'];rec=dict(**v,tuple=str(tp.relative_to(B)),witnesses=str(base.relative_to(B)),seconds=time.time()-t);hist.append(rec)
 (O/'h2_search_results.json').write_text(json.dumps(hist,indent=2)+'\n');print(json.dumps(rec),flush=True)
print(json.dumps({'best':D,'new_steps':len(hist),'seconds':time.time()-t}),flush=True)
