from pathlib import Path
import subprocess,json,time,numpy as np
B=Path(__file__).resolve().parents[1];O=B/'progress';t=time.time();k=110040
hist=json.load(open(O/'h3_search_results.json'));best=min(hist,key=lambda r:r['diameter']);tp=B/best['tuple'];wp=B/best['witnesses']
a=np.loadtxt(tp,dtype=np.int64);i=int(np.argmin(a[k-1:]-a[:len(a)-k+1]));a=a[i:i+k]
np.savetxt(O/'h3_small_seed.csv',a,fmt='%d');tp=O/'h3_small_seed.csv';records=[]
for stage in range(4):
 a=np.loadtxt(tp,dtype=np.int64);pref=O/f'h3_small_{stage}'
 with open(str(pref)+'.log','w') as f:subprocess.run([str(O/'cover_descent'),str(k),str(int(a[0])),str(int(a[-1])-2),str(wp),'140',str(pref),str(4091+stage*23),str(k)],stdout=f,stderr=subprocess.STDOUT,check=True)
 nt=Path(str(pref)+'.csv');nw=Path(str(pref)+'_witness.csv')
 if not nt.exists():break
 v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(nt),str(nw),str(k)],text=True));assert v['verified']
 records.append(dict(**v,tuple=str(nt.relative_to(B)),witnesses=str(nw.relative_to(B)),seconds=time.time()-t));tp,wp=nt,nw
 (O/'h3_small_search_results.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[-1]),flush=True)
print(json.dumps({'stages':len(records),'seconds':time.time()-t}),flush=True)
