"""Same per-element operation order as inherited profile_bounds; no fast-math.
The same 4*(number_of_cells+3)*2^-53 forward error allowance is retained.
"""
import ctypes
from pathlib import Path
import numpy as np
lib=ctypes.CDLL(str(Path(__file__).with_name('profile_parallel.so')))
f=lib.profile_bounds_raw
DP=np.ctypeslib.ndpointer(dtype=np.float64,ndim=1,flags='C_CONTIGUOUS')
IP=np.ctypeslib.ndpointer(dtype=np.int64,ndim=1,flags='C_CONTIGUOUS')
f.argtypes=[DP,DP,DP,IP,IP,ctypes.c_int64,ctypes.c_int64,ctypes.c_int64,DP,DP,DP,DP]
f.restype=None

def profile_bounds(h,tab,E,I):
 h=np.ascontiguousarray(h,dtype=float);lo=np.ascontiguousarray(tab[0]);hi=np.ascontiguousarray(tab[1])
 E=np.ascontiguousarray(E,dtype=np.int64);I=np.ascontiguousarray(I,dtype=np.int64)
 al=np.zeros(len(I));au=np.zeros(len(I));absl=np.zeros(len(I));absu=np.zeros(len(I))
 f(h,lo,hi,E,I,len(h),len(lo),len(I),al,au,absl,absu)
 fac=4*(len(h)+3)*2**-53*(1+1e-10)
 return np.nextafter(al-fac*absl-1e-290,-np.inf),np.nextafter(au+fac*absu+1e-290,np.inf)
