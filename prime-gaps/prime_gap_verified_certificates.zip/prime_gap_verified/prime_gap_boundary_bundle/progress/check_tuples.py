"""Independent verifier: generate all primes, then reduce all entries modulo p.
Unlike the inherited C++ checker this does not walk missing-residue progressions.
"""
from pathlib import Path
import sys,json,hashlib,math,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1]
def verify(tp,wp,k):
 tp,wp=Path(tp),Path(wp);a=np.loadtxt(tp,dtype=np.int64);w=np.loadtxt(wp,delimiter=',',skiprows=1,dtype=np.int64)
 assert len(a)==k and np.all(np.diff(a)>0)
 sieve=bytearray(b'\x01')*(k+1);sieve[0:2]=b'\x00\x00'
 for p in range(2,math.isqrt(k)+1):
  if sieve[p]:sieve[p*p:k+1:p]=b'\x00'*(((k-p*p)//p)+1)
 ps=[p for p in range(2,k+1) if sieve[p]];witnesses={int(p):int(r) for p,r in w}
 for p in ps:
  assert p in witnesses
  r=witnesses[p];assert 0<=r<p and not np.any(a%p==r),(p,r)
 cpp=json.loads(subprocess.check_output([str(B/'progress/verify_tuple'),str(tp),str(wp),str(k)],text=True))
 own=dict(verified=True,k=k,first=int(a[0]),last=int(a[-1]),diameter=int(a[-1]-a[0]),checked_primes=len(ps))
 assert cpp==own
 return dict(**own,python_method='direct modular reduction of every tuple element at every relevant prime',tuple_sha256=hashlib.sha256(tp.read_bytes()).hexdigest(),witness_sha256=hashlib.sha256(wp.read_bytes()).hexdigest())
if __name__=='__main__':
 r=verify(sys.argv[1],sys.argv[2],int(sys.argv[3]));print(json.dumps(r,indent=2))
 if len(sys.argv)>4:Path(sys.argv[4]).write_text(json.dumps(r,indent=2)+'\n')
