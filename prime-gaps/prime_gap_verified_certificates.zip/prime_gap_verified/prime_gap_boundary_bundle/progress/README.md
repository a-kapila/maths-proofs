# Finer H3 enclosure and further H2/H3 tuple improvements

**Current results (4 November 2026):** H2 <= 19,860 and H3 <= 1,358,724.
H4 <= 82,258,490 and H5 <= 4,831,230,984 are unchanged inherited results.

These are computer-assisted deductions in the inherited sieve framework, not independently audited published records. The new H3 evaluation proves the sufficient inequality at k=110040; the H2 analytic certificate at k=2304 is inherited, not recomputed here. See `progress/RESULTS.json` and `progress/proof_note.pdf`.

## Reproduce

From the archive root:

```sh
bash progress/reproduce.sh --checks-only
bash progress/reproduce.sh --full
```

Requirements: Python 3, NumPy, SciPy, mpmath, and a C++17 compiler with OpenMP. Keep C++ assertions enabled. The scalar module named `flint.py` is the retained mpmath.iv compatibility implementation, **not** FLINT/Arb.

The checks-only workflow recompiles the integer verifier and the original/parallel profile kernels, reruns bitwise kernel and exact-rational chunk-integration diagnostics, verifies the exact endpoint implications and equality of the old/new physical H3 functions, and checks both final tuples twice. The second tuple checker uses direct modular reduction of every entry, unlike the C++ arithmetic-progression checker.

The full workflow additionally recomputes the H3 fixed-trial interval evaluation, support loss, 108 direct Fourier comparisons, and 6006 comparisons with the full-grid Fourier interpolant. Full evaluation uses bounded chunks instead of constructing complete fine-grid CDF arrays. It requires several GB of memory. Its runtime and elapsed-time fields are not mathematical data.

## Successful new material

- `m3_k110040_finer.json`: exact six-profile trial, spacing 2^-25, identical physical function to the failed trial in `next23/m3_k110040.json`.
- `m3_k110040_finer.interval_certificate.json`: completed fresh calculation, including support loss and numerical diagnostics.
- `point_cdf.py`: requested-point evaluation of the inherited bounded Fourier interpolant. The per-point operations and error formula are unchanged.
- `profile_parallel.cpp`: disjoint blocks of coordinates evaluated in parallel; each coordinate uses the same summation order as the original kernel. No fast-math or FMA contraction.
- `run_refined.py`: 47 disjoint chunks, adding directed Abel lower bounds in scalar interval arithmetic.
- `h2_final.csv`, `h3_final.csv` and corresponding `_witness.csv`: complete final tuples and omitted residues.
- `verify_final.py`, `check_tuples.py`: exact deductions and complete finite verification.
- `MANIFEST.json`: hashes of the principal new sources and certificates.

## Search and unsuccessful experiments

Searches are optional and not needed to verify a fixed tuple. `polish_h2.py`, `polish_h2b.py`, `polish_h3.py`, and `grow_h3_small.py` record bounded heuristic searches. Constructors are retained under `baseline/inherited/search/`; compile them into `progress/tuple_local`, `progress/tuple_pair`, and `progress/cover_descent` to rerun searches. All final numerical claims refer only to the `h2_final` and `h3_final` files and the selected interval certificate.

`exchange_h2.py` checks one-out/two-in neighborhoods of two specified cropped 2303-element parents in width 19858. Its failure is not a global impossibility statement. Other `h2_pair*` and search outputs can contain too few elements and are not successful certificates. The successful and failed analytic calculations from earlier rounds remain separately labelled in their original directories.

## Inherited dependencies

This bundle contains the complete preceding archive, including the original distribution inputs' attribution, the enlarged-support proof, Fourier and support-loss error arguments, scalar implementation, earlier analytic certificates, and tuple data. No preceding download is required for this workflow. It does not independently prove all earlier mathematical or implementation assumptions. Integer verification is not an independent expert audit of the analytic proof.
