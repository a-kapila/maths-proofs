# Latest continuation: multirate Fourier synthesis

The latest bounds are **H2 <= 19,920; H3 <= 1,359,754; H4 <= 82,258,824;
H5 <= 4,831,267,356**. H2 and H3 are unchanged.

The authoritative latest result and note are `accurate/RESULTS.json` and
`accurate/proof_note.pdf`. See `accurate/README.md` for the numerical method,
dependencies, and exact scope.

```bash
bash accurate/reproduce.sh --checks-only
bash accurate/reproduce.sh --full
```

Both new quotient calculations were completed, each preceded by a same-mesh
control. The checks-only reproduction was also executed; all mathematical
output fields matched. The inherited stricter arithmetic support and capped
mean-numerator calculations were reused, not rerun. The prime-distribution
and enlarged-support arguments remain inherited dependencies. This is a
computer-assisted research derivation, not independent expert review.

The bundle includes all earlier source, notes, exact inputs, and compressed
integer witnesses. No earlier download is required. Reproduction reconstructs
the full large-tuple residue certificate and selected small tuple; large
reconstructed temporary files are deliberately omitted from this ZIP.

Old root-level RESULTS.json, proof_note.pdf, reproduce.sh, and historical
manifest files are retained for earlier continuations, not the latest results.
MANIFEST_MULTIRATE.json identifies every file in this deliverable. The failed
enlarged-cap experiment and uncertified higher-degree trial are labelled
under `uncapped/` and `explore_next/`; neither supports a reported bound.
