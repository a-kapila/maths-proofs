# Exploratory trials only

All scores here use binary64 quadrature and eigenvalue calculations. None is
an interval certificate. The fixed old trials were evaluated at three
quadrature orders (20,40,80); the apparent convergence is diagnostic only.

For m=4, a 400-cell mixed degree-six basis gave Q_exploratory=
15.23916877386067 at k=5,090,000. The basis includes Z2*Z4, Z3^2 and Z2^3.
This trial was not interval certified and is used for no final bound.
The `accurate/` continuation instead retains the old exact trial functions.
