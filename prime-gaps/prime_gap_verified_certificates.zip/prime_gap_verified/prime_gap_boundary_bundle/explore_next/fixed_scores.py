"""Floating point only: fixed-trial quotient diagnostics, not certificates."""
from pathlib import Path
import sys,json,time,math
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import Model,joint_transforms,tables,marginal_terms
from scipy.interpolate import CubicSpline
from scipy.special import roots_legendre
import numpy as np

def score(d,N=2**20,ng=40):
 t=time.time(); k=d['k'];basis=[tuple(x) for x in d['basis']]
 c=d['theta']/np.log(k);T=d['beta']/np.log(k);A=d['relative_shift']/(c+(k-1)*T)
 M=Model(k,d['theta'],d['beta'],A=A,N=N,P=16)
 marginal=sorted({ke for mon in basis for ke,_,_ in marginal_terms(mon)},key=lambda x:(len(x),x))
 keys=sorted({tuple(sorted(a+b)) for a in basis for b in basis}|{tuple(sorted(a+b)) for a in marginal for b in marginal},key=lambda x:(len(x),x))
 ki={x:i for i,x in enumerate(keys)}
 den_dens,cs=tables(M,joint_transforms(M,k,keys));dens,_=tables(M,joint_transforms(M,k-1,keys));s=np.arange(N)*M.h
 ed=np.array(d['E'])*d['delta'];hs=np.array(d['profiles']);eps=d['delta']*d['eps_cells']
 DD=np.diff(CubicSpline(s[:N//8+1],cs[:,:N//8+1].T)(ed),axis=0).T
 den=0
 for a,ma in enumerate(basis):
  for b,mb in enumerate(basis):den+=np.sum(hs[a]*hs[b]*DD[ki[tuple(sorted(ma+mb))]])
 lo=0.;hi=1-eps;cuts=np.unique(np.r_[lo,hi,ed[(ed>lo)&(ed<hi)],(ed-M.T)[(ed-M.T>lo)&(ed-M.T<hi)]])
 u,w=roots_legendre(ng);u=(u+1)/2;w=w/2;widths=np.diff(cuts)
 nodes=(cuts[1:,None]-widths[:,None]*u[None,:]**2).ravel();wt=(widths[:,None]*2*u[None,:]*w[None,:]).ravel()
 f=CubicSpline(s[:N//8+1],dens[:,:N//8+1].T);num=0
 for j in range(0,len(nodes),1000):
  yy=np.clip(ed[:,None]-nodes[None,j:j+1000],0,M.T);GG={0:np.diff(M.Gt(yy),axis=0)};Jcur=np.log1p(M.b*yy/M.c)/M.b
  for p in range(1,max(map(sum,basis))+1):
   Jcur=yy**p/(p*M.b)-M.c/M.b*Jcur;GG[p]=np.diff((Jcur+M.A*yy**(p+1)/(p+1))/M.T**p,axis=0)
  marg={key:np.zeros(len(nodes[j:j+1000])) for key in marginal}
  for h,mon in zip(hs,basis):
   for keep,power,co in marginal_terms(mon):marg[keep]+=co*(h@GG[power])
  fs=f(nodes[j:j+1000]).T;vals=np.zeros(len(nodes[j:j+1000]))
  for ma in marginal:
   for mb in marginal:vals+=marg[ma]*marg[mb]*fs[ki[tuple(sorted(ma+mb))]]
  num+=np.sum(vals*wt[j:j+1000])
 return dict(Q=k/M.m2*num/den,den=den,num=num,N=N,ng=ng,seconds=time.time()-t)
if __name__=='__main__':
 for m in map(int,sys.argv[1:] or [4,5]):
  d=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
  rows=[]
  for ng in [20,40,80]:
   row=dict(m=m,**score(d,ng=ng));rows.append(row);print(json.dumps(row),flush=True)
  (B/f'explore_next/fixed_m{m}.json').write_text(json.dumps(rows,indent=2))
