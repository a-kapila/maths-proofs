from pathlib import Path
import sys,json,time
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import optimize
m=int(sys.argv[1]);D=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
bases=[('mixed5',[(),(2,),(3,),(4,),(2,2),(2,3)]),('degree6',[(),(2,),(3,),(4,),(2,2),(2,3),(2,4),(3,3),(2,2,2)])]
for name,basis in bases:
 r=optimize(D,basis,ncell=160,N=2**19,ng=32,spacing=2**-22,tol=1e-12)
 d={**D,**r};(B/f'explore_next/m{m}_{name}.json').write_text(json.dumps(d,indent=2))
 print(json.dumps({a:b for a,b in r.items() if a not in ['E','profiles']}),flush=True)
