from pathlib import Path
import sys,json
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'baseline/exploratory'))
from explore_products import optimize
m=int(sys.argv[1]);ncell=int(sys.argv[2]) if len(sys.argv)>2 else 400
D=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
basis=[(),(2,),(3,),(4,),(2,2),(2,3),(2,4),(3,3),(2,2,2)]
r=optimize(D,basis,ncell=ncell,N=2**20,ng=48,spacing=2**-22,tol=1e-12)
d={**D,**r};(B/f'explore_next/m{m}_degree6_n{ncell}.json').write_text(json.dumps(d,indent=2))
print(json.dumps({a:b for a,b in r.items() if a not in ['E','profiles']}),flush=True)
