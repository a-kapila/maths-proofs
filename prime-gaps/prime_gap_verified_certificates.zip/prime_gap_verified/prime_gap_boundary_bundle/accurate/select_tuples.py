from pathlib import Path
import sys,json,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1]
rows=json.load(open(B/'accurate/deductions.json'))
for row in rows:
 m,K=row['m'],row['dimension']
 if m==4:
  parent=np.loadtxt(B/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
  assert np.all(np.diff(parent)>0)
  widths=parent[K-1:]-parent[:len(parent)-K+1];j=int(np.argmin(widths));a=parent[j:j+K]
  selected=dict(k=K,parent_cardinality=len(parent),candidate_windows=len(widths),start_index=j,first=int(a[0]),last=int(a[-1]),diameter=int(widths[j]))
  (B/'accurate/h4_selection.json').write_text(json.dumps(selected,indent=2)+'\n')
  np.savetxt(B/'accurate/recomputed/h4.csv',a,fmt='%d')
  with open(B/'accurate/h4_verified.json','w') as f:
   subprocess.run([str(B/'accurate/recomputed/verify_tuple'),str(B/'accurate/recomputed/h4.csv'),str(B/'baseline/inherited/tuples/h4_witness.csv'),str(K)],stdout=f,check=True)
  print(json.dumps(selected),flush=True)
 if m==5:
  with open(B/'accurate/h5_verified.json','w') as f:
   subprocess.run([str(B/'accurate/recomputed/verify_h5'),'234360000',str(K),'10000000','2432107459',str(B/'accurate/recomputed/current_h5.bin')],stdout=f,check=True)
 for field in ['verified','k','first','last','diameter']:assert field in json.load(open(B/f'accurate/h{m}_verified.json'))
 print((B/f'accurate/h{m}_verified.json').read_text(),flush=True)
