"""Exact deductions from improved fixed-trial quotients and saved mean intervals.
The higher-precision grid is proved to represent exactly the same trial.
"""
from pathlib import Path
from fractions import Fraction as F
import json,math,hashlib
B=Path(__file__).resolve().parents[1]
results=[]
for m in [4,5]:
 p=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json');tr=json.load(open(p))
 newtr=json.load(open(B/f'accurate/m{m}.json'));cert=json.load(open(B/f'accurate/m{m}.interval_certificate.json'))
 support=json.load(open(B/f'rescaled/integrated_m{m}.json'));mean=json.load(open(B/f'direct_mean/m{m}.json'))
 for field in ['m','k','theta','beta','relative_shift','basis','profiles','omega','smooth_delta','ufrac']:assert newtr[field]==tr[field],field
 assert F(newtr['delta'])*newtr['eps_cells']==F(tr['delta'])*tr['eps_cells']
 assert [F(newtr['delta'])*e for e in newtr['E']]==[F(tr['delta'])*e for e in tr['E']]
 k=tr['k'];rho=F(1,4)+F(tr['omega']);target=F(m)/rho;h=F(1,11)
 q=F(cert['Q_lower'])-F(support['restriction']['loss_upper'])
 correction=F(support['amplitude_upper'])**2*F(support['support_bad_probability_upper'])
 updated_l=(F(mean['weighted_numerator_lower'])-correction)/F(cert['den_upper'])
 updated_u=F(mean['weighted_numerator_upper'])/(F(cert['den_lower'])-correction)
 l=max(F(mean['capped_mean_lower']),F(math.nextafter(float(updated_l),-math.inf)))
 u=min(F(mean['capped_mean_upper']),F(math.nextafter(float(updated_u),math.inf)))
 assert l<=updated_l and u>=updated_u
 assert l>=F(mean['capped_mean_lower']) and u<=F(mean['capped_mean_upper'])
 assert q>target and 0<l<u<1 and 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3
 sig=1+F(tr['delta'])*tr['eps_cells'];assert 2*rho*sig<1
 def beta(d):return F(d,k)*l-F(d*(d-1),2*h*k*(k-1))*u
 def margin(d):return F(k-d,k)*q-target*(1-beta(d))
 low=0;high=int(h*(k-1))
 while low+1<high:
  mid=(low+high)//2
  if margin(mid)>0:low=mid
  else:high=mid
 assert margin(low)>0 and margin(low+1)<=0
 effective=margin(low)/(1-beta(low));ceiling=F(k)*(q-target)/(q-target*u)
 row=dict(m=m,trial_k=k,previous_dimension=mean['dimension'],dimension=k-low,deleted=low,additional_deleted=low-mean['deleted'],new_Q_lower=cert['Q_lower'],old_Q_lower=support['original_quotient_lower'],quotient_improvement=float(F(cert['Q_lower'])-F(support['original_quotient_lower'])),target=float(target),mean_lower=float(l),mean_upper=float(u),beta_lower=[beta(low).numerator,beta(low).denominator],raw_margin=[margin(low).numerator,margin(low).denominator],effective_margin=[effective.numerator,effective.denominator],effective_margin_display=float(effective),next_raw_margin=float(margin(low+1)),optimistic_maximum_deletions=(ceiling.numerator-1)//ceiling.denominator,same_physical_trial_verified=True,trial_sha256=hashlib.sha256((B/f'accurate/m{m}.json').read_bytes()).hexdigest())
 results.append(row)
(B/'accurate/deductions.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
