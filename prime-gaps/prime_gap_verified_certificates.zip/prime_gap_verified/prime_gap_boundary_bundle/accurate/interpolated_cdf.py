"""Bounded multirate Fourier synthesis for positive polynomial CDFs.

The infinite-series and alias bounds are inherited unchanged. A short radix-two
FFT evaluates derivatives of the finite trigonometric polynomial, and interval
Taylor remainder bounds control interpolation to the requested dyadic grid.
No FFT of the final fine-grid size is required.
"""
from pathlib import Path
import sys,ctypes,math,time,json
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'new'),str(B/'analysis'),str(B/'baseline/polynomial'),str(B/'baseline/inherited/analysis')]
from flint import arb,acb,ctx
from streaming_cdf import StreamingCDF
from periodic_shifted import upper,bit_reverse
from fft_native import lib
TWIDDLES={}

def short_twiddles(N):
    """8-point blocks; absolute twiddle error <128u, u=2^-53."""
    if N in TWIDDLES:return TWIDDLES[N]
    old=ctx.prec;ctx.prec=256
    try:
        block=8;angle=-2*arb.pi()/N
        sn,cs=angle.sin_cos()
        assert sn.rad()<arb(2)**-150 and cs.rad()<arb(2)**-150
        step=complex(float(cs.mid()),float(sn.mid()))
        powers=np.ones(block,complex)
        for j in range(1,block):powers[j]=powers[j-1]*step
        bases=[]
        for j in range(0,N//2,block):
            sn,cs=(angle*j).sin_cos()
            assert sn.rad()<arb(2)**-150 and cs.rad()<arb(2)**-150
            bases.append(complex(float(cs.mid()),float(sn.mid())))
        out=(np.asarray(bases)[:,None]*powers[None,:]).ravel()[:N//2]
        TWIDDLES[N]=out
        return out
    finally:ctx.prec=old

def short_fft(values):
    N=len(values);w=short_twiddles(N)
    a=np.asarray(values,np.complex128)[bit_reverse(N)]
    assert a.flags.c_contiguous and w.flags.c_contiguous
    lib.radix2_inplace(a.ctypes.data,w.ctypes.data,N)
    return a

class InterpolatedCDF(StreamingCDF):
    coarse_N=2**16
    order=8
    def table(self,key):
        if key in self.tables:return
        start=time.time();ctx.prec=256
        M=self.coarse_N;R=self.order
        assert self.N>=M and self.N%M==0 and self.J<M//2
        factor=self.N//M;coarse_top=self.imax//factor
        norm=[arb(0) for _ in range(R)];errs=[arb(0) for _ in range(R)]
        derived=np.zeros((R,self.J),complex);rem=arb(0)
        for j,raw in enumerate(self.coeffs[key],1):
            z=acb(float(raw.real),float(raw.imag));a=acb(0,-2*arb.pi()*j/M)
            for p in range(R):
                zr,zi=float(z.real.mid()),float(z.imag.mid())
                derived[p,j-1]=complex(zr,zi)
                norm[p]+=2*z.abs_upper()
                errs[p]+=2*((arb(zr)-z.real).abs_upper()+(arb(zi)-z.imag).abs_upper())
                z=z*a/(p+1)
            # Taylor's integral remainder on the real line: no exp factor.
            rem+=2*z.abs_upper()
        D=np.empty((R,coarse_top+1));fft_errors=[]
        stages=M.bit_length()-1;u=arb(2)**-53;fac=(1+256*u)**stages
        for p in range(R):
            z=np.zeros(M,complex);z[1:self.J+1]=derived[p];z[-self.J:]=np.conj(derived[p,::-1])
            v=short_fft(z)
            ferr=(fac-1)*norm[p]+fac*errs[p]+arb('1e-290')
            fu=upper(ferr);fft_errors.append(fu)
            assert np.max(np.abs(v.imag))<=fu,(key,p,np.max(np.abs(v.imag)),fu)
            D[p]=v.real[:coarse_top+1]
        ffttotal=sum(map(arb,fft_errors))
        # <=2(R-1) real operations per Horner path. Use 4R conservatively.
        gam=4*R*u/(1-4*R*u)
        horn=gam*(sum(norm)+ffttotal)+arb('1e-290')
        ferr=upper(ffttotal+horn+rem+arb(self.input_err[key]))
        tab=np.empty(self.imax+1)
        for first in range(0,self.imax+1,2**18):
            ix=np.arange(first,min(self.imax+1,first+2**18),dtype=np.int64)
            base=ix//factor;x=(ix%factor)/float(factor)
            value=D[-1,base].copy()
            for p in range(R-2,-1,-1):value=value*x+D[p,base]
            tab[first:first+len(ix)]=self.zero[key]*(ix.astype(float)/self.N)+self.const[key]-value
        combine=upper(32*u*(abs(arb(self.zero[key]))*arb(self.ymax)/arb(self.P)+2*abs(arb(self.const[key]))+arb(self.norm[key])+arb(ferr)+1))
        err=upper(arb(ferr)+arb(self.const_err[key])+arb(self.zero_err[key])*arb(self.ymax)/arb(self.P)+arb(combine)+arb(self.tail[key])+arb('1e-290'))
        self.tables[key]=tab;self.error[key]=err
        if not hasattr(self,'interpolation_reports'):self.interpolation_reports={}
        report=dict(key=list(key),coarse_N=M,order=R,fft_error_sum=upper(ffttotal),horner_error=upper(horn),taylor_remainder=upper(rem),total_error=err,seconds=time.time()-start)
        self.interpolation_reports[str(key)]=report
        if self.verbose:print(json.dumps(dict(stage='interpolated_CDF_table',**report)),flush=True)
