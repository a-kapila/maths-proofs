"""Independent finite-sum tests and exact rounding-budget inequalities.
Diagnostics, not a substitute for the enclosure proof.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,random
import numpy as np
import mpmath as mp
B=Path(__file__).resolve().parents[1];sys.path.insert(0,str(B/'accurate'))
from interpolated_cdf import InterpolatedCDF,short_twiddles,arb,ctx,upper
ctx.prec=320;mp.mp.dps=90
u=F(1,2**53)
assert (1+2*u)**8*(1+8*u)**8-1 <128*u
assert 128*u+8*u*(1+128*u)+2*u*(1+128*u)*(1+8*u)<256*u
assert 2*u<256*u
# Validate a selection of twiddles against independent 90-decimal exp.
rng=random.Random(71126);twtests=0;twratio=mp.mpf(0)
for N in [32,256,2048,65536]:
 w=short_twiddles(N)
 for j in sorted(set([0,N//2-1]+[rng.randrange(N//2) for _ in range(100)])):
  ref=mp.exp(-2j*mp.pi*j/N);got=mp.mpc(float(w[j].real),float(w[j].imag));r=abs(got-ref)/(128*mp.mpf(2)**-53)
  assert r<=1,(N,j,r);twratio=max(twratio,r);twtests+=1
# Use actual saved tagged-transform coefficients; their finite series is known
# independently of this interpolation routine. Compare before positivity clips.
checks=0;maxratio=mp.mpf(0);maxrem=0.;reports=[]
for m in [4,5]:
 z=np.load(B/f'direct_mean/m{m}_cdf_data.npz');coeff=z['C']
 for row in [0,4,len(coeff)-1]:
  obj=object.__new__(InterpolatedCDF);obj.coarse_N=2**16;obj.order=8
  obj.N=2**23;obj.P=8.;obj.DELTA=8/obj.N;obj.ymax=1.125;obj.imax=int(obj.ymax/obj.DELTA);obj.J=coeff.shape[1]
  key=(m,row);obj.tables={};obj.error={};obj.verbose=False;obj.coeffs={key:coeff[row]}
  # Arbitrary exact mass and constant suffice for finite-sum diagnostics.
  obj.zero={key:1.};obj.zero_err={key:0.};obj.const={key:0.};obj.const_err={key:0.};obj.input_err={key:0.};obj.tail={key:0.};obj.alias={key:0.}
  obj.norm={key:upper(sum(2*(arb(float(c.real))**2+arb(float(c.imag))**2).sqrt() for c in coeff[row]))}
  obj.table(key);err=obj.error[key]
  indices=sorted(set([0,1,127,128,129,obj.imax]+[rng.randrange(obj.imax+1) for _ in range(8)]))
  for ix in indices:
   y=mp.mpf(ix)*mp.mpf(obj.DELTA);step=mp.exp(-2j*mp.pi*y/8);phase=mp.mpc(1);val=mp.mpf(y)/8
   for raw in coeff[row]:
    phase*=step;val-=2*mp.re(mp.mpc(float(raw.real),float(raw.imag))*phase)
   ratio=abs(mp.mpf(float(obj.tables[key][ix]))-val)/mp.mpf(err)
   assert ratio<=1,(m,row,ix,ratio,err)
   checks+=1;maxratio=max(maxratio,ratio)
  report=obj.interpolation_reports[str(key)];reports.append(report);maxrem=max(maxrem,report['taylor_remainder'])
  del obj
out=dict(status='passed',twiddle_tests=twtests,max_twiddle_error_to_allowance=mp.nstr(twratio,16),finite_fourier_checks=checks,max_interpolation_error_to_allowance=mp.nstr(maxratio,16),max_taylor_remainder=maxrem,exact_error_budget_checks=3,reports=reports)
(B/'accurate/interpolation_diagnostics.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
