# Multirate Fourier synthesis: fixed-trial prime-gap certificates

This continuation changes numerical evaluation, not the prime-distribution
input or the exact trial functions. Eight scaled derivatives of each finite
trigonometric polynomial are evaluated by 65,536-point radix-two FFTs. Taylor
remainders and all floating-point errors are bounded. The output grid can be
much finer without requiring an FFT of that grid's size.

The two same-mesh evaluations are controls. `m4.json` and `m5.json` halve the
original integration spacing while doubling every integer edge; their exact
physical functions and epsilon values are unchanged. `deduce.py` verifies
that equality, reuses the previous stricter-support loss and direct mean
numerators, and checks the rescaled-slicing inequalities using exact fractions.

The analytic interpretation remains conditional on correctness of the inherited
sieve/distribution and numerical arguments. This is not independent expert
review of that framework. No asymptotic, H1, H2, or H3 improvement is claimed.

Run from the bundle root:

```bash
bash accurate/reproduce.sh --checks-only
bash accurate/reproduce.sh --full
```

`--checks-only` checks exact saved endpoint deductions, the independent
high-precision Fourier diagnostics, and complete integer tuple verifications.
`--full` additionally recalculates both new quotient enclosures. It does not
rerun the inherited stricter-support or direct mean-numerator certificates.
Their source, saved inputs, proof notes, and reproduction scripts remain in
the archive. Compilation requires C++17 and OpenMP; do not enable fast-math,
FMA contraction, or NDEBUG. Python needs NumPy, SciPy, mpmath. The `flint.py`
compatibility module uses mpmath.iv; it is not FLINT/Arb.

The finite-sum diagnostics are supplementary and do not replace the analytic
rounding, interpolation, Fourier-tail and alias bounds. The calculations named
`same_mesh` are not failed runs; they isolate the effect of the new synthesis.
The unsuccessful enlarged-cap experiment and uncertified sixth-degree searches
are labelled separately under `uncapped` and `explore_next`, and support no
reported bound.
