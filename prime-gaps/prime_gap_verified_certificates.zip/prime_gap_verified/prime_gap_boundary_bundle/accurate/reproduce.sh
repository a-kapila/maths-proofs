#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
 echo 'usage: bash accurate/reproduce.sh [--checks-only|--full]' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
mkdir -p accurate/recomputed
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
"$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
if [[ "$mode" == --full ]]; then
 python accurate/run_certificate.py accurate/m4.json | tee accurate/m4.log
 python accurate/run_certificate.py accurate/m5.json | tee accurate/m5.log
fi
python accurate/check_interpolation.py
python accurate/deduce.py
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o accurate/recomputed/verify_tuple
"$cxx" -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o accurate/recomputed/verify_h5
python baseline/inherited/tuples/decode_h5.py accurate/recomputed/old_unpatched.bin
python baseline/h5/apply_patches.py accurate/recomputed/old_unpatched.bin accurate/recomputed/previous_h5.bin
python new/apply_new_h5_patches.py accurate/recomputed/previous_h5.bin accurate/recomputed/current_h5.bin
python accurate/select_tuples.py
python accurate/final_check.py
