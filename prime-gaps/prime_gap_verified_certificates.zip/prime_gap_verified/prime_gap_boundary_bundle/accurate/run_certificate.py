from pathlib import Path
import sys,json
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'accurate'),str(B/'analysis'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from interpolated_cdf import InterpolatedCDF
import certify_centered as C
from certify_polynomial import amplitude
C.PolynomialCDF=InterpolatedCDF
# Retain the fixed five-term amplitude routine where it applies.
if any(len(mon)>2 or tuple(mon) not in [(),(2,),(3,),(4,),(2,2)] for mon in json.load(open(sys.argv[1]))['basis']):
 def generic(hs,basis,E,spacing,S):
  v=amplitude(hs,basis,E,spacing,S);return v,v
 C.profile_amplitude=generic
out=C.run(sys.argv[1])
out['new_enclosures']['cdf']='8-term Taylor synthesis from 65536-point FFTs; 128u twiddle and 256u butterfly bounds'
Path(sys.argv[1]).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
