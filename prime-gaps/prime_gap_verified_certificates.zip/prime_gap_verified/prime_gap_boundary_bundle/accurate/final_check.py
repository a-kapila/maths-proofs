from pathlib import Path
from fractions import Fraction as F
import json,hashlib,math
B=Path(__file__).resolve().parents[1]
rows=json.load(open(B/'accurate/deductions.json'))
previous=json.load(open(B/'direct_mean/RESULTS.json'))['bounds']
bounds=dict(previous);dimensions=dict(json.load(open(B/'direct_mean/RESULTS.json'))['dimensions'])
report=[];fourier_tests=0
for row in rows:
 m=row['m'];cert=json.load(open(B/f'accurate/m{m}.interval_certificate.json'));tr=json.load(open(B/f'accurate/m{m}.json'))
 tup=json.load(open(B/f'accurate/h{m}_verified.json'))
 assert tup['verified'] and tup['k']==row['dimension']
 assert tup['last']-tup['first']==tup['diameter']<previous[f'H{m}']
 assert cert['k']==tr['k']==row['trial_k']
 assert cert['Q_lower']==row['new_Q_lower']>row['old_Q_lower']
 assert F(*row['raw_margin'])>0 and F(*row['effective_margin'])>0 and row['next_raw_margin']<=0
 assert row['same_physical_trial_verified']
 fourier_tests+=len(cert['direct_fourier_checks'])
 # Extract the executed interpolation budgets from the complete run log.
 records=[]
 for line in (B/f'accurate/m{m}.log').read_text().splitlines():
  try:r=json.loads(line)
  except ValueError:continue
  if r.get('stage')=='interpolated_CDF_table':records.append(r)
 assert len(records)==2*len(cert['moment_keys'])
 for r in records:
  key=str(tuple(r['key']))
  assert cert['cdf']['error'][key]==r['total_error']
  assert r['taylor_remainder']>0 and r['fft_error_sum']>0
 report.append(dict(m=m,interpolated_tables=len(records),max_taylor_remainder=max(r['taylor_remainder'] for r in records),max_cdf_error=max(r['total_error'] for r in records),fine_spacing=tr['delta'],logical_grid=cert['cdf']['N'],synthesis_grid=65536,positive_frequencies=cert['cdf']['J'],trial_sha256=hashlib.sha256((B/f'accurate/m{m}.json').read_bytes()).hexdigest()))
 bounds[f'H{m}']=tup['diameter'];dimensions[f'H{m}']=row['dimension']
result=dict(date='2026-11-04',bounds=bounds,previous_bounds=previous,further_savings={key:previous[key]-bounds[key] for key in bounds},dimensions=dimensions,new_calculations=['Two improved fixed-trial quotient enclosures, each preceded by a same-mesh control','Exact physical-trial identity and stronger mean normalization','Exact rescaled-slicing endpoint inequalities','Complete H4 and H5 integer tuple verification'],inherited=['Prime-distribution and enlarged-support arguments','Stricter arithmetic support-loss certificates at dilation cap 11/10','Direct capped-sum weighted numerators','Integer tuple parents and all missing-residue witnesses'],no_claims=['No H1, H2, H3, distribution-exponent or method-wide optimality improvement','No independent expert review'],fourier_diagnostics_in_quotient_runs=fourier_tests,synthesis=report)
(B/'accurate/RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
# Generate exact outward-rounded textual displays separately from the raw JSON.
def comma(n):return f'{n:,}'
with open(B/'accurate/numbers.tex','w') as f:
 for row in rows:
  m=row['m'];tup=json.load(open(B/f'accurate/h{m}_verified.json'))
  vals={'Bound':comma(tup['diameter']),'Saving':comma(previous[f'H{m}']-tup['diameter']),'Dimension':comma(row['dimension']),'Deleted':comma(row['deleted']),'Additional':comma(row['additional_deleted']),'First':comma(tup['first']),'Last':comma(tup['last']),'Ideal':comma(row['optimistic_maximum_deletions']),'DimPlain':str(row['dimension'])}
  word='Four' if m==4 else 'Five'
  for name,val in vals.items():f.write('\\newcommand{\\'+name+word+'}{'+val+'}\n')
  f.write('\\newcommand{\\Q'+word+'}{'+f'{row["new_Q_lower"]:.12f}'+'}\n')
  f.write('\\newcommand{\\Margin'+word+'}{'+f'{row["effective_margin_display"]:.4g}'.replace('e-','\\times 10^{-')+'}\n') if False else None
