# Latest continuation: polynomial Laplace bounds and convex-Jensen slicing

The latest results are in `envelope/RESULTS.json` and `envelope/proof_note.pdf`.
See `envelope/README.md` for scope and complete reproduction instructions.

```bash
bash envelope/reproduce.sh --checks-only
bash envelope/reproduce.sh --full
```

The new reported bounds are H4 <= 82,286,942 and H5 <= 4,832,461,340.
H2 <= 19,920 and H3 <= 1,359,754 are inherited and unchanged.
The new fixed-trial scalar estimates and all final tuple checks have been executed.
The original Fourier and tighter-support estimates are reused, not rerun here.
This is not independent expert review of all inherited analytic dependencies.

All earlier notes, source, compressed witnesses, and reproduction scripts remain
in their earlier directories. Older root-level RESULTS.json and proof_note.pdf
are historical; they are not the latest result.
