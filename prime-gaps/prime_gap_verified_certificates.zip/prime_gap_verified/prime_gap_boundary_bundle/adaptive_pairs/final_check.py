from pathlib import Path
from fractions import Fraction as F
import sys,json,hashlib
if hasattr(sys,'set_int_max_str_digits'):sys.set_int_max_str_digits(0)
B=Path(__file__).resolve().parents[1];O=B/'adaptive_pairs'
expected={3:1358060,4:82238106,5:4830524292}
rows=[]
for m,D in expected.items():
    x=json.load(open(O/f'h{m}_result.json'));c=x['constants'];s=x['selection']
    assert s['D']==D and s['long_pairs']<=c['budget']<s['previous_even_min_count']
    for key in ['remaining_margin','strict_remaining_margin']:
        z=s[key];assert F(z['num'],z['den'])>0
    p=json.load(open(O/f'h{m}_pairs_verified.json'));assert p['long_pairs']==s['long_pairs'] and p['D']==D and p['k']==c['k']
    if m<5:
        t=json.load(open(O/f'h{m}_tuple_verified.json'));assert t['verified'] and t['k']==c['k'] and t['first']==s['first'] and t['last']==s['last']
    rows.append(dict(m=m,k=c['k'],H_bound=D,long_pairs=s['long_pairs'],pair_budget=c['budget'],prime_count_margin=s['remaining_margin']['display']))
parent=json.load(open(O/'h5_parent_verified.json'));assert parent['verified'] and parent['failures']==0
assert parent['certificate_prime_count']==12204094
assert json.load(open(O/'h3_python_verified.json'))['verified']
h2=json.load(open(O/'h2_limit.json'));assert h2['affordable_pairs']==0
manifest_path=O/'MANIFEST.json'
if manifest_path.exists():
    manifest=json.load(open(manifest_path))
    for p,h in manifest.items():assert hashlib.sha256((B/p).read_bytes()).hexdigest()==h,p
report=dict(checked=True,results=rows,H2_unchanged=19860,complete_large_parent_verified=True,manifest_checked=manifest_path.exists())
(O/'FINAL_VERIFICATION.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
