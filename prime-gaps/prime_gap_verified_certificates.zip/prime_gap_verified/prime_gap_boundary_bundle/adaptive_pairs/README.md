# Residual-support pair upper bound

Newest results, within the inherited sieve/numerical framework:

- H2 <= 19,860 (unchanged)
- H3 <= 1,358,060
- H4 <= 82,238,106
- H5 <= 4,830,524,292

The new analytic argument is in `proof_note.pdf` and `proof_note.tex`. It replaces a constant auxiliary support allocation by a trace-preserving extension using the remaining support on each fibre. A weighted Cauchy--Schwarz/symmetry estimate gives `C_new = 8*s^2*A(k*(1-2*s))`. The parameter is the exact minimizer in the one-parameter auxiliary majorization stated in the note; no global optimality is asserted.

The inherited Fourier quotients and arithmetic restriction loss estimates are reused. This continuation has NOT recomputed them and is not an independent audit of the entire analytic chain.

## Reproduce

From the archive's root, run:

```bash
bash adaptive_pairs/reproduce.sh
```

Requires Python 3.11+ with NumPy and mpmath, and a C++17/OpenMP compiler. Do not disable C++ assertions. The full integer verification uses around 1.5 GB of memory and several hundred MB of reconstructible disk files. No new high-dimensional Fourier calculation is needed.

The script recomputes the rational constant and strict-slack inequality; selects the new windows; reconstructs the large signed-prime parent and checks all 12,204,094 residue witnesses; verifies the explicit H3/H4 tuples and all three pair totals; independently checks H3 by direct modular reduction; and repeats analytic diagnostics. The H4 tuple and large binary tables are regenerated rather than stored twice. `h3_tuple.txt` is explicit. The complete inherited data and source are included; older result files are historical.

`adaptive_constant.py` uses exact Fraction arithmetic. Logarithms, pi, and the alternating series in A have explicit rational remainder bounds. The numerical mpmath comparisons in `check_analytic.py` are diagnostics only.

The unweighted second-moment input is Lemma 2.7 of Hexagon 2610.00419v1 / Theorem 3.6(i) of Polymath arXiv:1407.4897v4. The inherited prime-distribution and enlarged-support implications are additional dependencies. No independent peer review, publication priority, terminal bound, or improvement to H1 is claimed.
