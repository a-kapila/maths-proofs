#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p continuation2/recomputed
python baseline/inherited/tuples/decode_h5.py continuation2/recomputed/unpatched.bin
python baseline/h5/apply_patches.py continuation2/recomputed/unpatched.bin continuation2/recomputed/previous.bin
python new/apply_new_h5_patches.py continuation2/recomputed/previous.bin continuation2/recomputed/current.bin
g++ -O3 -std=c++17 -fopenmp continuation2/verify_h5_export.cpp -o adaptive_pairs/verify_h5_export
OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}" adaptive_pairs/verify_h5_export 234360000 232500000 10000000 2432107459 continuation2/recomputed/current.bin continuation2/recomputed/h5_tail.bin > adaptive_pairs/h5_parent_verified.json
