"""Rational enclosures for the residual-support pair sieve constant.
All input binary64 numbers are interpreted exactly as rationals.
"""
from pathlib import Path
from fractions import Fraction as F
import sys, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'continuation2'))
from pair_penalty import constants as previous_constants, fractions_json

def log_interval(x,terms=70):
    x=F(x); assert x>0
    e=x.numerator.bit_length()-x.denominator.bit_length()
    u=x/F(2)**e
    if u<1:e-=1;u*=2
    assert 1<=u<2
    def atanh(z):
        pw=z; total=F(0)
        for j in range(terms):total+=2*pw/(2*j+1);pw*=z*z
        return total,total+2*pw/((2*terms+1)*(1-z*z))
    a,b=atanh((u-1)/(u+1));c,d=atanh(F(1,3))
    return (a+e*c,b+e*d) if e>=0 else (a+e*d,b+e*c)

def pi_interval(terms=70):
    def atan(x):
        total=F(0)
        for j in range(terms):total+=(-1)**j*x**(2*j+1)/(2*j+1)
        nxt=(-1)**terms*x**(2*terms+1)/(2*terms+1)
        return min(total,total+nxt),max(total,total+nxt)
    a,b=atan(F(1,5));c,d=atan(F(1,239))
    return 16*a-4*d,16*b-4*c

def triangular_integral(a):
    """A(a)=int_{u+v<=1} 1/[(1-u-v+a*u)(1-u-v+a*v)]."""
    a=F(a);assert a>2
    ll,lu=log_interval(a-1);pl,pu=pi_interval()
    x=1/(a-1);assert 0<x<1
    N=12;su=sum(((-1)**j*x**j/F(j*j) for j in range(1,N+1)),F(0))
    sl=su-x**(N+1)/F((N+1)**2)
    return ((ll*ll+pl*pl/6+2*sl)/(a*(a-2)),
            (lu*lu+pu*pu/6+2*su)/(a*(a-2)))

def new_constants(trial,certificate,arithmetic=None):
    v=previous_constants(trial,certificate,arithmetic)
    s=v['rho']*v['sigma'];a=v['k']*(1-2*s)
    al,au=triangular_integral(a)
    pair=8*s*s*au
    v['old_pair']=v['pair'];v['old_budget']=v['budget']
    v['pair']=pair;v['a']=a;v['A_lower']=al;v['A_upper']=au
    v['budget']=(v['surplus'].numerator*pair.denominator-1)//(v['surplus'].denominator*pair.numerator)
    assert v['surplus']-v['budget']*pair>0
    assert v['surplus']-(v['budget']+1)*pair<=0
    assert pair<v['old_pair']
    v['relative_pair_reduction']=1-pair/v['old_pair']
    lam=v['rho']-F(1,2**60);b=F(1,2)-F(1,2**60);ss=lam*v['sigma']
    aaa=v['k']*(1-ss/b);_,aau=triangular_integral(aaa)
    v['strict_pair']=2*(ss/b)**2*aau;v['strict_surplus']=lam*v['q']-v['m']
    return v

INPUTS={
 3:('focus23/m3_fine.json','focus23/m3_fine.interval_certificate.json'),
 4:('accurate/m4.json','accurate/m4.interval_certificate.json'),
 5:('accurate/m5.json','accurate/m5.interval_certificate.json')}
if __name__=='__main__':
    sys.set_int_max_str_digits(0)
    out={}
    for m,(tp,cp) in INPUTS.items():
        v=new_constants(tp,cp);out[m]=fractions_json(v)
        print(json.dumps({k:(float(x) if isinstance(x,F) else x) for k,x in v.items()}),flush=True)
    (ROOT/'adaptive_pairs/constants.json').write_text(json.dumps(out,indent=2)+'\n')
