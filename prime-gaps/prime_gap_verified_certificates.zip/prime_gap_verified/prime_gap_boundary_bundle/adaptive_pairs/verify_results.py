from adaptive_constant import *
import subprocess, numpy as np, hashlib
sys.set_int_max_str_digits(0)
O=ROOT/'adaptive_pairs'
for m in (3,4,5):
    rec=json.load(open(O/f'h{m}_result.json'));s=rec['selection'];v=new_constants(*INPUTS[m]);k=v['k']
    assert s['long_pairs']<=v['budget']<s['previous_even_min_count']
    for key in ('pair','surplus','strict_pair','strict_surplus'):
        saved=rec['constants'][key];assert F(saved['num'],saved['den'])==v[key]
    assert v['strict_surplus']-s['long_pairs']*v['strict_pair']>0
    if m<5:
        with open(O/f'h{m}_tuple_verified.json','w') as f:
            subprocess.run([str(O/'verify_tuple'),str(O/f'h{m}_tuple.txt'),str(O/f'h{m}_witness.csv'),str(k)],check=True,stdout=f)
        cmd=[str(O/'check_pair_counts'),'tuple',str(O/f'h{m}_tuple.txt'),str(s['D'])]
    else:
        parent=json.load(open(O/'h5_parent_verified.json'))
        assert parent['verified'] and parent['failures']==0 and parent['parent_cardinality']==233950978
        cmd=[str(O/'check_pair_counts'),'signed',str(ROOT/'continuation2/recomputed/h5_tail.bin'),str(s['D']),str(s['negative_count']),str(s['positive_count'])]
    with open(O/f'h{m}_pairs_verified.json','w') as f:subprocess.run(cmd,check=True,stdout=f)
    got=json.load(open(O/f'h{m}_pairs_verified.json'));assert got['long_pairs']==s['long_pairs'] and got['k']==k
    print('verified',m,got,flush=True)
# Independent H3 check: direct modular reductions, own list of primes.
h=np.loadtxt(O/'h3_tuple.txt',dtype=np.int64)
k=len(h);sieve=bytearray(b'\x01')*(k+1);sieve[0:2]=b'\x00\x00'
import math
for p in range(2,math.isqrt(k)+1):
    if sieve[p]:sieve[p*p::p]=b'\x00'*(((k-p*p)//p)+1)
ps=[p for p in range(2,k+1) if sieve[p]]
w=dict(map(tuple,np.loadtxt(O/'h3_witness.csv',delimiter=',',skiprows=1,dtype=np.int64)))
assert len(h)==k and np.all(np.diff(h)>0)
for p in ps:assert np.all(h%p!=w[p])
result=dict(verified=True,k=k,checked_primes=len(ps),first=int(h[0]),last=int(h[-1]),method='Independent prime list and direct reduction of every entry')
(O/'h3_python_verified.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
# H2 uses the inherited selected component-wise surplus, not optional numerator.
tr=json.load(open(ROOT/'focus23/m2_k2304.json'));rho=F(1,4)+F(tr['omega']);s=rho*(1+F(tr['delta'])*tr['eps_cells'])
old=json.load(open(ROOT/'continuation2/h2_pair_limit.json'));sur=F(old['surplus']['num'],old['surplus']['den'])
a=tr['k']*(1-2*s);al,au=triangular_integral(a);pair=8*s*s*au
assert 0<sur<pair
rr=fractions_json(dict(k=tr['k'],surplus=sur,new_pair_upper=pair,a=a,affordable_pairs=0,old_pair_upper=F(old['pair_upper']['num'],old['pair_upper']['den'])))
(O/'h2_limit.json').write_text(json.dumps(rr,indent=2)+'\n');print('H2',float(sur),float(pair))
