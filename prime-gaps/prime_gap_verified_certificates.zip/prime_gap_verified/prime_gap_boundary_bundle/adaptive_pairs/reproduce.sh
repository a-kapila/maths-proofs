#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
python adaptive_pairs/adaptive_constant.py
python adaptive_pairs/select_small.py
bash adaptive_pairs/prepare_h5.sh
python adaptive_pairs/select_h5.py
g++ -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o adaptive_pairs/verify_tuple
g++ -O3 -std=c++17 continuation2/check_pair_counts.cpp -o adaptive_pairs/check_pair_counts
python adaptive_pairs/verify_results.py
python adaptive_pairs/check_analytic.py
python adaptive_pairs/final_check.py
