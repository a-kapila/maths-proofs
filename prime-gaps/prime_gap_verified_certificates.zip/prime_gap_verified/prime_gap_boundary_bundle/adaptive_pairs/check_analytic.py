"""Diagnostics for the new rational constant and pointwise Schur estimate.
These tests supplement the mathematical proof, not replace it.
"""
from adaptive_constant import *
import random, math, mpmath as mp
mp.mp.dps=150
rng=random.Random(20261104)
def M(x):x=F(x);return mp.mpf(x.numerator)/x.denominator
logs=[F(rng.randrange(2,10**12),rng.randrange(1,10**6)) for _ in range(100)]
for x in logs:
    l,u=log_interval(x);assert M(l)<=mp.log(M(x))<=M(u)
pl,pu=pi_interval();assert M(pl)<mp.pi<M(pu)
args=[F(3),F(5,2),F(19,3),F(50),F(1001)]+[new_constants(*INPUTS[m])['a'] for m in (3,4,5)]
# For a=2.5 the fixed 12-term alternating series is coarser but still valid.
maxrel=mp.mpf(0)
for aa in args:
    a=M(aa);l,u=triangular_integral(aa)
    closed=(mp.log(a-1)**2+mp.pi**2/6+2*mp.polylog(2,-1/(a-1)))/(a*(a-2))
    fn=lambda x:x*mp.exp(-x)/((1+mp.exp(-x))*(1+(a-1)*mp.exp(-x)))
    integral=2/a*mp.quad(fn,[0,mp.log(a),mp.log(a)+20,mp.inf])
    assert M(l)<=closed<=M(u)
    rel=abs(closed-integral)/closed;assert rel<mp.mpf('1e-100');maxrel=max(maxrel,rel)
# Exact pointwise bound: the denominator is the residual total support.
# This is the step that removes any need for a new numerical moment evaluation.
cases=800
for _ in range(cases):
    k=rng.randrange(6,25);b=F(1,2);s=F(rng.randrange(10,40),100)
    w=[rng.randrange(0,101) for _ in range(k)];W=sum(w)
    if W==0:continue
    t=[s*F(rng.randrange(0,21),20)] # replace by single common slack scale
    scale=t[0]
    t=[scale*F(x,W) for x in w];S=sum(t,F(0));a=k*(1-s/b)
    q=[s-S+a*x for x in t]
    lhs=sum((q[i]*q[j]/(b-S+t[i]+t[j])**2 for i in range(k) for j in range(i+1,k)),F(0))/math.comb(k,2)
    assert lhs<=(s/b)**2
    avgprod=sum((q[i]*q[j] for i in range(k) for j in range(i+1,k)),F(0))/math.comb(k,2)
    assert avgprod<=(s-S+a*S/k)**2
    assert s-S+a*S/k==(s/b)*(b-S)
result=dict(logarithm_enclosure_checks=len(logs),pi_enclosure_checked=True,integral_identity_checks=len(args),maximum_integral_relative_discrepancy=str(maxrel),exact_pointwise_schur_checks=cases)
(ROOT/'adaptive_pairs/diagnostics.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
