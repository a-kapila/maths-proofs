from adaptive_constant import *
from pair_penalty import load_witness,allowed,choose,primes_up_to,enumerate_long_pairs
import numpy as np
sys.set_int_max_str_digits(0)
O=ROOT/'adaptive_pairs'
for m in (3,4):
    tp,cp=INPUTS[m];v=new_constants(tp,cp)
    if m==3:
        w=load_witness('onward/h3_completed_witness.csv');a=allowed(w,-2000000,2000000)
    else:
        w=load_witness('baseline/inherited/tuples/h4_witness.csv')
        a=np.loadtxt(ROOT/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
    subset,res=choose(a,v['k'],v['budget'])
    if m==3:
        for p in primes_up_to(v['k']):
            if int(p) not in w:
                used=np.bincount(subset%p,minlength=int(p));missing=np.flatnonzero(used==0)
                assert len(missing);w[int(p)]=int(missing[0])
    res.update(first=int(subset[0]),last=int(subset[-1]),diameter=int(subset[-1]-subset[0]),points=len(a),trial=tp,certificate=cp)
    for key,pair,sur in [('remaining_margin',v['pair'],v['surplus']),('strict_remaining_margin',v['strict_pair'],v['strict_surplus'])]:
        margin=sur-res['long_pairs']*pair;assert margin>0
        res[key]=fractions_json({'value':margin})['value']
    np.savetxt(O/f'h{m}_tuple.txt',subset,fmt='%d')
    np.savetxt(O/f'h{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
    if m==3:
        pairs=enumerate_long_pairs(subset,res['D']);assert len(pairs)==res['long_pairs']
        np.savetxt(O/'h3_long_pairs.csv',np.array(pairs),fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
    (O/f'h{m}_result.json').write_text(json.dumps(dict(constants=fractions_json(v),selection=res),indent=2)+'\n')
    print(json.dumps({k:x for k,x in res.items() if 'margin' not in k}),flush=True)
    print('margin',res['remaining_margin']['display'],'strict margin',res['strict_remaining_margin']['display'],flush=True)
