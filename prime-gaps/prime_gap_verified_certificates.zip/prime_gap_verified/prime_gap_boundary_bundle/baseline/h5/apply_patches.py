"""Reconstruct the updated complete prime/residue certificate from the baseline.
Usage: python h5/apply_patches.py baseline.bin updated.bin
"""
from pathlib import Path
import csv, hashlib, json, sys
import numpy as np

def main():
    if len(sys.argv)!=3: raise SystemExit(__doc__)
    root=Path(__file__).resolve().parent;src,dst=map(Path,sys.argv[1:])
    meta=json.loads((root/'encoding.json').read_text());blob=src.read_bytes()
    if hashlib.sha256(blob).hexdigest()!=meta['base_sha256']:raise ValueError('Wrong baseline certificate')
    a=np.frombuffer(blob,dtype='<u4').reshape(-1,2).copy();count=0;seen=set()
    with (root/'h5_new_patches.csv').open() as f:
        for row in csv.DictReader(f):
            p,r=int(row['prime']),int(row['missing_residue'])
            i=int(np.searchsorted(a[:,0],p))
            if i>=len(a) or int(a[i,0])!=p or int(a[i,1])!=0 or not 0<r<p or p in seen:raise ValueError('Invalid patch')
            seen.add(p);a[i,1]=r;count+=1
    if count!=meta['patch_count']:raise ValueError('Wrong patch count')
    a.tofile(dst);digest=hashlib.sha256(dst.read_bytes()).hexdigest()
    if digest!=meta['updated_sha256']:raise ValueError('Updated checksum mismatch')
    print(json.dumps({'patches':count,'pairs':len(a),'sha256':digest,'output':str(dst)}))
if __name__=='__main__':main()
