"""Positive polynomial-weighted CDFs. Adapted from prior MultiCDF.
For r factors, set-partition expansion has at most r distinct coordinates.
Hence |transform| <= mass * |phi|^(n-r). The original periodization,
interval Fourier and bounded-FFT enclosures otherwise apply unchanged.
"""
import math,time,json
import numpy as np
from flint import arb,acb,ctx
from shifted_core import setup,make_phi
from polynomial_core import single_moments,weights,needed_moments
from periodic_shifted import CDF as OrdinaryCDF,fft_rounded,upper

class PolynomialCDF:
 def __init__(self,k,theta,beta,relative_shift=0.,basis=((),(2,),(3,),(4,),(2,2)),DELTA=2**-20,P=8.,ymax=2.,verbose=True):
  t=time.time();ctx.prec=256;self.basis=tuple(tuple(x) for x in basis);self.moment_keys,self.marginal_basis=needed_moments(self.basis);jmax=max(map(sum,self.moment_keys));rmax=max(map(len,self.moment_keys))
  self.k=k;self.ns=(k-1,k);self.S=setup(k,theta,beta,relative_shift);self.phi,_=make_phi(k,theta,beta,relative_shift)
  self.DELTA=DELTA;self.P=P;self.N=int(round(P/DELTA));assert self.N*DELTA==P and self.N&(self.N-1)==0
  self.ymax=ymax;self.imax=int(math.ceil(ymax/DELTA));self.freq=2*arb.pi()/arb(P);self.Tf=float(self.S['T'].mid());self.verbose=verbose
  self.J=128;nmin=k-1-rmax
  while True:
   z=self.phi(acb(self.freq*self.J))
   if z.abs_upper()<1 and nmin*z.abs_upper().log() < -140:break
   self.J=int(self.J*1.25)+1
   assert self.J<self.N//2
  mu=single_moments(self.S,jmax)
  self.mass={}
  for n in self.ns:
   
   for r,v in enumerate(weights(n,mu,self.moment_keys)):self.mass[n,r]=v
  self.keys=list(self.mass);self.coeffs={key:np.empty(self.J,complex) for key in self.keys}
  cons={key:arb(0) for key in self.keys};norm={key:arb(0) for key in self.keys};err={key:arb(0) for key in self.keys}
  for j in range(1,self.J+1):
   mu=single_moments(self.S,jmax,'fourier',self.freq*j)
   for n in self.ns:
    vals=weights(n,mu,self.moment_keys)
    for r,v in enumerate(vals):
     key=(n,r);z=v/acb(0,2*arb.pi()*j);zr,zi=float(z.real.mid()),float(z.imag.mid())
     assert z.is_finite() and z.real.rad()<arb('1e-35') and z.imag.rad()<arb('1e-35')
     self.coeffs[key][j-1]=complex(zr,zi);cons[key]+=2*z.real;norm[key]+=2*z.abs_upper()
     err[key]+=2*((arb(zr)-z.real).abs_upper()+(arb(zi)-z.imag).abs_upper())
  self.const={key:float(cons[key].mid()) for key in self.keys};self.const_err={key:upper((arb(self.const[key])-cons[key]).abs_upper()) for key in self.keys}
  self.norm={key:upper(norm[key]) for key in self.keys};self.input_err={key:upper(err[key]) for key in self.keys}
  self.zero={key:float(self.mass[key].mid()) for key in self.keys};self.zero_err={key:upper((arb(self.zero[key])-self.mass[key]).abs_upper()) for key in self.keys}
  base_tail=OrdinaryCDF._series_tail(self,nmin);self.tail={key:upper(self.mass[key]*arb(base_tail)) for key in self.keys}
  self.alias={key:upper(self.mass[key]) for key in self.keys}
  for lam in range(1,81):
   mu=single_moments(self.S,jmax,'positive',lam);assert all(x>0 for x in mu)
   for n in self.ns:
    c=(-arb(lam)*arb(P)).exp();b=[c*v for v in weights(n,mu,self.moment_keys)]
    for r,v in enumerate(b):
     vup=upper(v)
     if vup<self.alias[n,r]:self.alias[n,r]=vup
  self.tables={};self.error={}
  if verbose:print(json.dumps(dict(stage='moment_CDF_setup',k=k,J=self.J,N=self.N,seconds=time.time()-t,alias={str(key):v for key,v in self.alias.items()},tail={str(key):v for key,v in self.tail.items()})),flush=True)
 def table(self,key):
  if key in self.tables:return
  t=time.time();ctx.prec=256;z=np.zeros(self.N,complex);z[1:self.J+1]=self.coeffs[key];z[-self.J:]=np.conj(self.coeffs[key][::-1]);v=fft_rounded(z)
  stages=self.N.bit_length()-1;fac=(1+8192*arb(2)**-53)**stages
  ferr=upper((fac-1)*arb(self.norm[key])+fac*arb(self.input_err[key]));idx=np.arange(self.imax+1,dtype=float);line=idx/self.N
  tab=self.zero[key]*line+self.const[key]-v.real[:self.imax+1]
  combine=upper(32*arb(2)**-53*(abs(arb(self.zero[key]))*arb(self.ymax)/arb(self.P)+2*abs(arb(self.const[key]))+arb(self.norm[key])+arb(ferr)+1))
  err=upper(arb(ferr)+arb(self.const_err[key])+arb(self.zero_err[key])*arb(self.ymax)/arb(self.P)+arb(combine)+arb(self.tail[key])+arb('1e-290'))
  assert np.max(abs(v.imag))<=ferr
  self.tables[key]=tab;self.error[key]=err
  if self.verbose:print(json.dumps(dict(stage='moment_CDF_table',key=key,seconds=time.time()-t,error=err,alias=self.alias[key])),flush=True)
 def bounds(self,n,r,ys):
  key=(n,r);self.table(key);ys=np.asarray(ys,float);assert np.all(ys>=0) and np.all(ys<=self.ymax)
  xx=ys/self.DELTA;lo=np.floor(xx).astype(np.int64);hi=np.ceil(xx).astype(np.int64);err=self.error[key]
  L=np.maximum(0,np.nextafter(self.tables[key][lo]-np.nextafter(err+self.alias[key],np.inf),-np.inf))
  U=np.minimum(upper(self.mass[key]),np.nextafter(self.tables[key][hi]+err,np.inf));assert np.all(L<=U)
  return L,U
