"""Fixed-trial interval evaluation of polynomial power-sum profiles.
Inherits the previously documented FFT and support-loss enclosure argument.
"""
from pathlib import Path
import sys,json,time,math
ROOT=Path(__file__).resolve().parents[1]/'inherited'/'analysis'
sys.path.append(str(ROOT))
import numpy as np
from flint import arb,ctx
from polynomial_core import marginal_terms
from polynomial_cdf import PolynomialCDF
from certify_multi import make_tables
from certify_lifted import D,H,U,const,add,sub,mul,square,inv,scale,integrate_bound,profile_bounds
from loss_joint import restriction_loss

def amplitude(hs,basis,E,spacing,S):
    C=arb(0)
    for j in range(len(hs[0])):
        z=arb(int(E[j+1]))*arb(spacing)/S['T']; c=arb(0)
        for h,mon in zip(hs,basis): c+=arb(abs(float(h[j])))*z**len(mon)
        if c.upper()>C: C=c.upper()
    return float(H(float(C)))

def run(path):
    d=json.loads(Path(path).read_text());t=time.time();ctx.prec=256
    k,m=d['k'],d['m'];spacing=d['delta'];eps=spacing*d['eps_cells'];one=round(1/spacing)
    basis=[tuple(x) for x in d['basis']];E=np.array(d['E'],dtype=np.int64);hs=[np.array(h,float) for h in d['profiles']]
    assert len(basis)==len(hs) and basis[0]==() and E[0]==0 and E[-1]==one+d['eps_cells'] and np.all(np.diff(E)>0)
    assert all(all(p>=2 for p in mon) for mon in basis)
    for h in hs: assert len(h)==len(E)-1 and max(abs(h))<=1 and np.all(h*2**40==np.round(h*2**40))
    cdf=PolynomialCDF(k,d['theta'],d['beta'],d['relative_shift'],basis=basis,DELTA=spacing,P=d.get('period',8.),ymax=1.125)
    tdata=dict(d);maxp=max(map(sum,basis));tdata['powers']=list(range(1,maxp+1))
    tabs,m2,S=make_tables(tdata,cdf)
    print(json.dumps(dict(stage='antiderivative_tables',seconds=time.time()-t)),flush=True)
    ki={key:i for i,key in enumerate(cdf.moment_keys)}
    dc={key:(np.zeros(len(hs[0])),np.zeros(len(hs[0]))) for key in cdf.moment_keys}
    for a,ma in enumerate(basis):
        for b in range(a,len(basis)):
            key=tuple(sorted(ma+basis[b])); co=square((hs[a],hs[a])) if a==b else scale(mul((hs[a],hs[a]),(hs[b],hs[b])),2.)
            dc[key]=add(dc[key],co)
    denlo=arb(0);denhi=arb(0)
    for key in cdf.moment_keys:
        co=dc[key];L,V=cdf.bounds(k,ki[key],E*spacing)
        denlo+=arb(integrate_bound(co[0],L,V,-1));denhi+=arb(integrate_bound(co[1],L,V,1))
    dl=float(D(float(denlo.lower())));dh=float(H(float(denhi.upper())));assert dl>0
    ilo=int(E[1]);itop=one-d['eps_cells'];I=np.arange(ilo,itop,dtype=np.int64)
    AA={key:(np.zeros(len(I)),np.zeros(len(I))) for key in cdf.marginal_basis}
    for h,mon in zip(hs,basis):
        for keep,power,co in marginal_terms(mon):
            AA[keep]=add(AA[keep],scale(profile_bounds(h,tabs[power],E,I),float(co)))
    nc={key:(np.zeros(len(I)),np.zeros(len(I))) for key in cdf.moment_keys}
    for a,ma in enumerate(cdf.marginal_basis):
        for b in range(a,len(cdf.marginal_basis)):
            mb=cdf.marginal_basis[b];key=tuple(sorted(ma+mb))
            co=square(AA[ma]) if a==b else scale(mul(AA[ma],AA[mb]),2.)
            nc[key]=add(nc[key],co)
    num=arb(0);points=np.arange(ilo,itop+1)*spacing;components=[]
    # Omitted s<ilo*spacing contributes the square of a real marginal,
    # hence is nonnegative even though individual components can be signed.
    for key in cdf.moment_keys:
        co=nc[key];L,V=cdf.bounds(k-1,ki[key],points)
        value=integrate_bound(co[0],L,V,-1);components.append(value);num+=arb(value)
    nl=float(D(float(num.lower())));assert nl>0
    q=arb(k)/m2*arb(nl)/arb(dh);ql=float(D(float(q.lower())))
    Cup=amplitude(hs,basis,E,spacing,S);scaled_den=float(D(float((arb(dl)/arb(Cup)**2).lower())))
    print(json.dumps(dict(stage='quotient',k=k,Q_lower=ql,den_lower=dl,den_upper=dh,num_lower=nl,amplitude_upper=Cup,seconds=time.time()-t)),flush=True)
    rc=restriction_loss(k,d['theta'],d['beta'],d['smooth_delta'],d['omega'],scaled_den,ufrac=d['ufrac'],sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=1-eps)
    target=arb(m)/(arb(1)/4+arb(d['omega']));tu=float(H(float(target.upper())));margin=float(D(float((arb(ql)-arb(rc['loss_upper'])-arb(tu)).lower())))
    assert 240*arb(d['omega'])+80*arb(d['smooth_delta'])<3
    assert 2*(arb(1)/4+arb(d['omega']))*(1+arb(eps))<1
    out=dict(m=m,k=k,trial=str(path),basis=basis,Q_lower=ql,restriction=rc,target_upper=tu,margin_lower=margin,epsilon=eps,den_lower=dl,den_upper=dh,num_lower=nl,num_components_lower=components,amplitude_upper=Cup,scaled_den_lower=scaled_den,moment_keys=cdf.moment_keys,cdf=dict(J=cdf.J,N=cdf.N,error={str(key):v for key,v in cdf.error.items()},alias={str(key):v for key,v in cdf.alias.items()},series_tail={str(key):v for key,v in cdf.tail.items()}),elapsed=time.time()-t,backend='inherited mpmath.iv bounded scalar and Fourier/FFT routines')
    Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    from direct_fourier_check import check
    out['direct_fourier_checks']=check(cdf)
    Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({a:b for a,b in out.items() if a!='direct_fourier_checks'}),flush=True)
    return out
if __name__=='__main__':
    for p in sys.argv[1:]:run(p)
