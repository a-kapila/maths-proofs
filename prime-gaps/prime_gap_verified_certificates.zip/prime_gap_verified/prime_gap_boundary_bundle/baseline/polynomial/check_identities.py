"""Independent exact finite-distribution checks of new polynomial identities."""
import sys,json,itertools,random
from fractions import Fraction as F
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]/'inherited'/'analysis'))
from polynomial_core import weights,needed_moments,marginal_terms
basis=[(),(2,),(3,),(4,),(2,2)];keys,marginal=needed_moments(basis)
checks=0
for n in (2,3,4):
 for den in (3,5,7):
  vals=[F(0),F(1,den),F(1,2),F(1)]
  mu=[sum(x**p for x in vals)/len(vals) for p in range(9)]
  predicted=weights(n,mu,keys);direct=[F(0) for key in keys]
  for xs in itertools.product(vals,repeat=n):
   zs={p:sum(x**p for x in xs) for p in (2,3,4)}
   for j,key in enumerate(keys):
    v=F(1)
    for p in key:v*=zs[p]
    direct[j]+=v/F(len(vals)**n)
  for a,b in zip(predicted,direct):assert a==b,(n,den,a,b);checks+=1
rng=random.Random(5213);marginal_checks=0
for _ in range(200):
 x=F(rng.randrange(0,100),100);z={p:F(rng.randrange(0,100),17) for p in (2,3,4)}
 for mon in basis:
  lhs=F(1)
  for p in mon:lhs*=z[p]+x**p
  rhs=F(0)
  for ke,power,c in marginal_terms(mon):
   v=c*x**power
   for p in ke:v*=z[p]
   rhs+=v
  assert lhs==rhs;marginal_checks+=1
out={'exact_joint_moment_checks':checks,'exact_marginal_expansion_checks':marginal_checks,'status':'passed','moment_keys':keys}
Path(__file__).with_name('identity_checks.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
