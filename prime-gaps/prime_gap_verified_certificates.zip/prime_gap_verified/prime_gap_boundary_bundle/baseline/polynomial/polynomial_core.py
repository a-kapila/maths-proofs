"""Exact set-partition identities with interval-valued one-coordinate moments.
A tuple (p1,...,pr) denotes the nonnegative weight Z_p1 ... Z_pr.
No floating exploratory routines are imported in certification.
"""
from functools import lru_cache
from collections import Counter
from math import prod
from multi_core import single_moments

@lru_cache(None)
def partitions(items):
    if not items: return ((),)
    x,*rest=items; out=[]
    for part in partitions(tuple(rest)):
        out.append(((x,),)+part)
        for j in range(len(part)):
            out.append(part[:j]+((x,)+part[j],)+part[j+1:])
    return tuple(out)

@lru_cache(None)
def terms(key):
    return tuple(Counter(tuple(sorted(map(sum,p))) for p in partitions(key)).items())

def weights(n,mu,keys):
    rmax=max(map(len,keys)); ph={r:mu[0]**(n-r) for r in range(rmax+1)}
    ff={r:prod(n-i for i in range(r)) for r in range(rmax+1)}
    out=[]
    for key in keys:
        value=0
        for blocks,multiplicity in terms(tuple(key)):
            v=multiplicity*ff[len(blocks)]*ph[len(blocks)]
            for p in blocks: v=v*mu[p]
            value=value+v
        out.append(value)
    return out

@lru_cache(None)
def marginal_terms(mon):
    counts=Counter()
    for mask in range(2**len(mon)):
        keep=tuple(mon[j] for j in range(len(mon)) if not (mask>>j)&1)
        power=sum(mon[j] for j in range(len(mon)) if (mask>>j)&1)
        counts[keep,power]+=1
    return tuple((ke,pw,ct) for (ke,pw),ct in counts.items())

def needed_moments(basis):
    marginal=sorted({ke for mon in basis for ke,_,_ in marginal_terms(mon)},key=lambda x:(len(x),x))
    keys={tuple(sorted(a+b)) for a in basis for b in basis}
    keys.update(tuple(sorted(a+b)) for a in marginal for b in marginal)
    return sorted(keys,key=lambda x:(len(x),x)),marginal
