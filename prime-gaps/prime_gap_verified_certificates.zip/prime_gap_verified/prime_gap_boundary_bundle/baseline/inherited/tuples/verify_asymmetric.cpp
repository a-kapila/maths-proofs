// Full missing-residue verification and optimal consecutive subset within
// the specified signed-prime parent. Independent segmented byte prime sieve.
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <omp.h>
int main(int argc,char**argv){
 if(argc<6){std::cerr<<"original-k selected-k cutoff limit witness.bin\n";return 2;}
 uint64_t original_k=std::stoull(argv[1]),k=std::stoull(argv[2]),cutoff=std::stoull(argv[3]),limit=std::stoull(argv[4]);
 assert(k<=original_k && cutoff<original_k && original_k<limit);
 auto started=std::chrono::steady_clock::now();
 std::ifstream in(argv[5],std::ios::binary);assert(in);in.seekg(0,std::ios::end);auto len=in.tellg();assert(len>0 && len%8==0);in.seekg(0);
 std::vector<uint32_t>ps,rs;uint32_t pair[2];while(in.read((char*)pair,8)){ps.push_back(pair[0]);rs.push_back(pair[1]);}assert((uint64_t)len==8*ps.size());
 const uint64_t root=100000,block=1<<22;assert(root*root>=limit);
 std::vector<uint8_t>small(root+1,1);small[0]=small[1]=0;std::vector<uint32_t>base;
 for(uint64_t i=2;i<=root;i++)if(small[i]){base.push_back(i);for(uint64_t j=i*i;j<=root;j+=i)small[j]=0;}
 std::vector<uint8_t>prime((limit+1)/2,1);prime[0]=0;
 #pragma omp parallel for schedule(dynamic,1)
 for(uint64_t start=0;start<prime.size();start+=block){
  uint64_t stop=std::min<uint64_t>(prime.size(),start+block),lo=2*start+1,hi=2*stop-1;
  for(uint64_t p:base){if(p==2)continue;if(p*p>hi)break;uint64_t q=std::max(p*p,((lo+p-1)/p)*p);if(!(q&1))q+=p;for(;q<=hi;q+=2*p)prime[q/2]=0;}
 }
 uint64_t ni=0,deleted=0;for(uint64_t p=cutoff+1;p<=original_k;p++)if((p&1)&&prime[p/2]){assert(ni<ps.size()&&ps[ni]==p&&rs[ni]<p);if(rs[ni]==0)deleted++;ni++;}assert(ni==ps.size());
 for(size_t i=0;i<ps.size();i++)if(rs[i]==0)prime[ps[i]/2]=0;
 uint64_t N=0,last=0,first=0;for(uint64_t q=cutoff+1;q<=limit;q+=2)if(prime[q/2]){if(!first)first=q;last=q;N++;}
 assert(k>N && k<=2*N);uint64_t nmin=k-N;std::vector<uint32_t>tail;tail.reserve(2*N-k+1);uint64_t count=0;
 for(uint64_t q=cutoff+1;q<=limit;q+=2)if(prime[q/2]){count++;if(count>=nmin)tail.push_back(q);}assert(count==N && tail.size()==N-nmin+1);
 auto at=[&](uint64_t i){assert(i>=nmin&&i<=N);return(uint64_t)tail[i-nmin];};
 uint64_t best=UINT64_MAX,bn=0,left=0,right=0;
 for(uint64_t n=nmin;n<=N;n++){uint64_t D=at(n)+at(k-n);if(D<best){best=D;bn=n;left=at(n);right=at(k-n);}}
 uint64_t failures=0,checked=0;
 #pragma omp parallel for schedule(dynamic,256) reduction(+:failures,checked)
 for(size_t i=0;i<ps.size();i++){
  uint64_t p=ps[i],r=rs[i];if(!r){if(prime[p/2])failures++;continue;}
  for(uint64_t s:{r,p-r}){uint64_t q=((cutoff+1+p-1-s)/p)*p+s;for(;q<=last;q+=p)if((q&1)&&prime[q/2]){failures++;break;}}checked++;
 }
 auto secs=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
 std::cout<<"{\"verified\":"<<(failures?"false":"true")<<",\"k\":"<<k<<",\"parent_cardinality\":"<<2*N<<",\"cutoff\":"<<cutoff<<",\"limit\":"<<limit<<",\"certificate_prime_count\":"<<ps.size()<<",\"nonzero_witnesses_checked\":"<<checked<<",\"zero_witnesses_checked\":"<<deleted<<",\"negative_count\":"<<bn<<",\"positive_count\":"<<k-bn<<",\"first\":-"<<left<<",\"last\":"<<right<<",\"diameter\":"<<best<<",\"parent_last_positive\":"<<last<<",\"balanced_diameter\":"<<(at(k/2)+at(k-k/2))<<",\"candidate_windows\":"<<2*N-k+1<<",\"failures\":"<<failures<<",\"seconds\":"<<secs<<"}"<<std::endl;
 return failures?1:0;
}
