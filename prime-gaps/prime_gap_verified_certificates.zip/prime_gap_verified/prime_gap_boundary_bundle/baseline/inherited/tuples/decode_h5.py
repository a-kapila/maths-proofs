"""Reconstruct the complete (prime, missing-residue) certificate.

The compressed file stores one little-endian uint32 residue per prime in
(10_000_000, 234_360_000], in increasing order. The prime column is generated
independently by an exact Eratosthenes sieve. Output is little-endian uint32
pairs, consumed by verify_asymmetric.cpp. Requires NumPy.
"""
from pathlib import Path
import gzip
import json
import hashlib
import math
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent

def main() -> None:
    destination = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / 'h5_witness.bin'
    upper = 234_360_000
    sieve = np.ones((upper + 1) // 2, dtype=np.bool_)
    sieve[0] = False
    for p in range(3, math.isqrt(upper) + 1, 2):
        if sieve[p // 2]:
            sieve[p * p // 2::p] = False
    primes = 2 * np.flatnonzero(sieve) + 1
    primes = primes[(primes > 10_000_000) & (primes <= upper)]
    residues = np.frombuffer(gzip.decompress((ROOT / 'h5_residues.u32.gz').read_bytes()),
                             dtype='<u4')
    if len(primes) != 12_204_094 or len(primes) != len(residues):
        raise ValueError('Incomplete residue sequence or unexpected prime count')
    if np.any(residues >= primes):
        raise ValueError('Residue out of range')
    pairs = np.empty((len(primes), 2), dtype='<u4')
    pairs[:, 0] = primes
    pairs[:, 1] = residues
    pairs.tofile(destination)
    expected = json.loads((ROOT / 'h5_encoding.json').read_text())['decoded_pair_file_sha256']
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    if digest != expected:
        raise ValueError(f'Decoded certificate checksum mismatch: {digest}')
    print(f'Wrote {len(primes):,} prime/residue pairs to {destination}')

if __name__ == '__main__':
    main()
