#include <algorithm>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

// Independent verifier for an explicit tuple and one missing residue per prime.
// It checks the complete list of primes <=k and scans each forbidden arithmetic
// progression through the interval. It never trusts the constructor's counts.
int main(int argc,char**argv){
 if(argc<4){std::cerr<<"usage: verify_tuple tuple.csv witnesses.csv k\n";return 2;}
 uint64_t k=std::stoull(argv[3]);std::ifstream in(argv[1]);std::vector<int64_t> h;int64_t x;
 while(in>>x)h.push_back(x);assert(h.size()==k);
 for(size_t i=1;i<h.size();i++)assert(h[i]>h[i-1]&&((h[i]-h[0])%2==0));
 int64_t lo=h[0],hi=h.back();std::vector<uint8_t> present((hi-lo)/2+1,0);
 for(auto a:h)present[(a-lo)/2]=1;
 std::vector<uint8_t> isp(k+1,1);isp[0]=isp[1]=0;
 for(uint64_t p=2;p*p<=k;p++)if(isp[p])for(uint64_t q=p*p;q<=k;q+=p)isp[q]=0;
 std::ifstream cf(argv[2]);std::string line;std::getline(cf,line);uint64_t checked=0;
 uint64_t expected=2;
 while(std::getline(cf,line)){
  std::stringstream ss(line);int64_t p,r;char comma;assert(ss>>p>>comma>>r);assert(comma==','&&p>1&&0<=r&&r<p);
  if(p>int64_t(k))break;assert(uint64_t(p)==expected&&isp[p]);
  if(p==2){assert(((lo%2)+2)%2!=r);}
  else{
   int64_t delta=(r-lo)%p;if(delta<0)delta+=p;int64_t a=lo+delta;
   if((a-lo)%2)a+=p;
   for(;a<=hi;a+=2*p)assert(!present[(a-lo)/2]);
  }
  checked++;expected=p+1;while(expected<=k&&!isp[expected])expected++;
 }
 assert(expected>k);
 std::cout<<"{\"verified\":true,\"k\":"<<k<<",\"first\":"<<lo<<",\"last\":"<<hi<<",\"diameter\":"<<hi-lo<<",\"checked_primes\":"<<checked<<"}\n";
}
