# Current continuation

The copied prior notes and attribution files describe their own respective rounds.
Current additions are the quartic fixed trials, sharp_tail in loss_joint.py,
chunked independent FFT butterflies in periodic_shifted.py, exact final subsets,
and the additional 39,295 large-tuple residue witnesses. The original FFT routine
is retained as periodic_shifted_original.py. No external expert review is claimed.
