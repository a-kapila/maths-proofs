# Enlarging the support in hexagon:2610.00419v1

This note gives an extension of Theorem 3.4 of *Improved bounds on H_m for
2 <= m <= 5*, using the square-completion argument of Polymath,
*Variants of the Selberg sieve, and bounded intervals containing many primes*,
Theorem 3.12 and Section 5.3, arXiv:1407.4897v4. It uses the same
equidistribution inputs as the Hexagon paper; it does not improve those inputs.

## 1. Precise criterion

Let k >= 2 and m >= 1 be integers. Choose positive omega and delta satisfying

    240 omega + 80 delta < 3,

and put rho = 1/4 + omega. Choose positive u0 and kappa satisfying

    u0 < delta/rho,
    kappa < (1/4 + delta/2)/rho.

Let 0 <= epsilon < 1 and assume 2 rho (1+epsilon) < 1.
Define

    R_k(sigma;u0,kappa)
      = {t_i >= 0 : sum_i t_i <= sigma,
         (3/2)v + sum_{i:t_i>=v}t_i <= kappa
         for every u0 < v <= max_i t_i}.

For compactly supported square-integrable F define

    I(F) = integral F(t)^2 dt,
    M_i F(t_{-i}) = integral_0^infinity F(t_{-i},t_i) dt_i,
    J_{i,a}(F) = integral_{sum_{j!=i}t_j <= a} (M_i F(t_{-i}))^2 dt_{-i}.

**Proposition.** If a nonzero F is supported in
R_k(1+epsilon;u0,kappa) and

    sum_i J_{i,1-epsilon}(F)/I(F) > m/rho,

then DHL[k,m+1] holds.

No Elliott-Halberstam conjecture or additional distribution hypothesis is
being introduced: Proposition 3.3 of the Hexagon paper supplies the mixed
prime sums needed below.

## 2. Proof

First shrink coordinates by lambda = rho - eta, where eta > 0 is sufficiently
small. The rescaled function F_1(t)=F(t/lambda) satisfies

    sum_i J_{i,lambda(1-epsilon)}(F_1)/I(F_1) > m.

Its support is contained in
R_k(lambda(1+epsilon);lambda u0,lambda kappa). All arithmetic support
inequalities have a strict positive margin. The marginal operators M_i are
bounded from L2 to L2 on a common bounded support by Cauchy-Schwarz. Thus
shrinking by an additional arbitrarily small factor, shifting, and mollifying
as in the proof of Theorem 3.4 preserves a strict quotient above m, and keeps
the support inequalities strict. We may consequently use a smooth F_1 with
support in the positive orthant and with all these margins.

For each i choose a smooth cutoff chi_i(t_{-i}) in [0,1], supported where
sum_{j!=i} t_j < lambda(1-epsilon), tending from below to the indicator of
that simplex. Put

    K_i(t_{-i}) = chi_i(t_{-i}) M_i F_1(t_{-i}).

Because simplex boundaries have measure zero,

    2 <M_i F_1,K_i> - ||K_i||_2^2
      = integral (2 chi_i - chi_i^2) (M_i F_1)^2
      -> J_{i,lambda(1-epsilon)}(F_1).

Take the cutoffs close enough that the sum of these expressions still exceeds
m I(F_1).

Let f be the coordinatewise antiderivative of F_1, and let b_i be the
coordinatewise antiderivative of K_i in its k-1 coordinates. Their supports
lie in the coordinatewise down-closures of the original supports. The regions
R_k are down-sets (Lemma 3.2 of the paper). Removing a coordinate also
preserves the large-coordinate inequalities. Therefore:

* every outer coefficient support has total exponent less than
  lambda(1+epsilon);
* every inner coefficient support has total exponent less than
  lambda(1-epsilon);
* both satisfy the per-vector tail inequalities of Proposition 3.3 with
  strict slack, since lambda u0 < delta and
  lambda kappa < 1/4+delta/2.

Approximate these primitives, together with the mixed derivatives needed in
the quadratic forms, by finite sums of smooth tensor products with support
corners still inside these strict inequalities. This is precisely the
support-preserving approximation used in Theorem 3.4, Steps 3-4, applied also
in dimension k-1 to each b_i. The positive strict margin survives this
approximation. Write A(n) for the outer Selberg divisor sum associated with f,
and B_i(n) for the inner sum associated with b_i, omitting coordinate i.

The unweighted sum of A(n)^2 is evaluated by Lemma 2.7, because any two outer
support exponents sum to at most 2 lambda(1+epsilon) < 1. Its leading
constant is I(F_1).

On the support of theta(n+h_i), the divisor in coordinate i is forced to be
1, since its support exponent is less than 1. Consequently the mixed sums
theta(n+h_i) A(n) B_i(n) and theta(n+h_i) B_i(n)^2 can be evaluated by
Proposition 3.3:

* an outer-inner pair has exponent sum at most
  lambda(1+epsilon)+lambda(1-epsilon)=2 lambda<2 rho;
* an inner-inner pair has exponent sum at most 2 lambda(1-epsilon)<2 rho;
* each individual support satisfies the same dense-divisibility cap.

The respective leading constants are <M_i F_1,K_i> and ||K_i||_2^2. Here the
derivative signs of the two primitives agree and cancel in their product.

Finally, the identity

    A(n)^2 = 2 A(n) B_i(n) - B_i(n)^2 + (A(n)-B_i(n))^2

and theta >= 0 give a lower bound for the prime-weighted outer square with
leading constant 2 <M_i F_1,K_i> - ||K_i||_2^2. These constants are
nonnegative because 0 <= chi_i <= 1. Their sum exceeds m I(F_1), so the
pigeonhole criterion, Lemma 2.6, proves DHL[k,m+1].

## 3. Product trials and exact scaling

In direct enlarged coordinates, let

    F_psi(t) = psi(sum t_i) product_i g(t_i),
    0 <= psi <= 1, psi(s)=0 for s>1+epsilon,
    g(t)=1_[0,T](t)/(c+(k-1)t),
    m2=integral g^2,
    X_i iid with density g^2/m2,
    S_n=X_1+...+X_n,
    Psi(s)=integral_0^T psi(s+t)g(t)dt.

Then the quotient before imposing the large-coordinate restrictions is

    Q_epsilon(F_psi)
      = (k/m2) E[1_{S_{k-1}<=1-epsilon} Psi(S_{k-1})^2]
        / E[psi(S_k)^2].

This is exactly the objective already implemented by hopt_lat.py and
hcert.py when eps_cells is positive, with
epsilon = eps_cells * DELTA. The denominator's last edge is 1+epsilon and
the numerator's last endpoint is 1-epsilon.

Alternatively retain psi supported on [0,1] and g in their original
coordinates. Put a=(1-epsilon)/(1+epsilon) and

    R' = R_k(1;u0/(1+epsilon),kappa/(1+epsilon)).

Then the physical outer trial

    H(t)=F_psi(t/(1+epsilon))
          1_{R_k(1+epsilon;u0,kappa)}(t)

satisfies the exact scaling identity

    Q_epsilon(H) = (1+epsilon) Q_a(F_psi 1_{R'}),

where Q_a uses the cutoff S_{k-1}<=a. This formulation permits direct reuse
of the original support-loss formulas with the rescaled u0 and kappa.

## 4. Restriction-loss bound

For either coordinate convention, let Psi_R(t') denote the marginal after
restricting the outer trial to its R region. Since psi and g are nonnegative,
0 <= Psi_R <= Psi. Also I(F_psi 1_R) <= I(F_psi). Thus, whenever the right
side is positive,

    Q_epsilon(F_psi 1_R)
      >= Q_epsilon(F_psi)
         - (k/m2) E[Psi(S_{k-1})^2-Psi_R(X')^2]/E[psi(S_k)^2].

This drops the numerator cutoff in the nonnegative error term and is
therefore conservative. No unproved cancellation is used.

In direct enlarged coordinates, set sigma=1+epsilon. In Lemma 4.3 all
occurrences of 1 that arise from the outer support sum bound must be replaced
by sigma. In detail, for v_l cells and

    A_l=kappa-(3/2)v_{l+1},
    n_l^a=floor(A_l/T),
    n_l^b=floor((A_l-T)/T),

use

    b_l^a=min(sigma-A_l, sigma-(n_l^a+1)v_l),
    b_l^b=min(sigma-A_l, sigma-(n_l^b+2)v_l).

The same two-term upper bound in Lemma 4.3 then applies. Its simpler second
bound uses sigma-A_l instead of 1-A_l. The binomial/Chernoff calculation is
unchanged. This follows by repeating the proof with s'+t <= sigma in place
of s'+t <= 1.

For the rescaled formulation the original Lemma 4.3 applies verbatim to R',
since the original psi still vanishes above 1. If L' bounds that loss, the
usable lower bound is

    (1+epsilon) [ (k/m2) E[1_{S_{k-1}<=a}Psi(S_{k-1})^2]
                      /E[psi(S_k)^2] - L' ].

## 5. Scope and certification cautions

The proposition is a proved implication given the same prime-distribution
input used in the source paper. A numerical instance still requires a valid
lower certificate for Q_epsilon, a support-loss upper certificate adapted as
above, and an admissible k-tuple before it yields an explicit improved H_m.
The original source's hcert.py already accepts eps_cells, but its original
rc_loss_rig.py and rc_loss_rig2.py are written for sigma=1 and must not be
used unchanged on a direct psi supported beyond 1.

Sources:

* https://hexagonmath.org/2610.00419v1 — Theorem 3.4, Proposition 3.3,
  Lemmas 2.6, 2.7, 3.2, 4.1-4.3.
* https://arxiv.org/html/1407.4897v4 — Theorem 3.12 and Section 5.3,
  square-completion argument for an enlarged simplex.
