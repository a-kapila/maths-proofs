# Current continuation and retained attribution

The main original source is Hexagon 2610.00419v1, *Improved bounds on H_m for 2 <= m <= 5*, CC BY 4.0. Contributed by Annanay Kapila; the landing page credits Avi Eisenberg for supplying its manuscript and ancillary computations. Original URL: https://hexagonmath.org/2610.00419v1 . No endorsement is implied.

`PROVENANCE.txt` is retained historical attribution from the earlier research package. Its references to paths such as source_raw/ describe that historical package, not additional files silently assumed to be present in this one.

The present work adds the correlated factor psi0(S)+psi1(S)*Z, exact weighted-moment transforms, weighted CDF certification, signed-coefficient integration, the signed support-loss argument, and the whole-fiber inner-cap tightening. It retains the prior shifted profile, elementary-operation FFT, bounded scalar compatibility layer, arithmetic inputs, enlarged-support proof and tuple parent data. The new exact slicing and selected integer subsets are recorded in verification/.

The compressed H5 residues and previous provenance metadata are unchanged from the earlier continuation. The H2 parent is derived from the Engelsma--Sutherland public admissible-tuple database; see the historical attribution for the xfxie entry. This continuation claims no new prime-pair restoration and no external review of its mathematical derivation.
