#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){if(argc<6)return 2;int D=stoi(argv[1]),k=stoi(argv[2]),sweeps=stoi(argv[4]);string pref=argv[5];int N=D/2+1;vector<int>p,a;ifstream in(argv[3]);string s;getline(in,s);while(getline(in,s)){replace(s.begin(),s.end(),',',' ');istringstream ss(s);int pp,r;ss>>pp>>r;if(pp==2)continue;if(pp>k)continue;p.push_back(pp);a.push_back(1LL*r*((pp+1)/2)%pp);}vector<int>c(N),cp(k+1),cq(k+1),cpq(N+1),ok;for(size_t i=0;i<p.size();i++)for(int x=a[i];x<N;x+=p[i])c[x]++;int total=count(c.begin(),c.end(),0);cerr<<"start="<<total<<"\n";auto start=chrono::steady_clock::now();
 auto save=[&](){ofstream f(pref+".csv");for(int x=0;x<N;x++)if(!c[x])f<<2*x<<"\n";ofstream w(pref+"_witness.csv");w<<"prime,missing_residue\n2,1\n";for(size_t i=0;i<p.size();i++)w<<p[i]<<","<<2*a[i]%p[i]<<"\n";};
 for(int sw=0;sw<sweeps;sw++){
  int changed=0;
  for(size_t i=0;i<p.size();i++)for(size_t j=i+1;j<p.size();j++){
   int P=p[i],Q=p[j],PQ=P*Q;
   for(int x=a[i];x<N;x+=P)c[x]--;for(int x=a[j];x<N;x+=Q)c[x]--;
   fill(cp.begin(),cp.begin()+P,0);fill(cq.begin(),cq.begin()+Q,0);if(PQ<=N)fill(cpq.begin(),cpq.begin()+PQ,0);ok.clear();
   for(int x=0;x<N;x++)if(!c[x]){ok.push_back(x);cp[x%P]++;cq[x%Q]++;if(PQ<=N)cpq[x%PQ]++;}
   int R=min_element(cp.begin(),cp.begin()+P)-cp.begin(),S=min_element(cq.begin(),cq.begin()+Q)-cq.begin();int best=cp[R]+cq[S];
   for(int x:ok){int r=x%P,s=x%Q,v=cp[r]+cq[s]-(PQ<=N?cpq[x%PQ]:1);if(v<best){best=v;R=r;S=s;}}
   int newtotal=(int)ok.size()-best;
   if(newtotal>total){a[i]=R;a[j]=S;total=newtotal;changed++;cerr<<"gain p="<<P<<" q="<<Q<<" total="<<total<<" secs="<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<"\n";}
   for(int x=a[i];x<N;x+=P)c[x]++;for(int x=a[j];x<N;x+=Q)c[x]++;
   if(total>=k){save();cerr<<"SUCCESS="<<total<<"\n";return 0;}
  }
  cerr<<"sweep="<<sw<<" changes="<<changed<<" total="<<total<<"\n";if(!changed)break;
 }
 save();
}
