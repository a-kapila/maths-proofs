#include <bits/stdc++.h>
#include <omp.h>
using namespace std;
struct Bits{vector<uint64_t>w;Bits(uint64_t n):w((n+63)/64,~0ULL){}bool get(uint64_t i)const{return (w[i>>6]>>(i&63))&1;}void clear(uint64_t i){w[i>>6]&=~(1ULL<<(i&63));}};
int main(int argc,char**argv){
 if(argc<5){cerr<<"raw-r16 max-primes max-residue output\n";return 2;}
 const uint64_t oldk=234360000,k=233689918,cut=10000000,limit=2432107459;
 int maxp=stoi(argv[2]),maxr=stoi(argv[3]);string pref=argv[4];auto start=chrono::steady_clock::now();auto secs=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 Bits prime((limit+1)/2);prime.clear(0);for(uint64_t p=3;p*p<=limit;p+=2)if(prime.get(p/2))for(uint64_t j=p*p;j<=limit;j+=2*p)prime.clear(j/2);
 vector<uint32_t>ps,rs;vector<size_t>zeros;ifstream in(argv[1],ios::binary);uint32_t pair[2];
 while(in.read((char*)pair,8)){ps.push_back(pair[0]);rs.push_back(pair[1]);if(!pair[1])zeros.push_back(ps.size()-1);}
 assert(in.eof());cerr<<"sieved zero_count="<<zeros.size()<<" greatest_zero="<<ps[zeros.back()]<<" secs="<<secs()<<"\n";
 if(zeros.size()>(size_t)maxp)zeros.erase(zeros.begin(),zeros.end()-maxp);
 reverse(zeros.begin(),zeros.end());atomic<int>found(0),done(0);ofstream patches(pref+"_patches.csv");patches<<"prime,missing_residue\n";
 #pragma omp parallel for schedule(dynamic,32)
 for(size_t z=0;z<zeros.size();z++){
  size_t i=zeros[z];uint64_t p=ps[i];uint32_t success=0;
  for(uint64_t rr=1048577;rr<=(uint64_t)maxr;rr++){
   bool hit=false;
   for(int sign=0;sign<2&&!hit;sign++){
    uint64_t q=sign?p-rr:rr;if(q<=cut)q+=((cut-q)/p+1)*p;if(!(q&1))q+=p;
    for(;q<=limit;q+=2*p)if(prime.get(q/2)){hit=true;break;}
   }
   if(!hit){success=rr;break;}
  }
  if(success){rs[i]=success;found++;
   #pragma omp critical
   patches<<p<<","<<success<<"\n";
  }
  int dd=++done;if(dd%10000==0){
   #pragma omp critical
   cerr<<"done="<<dd<<" restored="<<found<<" seconds="<<secs()<<"\n";
  }
 }
 patches.close();ofstream cert(pref+"_witness.bin",ios::binary);for(size_t i=0;i<ps.size();i++){uint32_t pair[2]={ps[i],rs[i]};cert.write((char*)pair,8);if(!rs[i])prime.clear(ps[i]/2);}cert.close();
 uint64_t n=0,last=0,first=0;for(uint64_t q=cut+1;q<=limit;q++)if((q&1)&&prime.get(q/2)){if(!first)first=q;last=q;if(++n==k/2)break;}assert(n==k/2);
 ofstream meta(pref+"_result.json");meta<<"{\"k\":"<<k<<",\"restored_pairs\":"<<found<<",\"first_positive\":"<<first<<",\"last_positive\":"<<last<<",\"diameter\":"<<2*last<<",\"seconds\":"<<secs()<<"}\n";cerr<<"FINISHED restored="<<found<<" diameter="<<2*last<<" secs="<<secs()<<"\n";
}
