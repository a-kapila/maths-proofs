"""Exploratory density evaluator with cancellation-free log(phi).
Not a certificate; interval code is separate.
"""
import numpy as np
from scipy.special import exp1
class Model:
 def __init__(self,k,theta,beta,A=0.,P=16.,N=2**20,cut=1e-22):
  L=np.log(k);c=theta/L;T=beta/L;b=k-1;u=c+b*T
  assert 1/u+A>0
  self.k,self.c,self.T,self.b,self.A,self.P,self.N=k,c,T,b,A,P,N
  self.h=P/N
  m20=(1/c-1/u)/b;G0=np.log(u/c)/b;m2=m20+2*A*G0+A*A*T;self.m2=m2
  J=64
  while True:
   xi=2*np.pi*np.arange(1,J+1)/P;a=xi/b
   E=exp1(-1j*a*c)-exp1(-1j*a*u)
   fm1=np.exp(-1j*a*c)*E/b
   f0=np.expm1(1j*xi*T)/(1j*xi)
   delta=(-np.expm1(1j*xi*T)/(b*u)+1j*xi/b*fm1+2*A*(fm1-G0)+A*A*(f0-T))/m2
   re,im=delta.real,delta.imag
   logphi=.5*np.log1p(2*re+re*re+im*im)+1j*np.arctan2(im,1+re)
   if (k-1)*logphi[-1].real<np.log(cut) or J>N//4:break
   J*=2
  self.logphi=np.r_[0j,logphi];self.J=J
 def density(self,n):
  spec=np.zeros(self.N,dtype=complex);pn=np.exp(n*self.logphi)
  spec[:len(pn)]=pn;spec[-(len(pn)-1):]=np.conj(pn[1:][::-1])
  return np.maximum(np.fft.fft(spec).real/self.P,0.)
 def Gt(self,y):
  yy=np.clip(y,0.,self.T)
  return np.log1p(self.b*yy/self.c)/self.b+self.A*yy
 def cdf(self,n):
  pn=np.exp(n*self.logphi[1:]);j=np.arange(1,len(pn)+1)
  z=pn/(2j*np.pi*j);spec=np.zeros(self.N,dtype=complex)
  spec[1:len(pn)+1]=z;spec[-len(pn):]=np.conj(z[::-1])
  return np.arange(self.N)/self.N+2*np.sum(z.real)-np.fft.fft(spec).real
