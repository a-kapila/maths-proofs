"""Exploratory correlated trial F=prod(g)*(psi0(S)+psi1(S)*sum(t/T)^2)."""
import sys,json,time
import numpy as np
from scipy.special import exp1,roots_legendre
from scipy.interpolate import CubicSpline
from scipy.linalg import eigh
from stable_model import Model

def polynomial_integrals(xi,T,jmax):
 xi=np.asarray(xi);z=1j*xi*T;out=np.empty((jmax+1,len(xi)),complex)
 nz=xi!=0;ez=np.exp(z[nz]);zz=z[nz]
 out[0,nz]=np.expm1(zz)/zz
 for j in range(1,jmax+1):out[j,nz]=ez/zz-j*out[j-1,nz]/zz
 for j in range(jmax+1):out[j,~nz]=1/(j+1)
 small=abs(z)<3;zz=z[small];term=np.ones(len(zz),complex);s=np.zeros((jmax+1,len(zz)),complex)
 for l in range(80):
  if l:term*=zz/l
  for j in range(jmax+1):s[j]+=term/(l+j+1)
 out[:,small]=s
 for j in range(jmax+1):out[j]*=T**(j+1)
 return out

def moment_transforms(M,ns):
 k,c,T,b,A=M.k,M.c,M.T,M.b,M.A;xi=2*np.pi*np.arange(M.J+1)/M.P;aa=xi[1:]/b;u=c+b*T
 P=polynomial_integrals(xi,T,4);J=np.empty_like(P);K=np.empty_like(P)
 J[0,0]=np.log(u/c)/b;K[0,0]=(1/c-1/u)/b
 J[0,1:]=np.exp(-1j*aa*c)*(exp1(-1j*aa*c)-exp1(-1j*aa*u))/b
 K[0,1:]=(1/c-np.exp(1j*xi[1:]*T)/u)/b+1j*xi[1:]/b*J[0,1:]
 for j in range(1,5):
  J[j]=P[j-1]/b-c/b*J[j-1]
  K[j]=J[j-1]/b-c/b*K[j-1]
 a2=(K[2]+2*A*J[2]+A*A*P[2])/(M.m2*T*T)
 a4=(K[4]+2*A*J[4]+A*A*P[4])/(M.m2*T**4)
 outs={}
 for n in ns:
  ph=np.exp(n*M.logphi);ph1=np.exp((n-1)*M.logphi);ph2=np.exp((n-2)*M.logphi)
  outs[n]=np.array([ph,n*a2*ph1,n*a4*ph1+n*(n-1)*a2*a2*ph2])
 return outs

def tables(M,trans):
 densities=[];cdfs=[]
 for v in trans:
  spec=np.zeros(M.N,complex);spec[:len(v)]=v;spec[-len(v)+1:]=v[1:][::-1].conj()
  densities.append(np.fft.fft(spec).real/M.P)
  z=v[1:]/(2j*np.pi*np.arange(1,len(v)));spec[:]=0;spec[1:len(v)]=z;spec[-len(v)+1:]=z[::-1].conj()
  cdfs.append(v[0].real*np.arange(M.N)/M.N+2*np.sum(z.real)-np.fft.fft(spec).real)
 return np.array(densities),np.array(cdfs)

def optimize(d,ncell=200,N=2**19,ng=24,spacing=2**-21):
 k,th,be=d['k'],d['theta'],d['beta'];eps=d['delta']*d['eps_cells'];rel=d['relative_shift']
 A=rel/(th/np.log(k)+(k-1)*be/np.log(k));M=Model(k,th,be,A=A,N=N,P=16)
 tr=moment_transforms(M,[k-1,k]);_,cs=tables(M,tr[k]);dens,_=tables(M,tr[k-1]);s=np.arange(N)*M.h
 s0=s[np.searchsorted(cs[0,:N//8],1e-8)];ec=round(eps/spacing);one=round(1/spacing)
 E=np.unique(np.rint(np.linspace(s0/spacing,one+ec,ncell+1)).astype(np.int64));ed=E*spacing;nc=len(E)-1
 D=np.diff(CubicSpline(s[:N//8+1],cs[:,:N//8+1].T)(ed),axis=0).T
 # Local covariance whitening. Coordinates ordered (psi0 cells,psi1 cells).
 cov=np.stack([np.stack([D[0],D[1]],axis=-1),np.stack([D[1],D[2]],axis=-1)],axis=-2)
 eig,V=np.linalg.eigh(cov);print('eig_range',np.min(eig),np.max(eig),flush=True)
 keep=eig>np.max(eig)*1e-12;w=np.where(keep,1/np.sqrt(np.maximum(eig,1e-300)),0)
 W=V*w[:,None,:];Wbig=np.zeros((2*nc,2*nc));idx=np.arange(nc)
 for a in range(2):
  for b in range(2):Wbig[idx+a*nc,idx+b*nc]=W[:,a,b]
 f=CubicSpline(s[:N//8+1],dens[:,:N//8+1].T);lo=max(0.,ed[0]-M.T);hi=(one-ec)*spacing
 cuts=np.unique(np.r_[lo,hi,ed[(ed>lo)&(ed<hi)],(ed-M.T)[(ed-M.T>lo)&(ed-M.T<hi)]])
 u,w=roots_legendre(ng);u=(u+1)/2;w=w/2;widths=np.diff(cuts)
 nodes=(cuts[1:,None]-widths[:,None]*u[None,:]**2).ravel();weights=(widths[:,None]*2*u[None,:]*w[None,:]).ravel();fs=f(nodes).T*weights
 Bmat=np.zeros((2*nc,2*nc))
 for j in range(0,len(nodes),3000):
  yy=np.clip(ed[:,None]-nodes[None,j:j+3000],0,M.T)
  G0=M.Gt(yy);J0=np.log1p(M.b*yy/M.c)/M.b;J1=yy/M.b-M.c/M.b*J0;J2=yy*yy/(2*M.b)-M.c/M.b*J1
  G2=(J2+M.A*yy**3/3)/(M.T*M.T)
  G=np.diff(G0,axis=0);H=np.diff(G2,axis=0);f0,f1,f2=fs[:,j:j+3000]
  B00=(G*f0)@G.T;B01=(G*f0)@H.T+(G*f1)@G.T
  B11=(H*f0)@H.T+(H*f1)@G.T+(G*f1)@H.T+(G*f2)@G.T
  Bmat[:nc,:nc]+=B00;Bmat[:nc,nc:]+=B01;Bmat[nc:,:nc]+=B01.T;Bmat[nc:,nc:]+=B11
 B=Wbig.T@Bmat@Wbig;lam,Vv=eigh(B,subset_by_index=[2*nc-1,2*nc-1]);h=Wbig@Vv[:,0];h/=max(abs(h));h=np.rint(h*2**40)/2**40
 v0=1/np.sqrt(D[0]);base=eigh((Bmat[:nc,:nc]*v0[:,None])*v0[None,:],subset_by_index=[nc-1,nc-1],eigvals_only=True)[0]*k/M.m2
 den=np.sum(h[:nc]**2*D[0]+2*h[:nc]*h[nc:]*D[1]+h[nc:]**2*D[2]);Q=k/M.m2*(h@Bmat@h)/den
 return dict(k=k,theta=th,beta=be,relative_shift=rel,eps_cells=ec,delta=spacing,E=np.r_[0,E].tolist(),h0=np.r_[0,h[:nc]].tolist(),h1=np.r_[0,h[nc:]].tolist(),Q_exploratory=float(Q),Q_base=base,den=den,ncell=ncell,N=N,ng=ng)
if __name__=='__main__':
 import argparse
 from pathlib import Path
 parser=argparse.ArgumentParser(description='Exploratory, NOT certified, optimization at fixed one-coordinate parameters.')
 parser.add_argument('input',help='A trial JSON supplying k, theta, beta, relative_shift and epsilon.')
 parser.add_argument('output',help='Destination for the new trial JSON.')
 parser.add_argument('--cells',type=int,default=200)
 parser.add_argument('--grid-power',type=int,default=19)
 parser.add_argument('--quadrature',type=int,default=24)
 parser.add_argument('--spacing-power',type=int,default=21)
 args=parser.parse_args();t=time.time();d=json.loads(Path(args.input).read_text())
 R=optimize(d,ncell=args.cells,N=2**args.grid_power,ng=args.quadrature,spacing=2.**-args.spacing_power)
 d.update(R);Path(args.output).write_text(json.dumps(d,indent=2)+'\n')
 print(json.dumps({k:v for k,v in R.items() if k not in ('E','h0','h1')}))
 print('seconds',time.time()-t)
