"""Exploratory (non-certifying) optimization of several additive power sums."""
import json,time,sys
from pathlib import Path
import numpy as np
from scipy.special import exp1, roots_legendre
from scipy.interpolate import CubicSpline
from scipy.linalg import eigh
from stable_model import Model
from explore_lifted import polynomial_integrals, tables

def transforms(M,ns,powers):
    xi=2*np.pi*np.arange(M.J+1)/M.P
    jm=2*max(powers);P=polynomial_integrals(xi,M.T,jm);J=np.empty_like(P);K=np.empty_like(P)
    c,b,T,A=M.c,M.b,M.T,M.A;u=c+b*T
    J[0,0]=np.log(u/c)/b;K[0,0]=(1/c-1/u)/b
    aa=xi[1:]/b
    J[0,1:]=np.exp(-1j*aa*c)*(exp1(-1j*aa*c)-exp1(-1j*aa*u))/b
    K[0,1:]=(1/c-np.exp(1j*xi[1:]*T)/u)/b+1j*xi[1:]/b*J[0,1:]
    for j in range(1,jm+1):
        J[j]=P[j-1]/b-c/b*J[j-1];K[j]=J[j-1]/b-c/b*K[j-1]
    mu={j:(K[j]+2*A*J[j]+A*A*P[j])/(M.m2*T**j) for j in range(1,jm+1)}
    ps=[0]+list(powers);keys=[(a,b) for a in range(len(ps)) for b in range(a,len(ps))]
    outs={}
    for n in ns:
        ph=np.exp(n*M.logphi);ph1=np.exp((n-1)*M.logphi);ph2=np.exp((n-2)*M.logphi)
        arr=[]
        for a,b in keys:
            if b==0:v=ph
            elif a==0:v=n*mu[ps[b]]*ph1
            else:v=n*mu[ps[a]+ps[b]]*ph1+n*(n-1)*mu[ps[a]]*mu[ps[b]]*ph2
            arr.append(v)
        outs[n]=np.array(arr)
    return outs,keys

def optimize(d,ncell=120,N=2**18,ng=20,spacing=2**-21,powers=(2,3),quiet=False):
    start=time.time();k,th,be,rel=d['k'],d['theta'],d['beta'],d['relative_shift']
    eps=d['delta']*d['eps_cells'];A=rel/(th/np.log(k)+(k-1)*be/np.log(k))
    M=Model(k,th,be,A=A,N=N,P=16)
    tr,keys=transforms(M,[k-1,k],powers);dens,cs=tables(M,tr[k]);del dens
    dens,_=tables(M,tr[k-1]);s=np.arange(N)*M.h
    s0=s[np.searchsorted(cs[0,:N//8],1e-8)];ec=round(eps/spacing);one=round(1/spacing)
    E=np.unique(np.rint(np.linspace(s0/spacing,one+ec,ncell+1)).astype(np.int64));ed=E*spacing;nc=len(E)-1;nb=len(powers)+1
    DD=np.diff(CubicSpline(s[:N//8+1],cs[:,:N//8+1].T)(ed),axis=0).T
    cov=np.zeros((nc,nb,nb))
    for r,(a,b) in enumerate(keys):cov[:,a,b]=cov[:,b,a]=DD[r]
    eig,V=np.linalg.eigh(cov);keep=eig>np.max(eig)*1e-13
    w=np.where(keep,1/np.sqrt(np.maximum(eig,1e-300)),0);W=V*w[:,None,:]
    Wbig=np.zeros((nb*nc,nb*nc));idx=np.arange(nc)
    for a in range(nb):
        for b in range(nb):Wbig[idx+a*nc,idx+b*nc]=W[:,a,b]
    f=CubicSpline(s[:N//8+1],dens[:,:N//8+1].T)
    lo=max(0.,ed[0]-M.T);hi=(one-ec)*spacing
    cuts=np.unique(np.r_[lo,hi,ed[(ed>lo)&(ed<hi)],(ed-M.T)[(ed-M.T>lo)&(ed-M.T<hi)]])
    u,w=roots_legendre(ng);u=(u+1)/2;w=w/2;widths=np.diff(cuts)
    nodes=(cuts[1:,None]-widths[:,None]*u[None,:]**2).ravel();weights=(widths[:,None]*2*u[None,:]*w[None,:]).ravel()
    fs=f(nodes).T*weights;Bmat=np.zeros((nb*nc,nb*nc));keyidx={key:r for r,key in enumerate(keys)}
    for j in range(0,len(nodes),1500):
        yy=np.clip(ed[:,None]-nodes[None,j:j+1500],0,M.T);GG=[np.diff(M.Gt(yy),axis=0)]
        Jcur=np.log1p(M.b*yy/M.c)/M.b
        for p in range(1,max(powers)+1):
            Jcur=yy**p/(p*M.b)-M.c/M.b*Jcur
            if p in powers:GG.append(np.diff((Jcur+M.A*yy**(p+1)/(p+1))/M.T**p,axis=0))
        f0=fs[0,j:j+1500];G=GG[0]
        for a,b in keys:
            block=(GG[a]*f0)@GG[b].T
            if a>0:block+=(G*fs[keyidx[0,a],j:j+1500])@GG[b].T
            if b>0:block+=(GG[a]*fs[keyidx[0,b],j:j+1500])@G.T
            if a>0 and b>0:block+=(G*fs[keyidx[a,b],j:j+1500])@G.T
            Bmat[a*nc:(a+1)*nc,b*nc:(b+1)*nc]+=block
            if a!=b:Bmat[b*nc:(b+1)*nc,a*nc:(a+1)*nc]+=block.T
    B=Wbig.T@Bmat@Wbig;lam,Vv=eigh(B,subset_by_index=[nb*nc-1,nb*nc-1]);h=Wbig@Vv[:,0]
    h/=max(abs(h));h=np.rint(h*2**40)/2**40
    den=0.
    for r,(a,b) in enumerate(keys):den+=(1 if a==b else 2)*np.sum(h[a*nc:(a+1)*nc]*h[b*nc:(b+1)*nc]*DD[r])
    Q=k/M.m2*(h@Bmat@h)/den
    out=dict(k=k,theta=th,beta=be,relative_shift=rel,eps_cells=ec,delta=spacing,E=np.r_[0,E].tolist(),powers=list(powers),profiles=[np.r_[0,h[a*nc:(a+1)*nc]].tolist() for a in range(nb)],Q_exploratory=float(Q),den=float(den),ncell=ncell,N=N,ng=ng,seconds=time.time()-start,min_cov_eigen=float(np.min(eig)))
    if not quiet:print(json.dumps({key:val for key,val in out.items() if key not in ('E','profiles')}),flush=True)
    return out

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('input');ap.add_argument('output');ap.add_argument('--cells',type=int,default=120);ap.add_argument('--grid-power',type=int,default=18);ap.add_argument('--quadrature',type=int,default=20);ap.add_argument('--powers',default='2,3');ap.add_argument('--k',type=int)
    a=ap.parse_args();d=json.loads(Path(a.input).read_text())
    if a.k:d['k']=a.k
    r=optimize(d,ncell=a.cells,N=2**a.grid_power,ng=a.quadrature,powers=tuple(map(int,a.powers.split(','))))
    d.update(r);Path(a.output).write_text(json.dumps(d,indent=2)+'\n')
