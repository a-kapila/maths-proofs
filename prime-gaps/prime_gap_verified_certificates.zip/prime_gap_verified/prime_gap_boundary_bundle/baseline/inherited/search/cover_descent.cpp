// Optional constructor, with widened coverage counters.
// Final bounds rely on the separately checked tuple files, not this search.
#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
 if(argc<8){cerr<<"k lo hi witnesses sweeps out seed [pmax]\n";return 2;}
 long k=stol(argv[1]),lo=stol(argv[2]),hi=stol(argv[3]);string out=argv[6];int sweeps=stoi(argv[5]);mt19937 rng(stoul(argv[7]));long pmax=argc>8?stol(argv[8]):k;
 long first=lo+(lo%2!=0),N=(hi-first)/2+1;vector<int>ps,rs,aa;
 string s;ifstream in(argv[4]);getline(in,s);while(getline(in,s)){replace(s.begin(),s.end(),',',' ');istringstream ss(s);long p,r;ss>>p>>r;if(p>k)continue;ps.push_back(p);rs.push_back(r);if(p==2){aa.push_back(-1);continue;}long v=(r-first)%p;if(v<0)v+=p;aa.push_back(v*((p+1)/2)%p);}
 vector<uint32_t>cover(N,0);vector<uint32_t>counts(k+1);for(size_t i=1;i<ps.size();i++)for(long j=aa[i];j<N;j+=ps[i])cover[j]++;
 long cur=count(cover.begin(),cover.end(),0),best=cur;auto start=chrono::steady_clock::now();
 cerr<<"initial="<<cur<<"\n";
 long bestD=LONG_MAX; auto save=[&](){vector<long>h;for(long j=0;j<N;j++)if(cover[j]==0)h.push_back(first+2*j);long D=LONG_MAX;size_t at=0;if((long)h.size()<k)return;for(size_t j=0;j+k<=h.size();j++)if(h[j+k-1]-h[j]<D){D=h[j+k-1]-h[j];at=j;}if(D>=bestD)return;bestD=D;ofstream f(out+".csv");for(size_t j=at;j<at+k;j++)f<<h[j]<<"\n";ofstream w(out+"_witness.csv");w<<"prime,missing_residue\n";for(size_t i=0;i<ps.size();i++){long r=i?((first+2*aa[i])%ps[i]+ps[i])%ps[i]:1;w<<ps[i]<<","<<r<<"\n";}cerr<<"saved survivors="<<h.size()<<" diameter="<<D<<" first="<<h[at]<<" last="<<h[at+k-1]<<"\n";};
 vector<int>order;for(size_t i=1;i<ps.size();i++)if(ps[i]<=pmax)order.push_back(i);
 for(int sweep=0;sweep<sweeps;sweep++){
  if(sweep)shuffle(order.begin(),order.end(),rng);
  long improved=0,tested=0,plateaus=0;
  for(int i:order){int p=ps[i];long a=aa[i],freed=0;
   for(long j=a;j<N;j+=p)if(cover[j]==1)freed++;
   if(!freed&&rng()%20!=0)continue;
   for(long j=a;j<N;j+=p)cover[j]--;
   fill(counts.begin(),counts.begin()+p,0);
   long off=0;for(;off+p<=N;off+=p)for(int r=0;r<p;r++)counts[r]+=(cover[off+r]==0);
   for(int r=0;r<N-off;r++)counts[r]+=(cover[off+r]==0);
   int mn=*min_element(counts.begin(),counts.begin()+p),noptions=0,b=a;
   for(int r=0;r<p;r++)if(counts[r]==mn){if(rng()%++noptions==0)b=r;}
   assert(mn<=freed);for(long j=b;j<N;j+=p)cover[j]++;
   aa[i]=b;cur+=freed-mn;improved+=freed-mn;tested++;if(tested%1000==0)cerr<<"progress sweep="<<sweep<<" p="<<p<<" gain="<<improved<<" tested="<<tested<<"\n";plateaus+=(freed==mn&&b!=a);
  }
  double secs=chrono::duration<double>(chrono::steady_clock::now()-start).count();cerr<<"sweep="<<sweep<<" current="<<cur<<" gain="<<improved<<" tested="<<tested<<" plateaus="<<plateaus<<" secs="<<secs<<"\n";
  save();
 }
}
