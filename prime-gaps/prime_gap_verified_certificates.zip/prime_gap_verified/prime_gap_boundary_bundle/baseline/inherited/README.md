# Quartic correlations and further finite prime-gap bounds

Research continuation, 3 November 2026. These are computer-assisted research
derivations, not independently peer-reviewed records or formally verified proofs.
The external distribution inputs are those of Hexagon 2610.00419v1; the inherited
enlarged-support proof and numerical error argument remain dependencies.

## Results

| m | Trial dimension | Final DHL dimension | Bound for H_m | Analytic status |
|---|---:|---:|---:|---|
| 2 | 2,307 | 2,307 | 19,928 | Inherited |
| 3 | 110,175 | 110,175 | 1,361,118 | Fresh |
| 4 | 5,092,350 | 5,092,341 | 82,334,462 | Fresh |
| 5 | 232,620,000 | 232,619,597 | 4,835,476,492 | Fresh |

For m=3,4,5 the trial is
`F = [psi0(S) + psi2(S)*Z2 + psi3(S)*Z3 + psi4(S)*Z4] * product g(t_i)`,
with `Zp=sum (t_i/T)^p`, `S=sum t_i`, and the inherited shifted reciprocal g.
The four signed profiles give twenty positive weighted distribution functions.
The m=2 row deliberately retains the previous cubic certificate and bound.

A finite positive binomial sum with geometric remainder sharpens the prior
joint support-loss bound. On the previous H2 trial it reduces the loss endpoint
from 5.61435773033431e-5 to 2.088802291969111e-5. This alone does not reduce K.
The proof is elementary and no novelty claim in probability theory is made.

## Exact inputs and analytic reproduction

Every JSON floating value means the exact IEEE binary64 value after parsing.
Profiles are ordered by `powers` after the constant profile; heights are
multiples of 2^-40. Edges are integer `E` multiplied by dyadic `delta`.
The new m=3,4 meshes are 2^-21; m=5 uses 2^-22. The support epsilon is
`delta*eps_cells`. The fine m=5 evaluation uses the same exact step function as
the unsuccessful coarse trial, not a newly optimized function.

`verification/MANIFEST.json` identifies the exact trial bytes, successful
certificate, final dimension and separately verified tuple for each row.
The harmless `trial` metadata in the saved certificates is canonicalized;
the numerical endpoints are unchanged. Exploratory scores in trial JSON
are not certificate inputs, and can refer to the pre-transfer dimension.

Run sequentially on a memory-constrained machine:

```bash
python -m pip install -r requirements.txt
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
cd analysis
python certify_multi.py m3.json m4.json m5.json > ../verification/rerun_analysis.log
python exact_slicing.py > ../verification/rerun_slicing.json
python check_new_math.py
python check_sharp_binomial.py
python check_abel.py
python check_fft_memory.py
cd ..
```

Optional `python certify_multi.py m2.json` recomputes the inherited quotient
with the now-sharper loss routine; its bound can be more conservative or less
conservative than the saved inherited output, without changing the stated K.
The exact slicing check uses full saved binary64 endpoints as exact fractions.
A certificate runner can write an unsuccessful enclosure: **margin_lower must
be positive**. Failed trials are never certified DHL statements.

The scalar `analysis/flint.py` file is a **mpmath.iv compatibility layer, not
FLINT/Arb**. Exponential integrals have explicit remainder bounds. Historical
comments in inherited helper modules may mention Arb; that is not the backend.
The custom FFT uses interval-derived twiddles and the inherited rounding bound,
not an unbounded library FFT. Its new memory-bounded version merely batches
independent butterflies; arithmetic within each butterfly is unchanged.
`periodic_shifted_original.py` is retained for comparison. Ten sizes from 2 to
2^20 gave bitwise-identical results. The m=5 FFT has 2^25 points.

The analytic diagnostics comprise 81 high-precision moment comparisons,
300 joint-probability tests, 508 exact-reference binomial-tail tests,
300 exact-Fraction signed-Abel tests, and 60 direct Fourier checks per new trial.
These diagnostics do not replace the interval argument.

## Complete integer verification

Compile without `-DNDEBUG`; assertions form part of verification.

```bash
g++ -O3 -std=c++17 tuples/verify_tuple.cpp -o verify_tuple
g++ -O3 -std=c++17 -fopenmp tuples/verify_asymmetric.cpp -o verify_asymmetric
./verify_tuple tuples/h2.csv tuples/h2_witness.csv 2307
./verify_tuple tuples/h3.csv tuples/h3_witness.csv 110175
./verify_tuple tuples/h4.csv tuples/h4_witness.csv 5092341
python tuples/decode_h5.py tuples/h5_witness.bin
OMP_NUM_THREADS=2 ./verify_asymmetric 234360000 232619597 10000000 2432107459 tuples/h5_witness.bin
```

The first three checkers cover all primes up to the respective cardinalities:
342, 10,464, and 354,474 primes.
The full tuples and missing-residue witnesses are present, not samples.

The H5 certificate has **12,204,094 prime/residue pairs**. The compressed file
contains one residue for each prime in (10,000,000,234,360,000]. Its decoder
independently reconstructs the prime column and checks this decoded SHA-256:

`a26b388c40c4666939842345647a48a0efd67aaa2449cdd9a39f02780e1a91c5`

The new search restores **39,295 prime pairs**, not merely that many entries.
The independent verifier checks all 11,539,072 nonzero and 665,022 zero
witnesses, reconstructs the parent of 233,949,232 entries, and examines all
1,329,636 consecutive windows at the final cardinality, with zero failures.
The final interval has endpoints -2,408,401,433 and 2,427,075,059.
Its diameter is minimal only within this specified parent, not globally.
At the previous K=232,649,485 the new parent alone gives 4,836,120,478.

## Files, failed trials, and limitations

- `proof_note.pdf/.tex` supplies formulas, proof details, outputs and scope.
- `analysis/` supplies complete fixed trials and evaluators.
- `verification/` supplies actual outputs, exact fractions, diagnostics and manifest.
- `tuples/` supplies complete integer data and separate verification code.
- `search/` supplies optional search sources and the full restored-pair patch list.
- `exploratory/` retains unsuccessful coarse m4/m5 certificates, failed H2 searches,
  and optimizer logs. They are not used in the result.
- `baseline/` retains inherited proof notes, source attribution and the old loss routine.

The first quartic m4 trial at 5,092,000 and first m5 trial at 232,620,000 on mesh
2^-21 failed after error deductions. A parallel fine-grid run was interrupted
by the memory limit and produced no certificate. The final m5 evaluation is
a complete restarted run with memory-bounded butterflies. The search program
`h5_restore_more.cpp` prints a diagnostic diameter at a hardcoded different K;
**that is not the claimed H5 bound**. Only the full verifier at the final K
supplies the final interval and diameter.

The external prime-distribution theorem, inherited enlarged-support argument,
interval and FFT error analysis, implementation, and IEEE arithmetic model
remain dependencies. Independent integer code is not independent expert review
of the entire analytic proof. No H1 improvement, new distribution exponent,
asymptotic improvement, global tuple optimality, or priority claim is made.
