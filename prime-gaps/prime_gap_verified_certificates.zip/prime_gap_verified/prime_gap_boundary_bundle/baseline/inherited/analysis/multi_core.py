"""Interval transforms of additive power-sum moments.
All inputs are exact binary64 values. No exploratory evaluator is used.
"""
from flint import arb,acb

def single_moments(S,jmax,kind='zero',value=0):
 c,b,T,A,m2=(S[x] for x in ('c','b','T','A','m2'));u=c+b*T
 if kind=='zero':
  J=[(u/c).log()/b];K=[(1/c-1/u)/b];P=[T**(j+1)/(j+1) for j in range(jmax+1)]
 else:
  if kind=='fourier':
   xi=value;a=xi/b;z=acb(0,xi);end=(z*T).exp()
   E=acb(0,-a*c).expint(1)-acb(0,-a*u).expint(1)
   J=[acb(0,-a*c).exp()*E/b];K=[(acb(1/c)-end/u)/b+z/b*J[0]]
  else:
   z=arb(value);a=z/b;end=(z*T).exp()
   E=(a*u).ei()-(a*c).ei();J=[(-a*c).exp()*E/b];K=[(1/c-end/u)/b+z/b*J[0]]
  P=[(end-1)/z]
  for j in range(1,jmax+1):P.append(end*T**j/z-j*P[-1]/z)
 for j in range(1,jmax+1):
  J.append(P[j-1]/b-c/b*J[-1]);K.append(J[j-1]/b-c/b*K[-1])
 return [(K[j]+2*A*J[j]+A*A*P[j])/(m2*T**j) for j in range(jmax+1)]

def weights(n,mu,powers):
 ps=[0]+list(powers);ph=mu[0];phn=ph**n;ph1=ph**(n-1);ph2=ph**(n-2)
 out=[]
 for a in range(len(ps)):
  for b in range(a,len(ps)):
   if b==0:v=phn
   elif a==0:v=n*mu[ps[b]]*ph1
   else:v=n*mu[ps[a]+ps[b]]*ph1+n*(n-1)*mu[ps[a]]*mu[ps[b]]*ph2
   out.append(v)
 return out
