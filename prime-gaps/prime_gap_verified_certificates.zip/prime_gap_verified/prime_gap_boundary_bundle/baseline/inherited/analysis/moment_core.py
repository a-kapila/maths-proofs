"""Interval transforms for the nonnegative measures weighted by Z and Z^2.
Z=sum (X_i/T)^2, X has density (1/(c+b*t)+A)^2 / m2.
The scalar backend is the explicitly bounded mpmath.iv compatibility layer.
"""
from flint import arb,acb,ctx
from shifted_core import setup

def zero_moments(S):
 c,b,T,A,m2=(S[x] for x in ('c','b','T','A','m2'));u=c+b*T
 J=[(u/c).log()/b];K=[(1/c-1/u)/b];P=[T**(j+1)/(j+1) for j in range(5)]
 for j in range(1,5):
  J.append(P[j-1]/b-c/b*J[-1]);K.append(J[j-1]/b-c/b*K[-1])
 return [(K[j]+2*A*J[j]+A*A*P[j])/(m2*T**j) for j in (0,2,4)]

def frequency_moments(xi,S):
 c,b,T,A,m2=(S[x] for x in ('c','b','T','A','m2'));u=c+b*T;a=xi/b;iz=acb(0,xi);end=(iz*T).exp()
 E=acb(0,-a*c).expint(1)-acb(0,-a*u).expint(1)
 J=[acb(0,-a*c).exp()*E/b];K=[(acb(1/c)-end/u)/b+iz/b*J[0]];P=[(end-1)/iz]
 for j in range(1,5):
  P.append(end*T**j/iz-j*P[-1]/iz)
  J.append(P[j-1]/b-c/b*J[-1]);K.append(J[j-1]/b-c/b*K[-1])
 return [(K[j]+2*A*J[j]+A*A*P[j])/(m2*T**j) for j in (0,2,4)]

def positive_moments(lam,S):
 c,b,T,A,m2=(S[x] for x in ('c','b','T','A','m2'));u=c+b*T;lam=arb(lam);a=lam/b;end=(lam*T).exp()
 E=(a*u).ei()-(a*c).ei();J=[(-a*c).exp()*E/b];K=[(1/c-end/u)/b+lam/b*J[0]];P=[(end-1)/lam]
 for j in range(1,5):
  P.append(end*T**j/lam-j*P[-1]/lam)
  J.append(P[j-1]/b-c/b*J[-1]);K.append(J[j-1]/b-c/b*K[-1])
 return [(K[j]+2*A*J[j]+A*A*P[j])/(m2*T**j) for j in (0,2,4)]
