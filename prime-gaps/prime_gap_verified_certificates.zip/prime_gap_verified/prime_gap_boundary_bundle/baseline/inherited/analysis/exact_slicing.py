"""Derive smaller sieve dimensions from certified endpoints using exact fractions."""
from pathlib import Path
from fractions import Fraction as F
import json, sys

def check(trial):
 p=Path(trial);d=json.loads(p.read_text());c=json.loads(p.with_suffix('.interval_certificate.json').read_text())
 k,m=d['k'],d['m'];rho=F(1,4)+F(d['omega']);q=F(c['Q_lower'])-F(c['restriction']['loss_upper'])
 assert q>0 and F(240)*F(d['omega'])+80*F(d['smooth_delta'])<3
 eps=F(d['delta'])*d['eps_cells'];assert 2*rho*(1+eps)<1
 K=(F(k*m)/(rho*q)).numerator//(F(k*m)/(rho*q)).denominator+1
 assert K<=k
 margin=F(K,k)*q-F(m)/rho
 assert margin>0 and F(K-1,k)*q<=F(m)/rho
 return dict(m=m,trial_k=k,final_K=K,removed=k-K,margin_float=float(margin),margin_exact=str(margin),corrected_q_exact=str(q),rho_exact=str(rho),verified=True)
if __name__=='__main__':
 paths=sys.argv[1:] or [f'm{m}.json' for m in (2,3,4,5)]
 result=[check(p) for p in paths]
 print(json.dumps(result,indent=2))
