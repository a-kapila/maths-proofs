"""Signed Abel-summation diagnostics against exact rational arithmetic."""
from fractions import Fraction as F
from pathlib import Path
import json
import numpy as np
from certify_lifted import integrate_bound
rng=np.random.default_rng(20261103)
for test in range(300):
    n=int(rng.integers(2,100))
    weights=rng.integers(0,1000,size=n,dtype=np.int64)
    # Dyadic weights and coefficients have exact binary64 representations.
    C=np.r_[0,np.cumsum(weights)]/2**20
    c=rng.integers(-100000,100001,size=n,dtype=np.int64)/2**17
    truth=sum((F(float(c[j]))*(F(float(C[j+1]))-F(float(C[j]))) for j in range(n)),F(0))
    L=np.maximum(0,np.nextafter(C,-np.inf));U=np.nextafter(C,np.inf)
    low=integrate_bound(c,L,U,-1);high=integrate_bound(c,L,U,1)
    assert F(low)<=truth<=F(high),(test,low,truth,high)
result=dict(tests=300,passed=True,method='exact Fraction reference; signed random coefficients')
(Path(__file__).resolve().parents[1]/'verification'/'abel_tests.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
