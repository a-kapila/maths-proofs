"""Certify a signed correlated trial H=psi0(S)+psi1(S)Z, Z=sum(t_i/T)^2.
Positive weighted CDF measures permit signed-coefficient Abel summation.
Every tabulation and integration step is outward-bounded. Exploratory
quadrature is not imported by this program.
"""
from pathlib import Path
import json,sys,time,math
import numpy as np
from flint import arb,ctx
from shifted_core import setup
from moment_cdf import MomentCDF
from hcert_shifted import gtable
from loss_shifted import restriction_loss
U=2**-53
D=lambda x:np.nextafter(x,-np.inf)
H=lambda x:np.nextafter(x,np.inf)
def const(x):return (float(D(float(x.lower()))),float(H(float(x.upper()))))
def add(a,b):return D(a[0]+b[0]),H(a[1]+b[1])
def sub(a,b):return D(a[0]-b[1]),H(a[1]-b[0])
def mul(a,b):
 z=[a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]]
 return D(np.minimum.reduce(z)),H(np.maximum.reduce(z))
def square(a):
 lo=np.where((a[0]<=0)&(a[1]>=0),0.,np.minimum(a[0]*a[0],a[1]*a[1]));hi=np.maximum(a[0]*a[0],a[1]*a[1])
 return np.maximum(0,D(lo)),H(hi)
def inv(a):assert np.all(np.asarray(a[0])>0);return D(1/a[1]),H(1/a[0])
def scale(a,x):return mul(a,(x,x))

def outward_sum(a,direction):
 """Any binary64 addition tree has error <= gamma_(N+1) sum(abs(a))."""
 a=np.asarray(a);n=a.size+2;assert n*U<1e-4
 total=np.sum(a,dtype=np.float64);absum=np.sum(abs(a),dtype=np.float64)
 err=2*n*U/(1-n*U)*absum*(1+1e-10)+1e-290
 return float(D(total-err)) if direction<0 else float(H(total+err))

def integrate_bound(c,L,V,direction):
 """Abel sum of exact binary64 cell coefficients against positive measure."""
 c=np.asarray(c);d=c[:-1]-c[1:];d=D(d) if direction<0 else H(d)
 co=np.r_[-c[0],d,c[-1]]
 if direction<0:terms=D(co*np.where(co>=0,L,V))
 else:terms=H(co*np.where(co>=0,V,L))
 return outward_sum(terms,direction)

def make_tables(d,cdf):
 k=d['k'];spacing=d['delta'];nmax=math.ceil(cdf.Tf/spacing)+2
 glo,ghi,m2,GT=gtable(k,d['theta'],d['beta'],nmax,DELTA=spacing,relative_shift=d['relative_shift'])
 S=setup(k,d['theta'],d['beta'],d['relative_shift']);c,b,T,A=(const(S[x]) for x in ('c','b','T','A'))
 w0=np.arange(nmax+1)*spacing;w=(np.minimum(w0,T[0]),np.minimum(w0,T[1]));w2=square(w);w3=mul(w2,w)
 J0=sub((glo,ghi),mul(A,w));ib=inv(b);cb=mul(c,ib)
 J2=add(sub(scale(mul(w2,ib),.5),mul(mul(cb,ib),w)),mul(square(cb),J0))
 # Enclose the exact rational 1/3, not its nearest binary64 approximation.
 third=const(arb(1)/3)
 G2=mul(add(J2,mul(mul(A,w3),third)),inv(square(T)))
 G2=(np.maximum(0,G2[0]),np.maximum(0,G2[1]));G2[0][0]=0.;G2[1][0]=0.
 return [(glo,ghi),G2],m2,S

def profile_bounds(h,tab,E,I):
 lo,hi=tab;nmax=len(lo)-1
 def lookup(a,ix):return np.where(ix<0,0.,a[np.clip(ix,0,nmax)])
 al=np.zeros(len(I));au=np.zeros(len(I));absl=np.zeros(len(I));absu=np.zeros(len(I))
 coeff=np.r_[h[:-1]-h[1:],h[-1]]
 for j,z in enumerate(coeff):
  if z==0:continue
  edge=E[j+1]
  if z>0:vl=z*lookup(lo,edge-I-1);vu=z*lookup(hi,edge-I)
  else:vl=z*lookup(hi,edge-I);vu=z*lookup(lo,edge-I-1)
  al+=vl;au+=vu;absl+=abs(vl);absu+=abs(vu)
 fac=4*(len(h)+3)*U*(1+1e-10)
 return D(al-fac*absl-1e-290),H(au+fac*absu+1e-290)

def run(path):
 d=json.loads(Path(path).read_text());t=time.time();ctx.prec=256;k=d['k'];m=d['m'];eps=d['delta']*d['eps_cells']
 E=np.asarray(d['E'],dtype=np.int64);h0=np.asarray(d['h0'],float);h1=np.asarray(d['h1'],float);spacing=d['delta'];one=round(1/spacing)
 assert E[0]==0 and E[-1]==one+d['eps_cells'] and np.all(np.diff(E)>0)
 for h in (h0,h1):assert len(h)==len(E)-1 and np.max(abs(h))<=1 and np.all(h*2**40==np.round(h*2**40))
 cdf=MomentCDF(k,d['theta'],d['beta'],d['relative_shift'],DELTA=spacing,P=d.get('period',8.))
 tabs,m2,S=make_tables(d,cdf)
 print(json.dumps(dict(stage='antiderivative_tables',seconds=time.time()-t)),flush=True)
 den_coeff=[square((h0,h0)),scale(mul((h0,h0),(h1,h1)),2.),square((h1,h1))]
 denlo=arb(0);denhi=arb(0)
 for r,co in enumerate(den_coeff):
  L,V=cdf.bounds(k,r,E*spacing)
  denlo+=arb(integrate_bound(co[0],L,V,-1));denhi+=arb(integrate_bound(co[1],L,V,1))
 dl=float(D(float(denlo.lower())));dh=float(H(float(denhi.upper())));assert dl>0
 ilo=int(E[1]);itop=one-d['eps_cells'];I=np.arange(ilo,itop,dtype=np.int64)
 # Dropping complete nonnegative square mass below ilo is safe.
 A0=add(profile_bounds(h0,tabs[0],E,I),profile_bounds(h1,tabs[1],E,I));A1=profile_bounds(h1,tabs[0],E,I)
 numcoeff=[square(A0)[0],scale(mul(A0,A1),2.)[0],square(A1)[0]]
 num=arb(0);points=np.arange(ilo,itop+1)*spacing;components=[]
 for r,co in enumerate(numcoeff):
  L,V=cdf.bounds(k-1,r,points);value=integrate_bound(co,L,V,-1);components.append(value);num+=arb(value)
 nl=float(D(float(num.lower())));assert nl>0
 q=arb(k)/m2*arb(nl)/arb(dh);ql=float(D(float(q.lower())))
 ctx.prec=256;C=arb(0)
 for j,(a,b) in enumerate(zip(h0,h1)):
  z=arb(int(E[j+1]))*arb(spacing)/S['T']
  for v in (arb(a).abs_upper(),(arb(a)+arb(b)*z).abs_upper()):
   if v>C:C=v
 Cup=float(H(float(C.upper())));scaled_den=float(D(float((arb(dl)/arb(Cup)**2).lower())))
 print(json.dumps(dict(stage='quotient',k=k,Q_lower=ql,den_lower=dl,den_upper=dh,num_lower=nl,num_components=components,amplitude_upper=Cup,seconds=time.time()-t)),flush=True)
 rc=restriction_loss(k,d['theta'],d['beta'],d['smooth_delta'],d['omega'],scaled_den,ufrac=d['ufrac'],sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=(1-eps if d.get('use_inner_cap_loss',False) else None))
 target=arb(m)/(arb(1)/4+arb(d['omega']));tu=float(H(float(target.upper())));margin=float(D(float((arb(ql)-arb(rc['loss_upper'])-arb(tu)).lower())))
 assert 240*arb(d['omega'])+80*arb(d['smooth_delta'])<3
 assert 2*(arb(1)/4+arb(d['omega']))*(1+arb(eps))<1
 out=dict(m=m,k=k,trial=str(path),Q_lower=ql,restriction=rc,target_upper=tu,margin_lower=margin,epsilon=eps,den_lower=dl,den_upper=dh,num_lower=nl,num_components_lower=components,amplitude_upper=Cup,scaled_den_lower=scaled_den,cdf=dict(J=cdf.J,N=cdf.N,error={str(key):v for key,v in cdf.error.items()},alias={str(key):v for key,v in cdf.alias.items()},series_tail={str(key):v for key,v in cdf.tail.items()}),elapsed=time.time()-t,backend='mpmath.iv bounded E1/Ei, bounded FFT, directed binary64 Abel sums')
 from direct_fourier_check import check
 checks=check(cdf);out['direct_fourier_checks']=checks
 Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True);return out
if __name__=='__main__':
 for p in sys.argv[1:]:run(p)
