"""Compatibility subset using mpmath interval arithmetic (not FLINT).

Only the scalar interval operations needed by the retained certificate code
are implemented. E1/Ei use explicit convergent-series or integral-remainder
bounds. No polynomial routines are implemented or used.
"""
import math
from mpmath import iv, mp
from mpmath.libmp import mpf_add, mpf_shift

class Context:
    @property
    def prec(self): return iv.prec
    @prec.setter
    def prec(self,p): iv.prec=int(p)
ctx=Context(); ctx.prec=256

def point(t): return iv.make_mpf((t,t))
def unwrap(x):
    if isinstance(x,arb):return x.x
    if isinstance(x,acb):return x.x
    if hasattr(x,'item'): x=x.item()
    return x

def mid_iv(x):
    a,b=x._mpi_; m=mpf_shift(mpf_add(a,b,iv.prec,'n'),-1)
    return point(m)

def real_e1_point(x):
    """E1(x) for a positive, point interval; explicit integral tail."""
    assert x.a>0
    if x.a>=128:
        term=1/x; total=term; N=128
        for j in range(1,N): term=term*(-j)/x; total+=term
        err=iv.mpf(math.factorial(N))/x**(N+1)
        return iv.exp(-x)*(total+iv.mpf([-1,1])*err.b)
    term=iv.mpf(1); total=iv.mpf(0); tol=iv.mpf(2)**-250
    for n in range(1,2000):
        term*=(-x)/n; total+=term/n
        ratio=x/(n+2)
        if ratio.b<iv.mpf('0.5'):
            err=abs(term)*x/((n+1)**2)/(1-ratio)
            if err.b<tol:
                return -iv.euler-iv.log(x)-total+iv.mpf([-1,1])*err.b
    raise ArithmeticError('E1 series not converged')

def imag_e1_point(x):
    """E1(-i*x), x>0, on the principal branch.
    For x>=128 use e^(ix) int_0^infty e^-t/(t-ix) dt, expanding
    1/(t-ix); remainder <= N!/x^(N+1). Otherwise use its entire series.
    """
    assert x.a>0
    if x.a>=128:
        term=iv.mpc(0,1)/x; total=term; N=128
        for j in range(1,N):term*=iv.mpc(0,-j)/x;total+=term
        err=iv.mpf(math.factorial(N))/x**(N+1)
        v=iv.exp(iv.mpc(0,1)*x)*total
        return v+iv.mpc(iv.mpf([-1,1])*err.b,iv.mpf([-1,1])*err.b)
    term=iv.mpc(1);total=iv.mpc(0);tol=iv.mpf(2)**-250
    for n in range(1,2000):
        term*=iv.mpc(0,1)*x/n;total+=term/n
        ratio=x/(n+2)
        if ratio.b<iv.mpf('0.5'):
            err=abs(term)*x/((n+1)**2)/(1-ratio)
            if err.b<tol:
                v=iv.mpc(-iv.euler-iv.log(x),iv.pi/2)-total
                return v+iv.mpc(iv.mpf([-1,1])*err.b,iv.mpf([-1,1])*err.b)
    raise ArithmeticError('imag E1 series not converged')

def widen_real_arg(fun,x,deriv_bound):
    old=iv.prec
    try:
        iv.prec=max(512,old)
        m=mid_iv(x); rad=max(abs(m-x.a).b,abs(x.b-m).b)
        y=fun(m); err=(deriv_bound(x)*rad).b
        return y+iv.mpf([-1,1])*err
    finally:iv.prec=old

class arb:
    __slots__=('x',)
    def __init__(self,a=0): self.x=iv.mpf(unwrap(a))
    @classmethod
    def raw(cls,x):a=object.__new__(cls);a.x=x;return a
    def __add__(self,b):return arb.raw(self.x+unwrap(b))
    __radd__=__add__
    def __sub__(self,b):return arb.raw(self.x-unwrap(b))
    def __rsub__(self,b):return arb.raw(unwrap(b)-self.x)
    def __mul__(self,b):return arb.raw(self.x*unwrap(b))
    __rmul__=__mul__
    def __truediv__(self,b):return arb.raw(self.x/unwrap(b))
    def __rtruediv__(self,b):return arb.raw(unwrap(b)/self.x)
    def __pow__(self,b):return arb.raw(self.x**unwrap(b))
    def __neg__(self):return arb.raw(-self.x)
    def __abs__(self):return arb.raw(abs(self.x))
    def __float__(self):return float(mid_iv(self.x))
    def __lt__(self,b):return bool(self.x.b<iv.mpf(unwrap(b)).a)
    def __le__(self,b):return bool(self.x.b<=iv.mpf(unwrap(b)).a)
    def __gt__(self,b):return bool(self.x.a>iv.mpf(unwrap(b)).b)
    def __ge__(self,b):return bool(self.x.a>=iv.mpf(unwrap(b)).b)
    def __eq__(self,b):
        try:return self.x._mpi_==iv.mpf(unwrap(b))._mpi_
        except:return False
    def __repr__(self):return str(self.x)
    def lower(self):return arb.raw(self.x.a)
    def upper(self):return arb.raw(self.x.b)
    def mid(self):return arb.raw(mid_iv(self.x))
    def rad(self):
        m=mid_iv(self.x);return arb.raw(max((m-self.x.a).b,(self.x.b-m).b))
    def abs_upper(self):return arb.raw(abs(self.x).b)
    def sqrt(self):return arb.raw(iv.sqrt(self.x))
    def log(self):return arb.raw(iv.log(self.x))
    def exp(self):return arb.raw(iv.exp(self.x))
    def sin_cos(self):return arb.raw(iv.sin(self.x)),arb.raw(iv.cos(self.x))
    def union(self,b):
        y=iv.mpf(unwrap(b));return arb.raw(iv.mpf([min(self.x.a,y.a),max(self.x.b,y.b)]))
    def is_finite(self):return all(mp.isfinite(mp.make_mpf(t)) for t in self.x._mpi_)
    def expint(self,n):
        assert n==1
        assert self.x.a>0
        return arb.raw(widen_real_arg(real_e1_point,self.x,lambda x:iv.exp(-x.a)/x.a))
    def ei(self):
        x=self.x
        if x.b<0:return -(-self).expint(1)
        assert x.a>0
        def fun(y):
            term=iv.mpf(1);total=iv.mpf(0)
            for n in range(1,2000):
                term*=y/n;total+=term/n
                ratio=y/(n+2)
                if ratio.b<iv.mpf('0.5'):
                    err=abs(term)*y/((n+1)**2)/(1-ratio)
                    if err.b<iv.mpf(2)**-250:return iv.euler+iv.log(y)+total+iv.mpf([-1,1])*err.b
            raise ArithmeticError('Ei series')
        return arb.raw(widen_real_arg(fun,x,lambda z:iv.exp(z.b)/z.a))
    @staticmethod
    def pi():return arb.raw(+iv.pi)

class acb:
    __slots__=('x',)
    def __init__(self,a=0,b=None):
        u=unwrap(a)
        self.x=(u if hasattr(u,"_mpci_") else iv.mpc(u)) if b is None else iv.mpc(u,unwrap(b))
    @classmethod
    def raw(cls,x):a=object.__new__(cls);a.x=x;return a
    @property
    def real(self):return arb.raw(self.x.real)
    @property
    def imag(self):return arb.raw(self.x.imag)
    def __add__(self,b):return acb.raw(self.x+unwrap(b))
    __radd__=__add__
    def __sub__(self,b):return acb.raw(self.x-unwrap(b))
    def __rsub__(self,b):return acb.raw(unwrap(b)-self.x)
    def __mul__(self,b):return acb.raw(self.x*unwrap(b))
    __rmul__=__mul__
    def __truediv__(self,b):return acb.raw(self.x/unwrap(b))
    def __rtruediv__(self,b):return acb.raw(unwrap(b)/self.x)
    def __pow__(self,n):return acb.raw(self.x**int(n))
    def __neg__(self):return acb.raw(-self.x)
    def exp(self):return acb.raw(iv.exp(self.x))
    def is_finite(self):return self.real.is_finite() and self.imag.is_finite()
    def abs_upper(self):return arb.raw(abs(self.x).b)
    def expint(self,n):
        assert n==1
        if self.imag==0:return acb(self.real.expint(1))
        assert self.real==0 and self.imag<0
        x=-self.x.imag;old=iv.prec
        try:
            iv.prec=max(512,old)
            m=mid_iv(x);rad=max((m-x.a).b,(x.b-m).b)
            v=imag_e1_point(m);err=(rad/x.a).b
            return acb.raw(v+iv.mpc(iv.mpf([-1,1])*err,iv.mpf([-1,1])*err))
        finally:iv.prec=old
    def __repr__(self):return str(self.x)
