"""Independent high-precision diagnostics, not replacements for interval bounds."""
import json,math,random,time
from pathlib import Path
import mpmath as mp
from multi_core import single_moments,weights
from shifted_core import setup
from flint import ctx,arb
from rc_loss_rig import kl_tail
ctx.prec=256;mp.mp.dps=85
out=[];start=time.time()
for m in (3,4,5):
 d=json.loads((Path(__file__).resolve().parent / f'm{m}.json').read_text());k=d['k'];th=mp.mpf(d['theta']);be=mp.mpf(d['beta']);rel=mp.mpf(d['relative_shift'])
 c=th/mp.log(k);T=be/mp.log(k);b=mp.mpf(k-1);A=rel/(c+b*T);g=lambda t:1/(c+b*t)+A
 cuts=[mp.mpf(0),c/b,10*c/b,mp.sqrt(c*T/b),T];cuts=sorted(set(x for x in cuts if 0<=x<=T))
 norm=mp.quad(lambda t:g(t)**2,cuts);S=setup(k,d['theta'],d['beta'],d['relative_shift'])
 for kind,val in [('zero',0),('fourier',13),('positive',7)]:
  got=single_moments(S,8,kind,arb(val));z=0 if kind=='zero' else (mp.j*val if kind=='fourier' else mp.mpf(val))
  for j,v in enumerate(got):
   target=mp.quad(lambda t:(t/T)**j*g(t)**2*mp.exp(z*t),cuts)/norm
   # The compatibility classes expose an interval midpoint convertible through str.
   if kind=='fourier':approx=mp.mpc(mp.make_mpf(v.real.mid().x._mpi_[0]),mp.make_mpf(v.imag.mid().x._mpi_[0]))
   else:approx=mp.make_mpf(v.mid().x._mpi_[0])
   err=abs(target-approx);assert err<mp.mpf('1e-55'),(m,kind,j,err)
   out.append(dict(m=m,kind=kind,j=j,error=mp.nstr(err,12)))
# Check the probability bound on exactly summable two-point distributions.
rng=random.Random(2309);max_slack=0
for i in range(300):
 K=rng.randint(2,35);r=rng.randint(1,K);p=rng.uniform(.01,.9);x=rng.uniform(.001,.4);B=rng.uniform(.001,K*x);lam=10**rng.uniform(-2,2)
 pp=mp.mpf(p);dd=(1-pp)*mp.exp(-mp.mpf(lam)*x);tilt=pp/(pp+dd)
 exact=sum(mp.binomial(K,n)*pp**n*(1-pp)**(K-n) for n in range(r,K+1) if (K-n)*x<B)
 bound=mp.exp(mp.mpf(lam)*B)*(pp+dd)**K*sum(mp.binomial(K,n)*tilt**n*(1-tilt)**(K-n) for n in range(r,K+1))
 assert bound+mp.mpf('1e-65')>=exact
 max_slack=max(max_slack,float(bound-exact))
result=dict(moment_quadrature_checks=out,joint_probability_checks=300,elapsed=time.time()-start,passed=True)
(Path(__file__).resolve().parents[1]/'verification'/'new_math_checks.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(moment_checks=len(out),probability_checks=300,passed=True,seconds=time.time()-start)),flush=True)
