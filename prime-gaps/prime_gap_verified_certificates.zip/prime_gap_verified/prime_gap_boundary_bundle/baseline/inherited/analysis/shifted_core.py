"""Exact one-coordinate formulas for g(t)=1/(c+bt)+A on [0,T].
A = r/(c+bT); all input binary64 values are interpreted exactly.
The scalar backend is mpmath.iv with explicitly bounded E1/Ei evaluations.
"""
from flint import arb,acb,ctx

def setup(k,theta,beta,relative_shift=0.):
 kk=arb(k);L=kk.log();c=arb(theta)/L;T=arb(beta)/L;b=kk-1
 A=arb(relative_shift)/(c+b*T)
 assert A>=0
 def integral2(w):
  u=c+b*w
  return (1/c-1/u)/b+2*A*(u/c).log()/b+A*A*w
 m2=integral2(T)
 I1=(((c+b*T)/c).log()+c/(c+b*T)-1)/b**2
 I1+=2*A*(T/b-c*((c+b*T)/c).log()/b**2)+A*A*T*T/2
 F=lambda w:integral2(w)/m2
 f=lambda w:(1/(c+b*w)+A)**2/m2
 G=lambda w:(1+b*w/c).log()/b+A*w
 return dict(k=k,c=c,T=T,b=b,A=A,m2=m2,mu=I1/m2,F=F,f=f,G=G)

def make_phi(k,theta,beta,relative_shift=0.):
 cache={}
 def consts():
  if ctx.prec not in cache:cache[ctx.prec]=setup(k,theta,beta,relative_shift)
  return cache[ctx.prec]
 def raw(xi):
  S=consts();c,T,b,A,m2=(S[x] for x in ('c','T','b','A','m2'))
  a=xi/b;u=c+b*T;imag=acb(0,1)
  E=(acb(0,-1)*a*c).expint(1)-(acb(0,-1)*a*u).expint(1)
  pref=(-imag*a*c).exp()/b
  fm2=pref*((imag*a*c).exp()/c-(imag*a*u).exp()/u+imag*a*E)
  fm1=pref*E
  f0=((imag*xi*T).exp()-1)/(imag*xi)
  return (fm2+2*A*fm1+A*A*f0)/m2
 def phi(xi,analytic=False,tol=1e-40):
  assert not analytic
  old=ctx.prec
  try:
   for p in (old,2*old,4*old,8*old):
    ctx.prec=p;z=raw(acb(xi))
    if z.is_finite() and float(z.real.rad())<tol and float(z.imag.rad())<tol:return z
   raise ArithmeticError('Characteristic function enclosure too wide')
  finally:ctx.prec=old
 return phi,consts()

def mgf_positive(lam,S):
 """E exp(lam X), lam>0."""
 c,b,T,A,m2=(S[x] for x in ('c','b','T','A','m2'));lam=arb(lam);a=lam/b;u=c+b*T
 ei_diff=(a*u).ei()-(a*c).ei()
 fm2=(-a*c).exp()*(-(a*u).exp()/u+(a*c).exp()/c+a*ei_diff)/b
 fm1=(-a*c).exp()*ei_diff/b
 f0=((lam*T).exp()-1)/lam
 return (fm2+2*A*fm1+A*A*f0)/m2

def mgf_negative(lam,c,b,w,A):
 """Integral_0^w exp(-lam t) g(t)^2 dt, lam>0."""
 a=lam/b;u=c+b*w
 ed=(a*c).expint(1)-(a*u).expint(1)
 fm1=(a*c).exp()*ed/b
 fm2=(1/c-(-lam*w).exp()/u-a*(a*c).exp()*ed)/b
 f0=(1-(-lam*w).exp())/lam
 return fm2+2*A*fm1+A*A*f0
