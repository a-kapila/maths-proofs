"""Interval-certified CDFs using Fourier periodization and a custom radix-2 FFT.

No binary64 trigonometric calls are used. Characteristic functions and
twiddle-factor block bases are evaluated by interval arithmetic; FFT butterflies use only IEEE binary64
addition and multiplication with an explicit forward-error bound.

For S_n >= 0, its P-periodic density has integrated CDF C_P(y) satisfying
0 <= C_P(y)-P(S_n<=y) <= P(S_n>=P), 0<=y<P. The alias tail is bounded by
Chernoff with an interval evaluation of the exact moment-generating function.
The omitted Fourier-series tail is bounded on integer-frequency cells by
Lipschitz and decreasing-density envelopes, then a power-law integral.

Import CDF and pass it to the original hcert.hcert(...,cdf=cdf).
Original source dependencies are phi.py and fcert.py, unmodified.
"""
import math
import os
import sys
import time
import json
import numpy as np
from flint import arb, acb, ctx

from shifted_core import make_phi, setup, mgf_positive

U = 2.0 ** -53
_TWIDDLES = {}
_PERM = {}


def upper(x):
    """Outward binary64 upper bound, including conversion rounding."""
    return float(np.nextafter(float(x.upper()), np.inf))


def twiddles(N):
    """Block-recurrence twiddles: complex absolute error <4096u.

    Exact interval sine/cosine base every 256 entries; intermediate powers
    use at most 255 IEEE complex multiplies. A multiply's absolute error
    is <=8u times the product of operand magnitudes. With base conversion,
    step conversion and final multiplication, 4096u is conservative.
    """
    if N in _TWIDDLES:return _TWIDDLES[N]
    old=ctx.prec;ctx.prec=256
    try:
        block=256
        step=-2*arb.pi()/N
        sn,cs=step.sin_cos()
        z=complex(float(cs.mid()),float(sn.mid()))
        powers=np.ones(block,dtype=np.complex128)
        for j in range(1,block):powers[j]=powers[j-1]*z
        bases=[]
        for j in range(0,N//2,block):
            sn,cs=(step*j).sin_cos()
            assert sn.rad()<arb(2)**-150 and cs.rad()<arb(2)**-150
            bases.append(complex(float(cs.mid()),float(sn.mid())))
        out=(np.asarray(bases)[:,None]*powers[None,:]).ravel()[:N//2]
        _TWIDDLES[N]=out
        return out
    finally:ctx.prec=old


def bit_reverse(N):
    if N in _PERM:
        return _PERM[N]
    bits = N.bit_length() - 1
    a = np.arange(N, dtype=np.uint32 if N <= 2**32 else np.uint64)
    b = np.zeros(N, dtype=a.dtype)
    for _ in range(bits):
        b = (b << 1) | (a & 1)
        a >>= 1
    _PERM[N] = b
    return b


def fft_rounded(values):
    """Unnormalized FFT with natural output order and documented butterflies."""
    N = len(values)
    assert N >= 2 and N & (N-1) == 0
    w = twiddles(N)
    # Advanced indexing already creates a private copy. Process disjoint
    # butterflies in small blocks: same operations and twiddles, lower RAM.
    a = np.asarray(values, dtype=np.complex128)[bit_reverse(N)]
    length = 2
    chunk = 1 << 18
    while length <= N:
        half = length // 2
        blocks = a.reshape(-1, length)
        cols = min(half, chunk)
        rows = max(1, chunk // cols)
        for r in range(0, len(blocks), rows):
            for j in range(0, half, cols):
                end = min(half, j + cols)
                left = blocks[r:r+rows, j:end].copy()
                right = (blocks[r:r+rows, half+j:half+end]
                         * w[j*(N//length):end*(N//length):N//length][None, :])
                blocks[r:r+rows, j:end] = left + right
                blocks[r:r+rows, half+j:half+end] = left - right
        length *= 2
    return a


class CDF:
    def __init__(self, k, theta, beta, ns, DELTA=2.0**-18, P=8.0,
                 ymax=2.0, J=None, verbose=True, relative_shift=0.):
        t0 = time.time()
        ctx.prec = 256
        self.k, self.theta, self.beta = int(k), float(theta), float(beta)
        self.ns = tuple(int(n) for n in ns)
        self.DELTA = float(DELTA)
        self.P = float(P)
        self.N = int(round(P / DELTA))
        assert self.N >= 2 and self.N & (self.N - 1) == 0
        assert self.N * self.DELTA == self.P
        assert 0 < ymax < P
        self.ymax = ymax
        self.imax = min(self.N-1, int(math.ceil(ymax/DELTA)))
        self.verbose = verbose
        self.S = setup(k, theta, beta, relative_shift)
        self.Tf = float(self.S["T"].mid())
        self.phi, _ = make_phi(k, theta, beta, relative_shift)
        self.freq = 2 * arb.pi() / arb(P)
        nmin = min(self.ns)
        if J is None:
            J = 128
            while True:
                z = self.phi(acb(self.freq * J))
                if z.abs_upper() < 1 and nmin * z.abs_upper().log() < -140:
                    break
                J = int(J * 1.25) + 1
                if J >= self.N // 2:
                    raise ArithmeticError("Frequency grid too short")
        self.J = int(J)
        assert self.J < self.N // 2
        self.Xi1 = float((self.freq*self.J).mid())
        self.coeffs = {n: np.empty(self.J, dtype=np.complex128) for n in self.ns}
        constants = {n: arb(0) for n in self.ns}
        norms = {n: arb(0) for n in self.ns}
        errors = {n: arb(0) for n in self.ns}
        for j in range(1, self.J+1):
            ph = self.phi(acb(self.freq*j))
            for n in self.ns:
                z = ph**n / acb(0, 2*arb.pi()*j)
                zr, zi = float(z.real.mid()), float(z.imag.mid())
                self.coeffs[n][j-1] = complex(zr, zi)
                constants[n] += 2*z.real
                norms[n] += 2*z.abs_upper()
                errors[n] += 2*((arb(zr)-z.real).abs_upper()
                                  +(arb(zi)-z.imag).abs_upper())
        self.const = {n: float(constants[n].mid()) for n in self.ns}
        self.const_err = {n: upper((arb(self.const[n])-constants[n]).abs_upper())
                          for n in self.ns}
        self.norm = {n: upper(norms[n]) for n in self.ns}
        self.input_err = {n: upper(errors[n]) for n in self.ns}
        self.alias = {n: self._alias(n) for n in self.ns}
        self.tail = {n: self._series_tail(n) for n in self.ns}
        self.tables = {}
        self.error = {}
        self.t_setup = time.time()-t0
        if verbose:
            print(json.dumps(dict(method="periodic_cdf",k=k,J=self.J,N=self.N,
                  DELTA=self.DELTA,P=P,Xi1=self.Xi1,alias=self.alias,
                  series_tail=self.tail,setup_seconds=self.t_setup)),flush=True)

    def _mgf(self, lam):
        return mgf_positive(lam, self.S)

    def _alias(self, n):
        """Every candidate is a rigorous bound; search is only for efficiency."""
        best = arb(1)
        best_lam = None
        for lam in range(1, 81):
            mg = self._mgf(lam)
            if not mg.is_finite() or mg.lower() <= 0:
                raise ArithmeticError("Invalid moment-generating-function enclosure")
            candidate = (arb(n)*mg.log()-arb(lam)*arb(self.P)).exp()
            if candidate.upper() < best.upper():
                best, best_lam = candidate, lam
        return upper(best)

    def _series_tail(self, n):
        """Bound (2/pi) sum_{j>J} |phi(2*pi*j/P)|^n / j."""
        S = self.S
        mu,T = S["mu"], S["T"]
        alpha = 4*arb(2).sqrt()
        j = self.J+1
        total = arb(0)
        steps = 0
        # Lipschitz envelope on exact integer-frequency cells.
        while True:
            xi = self.freq*j
            p = self.phi(acb(xi)).abs_upper()
            if p >= 1:
                raise ArithmeticError("Unexpected large characteristic function")
            ratio = (1-p)/(4*mu*self.freq)
            width = max(1,int(math.floor(float(ratio.lower()))))
            end = j+width
            B = p+mu*self.freq*width
            if B > 1:
                B = arb(1)
            H = arb(1)/j + (arb(end)/j).log()
            total += H*B**n
            j = end
            xi = self.freq*j
            a = alpha/xi
            if a <= T:
                Bm = S["F"](a)+2*arb(2).sqrt()*S["f"](a)/xi
                if Bm < 1 and arb(n)*Bm.log() < -160:
                    break
            steps += 1
            if steps > 500000:
                raise ArithmeticError("Lipschitz series tail did not terminate")
        # Decreasing-density envelope on geometric integer cells.
        D = 6*arb(2).sqrt()*S["f"](arb(0))
        for _ in range(200000):
            xi = self.freq*j
            if D/xi < arb(1)/2:
                # sum_{r=j}^infinity r^(-n-1) <= j^(-n-1)+j^(-n)/n.
                total += (D/xi)**n*(arb(1)/j+arb(1)/n)
                return upper(2*total/arb.pi())
            end = max(j+1,(101*j+99)//100)
            xn = self.freq*end
            B = S["F"](alpha/xi)+2*arb(2).sqrt()*S["f"](alpha/xn)/xi
            if B > 1:
                B = arb(1)
            H = arb(1)/j+(arb(end)/j).log()
            total += H*B**n
            j = end
        raise ArithmeticError("Geometric series tail did not terminate")

    def _table(self, n):
        if n in self.tables:
            return
        t0 = time.time()
        z = np.zeros(self.N,dtype=np.complex128)
        z[1:self.J+1] = self.coeffs[n]
        z[-self.J:] = np.conj(self.coeffs[n][::-1])
        result = fft_rounded(z)
        # An l-stage butterfly output depends on at most 2^l initial inputs.
        # Each rounded butterfly differs by <=8192u(|x|+|y|), including <=4096u
        # twiddle error. Induction gives the weighted l1 error bound below.
        stages = self.N.bit_length()-1
        factor = (1+8192*arb(2)**-53)**stages
        ef = (factor-1)*arb(self.norm[n])+factor*arb(self.input_err[n])
        fft_err = upper(ef)
        idx = np.arange(self.imax+1,dtype=np.float64)
        line = idx/self.N  # exact: numerator integer and denominator power of 2
        table = line+self.const[n]-result.real[:self.imax+1]
        combine = upper(16*arb(2)**-53*(arb(self.ymax)/arb(self.P)
                            +2*abs(arb(self.const[n]))+arb(self.norm[n])
                            +arb(fft_err)+1))
        rounding = upper(arb(fft_err)+arb(self.const_err[n])+arb(combine)+arb("1e-290"))
        total_error = upper(arb(rounding)+arb(self.tail[n]))
        self.tables[n] = table
        self.error[n] = total_error
        # Verify the imaginary residual lies within the same justified FFT bound.
        imag_max = float(np.max(np.abs(result.imag)))
        if imag_max > fft_err:
            raise ArithmeticError("FFT imaginary residual exceeds proven bound")
        if self.verbose:
            print(json.dumps(dict(n=n,fft_seconds=time.time()-t0,
                  fft_rounding_bound=fft_err,cdf_symmetric_error=total_error,
                  alias_upper=self.alias[n],imaginary_residual=imag_max)),flush=True)

    def bounds(self, n, ys, chunk=None):
        assert n in self.ns
        ys = np.asarray(ys,dtype=np.float64)
        if np.any(ys<0) or np.any(ys>self.ymax):
            raise ValueError("CDF query outside configured [0,ymax]")
        self._table(n)
        scaled = ys/self.DELTA
        lo = np.floor(scaled).astype(np.int64)
        hi = np.ceil(scaled).astype(np.int64)
        tab = self.tables[n]
        e = self.error[n]
        # Non-lattice inputs are enclosed using monotonicity. Lattice inputs
        # incur only the global roundoff/tail/alias budget.
        le = np.nextafter(e+self.alias[n],np.inf)
        L = np.maximum(0,np.nextafter(tab[lo]-le,-np.inf))
        Uu = np.minimum(1,np.nextafter(tab[hi]+e,np.inf))
        if np.any(L>Uu):
            raise ArithmeticError("Inconsistent CDF interval")
        return L,Uu


if __name__ == "__main__":
    k = int(sys.argv[1]) if len(sys.argv)>1 else 2328
    th = float(sys.argv[2]) if len(sys.argv)>2 else 1.028
    be = float(sys.argv[3]) if len(sys.argv)>3 else 2.85
    C = CDF(k,th,be,(k-1,k))
    ys = np.array([0,.5,.75,1,1.25])
    for n in C.ns:
        L,H=C.bounds(n,ys)
        print(json.dumps(dict(n=n,y=ys.tolist(),lower=L.tolist(),upper=H.tolist())))
