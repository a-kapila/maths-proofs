"""Bitwise comparison of the old and chunked bounded-error butterflies."""
from pathlib import Path
import json
import numpy as np
import periodic_shifted as current
import periodic_shifted_original as original
rng=np.random.default_rng(20261103)
sizes=[2,4,16,256,1024,4096,16384,65536,262144,1048576]
for n in sizes:
 z=rng.normal(size=n)+1j*rng.normal(size=n)
 a=original.fft_rounded(z);b=current.fft_rounded(z)
 assert np.array_equal(a,b),n
out=dict(passed=True,bitwise_equal_lengths=sizes,method='same radix-two butterflies and twiddles, disjoint chunk ordering')
(Path(__file__).resolve().parents[1]/'verification/fft_memory_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
