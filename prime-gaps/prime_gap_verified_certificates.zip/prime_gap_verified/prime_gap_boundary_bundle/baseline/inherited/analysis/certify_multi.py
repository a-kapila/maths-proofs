"""Certify F=(h0(S)+sum h_p(S) Z_p)*product g with bounded numerical errors.
Z_p=sum (t_i/T)^p, p>=2. Products Z_p Z_q are nonnegative measure weights.
"""
from pathlib import Path
import json,sys,time,math
import numpy as np
from flint import arb,ctx
from multi_cdf import MultiCDF
from shifted_core import setup
from hcert_shifted import gtable
from loss_joint import restriction_loss
from certify_lifted import D,H,U,const,add,sub,mul,square,inv,scale,integrate_bound,profile_bounds

def make_tables(d,cdf):
 k=d['k'];spacing=d['delta'];nmax=math.ceil(cdf.Tf/spacing)+2
 glo,ghi,m2,GT=gtable(k,d['theta'],d['beta'],nmax,DELTA=spacing,relative_shift=d['relative_shift'])
 S=setup(k,d['theta'],d['beta'],d['relative_shift']);c,b,T,A=(const(S[x]) for x in ('c','b','T','A'))
 w0=np.arange(nmax+1)*spacing;w=(np.minimum(w0,T[0]),np.minimum(w0,T[1]));wp=w
 ib=inv(b);cb=mul(c,ib);Jcur=sub((glo,ghi),mul(A,w));tabs=[(glo,ghi)];tp=T
 for p in range(1,max(d['powers'])+1):
  Jcur=sub(mul(mul(wp,ib),const(arb(1)/p)),mul(cb,Jcur));wnext=mul(wp,w)
  if p in d['powers']:
   G=mul(add(Jcur,mul(mul(A,wnext),const(arb(1)/(p+1)))),inv(tp))
   G=(np.maximum(0,G[0]),np.maximum(0,G[1]));G[0][0]=0.;G[1][0]=0.;tabs.append(G)
  wp=wnext;tp=mul(tp,T)
 return tabs,m2,S

def amplitude(profiles,powers,E,spacing,S):
 """Since sum x_i=s/T, sum_p h_p sum_i x_i^p is a weighted mean
 of q(x)=sum_p h_p*x^(p-1), multiplied by s/T. Interval evaluation
 on every dyadic subinterval encloses q([0,1]); q(0)=0 is included.
 """
 x=(np.arange(256)/256.,np.arange(1,257)/256.);C=arb(0)
 for j in range(len(profiles[0])):
  q=(np.zeros(256),np.zeros(256));xp=(np.ones(256),np.ones(256));power_map={p:profiles[a+1][j] for a,p in enumerate(powers)}
  for p in range(1,max(powers)):
   xp=mul(xp,x)
   if p+1 in power_map:q=add(q,scale(xp,power_map[p+1]))
  qlo=min(0.,float(np.min(q[0])));qhi=max(0.,float(np.max(q[1])))
  z=arb(int(E[j+1]))*arb(spacing)/S['T'];h=arb(float(profiles[0][j]))
  for v in (h+z*arb(qlo),h+z*arb(qhi)):
   v=v.abs_upper()
   if v>C:C=v
 return float(H(float(C.upper())))

def run(path):
 d=json.loads(Path(path).read_text());t=time.time();ctx.prec=256;k=d['k'];m=d['m'];eps=d['delta']*d['eps_cells']
 powers=d['powers'];assert powers==sorted(set(powers)) and min(powers)>=2
 E=np.array(d['E'],dtype=np.int64);hs=[np.array(h,float) for h in d['profiles']];spacing=d['delta'];one=round(1/spacing)
 assert len(hs)==len(powers)+1 and E[0]==0 and E[-1]==one+d['eps_cells'] and np.all(np.diff(E)>0)
 for h in hs:assert len(h)==len(E)-1 and max(abs(h))<=1 and np.all(h*2**40==np.round(h*2**40))
 cdf=MultiCDF(k,d['theta'],d['beta'],d['relative_shift'],powers=powers,DELTA=spacing,P=d.get('period',8.))
 tabs,m2,S=make_tables(d,cdf);pairs=cdf.pairs
 print(json.dumps(dict(stage='antiderivative_tables',seconds=time.time()-t)),flush=True)
 denlo=arb(0);denhi=arb(0)
 for r,(a,b) in enumerate(pairs):
  co=square((hs[a],hs[a])) if a==b else scale(mul((hs[a],hs[a]),(hs[b],hs[b])),2.)
  L,V=cdf.bounds(k,r,E*spacing);denlo+=arb(integrate_bound(co[0],L,V,-1));denhi+=arb(integrate_bound(co[1],L,V,1))
 dl=float(D(float(denlo.lower())));dh=float(H(float(denhi.upper())));assert dl>0
 ilo=int(E[1]);itop=one-d['eps_cells'];I=np.arange(ilo,itop,dtype=np.int64)
 A0=profile_bounds(hs[0],tabs[0],E,I)
 for a in range(1,len(hs)):A0=add(A0,profile_bounds(hs[a],tabs[a],E,I))
 AA=[A0]+[profile_bounds(h,tabs[0],E,I) for h in hs[1:]]
 num=arb(0);points=np.arange(ilo,itop+1)*spacing;components=[]
 for r,(a,b) in enumerate(pairs):
  co=square(AA[a])[0] if a==b else scale(mul(AA[a],AA[b]),2.)[0]
  L,V=cdf.bounds(k-1,r,points);value=integrate_bound(co,L,V,-1);components.append(value);num+=arb(value)
 nl=float(D(float(num.lower())));assert nl>0
 q=arb(k)/m2*arb(nl)/arb(dh);ql=float(D(float(q.lower())))
 Cup=amplitude(hs,powers,E,spacing,S);scaled_den=float(D(float((arb(dl)/arb(Cup)**2).lower())))
 print(json.dumps(dict(stage='quotient',k=k,Q_lower=ql,den_lower=dl,den_upper=dh,num_lower=nl,num_components=components,amplitude_upper=Cup,seconds=time.time()-t)),flush=True)
 rc=restriction_loss(k,d['theta'],d['beta'],d['smooth_delta'],d['omega'],scaled_den,ufrac=d['ufrac'],sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=(1-eps if d.get('use_inner_cap_loss',False) else None))
 target=arb(m)/(arb(1)/4+arb(d['omega']));tu=float(H(float(target.upper())));margin=float(D(float((arb(ql)-arb(rc['loss_upper'])-arb(tu)).lower())))
 assert 240*arb(d['omega'])+80*arb(d['smooth_delta'])<3
 assert 2*(arb(1)/4+arb(d['omega']))*(1+arb(eps))<1
 out=dict(m=m,k=k,trial=str(path),powers=powers,Q_lower=ql,restriction=rc,target_upper=tu,margin_lower=margin,epsilon=eps,den_lower=dl,den_upper=dh,num_lower=nl,num_components_lower=components,amplitude_upper=Cup,scaled_den_lower=scaled_den,cdf=dict(J=cdf.J,N=cdf.N,error={str(key):v for key,v in cdf.error.items()},alias={str(key):v for key,v in cdf.alias.items()},series_tail={str(key):v for key,v in cdf.tail.items()}),elapsed=time.time()-t,backend='mpmath.iv bounded E1/Ei, bounded FFT, directed binary64 Abel sums')
 Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
 from direct_fourier_check import check
 out['direct_fourier_checks']=check(cdf)
 Path(path).with_suffix('.interval_certificate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({a:b for a,b in out.items() if a!='direct_fourier_checks'}),flush=True);return out
if __name__=='__main__':
 for p in sys.argv[1:]:run(p)
