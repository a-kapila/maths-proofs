"""Exact-reference diagnostics for finite positive binomial-tail enclosures."""
from pathlib import Path
from fractions import Fraction as F
import json, math
from flint import arb,ctx
from loss_joint import sharp_tail
ctx.prec=256
tests=0
for n in (2,5,10,30,80):
 for r in range(1,n+1):
  for p in (F(1,100),F(1,10),F(1,2),F(9,10)):
   prob=sum(F(math.comb(n,j))*p**j*(1-p)**(n-j) for j in range(r,n+1))
   pp=arb(p.numerator)/arb(p.denominator)
   bd=sharp_tail(n,r,pp)
   assert bd.upper()>=(arb(prob.numerator)/arb(prob.denominator)).upper()
   tests+=1
out=dict(tests=tests,passed=True,reference='exact rational binomial sums; interval conversion')
(Path(__file__).resolve().parents[1]/'verification/binomial_tests.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
