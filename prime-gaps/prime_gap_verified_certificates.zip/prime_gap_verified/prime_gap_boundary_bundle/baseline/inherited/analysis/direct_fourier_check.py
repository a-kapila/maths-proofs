"""Independent high-precision direct sums checking the FFT grid at 18 points.
These are diagnostics; the certificate does not depend on their accuracy.
"""
import mpmath as mp
import numpy as np

def check(cdf):
 mp.mp.dps=70;out=[]
 for key in cdf.keys:
  for y in (.5,.75,1.):
   zsum=mp.mpf(0)
   for j,z in enumerate(cdf.coeffs[key],start=1):
    zz=mp.mpc(float(z.real),float(z.imag));phase=mp.exp(-2j*mp.pi*j*mp.mpf(y)/mp.mpf(cdf.P));zsum+=2*mp.re(zz*phase)
   direct=mp.mpf(cdf.zero[key])*mp.mpf(y)/mp.mpf(cdf.P)+mp.mpf(cdf.const[key])-zsum
   L,U=cdf.bounds(*key,np.array([y]))
   # A truncated Fourier sum can be slightly negative near zero.  Check the
   # raw FFT enclosure before clipping to the positive measure's range.
   idx=int(round(y/cdf.DELTA));raw=float(cdf.tables[key][idx]);err=float(cdf.error[key])
   assert abs(direct-mp.mpf(raw))<=mp.mpf(err),(key,y,direct,raw,err)
   assert direct+mp.mpf(err)>=0 and direct-mp.mpf(err)<=mp.mpf(float(cdf.mass[key].upper()))
   out.append(dict(n=key[0],moment=key[1],y=y,direct=mp.nstr(direct,25),lower=float(L[0]),upper=float(U[0]),raw_fft=raw,raw_error=err))
 return out
