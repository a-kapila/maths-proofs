"""Interval checks at the dimension barriers; not achievable prime-gap bounds.
The scalar backend is the inherited mpmath.iv compatibility layer, NOT FLINT.
Monotonicity in k extends each k-1 exclusion to every smaller k>=2.
"""
from pathlib import Path
import sys,json
root=Path(__file__).resolve().parents[1]
sys.path.append(str(root/'inherited/analysis'))
from flint import arb,ctx
ctx.prec=256
rows=json.loads((Path(__file__).with_name('method_barriers.json')).read_text())
results=[]
for d in rows:
    m=d['m'];target=arb(80)*m/21;eps=arb(d['epsilon']);res={'m':m,'current_k':110100 if m==3 else d['current_k'],'epsilon':d['epsilon']}
    funcs={'simplex_min_k':lambda k:arb(k)/(k-1)*arb(k).log(),
           'fixed_epsilon_min_k':lambda k:(1+eps)*arb(k)/(k-1)*arb(k).log(),
           'all_epsilon_min_k':lambda k:arb(k)/(k-1)*arb(2*k-1).log()}
    for name,fn in funcs.items():
        k=d[name];before=fn(k-1)-target;after=fn(k)-target
        assert before.upper()<0 and after.lower()>0
        res[name]={'k':k,'previous_upper_margin':str(before),'current_upper_margin':str(after),'bracket_verified':True}
    results.append(res)
print(json.dumps(results,indent=2))
