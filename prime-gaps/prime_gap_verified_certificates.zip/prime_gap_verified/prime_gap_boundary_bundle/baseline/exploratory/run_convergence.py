import sys,json,time
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'inherited'
sys.path.insert(0,str(root/'search'));sys.path.insert(0,str(root/'analysis'))
from explore_multi import optimize
out=Path(__file__).resolve().parent/'convergence';out.mkdir(exist_ok=True)
for m in (2,3,4,5):
 d=json.load(open(root/'analysis'/f'm{m}.json'))
 for degree in (2,3,4,5,6):
  key=f'm{m}_degree{degree}_n160'
  if (out/(key+'.json')).exists(): continue
  t=time.time()
  r=optimize(d,ncell=160,N=2**18,ng=28,spacing=2**-22,powers=tuple(range(2,degree+1)),quiet=True)
  (out/(key+'.json')).write_text(json.dumps(r))
  print(json.dumps({'m':m,'degree':degree,'cells':160,'Q':r['Q_exploratory'],'time':time.time()-t,'min_cov':r['min_cov_eigen']}),flush=True)
