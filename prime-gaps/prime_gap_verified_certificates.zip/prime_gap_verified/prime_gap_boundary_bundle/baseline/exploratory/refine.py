import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from explore_products import optimize,ROOT
out=Path(__file__).resolve().parent/'refined';out.mkdir(exist_ok=True)
for m in (2,3,4,5):
 d=json.load(open(ROOT/'analysis'/f'm{m}.json'))
 for name,basis in [('quartic',[(),(2,),(3,),(4,)]),('sixth',[(),(2,),(3,),(4,),(5,),(6,)]),('full_quartic',[(),(2,),(3,),(4,),(2,2)])]:
  r=optimize(d,basis,ncell=320,N=2**20,ng=36,tol=1e-12)
  (out/f'm{m}_{name}.json').write_text(json.dumps(r))
  print(json.dumps({'m':m,'basis':name,'Q':r['Q_exploratory'],'seconds':r['seconds'],'cells':320}),flush=True)
d=json.load(open(ROOT/'analysis/m3.json'))
for name,basis in [('full_fifth',[(),(2,),(3,),(4,),(2,2),(5,),(2,3)]),('full_sixth',[(),(2,),(3,),(4,),(2,2),(5,),(2,3),(6,),(2,4),(3,3),(2,2,2)])]:
 r=optimize(d,basis,ncell=160,N=2**19,ng=36,tol=1e-11)
 (out/f'm3_{name}.json').write_text(json.dumps(r))
 print(json.dumps({'m':3,'basis':name,'Q':r['Q_exploratory'],'seconds':r['seconds'],'cells':160}),flush=True)
d['k']=110100
r=optimize(d,[(),(2,),(3,),(4,),(2,2)],ncell=800,N=2**20,ng=40,spacing=2**-22,tol=1e-12)
r={**d,**r};(out/'m3_cross_candidate.json').write_text(json.dumps(r))
print(json.dumps({'m':3,'basis':'certificate_candidate','k':r['k'],'Q':r['Q_exploratory'],'seconds':r['seconds'],'cells':800}),flush=True)
