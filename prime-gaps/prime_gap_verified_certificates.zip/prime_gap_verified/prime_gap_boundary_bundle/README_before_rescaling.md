# Prime-gap continuation: mixed terms and deletion-dependent tuples

Date: 4 November 2026.

New results: H3 <= 1,359,754 and H5 <= 4,832,810,284. H2 <= 19,920 and
H4 <= 82,294,500 are unchanged. These are computer-assisted research derivations
within inherited analytic assumptions, not independently reviewed records.

Start with `new/proof_note.pdf`, `new/README.md`, and `new/RESULTS.json`.
The exact new trial, successful and failed enclosures, all new patches, and
separate full integer verifiers are included. This is a complete bundle: no
previous download is required. Root files outside `new/` are inherited from
the preceding continuation; `README_previous.md` describes those files.

From this directory:

```sh
bash new/reproduce.sh --checks-only
bash new/reproduce.sh --full
```

The first command checks saved endpoints and runs all new tuple verification;
the second also recomputes the NEW H3 interval evaluation. The old root
`reproduce.sh` reruns the preceding continuation. Neither command substitutes
for an independent expert review of the inherited analytic argument.

The source archive was `prime_gap_refined_enclosure_certificates.zip`, SHA-256
`d5424062386b1c7d727dea6c5a4cb64ee3e12047ad87113a2ec7eb892c00987f`.
Its mathematical source files were unchanged in this continuation. The old
root manifest is preserved as `MANIFEST_previous.sha256.json`; its README and
manifest paths have changed. `MANIFEST.sha256.json` covers this complete bundle.
