from pathlib import Path
import sys,json
import numpy as np
import mpmath as mp
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'fused_pair'))
from compute import get_constants
mp.mp.dps=45

def J_mp(k,a):
 a=mp.mpf(a);g=mp.sqrt(1-mp.mpf(2)/k);c=a*g/(a-2)
 L0=mp.log(c);L1=mp.log(c-g)
 v=mp.log(c+1)*(L0-L1)-(L0**2-L1**2)/2
 v+=mp.polylog(2,(c-g)/(c+1))-mp.polylog(2,c/(c+1))
 v+=mp.polylog(2,(c-1)/(c-g))-mp.polylog(2,(c-1)/c)
 return float(2*v/(a*g*(a-2)))

def prepare(m):
 j=json.load(open(ROOT/f'radial_pair/m{m}_cell_masses.json'))
 def val(a):return a[0]/a[1]
 sigma=val(j['sigma']);rho=val(j['rho']);s=rho*sigma;t=2*s
 xx=np.array([val(c['right'])/sigma for c in j['cells']]);mass=np.array([val(c['mass_lower']) for c in j['cells']]);D=val(j['den_upper'])
 def moment(eta):
  f1=(eta/(1-t))**2
  R=(1+(eta-1)*xx)/(1-t*xx)
  return f1-np.dot((f1-R**2)/xx,mass)/D
 return j,t,moment

def test(m,ds):
 j,t,M=prepare(m);k=j['k']
 for d in ds:
  base=get_constants(m,d);K=k-d
  opt=minimize_scalar(lambda eta:J_mp(K,K*eta)*M(eta),bounds=(1-t+1e-7,1.9),method='bounded',options={'xatol':1e-9})
  eta=float(opt.x);pair=8*(t/2)**2*opt.fun
  beta=float(base['beta_lower']);old=float(base['pair'])*(1-beta)
  # Raw source-weighted surplus, not the divided quotient surplus.
  rawsur=float(base['surplus'])*(1-beta)
  print(dict(m=m,d=d,K=K,eta=eta,M=M(eta),pair=pair,old=old,reduction=1-pair/old,budget_est=rawsur/pair,old_budget=base['budget']),flush=True)

if __name__=='__main__':
 test(4,[0,910,1000,1100]);test(5,[0,36500,39000,45000])
