"""Recheck rational source-weighted inequalities and all finite outputs."""
from pathlib import Path
import json,sys,subprocess,hashlib,importlib.util
from fractions import Fraction as F
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'radial_pair'
spec=importlib.util.spec_from_file_location('radial_compute',OUT/'compute.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)

def run(args,name):
 z=subprocess.run([str(x)for x in args],cwd=ROOT,check=True,capture_output=True,text=True)
 (OUT/name).write_text(z.stdout)
 return json.loads(z.stdout)

for src,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
 subprocess.run(['g++','-O3','-std=c++17',str(ROOT/src),'-o',str(OUT/name)],check=True)
rows=[]
for m,d in [(4,850),(5,35000)]:
 obj=json.load(open(OUT/f'm{m}_d{d}.json'));v=c.constants(m,d);row=dict(obj['selection'])
 assert c.old.encode(v)==obj['constants']
 cnt=row['long_pairs'];ma=v['raw_surplus']-cnt*v['raw_pair_upper'];st=v['strict_raw_surplus']-cnt*v['strict_raw_pair_upper']
 assert ma>0 and st>0
 assert c.old.encode(ma)==obj['raw_margin'] and c.old.encode(st)==obj['strict_raw_margin']
 assert cnt<=v['pair_budget']<row['previous_even_min_count']
 mass=json.load(open(OUT/f'm{m}_cell_masses.json'))
 for p,sha in mass['sources'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==sha
 search=c.Search(m)
 cs=search.counts(v['k'],row['D']);assert len(cs)==row['windows'] and int(cs.argmin())==row['index'] and int(cs.min())==cnt
 assert int(search.counts(v['k'],row['D']-2).min())==row['previous_even_min_count']
 if m==4:
  a=search.a[row['index']:row['index']+v['k']];p=OUT/'h4_selected.txt'
  assert len(a)==v['k'] and int(a[0])==row['first'] and int(a[-1])==row['last']
  np.savetxt(p,a,fmt='%d')
  tv=run([OUT/'verify_tuple',p,ROOT/'baseline/inherited/tuples/h4_witness.csv',v['k']],'h4_tuple_verified.json')
  pv=run([OUT/'check_pairs','tuple',p,row['D']],'h4_pairs_verified.json')
  assert tv['verified'];row['checked_primes']=tv['checked_primes'];row['tuple_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 else:
  parent=json.load(open(OUT/'h5_parent_verified.json'))
  assert parent['verified'] and parent['failures']==0 and parent['parent_cardinality']==233950978 and parent['certificate_prime_count']==12204094
  assert row['negative_count']+row['positive_count']==v['k']
  assert row['first']==-int(search.a[row['negative_count']-search.rank0])
  assert row['last']==int(search.a[row['positive_count']-search.rank0])
  pv=run([OUT/'check_pairs','signed',ROOT/'continuation2/recomputed/h5_tail.bin',row['D'],row['negative_count'],row['positive_count']],'h5_pairs_verified.json')
 assert pv['k']==v['k'] and pv['long_pairs']==cnt
 previous={4:82235890,5:4830389798}[m]
 row.update(previous_best=previous,improvement=previous-row['D'],pair_upper=float(v['raw_pair_upper']),effective_pair_upper=float(v['effective_pair_upper']),pair_reduction_same_dimension=float(v['reduction_at_same_dimension']),radial_moment_upper=float(v['radial']['moment_upper']),eta=float(v['eta']))
 assert row['improvement']>0
 rows.append(row);print('VERIFIED',row,flush=True)
result=dict(status='passed',bounds={'H2':19860,'H3':1358042,'H4':rows[0]['D'],'H5':rows[1]['D']},results=rows,
 scope='New exact postprocessing of inherited positive tagged CDF enclosures; a new source-averaged pair proof; full finite checks. Successful quotient, tagged-CDF and arithmetic-support enclosures were NOT recomputed. No global-optimality or external-review claim.')
(OUT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
