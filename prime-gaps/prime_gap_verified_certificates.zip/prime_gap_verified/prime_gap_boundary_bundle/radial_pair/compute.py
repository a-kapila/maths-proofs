"""Trial-specific radial pair estimate, combined with slicing by averaging.
New arithmetic is outward-rounded rational arithmetic. Tagged CDF and successful
quotient/support certificates are inherited and are not silently recomputed.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'radial_pair'
sys.path.insert(0,str(ROOT/'fused_pair'))
import importlib.util
_spec=importlib.util.spec_from_file_location("inherited_fused_compute",ROOT/"fused_pair/compute.py")
old=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(old)
from intervals import I,J
sys.set_int_max_str_digits(0)
_CELLS={};_MOM={}

def radial_moment(m,eta,t):
    """Upper E_nu R_eta(S/sigma)^2 from positive tagged cell masses.
    t = physical outer radius / auxiliary radius. eta >= 1-t.
    nu is the original restricted trial, before selecting a coordinate slice.
    """
    eta,t=F(eta),F(t);key=(m,eta,t)
    if key in _MOM:return _MOM[key]
    assert eta>=1-t and 0<t<1
    if m not in _CELLS:
        _CELLS[m]=json.load(open(OUT/f'm{m}_cell_masses.json'))
    src=_CELLS[m];sigma=F(*src['sigma']);den=F(*src['den_upper']);bad=F(*src['removed_square_mass_upper'])
    R1=(I(eta)/(1-t))**2;N=I(0);nonzero=0
    for cell in src['cells']:
        mass=F(*cell['mass_lower']);x=F(*cell['right'])/sigma
        if not mass:continue
        assert 0<x<=1
        R=(1+(eta-1)*I(x))/(1-t*I(x))
        phi=(R1-R**2)/x
        # Exactly zero at x=1; avoid a tiny negative lower endpoint due rounding.
        if x==1:phi=I(0)
        else:assert phi.lo>=0
        N+=I(mass)*phi
        nonzero+=1
    corrected=N.lo-R1.hi*bad
    assert corrected>0
    upper=R1.hi-corrected/den
    # At eta>=1-t, R(x)^2>=1. This is only a sanity check, not a lower certificate.
    assert upper>=1
    out=dict(moment_upper=upper,weighted_improvement_lower=N.lo,removed_correction_upper=R1.hi*bad,
             endpoint_square_upper=R1.hi,denominator_upper=den,eta=eta,t=t,nonzero_cells=nonzero)
    _MOM[key]=out
    return out

def constants(m,d,eta=None):
    if eta is None:eta={4:F(1081,1000),5:F(541,500)}[m]
    eta=F(eta);v=old.get_constants(m,d);K=v['k'];k=v['original_k'];rho=v['rho'];sigma=v['sigma'];beta=v['beta_lower']
    t=2*rho*sigma
    mom=radial_moment(m,eta,t);jj=J(K,K*eta)
    pair=2*t*t*jj.hi*mom['moment_upper']
    rawsur=v['surplus']*(1-beta)
    rat=rawsur/pair;budget=(rat.numerator-1)//rat.denominator
    lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);ts=lam*sigma/b
    strict_mom=radial_moment(m,eta,ts)
    strict_pair=2*ts*ts*jj.hi*strict_mom['moment_upper']
    strict_sur=(lam*v['q']-m)*(1-beta)
    assert rawsur-budget*pair>0>=rawsur-(budget+1)*pair
    out=dict(m=m,k=K,original_k=k,deleted=d,rho=rho,sigma=sigma,eta=eta,
             beta_lower=beta,source_quotient=v['q']*(1-beta)*F(k,K),
             raw_surplus=rawsur,raw_pair_upper=pair,pair_budget=budget,
             effective_pair_upper=pair/(1-beta),inherited_universal_pair_upper=v['pair'],
             reduction_at_same_dimension=1-pair/((1-beta)*v['pair']),
             J_lower=jj.lo,J_upper=jj.hi,radial=mom,strict_radial=strict_mom,
             strict_raw_pair_upper=strict_pair,strict_raw_surplus=strict_sur)
    return out

class Search(old.Search):
    def run_new(self,d,eta=None):
        v=constants(self.m,d,eta);K=v['k'];budget=v['pair_budget']
        lo,hi={4:(82190000,82300000),5:(4829500000,4831000000)}[self.m];lo//=2;hi//=2
        assert int(self.counts(K,hi*2).min())<=budget
        assert int(self.counts(K,lo*2).min())>budget
        while lo<hi:
            md=(lo+hi)//2
            if int(self.counts(K,md*2).min())<=budget:hi=md
            else:lo=md+1
        D=lo*2;cs=self.counts(K,D);idx=int(cs.argmin());cnt=int(cs[idx]);a=self.a
        row=dict(m=self.m,k=K,original_k=v['original_k'],deleted=d,D=D,long_pairs=cnt,budget=budget,windows=len(cs),index=idx,
                 previous_even_min_count=int(self.counts(K,D-2).min()))
        if self.m!=5:row.update(first=int(a[idx]),last=int(a[idx+K-1]))
        else:
            neg=K-self.N+idx;pos=K-neg
            row.update(negative_count=neg,positive_count=pos,first=-int(a[neg-self.rank0]),last=int(a[pos-self.rank0]),tail_first_rank=self.rank0,parent_positive_count=self.N)
        row['diameter']=row['last']-row['first']
        margin=v['raw_surplus']-cnt*v['raw_pair_upper'];strict=v['strict_raw_surplus']-cnt*v['strict_raw_pair_upper']
        assert margin>0 and strict>0
        row.update(raw_margin=float(margin),strict_raw_margin=float(strict))
        out=dict(constants=v,selection=row,raw_margin=margin,strict_raw_margin=strict)
        (OUT/f'm{self.m}_d{d}.json').write_text(json.dumps(old.encode(out),indent=2)+'\n')
        print(row,'pair_reduction',float(v['reduction_at_same_dimension']),flush=True)
        return row

if __name__=='__main__':
    m=int(sys.argv[1]);ds=list(map(int,sys.argv[2:]));s=Search(m)
    for d in ds:s.run_new(d)
