"""Exact post-processing of inherited tagged positive-measure CDF bounds.
Produces a lower enclosure for integral_cell U F0^2 / m2^k.
All input binary64 endpoints and dyadic coefficients are treated as exact.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

def build(m):
 r={4:10,5:4}[m]
 tr=json.load(open(ROOT/f'accurate/m{m}.json'))
 me=json.load(open(ROOT/f'continuation/mean_m{m}_r{r}.json'))
 z=np.load(ROOT/f'continuation/mean_m{m}_r{r}_cdf.npz')
 keys=[tuple(x) for x in me['moment_keys']]
 hs=[[F(v) for v in h]for h in tr['profiles']]
 nc=len(hs[0]);coef=defaultdict(lambda:[F(0)]*nc)
 for h,bi in zip(hs,tr['basis']):
  for g,bj in zip(hs,tr['basis']):
   key=tuple(sorted(bi+bj))
   coef[key]=[a+x*y for a,x,y in zip(coef[key],h,g)]
 assert set(keys)==set(coef)
 edges=[F(tr['delta'])*e for e in tr['E']]
 assert len(edges)==nc+1
 assert all(F(float(y))==e for y,e in zip(z['y'],edges))
 lows=[F(0)]*nc;ups=[F(0)]*nc
 for ri,key in enumerate(keys):
  L=list(map(F,map(float,z['L'][ri])));V=list(map(F,map(float,z['V'][ri])))
  assert all(l<=v for l,v in zip(L,V))
  for j,c in enumerate(coef[key]):
   ml=max(F(0),L[j+1]-V[j]);mu=V[j+1]-L[j]
   assert mu>=ml
   if c>=0:lows[j]+=c*ml;ups[j]+=c*mu
   else:lows[j]+=c*mu;ups[j]+=c*ml
 # The full cell integrand U P^2 is nonnegative, although components are signed.
 lows=list(map(lambda a:max(F(0),a),lows))
 assert all(l<=u for l,u in zip(lows,ups))
 cert=json.load(open(ROOT/f'accurate/m{m}.interval_certificate.json'))
 su=json.load(open(ROOT/f'continuation/support_m{m}_{r}_{r-1}.json'))
 pbad=F(su['amplitude_upper'])**2*F(su['support_bad_probability_upper'])
 sigma=F(1)+F(tr['eps_cells'])*F(tr['delta'])
 out=dict(m=m,k=tr['k'],r=r,
          sigma=[sigma.numerator,sigma.denominator],rho=[(F(1,4)+F(tr['omega'])).numerator,(F(1,4)+F(tr['omega'])).denominator],
          cells=[dict(left=[l.numerator,l.denominator],right=[r.numerator,r.denominator],mass_lower=[ml.numerator,ml.denominator],mass_upper=[mu.numerator,mu.denominator]) for l,r,ml,mu in zip(edges[:-1],edges[1:],lows,ups)],
          den_upper=[F(cert['den_upper']).numerator,F(cert['den_upper']).denominator],
          removed_square_mass_upper=[pbad.numerator,pbad.denominator],
          sources={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in [f'accurate/m{m}.json',f'accurate/m{m}.interval_certificate.json',f'continuation/mean_m{m}_r{r}.json',f'continuation/mean_m{m}_r{r}_cdf.npz',f'continuation/support_m{m}_{r}_{r-1}.json']},
          inherited_cdf_bounds=True,tagged_mass_lower=float(sum(lows)),tagged_mass_upper=float(sum(ups)))
 (ROOT/f'radial_pair/m{m}_cell_masses.json').write_text(json.dumps(out,indent=2)+'\n')
 print(m,'cells',nc,'tagged numerator',float(sum(lows)),float(sum(ups)),'original',me['weighted_numerator_lower'],me['weighted_numerator_upper'],'zero lower cells',sum(v==0 for v in lows),flush=True)
 return out

if __name__=='__main__':
 for m in map(int,sys.argv[1:]or[4,5]):build(m)
