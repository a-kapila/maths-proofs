"""Finite exact checks and independent quadrature diagnostics, not proof substitutes."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import sys,random,json,math
import mpmath as mp
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'radial_pair'
sys.path.insert(0,str(ROOT/'fused_pair'))
from intervals import J
rng=random.Random(20261105)
N=1500
for it in range(N):
    k=rng.randrange(3,15);sigma=F(1);b=F(1,2);s=F(rng.randrange(20,40),100);t=s/b
    vals=[F(rng.randrange(0,50),100) for _ in range(k)];sm=sum(vals)
    if sm>1:vals=[x/sm for x in vals]
    S=sum(vals);d=rng.randrange(0,k-1);Z=sum(vals[:d],F(0));cap=F(rng.randrange(11,20),10)
    alpha=cap if Z==1 else min(cap,F(1)/(1-Z))
    Sout=alpha*(S-Z)
    assert 0<=Sout<=S<=1
    eta=1-t+F(rng.randrange(0,100),100)
    def R(x):return (1+(eta-1)*x)/(1-t*x)
    assert R(Sout)**2/alpha<=R(S)**2
    x,y=sorted([F(rng.randrange(1,101),100),F(rng.randrange(1,101),100)])
    assert R(x)<=R(y)
    phix=(R(1)**2-R(x)**2)/x;phiy=(R(1)**2-R(y)**2)/y
    assert phix>=phiy>=0
    physical=[s*x for x in vals];r=s-sum(physical);a=k*eta
    ww=sum((r+a*physical[i])*(r+a*physical[j])+a*a/F(2*k)*(physical[i]-physical[j])**2 for i,j in combinations(range(k),2))
    assert ww/F(math.comb(k,2))==(r+eta*sum(physical))**2

# Independent finite distributions test the complete radial expectation bound.
# CDF increments are interval-bounded and signed polynomial components collected.
finite=0
for it in range(100):
 k=4;r=3;edges=[F(i,5)for i in range(6)];basis=[(),(2,),(3,),(2,2)]
 hs=[[F(rng.randrange(-10,11),8)for _ in range(5)]for _ in basis]
 co={}
 for ii,bi in enumerate(basis):
  for jj,bj in enumerate(basis):
   key=tuple(sorted(bi+bj));co.setdefault(key,[F(0)]*5)
   co[key]=[v+x*y for v,x,y in zip(co[key],hs[ii],hs[jj])]
 vals=[]
 for _ in range(30):
  ts=[F(rng.randrange(1,20),100)for _ in range(k)];S=sum(ts);assert 0<S<1
  U=sum(min(x,F(1,r))for x in ts);Z={j:sum(x**j for x in ts)for j in [2,3]};cell=min(int(5*S),4)
  def mon(key):return math.prod(Z[p]for p in key)
  P=sum(hs[j][cell]*mon(key)for j,key in enumerate(basis));weight=F(1,30)
  vals.append((S,U,cell,Z,P,weight))
 D=sum(P*P*w for S,U,cell,Z,P,w in vals)
 if D==0:continue
 eta=F(1081,1000);t=F(21,40)
 def R(x):return (1+(eta-1)*x)/(1-t*x)
 masslower=[F(0)]*5
 for key,cc in co.items():
  masses=[sum(w*U*math.prod(Z[p]for p in key)for S,U,cell,Z,P,w in vals if cell==j)for j in range(5)]
  for j,c in enumerate(cc):
   err=F(1,10**12);lo=max(F(0),masses[j]-err);hi=masses[j]+err
   masslower[j]+=c*(lo if c>=0 else hi)
 masslower=list(map(lambda x:max(F(0),x),masslower))
 for j in range(5):
  real=sum(w*U*P*P for S,U,cell,Z,P,w in vals if cell==j)
  assert masslower[j]<=real
 Nlo=sum(M*(R(1)**2-R(edges[j+1])**2)/edges[j+1]for j,M in enumerate(masslower))
 upper=R(1)**2-Nlo/D
 exact=sum(w*P*P*R(S)**2 for S,U,cell,Z,P,w in vals)/D
 assert upper>=exact
 finite+=1

mp.mp.dps=100
quad=[]
for k,eta in [(7,F(11,10)),(100,F(1081,1000)),(2304,F(1081,1000)),(5089150,F(1081,1000)),(232465000,F(541,500))]:
 a=F(k)*eta;iv=J(k,a);aa=mp.mpf(a.numerator)/a.denominator;g=mp.sqrt(1-mp.mpf(2)/k)
 def f(x):return 4*mp.atanh(aa*g*x/(2+(aa-2)*x))/(aa*g*(2+(aa-2)*x))
 points=sorted(set([mp.mpf(0),min(mp.mpf(1),1/aa),min(mp.mpf(1),10/aa),mp.mpf('.1'),mp.mpf(1)]))
 v=mp.quad(f,points)
 l=mp.mpf(iv.lo.numerator)/iv.lo.denominator;u=mp.mpf(iv.hi.numerator)/iv.hi.denominator
 assert l<=v<=u,(k,str(v),str(l),str(u))
 quad.append(dict(k=k,eta=float(eta),inside_interval=True,interval_width=float(iv.hi-iv.lo)))
out=dict(exact_weight_and_dilation_tests=N,exact_monotonicity_tests=N,finite_distribution_radial_tests=finite,positive_integral_quadratures=quad,status='passed',scope='Diagnostics supplement the written proofs; quadrature is not used to decide a final inequality.')
(OUT/'diagnostics.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
