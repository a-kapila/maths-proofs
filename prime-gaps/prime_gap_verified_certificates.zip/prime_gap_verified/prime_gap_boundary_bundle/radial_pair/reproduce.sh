#!/usr/bin/env bash
# No command here reruns the inherited successful Fourier integrations.
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
mode="${1:---integers}"
case "$mode" in
 --integers)
  mkdir -p continuation2/recomputed
  python baseline/inherited/tuples/decode_h5.py continuation2/recomputed/unpatched.bin
  python baseline/h5/apply_patches.py continuation2/recomputed/unpatched.bin continuation2/recomputed/previous.bin
  python new/apply_new_h5_patches.py continuation2/recomputed/previous.bin continuation2/recomputed/current.bin
  "${CXX:-g++}" -O3 -std=c++17 -fopenmp continuation2/verify_h5_export.cpp -o continuation2/verify_h5_export
  continuation2/verify_h5_export 234360000 232500000 10000000 2432107459 continuation2/recomputed/current.bin continuation2/recomputed/h5_tail.bin > radial_pair/h5_parent_verified.json
  python radial_pair/verify.py
  ;;
 --scalars)
  test -f continuation2/recomputed/h5_tail.bin || { echo 'Run --integers first to reconstruct the prime tail.' >&2; exit 2; }
  python radial_pair/radial_mass.py 4 5
  python radial_pair/compute.py 4 850
  python radial_pair/compute.py 5 35000
  python radial_pair/diagnostics.py
  python radial_pair/verify.py
  ;;
 *) echo 'usage: bash radial_pair/reproduce.sh --integers|--scalars' >&2; exit 2;;
esac
