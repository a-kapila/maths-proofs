# Trial-specific radial pair estimate — 5 November 2026

The authoritative new result is `radial_pair/RESULTS.json`:
H2 <= 19,860 (unchanged); H3 <= 1,358,042 (unchanged);
H4 <= 82,234,788; H5 <= 4,830,355,416.
These are research deductions within the inherited sieve and numerical framework,
not independently reviewed published records.

## What is new

`proof_note.pdf` and its TeX source prove a trial-specific pair estimate and a
source-averaged slicing criterion. The prime first moment and pair penalty are
averaged together; no independently favorable slices are conflated.

`radial_mass.py` exactly collects signed coefficients in the saved positive
weighted CDFs, giving nonnegative cell lower bounds. `compute.py` applies these
bounds to a monotone rational radial weight using outward 256-bit fixed-point
arithmetic and the inherited rigorous enclosure for J. The two exact selected
parameters are eta=1081/1000 for H4 and eta=541/500 for H5. Candidate optimization
was floating-point; the selected inequalities are rationally rechecked.

`verify.py` rechecks source hashes, all rational deductions, full selected-window
scans, explicit H4 admissibility, and both independent C++ pair counts. H5
admissibility follows from the fully reconstructed and reverified parent.

## Reproduce

In a fresh extraction run, in this order:

    bash radial_pair/reproduce.sh --integers
    bash radial_pair/reproduce.sh --scalars

Python 3, NumPy, SciPy, mpmath and a C++17 compiler with OpenMP are required.
Assertions must stay enabled. Working storage includes reconstructed binary
prime tables and the 5-million-entry H4 tuple. These generated files are omitted
from the archive and reconstructed by the commands.

These commands do NOT rerun the inherited successful Fourier quotient,
tagged-CDF, or arithmetic-support computations. Their original sources, proof
notes, exact trials, output certificates and reproduction commands remain in the
complete archive, particularly accurate/, continuation/, and direct_mean/.
The inherited scalar Fourier backend is mpmath.iv plus explicit remainder
bounds, not FLINT/Arb. New post-processing uses integer/rational outward rounding.

## Inputs and limitations

The source profiles, physical boundaries and one-coordinate laws match the saved
tagged CDF calculations; the inherited `deduce_caps.calc` checks that identity.
The exact binary64 CDF endpoints are treated as rationals. Source hashes are
stored in `m4_cell_masses.json` and `m5_cell_masses.json`. The independent
positive-cell tests in diagnostics.py do not replace the inherited CDF proofs.

An optional H3 tagged-moment run was interrupted without a complete certificate.
Its incomplete log is exploratory and is not an input to any deduction.
No fresh H2 trial was evaluated. No globally optimal dimension, tuple, trial,
parameter, or terminal prime-gap bound is asserted.

The selected source dimensions are 5,090,000 and 232,500,000; selected deletion
counts are 850 and 35,000. Other stored `m*_d*.json` files are successful candidate
comparisons, not claims of an exhaustive search over deletion counts.
The bounds are cluster lengths, shorter than the full selected tuple diameters.
