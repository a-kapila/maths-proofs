from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'radial_pair'
if '--check' in sys.argv:
 data=json.load(open(OUT/'MANIFEST.json'))
 for p,h in data.items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
 print('Manifest verified:',len(data),'files')
else:
 names=set()
 for p in OUT.iterdir():
  if p.suffix in ['.py','.sh','.tex','.pdf','.json','.md'] and p.name not in ['MANIFEST.json','h5_parent_verified.json']:
   names.add(str(p.relative_to(ROOT)))
 for m in [4,5]:names.update(json.load(open(OUT/f'm{m}_cell_masses.json'))['sources'])
 data={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest()for p in sorted(names)}
 (OUT/'MANIFEST.json').write_text(json.dumps(data,indent=2)+'\n');print('Manifest created:',len(data),'files')
