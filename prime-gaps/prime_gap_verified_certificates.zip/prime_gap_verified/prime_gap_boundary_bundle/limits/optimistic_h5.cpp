// Optimistic relaxation only: includes ALL signed primes in the fixed universe.
// No assertion of admissibility. Every restore-only construction is a subset.
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <stdexcept>
#include <iostream>
#include <vector>
struct Bits{std::vector<uint64_t>w;Bits(uint64_t n):w((n+63)/64,~0ULL){}bool get(uint64_t i)const{return(w[i>>6]>>(i&63))&1;}void clear(uint64_t i){w[i>>6]&=~(1ULL<<(i&63));}};
int main(int argc,char**argv){
 if(argc!=2){std::cerr<<"usage: optimistic_h5 K\n";return 2;}
 const uint64_t cutoff=10000000,limit=2432107459,k=std::stoull(argv[1]);
 auto started=std::chrono::steady_clock::now();Bits prime((limit+1)/2);prime.clear(0);
 for(uint64_t p=3;p*p<=limit;p+=2)if(prime.get(p/2))for(uint64_t q=p*p;q<=limit;q+=2*p)prime.clear(q/2);
 uint64_t N=0;for(uint64_t q=cutoff+1;q<=limit;q+=2)if(prime.get(q/2))N++;
 assert(N<k&&k<=2*N);uint64_t nmin=k-N,count=0;std::vector<uint32_t>tail;tail.reserve(2*N-k+1);
 for(uint64_t q=cutoff+1;q<=limit;q+=2)if(prime.get(q/2)){count++;if(count>=nmin)tail.push_back(q);}
 assert(count==N&&tail.size()==2*N-k+1);uint64_t best=UINT64_MAX,bn=0,left=0,right=0;
 for(uint64_t n=nmin;n<=N;n++){uint64_t l=tail[n-nmin],r=tail[k-n-nmin];if(l+r<best){best=l+r;bn=n;left=l;right=r;}}
 std::cout<<"{\"status\":\"optimistic_nonadmissible_relaxation\",\"k\":"<<k<<",\"positive_parent_count\":"<<N<<",\"diameter_lower_bound_for_restore_only\":"<<best<<",\"negative_count\":"<<bn<<",\"left\":-"<<left<<",\"right\":"<<right<<",\"candidate_windows\":"<<2*N-k+1<<",\"seconds\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count()<<"}\n";
}
