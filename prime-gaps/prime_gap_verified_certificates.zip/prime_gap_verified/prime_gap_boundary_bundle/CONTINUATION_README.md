The newest continuation is in direct_mean/. Read direct_mean/README.md and direct_mean/proof_note.pdf. The older root README and prior directories are retained dependencies.
