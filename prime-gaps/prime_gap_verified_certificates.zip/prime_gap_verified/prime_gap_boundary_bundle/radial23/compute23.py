"""New radial enclosures at k=2304 and k=110070, with exact final deductions."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,importlib.util,math
import numpy as np
import mpmath as mp
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1];O=B/'radial23'
sys.path[:0]=[str(B/'radial_pair'),str(B/'fused_pair'),str(B/'continuation2')]
sp=importlib.util.spec_from_file_location('radial_compute',B/'radial_pair/compute.py');rad=importlib.util.module_from_spec(sp);sp.loader.exec_module(rad)
from intervals import I,J
from pair_penalty import allowed,load_witness,choose,primes_up_to,enumerate_long_pairs
mp.mp.dps=40

def jf(k,a):
 a=mp.mpf(a);g=mp.sqrt(1-mp.mpf(2)/k);c=a*g/(a-2)
 L0=mp.log(c);L1=mp.log(c-g)
 v=mp.log(c+1)*(L0-L1)-(L0**2-L1**2)/2
 v+=mp.polylog(2,(c-g)/(c+1))-mp.polylog(2,c/(c+1))
 v+=mp.polylog(2,(c-1)/(c-g))-mp.polylog(2,(c-1)/c)
 return float(2*v/(a*g*(a-2)))

def get_inputs(m):
 if m==3:
  v=rad.old.get_constants(3,0);return v['k'],v['rho'],v['sigma'],v['q']
 tr=json.load(open(B/'focus23/m2_k2304.json'))
 row=json.load(open(B/'focus23/RESULTS.json'))['results'][0]
 return tr['k'],F(1,4)+F(tr['omega']),F(1)+F(tr['delta'])*tr['eps_cells'],F(json.load(open(O/'hilbert_recheck.json'))['recomputed_quotient_lower'])-F(json.load(open(B/'focus23/m2_k2304.support_1.005.json'))['loss_upper'])

def calc(m,eta=None):
 k,rho,sigma,q=get_inputs(m);src=json.load(open(O/f'm{m}_cell_masses.json'));rad._CELLS[m]=src
 t=2*rho*sigma
 xx=np.array([float(F(*c['right'])/sigma)for c in src['cells']]);ll=np.array([float(F(*c['mass_lower']))for c in src['cells']]);mask=xx>0;xx=xx[mask];ll=ll[mask]
 den=float(F(*src['den_upper']));bad=float(F(*src['removed_square_mass_upper']));tf=float(t)
 def obj(e):
  R1=(e/(1-tf))**2;R=(1+(e-1)*xx)/(1-tf*xx);M=R1-((ll*(R1-R*R)/xx).sum()-R1*bad)/den
  return 2*tf*tf*jf(k,k*e)*M
 opt=minimize_scalar(obj,bounds=(float(1-t),1.9),method='bounded',options={'xatol':1e-9})
 if eta is None:eta=F(round(float(opt.x)*1000000),1000000)
 mo=rad.radial_moment(m,eta,t);ji=J(k,k*eta);pair=2*t*t*ji.hi*mo['moment_upper'];sur=rho*q-m
 budget=(sur/pair).numerator//(sur/pair).denominator
 while sur-budget*pair<=0:budget-=1
 lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);tt=lam*sigma/b
 mo_s=rad.radial_moment(m,eta,tt);pair_s=2*tt*tt*ji.hi*mo_s['moment_upper'];sur_s=lam*q-m
 out=dict(m=m,k=k,eta=eta,rho=rho,sigma=sigma,source_q=q,surplus=sur,pair_upper=pair,pair_budget=budget,strict_pair_upper=pair_s,strict_surplus=sur_s,radial=mo,mean_source=str(O/f'm{m}_cell_masses.json'),optimization_candidate=opt.x,optimization_pair=obj(opt.x),J_lower=ji.lo,J_upper=ji.hi)
 if m==3:
  w=load_witness('onward/h3_completed_witness.csv');a=allowed(w,-2000000,2000000);sub,res=choose(a,k,budget)
  for p in primes_up_to(k):
   if int(p) not in w:
    used=np.bincount(sub%p,minlength=int(p));missing=np.flatnonzero(used==0);assert len(missing);w[int(p)]=int(missing[0])
  res.update(first=int(sub[0]),last=int(sub[-1]),diameter=int(sub[-1]-sub[0]),points=len(a),cardinality=k)
  cnt=res['long_pairs'];margin=sur-cnt*pair;strict=sur_s-cnt*pair_s;assert margin>0 and strict>0
  out.update(selection=res,margin=margin,strict_margin=strict)
  np.savetxt(O/'h3_tuple.txt',sub,fmt='%d');np.savetxt(O/'h3_tuple.csv',sub,fmt='%d',header='h',comments='')
  np.savetxt(O/'h3_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
  pairs=enumerate_long_pairs(sub,res['D']);assert len(pairs)==cnt
  np.savetxt(O/'h3_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
 (O/f'm{m}_deduction.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
 print(m,'eta',float(eta),'M',float(mo['moment_upper']),'pair',float(pair),'surplus',float(sur),'budget',budget,'selection',out.get('selection'),'margin',float(out.get('margin',0)),flush=True)
 return out
if __name__=='__main__':
 for m in map(int,sys.argv[1:]):calc(m)
