"""Postprocess the freshly evaluated k=2305 radial distributions."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'radial23'
def build():
 tp=B/'trials/m2_final.json';tr=json.load(open(tp));cert=json.load(open(tp.with_suffix('.interval_certificate.json')))
 mep=B/'continuation/new_m2_k2305_r1.json';zp=B/'continuation/new_m2_k2305_r1_cdf.npz';sp=O/'m2_k2305_support.json'
 me=json.load(open(mep));z=np.load(zp);su=json.load(open(sp))
 assert me['k']==tr['k']==su['k']==2305
 assert me['trial_sha256']==hashlib.sha256(tp.read_bytes()).hexdigest()
 keys=[tuple(x)for x in me['moment_keys']];hs=[[F(v)for v in h]for h in tr['profiles']];nc=len(hs[0]);co=defaultdict(lambda:[F(0)]*nc)
 for h,bi in zip(hs,tr['basis']):
  for g,bj in zip(hs,tr['basis']):
   key=tuple(sorted(bi+bj));co[key]=[a+x*y for a,x,y in zip(co[key],h,g)]
 assert set(keys)==set(co)
 edges=[F(tr['delta'])*e for e in tr['E']];assert all(F(float(v))==e for v,e in zip(z['y'],edges))
 lo=[F(0)]*nc;hi=[F(0)]*nc
 for ri,key in enumerate(keys):
  L=list(map(F,map(float,z['L'][ri])));V=list(map(F,map(float,z['V'][ri])))
  for j,c in enumerate(co[key]):
   ml=max(F(0),L[j+1]-V[j]);mu=V[j+1]-L[j];assert mu>=ml
   if c>=0:lo[j]+=c*ml;hi[j]+=c*mu
   else:lo[j]+=c*mu;hi[j]+=c*ml
 lo=[max(F(0),x)for x in lo];assert all(l<=u for l,u in zip(lo,hi))
 sig=F(1)+F(tr['delta'])*tr['eps_cells'];bad=F(*map(int,su['removed_mass_upper']));den=F(cert['den_upper'])
 out=dict(m=2,k=2305,sigma=[sig.numerator,sig.denominator],den_upper=[den.numerator,den.denominator],removed_square_mass_upper=[bad.numerator,bad.denominator],cells=[dict(left=[l.numerator,l.denominator],right=[r.numerator,r.denominator],mass_lower=[ml.numerator,ml.denominator],mass_upper=[mu.numerator,mu.denominator])for l,r,ml,mu in zip(edges[:-1],edges[1:],lo,hi)],fresh_tagged_CDF=True,tag='S/sigma',sources={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [tp,tp.with_suffix('.interval_certificate.json'),mep,zp,sp]},mean_lower=float((sum(lo)-bad)/den))
 (O/'m2_k2305_cell_masses.json').write_text(json.dumps(out,indent=2)+'\n');print('mean_lower',out['mean_lower'])
if __name__=='__main__':build()
