#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
mode="${1:---checks-only}"
case "$mode" in
 --full)
  python focus23/moment_amplitude.py trials/m2_cross.json radial23/m2_k2305_amplitude.json
  python continuation/capped_mean_general.py 2 1 trials/m2_final.json new_m2_k2305_r1
  python continuation/capped_mean_general.py 3 1 focus23/m3_fine.json new_m3_r1
  python radial23/support2305.py
  python radial23/support_mass.py 3
  ;;
 --checks-only) ;;
 *) echo 'usage: bash radial23/reproduce.sh --checks-only|--full' >&2; exit 2;;
esac
python radial23/build2305.py
python radial23/build_cells.py 3
python radial23/verify_final.py
python radial23/check_new_moments.py
