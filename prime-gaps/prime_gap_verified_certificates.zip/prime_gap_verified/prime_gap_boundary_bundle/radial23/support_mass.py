from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'rescaled'),str(B/'baseline/inherited/analysis')]
from scaled_slicing import bad_probability,up,down
from flint import arb,ctx
ctx.prec=256
m=int(sys.argv[1]); trp=B/f'focus23/m{m}_'+Path('') if False else B/('focus23/m3_fine.json' if m==3 else 'focus23/m2_k2304.json')
d=json.load(open(trp)); c=json.load(open(trp.with_suffix('.interval_certificate.json')))
if m==3:
 a=json.load(open(B/'direct_pair/m3_arithmetic.json'));d['omega']=a['omega'];d['smooth_delta']=a['delta']
rho=arb(1)/4+arb(d['omega']); kap=(arb(1)/4+arb(d['smooth_delta'])/2)/rho-arb('0.0001'); kp=down(kap)
t=time.time();pbad,n=bad_probability(d,d['ufrac'],kp)
C=F(c['amplitude_upper']);cor=C*C*F(pbad)
print(json.dumps(dict(m=m,pbad=pbad,bins=n,amplitude_upper=float(C),removed_mass_upper=[str(cor.numerator),str(cor.denominator)],new_kappa=kp,ufrac=d['ufrac'],omega=d['omega'],smooth_delta=d['smooth_delta'],seconds=time.time()-t)),flush=True)
(B/f'radial23/m{m}_support_mass.json').write_text(json.dumps(dict(m=m,pbad=pbad,bins=n,amplitude_upper=float(C),removed_mass_upper=[str(cor.numerator),str(cor.denominator)],new_kappa=kp,ufrac=d['ufrac'],omega=d['omega'],smooth_delta=d['smooth_delta'],seconds=time.time()-t),indent=2)+'\n')
