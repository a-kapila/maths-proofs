"""Independent direct modular verification and pair enumeration for new tuples."""
from pathlib import Path
import numpy as np,json,math,time
B=Path(__file__).resolve().parents[1];O=B/'radial23'
def primes(n):
 a=np.ones(n+1,dtype=bool);a[:2]=False
 for p in range(2,math.isqrt(n)+1):
  if a[p]:a[p*p::p]=False
 return np.flatnonzero(a)
def verify(m,path,wp,D):
 t=time.time();a=np.loadtxt(B/path,dtype=np.int64);k=len(a);assert np.all(a[1:]>a[:-1]);w=np.loadtxt(B/wp,dtype=np.int64,delimiter=',',skiprows=1);wd=dict(map(tuple,w));ps=primes(k)
 for p in ps:
  r=int(wd[int(p)]);assert 0<=r<p;assert np.all(a%p!=r),(m,p)
 count=0;pairs=[]
 for i,x in enumerate(a):
  js=np.flatnonzero(a-x>D)
  for j in js:
   assert j>i;pairs.append((int(i),int(j),int(x),int(a[j])));count+=1
  if len(js)==0:break
 row=dict(m=m,k=k,first=int(a[0]),last=int(a[-1]),diameter=int(a[-1]-a[0]),D=D,checked_primes=len(ps),long_pairs=count,verified=True,seconds=time.time()-t)
 (O/f'h{m}_python_verified.json').write_text(json.dumps(row,indent=2)+'\n');print(row,flush=True)
 return row
if __name__=='__main__':
 verify(2,'radial23/h2_candidate.txt','progress/h2_final_witness.csv',19854)
 verify(3,'radial23/h3_tuple.txt','radial23/h3_witness.csv',1358016)
