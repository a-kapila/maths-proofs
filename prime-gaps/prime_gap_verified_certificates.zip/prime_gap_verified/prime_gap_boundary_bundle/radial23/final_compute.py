"""Final m=2 and m=3 computations. Uses only component-wise saved quotients.
All accepted inequalities use exact rational enclosures and explicit strict slack.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,importlib.util,math
import numpy as np
from scipy.optimize import minimize_scalar
B=Path(__file__).resolve().parents[1];O=B/'radial23';sys.path.insert(0,str(O))
import compute23 as base
rad=base.rad;J=base.J

def calculate(m,eta=None):
 if m==2:
  tp=B/'trials/m2_final.json';tr=json.load(open(tp));c=json.load(open(tp.with_suffix('.interval_certificate.json')));su=json.load(open(O/'m2_k2305_support.json'))
  k=2305;rho=F(1,4)+F(tr['omega']);sigma=1+F(tr['delta'])*tr['eps_cells'];q=F(c['Q_lower'])-F(su['restriction']['loss_upper']);srcp=O/'m2_k2305_cell_masses.json';witness='progress/h2_final_witness.csv';extent=1000000
  assert q>F(2)/rho;assert 240*F(tr['omega'])+80*F(tr['smooth_delta'])<3
 else:
  k,rho,sigma,q=base.get_inputs(3);srcp=O/'m3_cell_masses.json';witness='onward/h3_completed_witness.csv';extent=5000000
 src=json.load(open(srcp));assert src['k']==k;rad._CELLS[m]=src;rad._MOM.clear();t=2*rho*sigma
 xx=np.array([float(F(*c['right'])/sigma)for c in src['cells']]);ll=np.array([float(F(*c['mass_lower']))for c in src['cells']]);mask=xx>0;xx=xx[mask];ll=ll[mask];den=float(F(*src['den_upper']));bad=float(F(*src['removed_square_mass_upper']));tf=float(t)
 def obj(e):
  R1=(e/(1-tf))**2;R=(1+(e-1)*xx)/(1-tf*xx);M=R1-((ll*(R1-R*R)/xx).sum()-R1*bad)/den
  return 2*tf*tf*base.jf(k,k*e)*M
 opt=minimize_scalar(obj,bounds=(float(1-t),1.9),method='bounded',options={'xatol':1e-9})
 if eta is None:eta=F(round(float(opt.x)*1000000),1000000)
 mo=rad.radial_moment(m,eta,t);ji=J(k,k*eta);pair=2*t*t*ji.hi*mo['moment_upper'];sur=rho*q-m;ratio=sur/pair;budget=(ratio.numerator-1)//ratio.denominator
 lam=rho-F(1,2**60);b=F(1,2)-F(1,2**60);tt=lam*sigma/b;ms=rad.radial_moment(m,eta,tt);ps=2*tt*tt*ji.hi*ms['moment_upper'];ss=lam*q-m
 w=base.load_witness(witness);a=base.allowed(w,-extent,extent);sub,res=base.choose(a,k,budget)
 for p in base.primes_up_to(k):
  if int(p) not in w:
   missing=np.flatnonzero(np.bincount(sub%p,minlength=int(p))==0);assert len(missing);w[int(p)]=int(missing[0])
 res.update(m=m,cardinality=k,first=int(sub[0]),last=int(sub[-1]),diameter=int(sub[-1]-sub[0]),search_points=len(a),search_range=[-extent,extent],pair_budget=budget)
 cnt=res['long_pairs'];margin=sur-cnt*pair;strict=ss-cnt*ps;assert margin>0 and strict>0
 assert cnt<=budget<res['previous_even_min_count']
 out=dict(selection=res,k=k,m=m,eta=eta,rho=rho,sigma=sigma,quotient_after_support=q,surplus=sur,pair_upper=pair,pair_budget=budget,J_lower=ji.lo,J_upper=ji.hi,radial_moment_upper=mo['moment_upper'],radial_certificate=mo,strict_radial_certificate=ms,strict_pair_upper=ps,margin=margin,strict_margin=strict,cell_mass_source=str(srcp.relative_to(B)),selected_numerator='Inherited component-wise lower bound; no Hilbert alternative used in final results',previous_bound={2:19860,3:1358042}[m])
 np.savetxt(O/f'final_h{m}.txt',sub,fmt='%d');np.savetxt(O/f'final_h{m}_witness.csv',np.array(sorted(w.items())),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
 pairs=base.enumerate_long_pairs(sub,res['D']);assert len(pairs)==cnt
 np.savetxt(O/f'final_h{m}_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
 (O/f'final_m{m}.json').write_text(json.dumps(rad.old.encode(out),indent=2)+'\n')
 print(res,'eta',float(eta),'pair',float(pair),'surplus',float(sur),'margin',float(margin),flush=True)
 return out
if __name__=='__main__':
 for m in map(int,sys.argv[1:]):calculate(m)
