from pathlib import Path
from fractions import Fraction as F
import sys,json,time,math,hashlib
B=Path(__file__).resolve().parents[1];O=B/'radial23'
sys.path[:0]=[str(B/'analysis'),str(B/'rescaled'),str(B/'baseline/inherited/analysis')]
from loss_tagged import restriction_loss
from scaled_slicing import bad_probability,down
from flint import arb,ctx
ctx.prec=256
p=B/'trials/m2_final.json';tr=json.load(open(p));c=json.load(open(p.with_suffix('.interval_certificate.json')));amp=json.load(open(O/'m2_k2305_amplitude.json'));other=json.load(open(B/amp['trial']))
for key in ['k','theta','beta','relative_shift','basis','profiles','E','delta','eps_cells']:assert tr[key]==other[key]
C=F(amp['amplitude_upper']);den=F(c['den_lower']);scaled=den/(C*C);scaledlo=math.nextafter(float(scaled),-math.inf);assert F(scaledlo)<=scaled
rho=arb(1)/4+arb(tr['omega']);eps=tr['delta']*tr['eps_cells'];t=time.time()
loss=restriction_loss(tr['k'],tr['theta'],tr['beta'],tr['smooth_delta'],tr['omega'],scaledlo,eta=1e-8,ufrac=tr['ufrac'],ratio=1.005,sum_cap=1+eps,relative_shift=tr['relative_shift'],inner_cap=1-eps)
kp=down((arb(1)/4+arb(tr['smooth_delta'])/2)/rho-arb('0.0001'));pb,bins=bad_probability(tr,tr['ufrac'],kp);bad=C*C*F(pb)
out=dict(k=tr['k'],amplitude_upper=float(C),amplitude_source='radial23/m2_k2305_amplitude.json',scaled_den_lower=scaledlo,restriction=loss,pbad=pb,pbad_kappa=kp,removed_mass_upper=[str(bad.numerator),str(bad.denominator)],pbad_bins=bins,trial='trials/m2_final.json',quotient_source='trials/m2_final.interval_certificate.json',quotient_lower=c['Q_lower'],seconds=time.time()-t)
(O/'m2_k2305_support.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
