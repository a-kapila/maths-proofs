"""Outward scalar recheck of the inherited Hilbert numerator, not a new Fourier run.
The norm inequality is ||f|| >= max(0,||center||-||radius polynomial||).
Midpoint lower and error upper fields were printed as floats, so widen one ulp.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math,hashlib
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from flint import arb,ctx
from shifted_core import setup
ctx.prec=384
p=B/'focus23/m2_k2304.interval_certificate.json';c=json.load(open(p));t=json.load(open(B/'focus23/m2_k2304.json'))
ml=math.nextafter(c['num_midpoint_lower'],-math.inf);eu=math.nextafter(c['num_error_upper'],math.inf)
gap=arb(ml).sqrt()-arb(eu).sqrt();assert gap>0
nl=math.nextafter(float((gap*gap).lower()),-math.inf)
S=setup(t['k'],t['theta'],t['beta'],t['relative_shift'])
qq=arb(t['k'])/S['m2']*arb(nl)/arb(c['den_upper'])
ql=min(c['Q_lower'],math.nextafter(float(qq.lower()),-math.inf))
assert ql>7.61954692620
out=dict(checked=True,midpoint_norm_squared_lower=ml,error_norm_squared_upper=eu,recomputed_numerator_lower=nl,recomputed_quotient_lower=ql,saved_quotient_lower=c['Q_lower'],source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),precision_bits=ctx.prec,scope='Rechecks scalar Hilbert inequality using saved certified norms, with extra directed rounding. Does not recompute the underlying moment integrals.')
(B/'radial23/hilbert_recheck.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)
