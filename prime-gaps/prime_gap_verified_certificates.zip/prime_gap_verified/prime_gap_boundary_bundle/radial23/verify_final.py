"""Recompute accepted scalar/window deductions and independently verify finite data."""
from pathlib import Path
from fractions import Fraction as F
import sys,json,math,hashlib,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'radial23';sys.path.insert(0,str(O))
from final_compute import calculate
from compute23 import rad

def prime_list(n):
 a=np.ones(n+1,dtype=bool);a[:2]=False
 for p in range(2,math.isqrt(n)+1):
  if a[p]:a[p*p::p]=False
 return np.flatnonzero(a)

def run(args,filename):
 z=subprocess.run([str(a)for a in args],cwd=B,check=True,text=True,capture_output=True);(O/filename).write_text(z.stdout);return json.loads(z.stdout)
for src,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
 subprocess.run(['g++','-O3','-std=c++17',str(B/src),'-o',str(O/name)],check=True)
rows=[]
for m in [2,3]:
 p=O/f'final_m{m}.json';old=json.load(open(p));eta=F(int(old['eta']['numerator']),int(old['eta']['denominator']))
 v=calculate(m,eta);assert rad.old.encode(v)==old
 assert v['margin']>0 and v['strict_margin']>0
 row=dict(v['selection']);D=row['D'];k=row['cardinality'];ap=O/f'final_h{m}.txt';wp=O/f'final_h{m}_witness.csv'
 cv=run([O/'verify_tuple',ap,wp,k],f'final_h{m}_cpp_verified.json');cp=run([O/'check_pairs','tuple',ap,D],f'final_h{m}_cpp_pairs.json')
 a=np.loadtxt(ap,dtype=np.int64);assert len(a)==k and np.all(a[1:]>a[:-1]);w=dict(map(tuple,np.loadtxt(wp,dtype=np.int64,delimiter=',',skiprows=1)))
 ps=prime_list(k)
 for prime in ps:
  assert 0<=w[int(prime)]<prime and np.all(a%prime!=w[int(prime)]),(m,prime)
 pairs=[]
 for i,x in enumerate(a):
  js=np.flatnonzero(a-x>D)
  for j in js:
   assert j>i;pairs.append((i,int(j),int(x),int(a[j]),int(a[j]-x)))
  if not len(js):break
 saved=np.loadtxt(O/f'final_h{m}_long_pairs.csv',dtype=np.int64,delimiter=',',skiprows=1).reshape(-1,5)
 assert np.array_equal(np.array(pairs,dtype=np.int64).reshape(-1,5),saved)
 assert cp['long_pairs']==len(pairs)==row['long_pairs'];assert cv['verified'] and cv['checked_primes']==len(ps)
 cell=json.load(open(B/v['cell_mass_source']))
 for name,sha in cell['sources'].items():assert hashlib.sha256((B/name).read_bytes()).hexdigest()==sha,name
 py=dict(verified=True,k=k,checked_primes=len(ps),long_pairs=len(pairs),first=int(a[0]),last=int(a[-1]),D=D)
 (O/f'final_h{m}_python_verified.json').write_text(json.dumps(py,indent=2)+'\n')
 row.update(previous_bound=v['previous_bound'],improvement=v['previous_bound']-D,quotient_after_support=float(v['quotient_after_support']),weighted_prime_count_surplus=float(v['surplus']),pair_upper=float(v['pair_upper']),radial_moment_upper=float(v['radial_moment_upper']),eta=float(v['eta']),strict_margin=float(v['strict_margin']),margin=float(v['margin']),checked_primes=len(ps),tuple_sha256=hashlib.sha256(ap.read_bytes()).hexdigest())
 assert row['improvement']>0;rows.append(row);print('VERIFIED',row,flush=True)
res=dict(status='passed',bounds={'H2':rows[0]['D'],'H3':rows[1]['D'],'H4':82234788,'H5':4830355416},results=rows,scope='Fresh tagged Fourier distributions for H2 and H3; fresh H2 amplitude and support-loss bounds; inherited component-wise quotient certificates and sieve arguments. Both complete tuple checks and independent pair counts pass. No new successful quotient integration, smaller-dimensional DHL statement, external peer review, or global optimality claim.')
(O/'RESULTS.json').write_text(json.dumps(res,indent=2)+'\n')
