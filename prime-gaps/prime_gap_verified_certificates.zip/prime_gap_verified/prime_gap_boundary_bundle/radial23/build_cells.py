from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1]
def build(m):
 tp=B/('focus23/m3_fine.json' if m==3 else 'focus23/m2_k2304.json')
 tr=json.load(open(tp));cert=json.load(open(tp.with_suffix('.interval_certificate.json')))
 me=json.load(open(B/f'continuation/new_m{m}_r1.json'));z=np.load(B/f'continuation/new_m{m}_r1_cdf.npz')
 su=json.load(open(B/f'radial23/m{m}_support_mass.json'))
 keys=[tuple(x) for x in me['moment_keys']]; hs=[[F(v)for v in h]for h in tr['profiles']]; nc=len(hs[0]);co=defaultdict(lambda:[F(0)]*nc)
 for h,bi in zip(hs,tr['basis']):
  for g,bj in zip(hs,tr['basis']):
   key=tuple(sorted(bi+bj));co[key]=[a+x*y for a,x,y in zip(co[key],h,g)]
 edges=[F(tr['delta'])*e for e in tr['E']]
 assert all(F(float(v))==e for v,e in zip(z['y'],edges))
 lo=[F(0)]*nc; hi=[F(0)]*nc
 for ri,key in enumerate(keys):
  L=list(map(F,map(float,z['L'][ri])));V=list(map(F,map(float,z['V'][ri])))
  for j,c in enumerate(co[key]):
   ml=max(F(0),L[j+1]-V[j]);mu=V[j+1]-L[j];assert mu>=ml
   if c>=0:lo[j]+=c*ml;hi[j]+=c*mu
   else:lo[j]+=c*mu;hi[j]+=c*ml
 lo=[max(F(0),l)for l in lo];assert all(l<=u for l,u in zip(lo,hi))
 sigma=F(1)+F(tr['delta'])*tr['eps_cells']
 bad=F(*map(int,su['removed_mass_upper']))
 out=dict(m=m,k=tr['k'],sigma=[sigma.numerator,sigma.denominator],den_upper=[F(cert['den_upper']).numerator,F(cert['den_upper']).denominator],removed_square_mass_upper=[bad.numerator,bad.denominator],cells=[dict(left=[l.numerator,l.denominator],right=[r.numerator,r.denominator],mass_lower=[ml.numerator,ml.denominator],mass_upper=[mu.numerator,mu.denominator])for l,r,ml,mu in zip(edges[:-1],edges[1:],lo,hi)],fresh_tagged_CDF=True,tag='S/sigma',sources={str(p.relative_to(B)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [tp,tp.with_suffix('.interval_certificate.json'),B/f'continuation/new_m{m}_r1.json',B/f'continuation/new_m{m}_r1_cdf.npz',B/f'radial23/m{m}_support_mass.json']})
 (B/f'radial23/m{m}_cell_masses.json').write_text(json.dumps(out,indent=2)+'\n')
 print(m,'mean lower',float((sum(lo)-bad)/F(cert['den_upper'])),'bad mass',float(bad),'cell mass lower',float(sum(lo)),flush=True)
if __name__=='__main__':
 for m in map(int,sys.argv[1:]):build(m)
