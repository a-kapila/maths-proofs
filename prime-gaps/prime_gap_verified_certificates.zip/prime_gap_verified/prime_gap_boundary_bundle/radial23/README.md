# Radial pair certificates for H2 and H3 — 5 November 2026

## Authoritative results

`radial23/RESULTS.json` is authoritative for this continuation:

- H2 <= 19,850 (previously 19,860).
- H3 <= 1,358,016 (previously 1,358,042).
- H4 <= 82,234,788 and H5 <= 4,830,355,416 are unchanged and inherited.

These are computer-assisted deductions within the retained sieve framework. They
are not independently peer-reviewed records or proof-assistant formalizations.
The new output is a prime-cluster length, not the diameter of the entire tuple.

## What was actually recomputed

The tagged radial Fourier distributions were evaluated anew at k=2305 and
k=110070. A new mass-aware amplitude bound and tagged-coordinate support-loss
bound were evaluated at k=2305, with geometric ratio 1.005. The successful
unrestricted quotient integrals remain inherited. The final H2 deduction uses
`trials/m2_final.interval_certificate.json`, the original component-wise lower
numerator, NOT its optional Hilbert-space alternative. H3 uses the saved
`focus23/m3_fine.interval_certificate.json` and the inherited retuned support
calculation in `direct_pair/m3_arithmetic.json`.

The final proof is `radial23/proof_note.pdf` (with its TeX source). It applies the
previous radial pair inequality without coordinate slicing. It does not claim a
new smaller-dimensional DHL statement. New Fourier calculations use the retained
mpmath.iv implementation plus explicit remainders, not FLINT/Arb. New scalar
acceptance tests use outward fixed-point rational arithmetic.

## Checks and reproduction

From the archive root:

```sh
bash radial23/reproduce.sh --checks-only
bash radial23/reproduce.sh --full
```

The first repeats signed-CDF post-processing, exact final scalar inequalities,
finite window scans, two separate admissibility checks and pair counts, and
high-precision integral/Fourier diagnostics. It does not recompute the tagged
Fourier coefficients, the amplitude certificate, or support probabilities.

The full command additionally recomputes those new analytic inputs. Neither
command reruns the inherited successful quotient integrations, for which original
reproduction commands remain in earlier directories. Keep C++ assertions enabled.
Python 3, NumPy, SciPy, mpmath and a C++17 compiler are required.

The packaged MANIFEST checks byte integrity. Timing fields change on full reruns;
mathematical endpoint comparisons, not unchanged timing hashes, are the relevant
reproduction check after a full run.

## Successful and supplementary branches

`final_m2.json`, `final_m3.json`, the final tuples/witnesses and `RESULTS.json`
record the successful deductions. `m2_radial_only_no_improvement.json` records the
unsuccessful attempt to use only the newly computed radial estimate at k=2304.
A separately checked Hilbert numerator and finer k=2304 support calculation do
permit an auxiliary bound 19,854. The final 19,850 result instead uses k=2305 and
the smaller, component-wise numerator; it does not depend on that Hilbert branch.
Other candidate files are not final bounds.

The search windows are exhaustive only within two finite residue constructions:
[-1,000,000,1,000,000] for H2 and [-5,000,000,5,000,000] for H3. No global tuple,
variational or terminal optimum is asserted. All original source attribution and
the complete inherited proof/code/data chain are retained.
