"""New radial exponential majorants for the capped-coordinate Laplace transform.
Exploration chooses parameters; certify() recomputes each majorant in interval arithmetic.
"""
from pathlib import Path
import sys, json, math
from fractions import Fraction as F
from collections import defaultdict
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'envelope'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from flint import arb,ctx
from weighted_mgf import truncated_moments
from multi_core import single_moments
from polynomial_core import weights
from shifted_core import setup

def ar(x):
    x=F(x); return arb(x.numerator)/x.denominator

def up(x):return float(np.nextafter(float(x.upper()),np.inf))
def down(x):return float(np.nextafter(float(x.lower()),-np.inf))

class RadialMGF:
    def __init__(self,m):
        self.m=m
        self.tr=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
        self.old=json.load(open(B/f'rescaled/integrated_m{m}.json'))
        tr=self.tr; self.k=tr['k'];self.sig=1+F(tr['delta'])*tr['eps_cells'];self.w=ar(self.sig)/11
        self.S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift'])
        self.dr=arb(self.old['restricted_den_lower'])
        basis=[tuple(x) for x in tr['basis']];nc=len(tr['profiles'][0]);hs=[[F(v) for v in row] for row in tr['profiles']]
        cc=defaultdict(lambda:[F(0)]*nc)
        for a,ma in enumerate(basis):
            for b,mb in enumerate(basis):
                key=tuple(sorted(ma+mb))
                cc[key]=[q+x*y for q,x,y in zip(cc[key],hs[a],hs[b])]
        self.keys=sorted(cc,key=lambda x:(len(x),x));self.jmax=max(map(sum,self.keys))
        self.cf=[[max(F(0),c) for c in cc[key]] for key in self.keys]
        self.c=np.array([[float(c) for c in row] for row in self.cf])
        with np.errstate(divide='ignore'):self.logc=np.log(self.c)
        self.left=[F(tr['delta'])*e for e in tr['E'][:-1]]
        self.right=[F(tr['delta'])*e for e in tr['E'][1:]]
        assert len(self.left)==nc
        self.l=np.array(list(map(float,self.left)));self.r=np.array(list(map(float,self.right)))
        self.full=single_moments(self.S,self.jmax)
        self.low=truncated_moments(self.S,self.jmax,self.w)
        self.tail=[x-y for x,y in zip(self.full,self.low)]
        self.calls=0
    def mu(self,lam,eta):
        # E[(X/T)^p exp(eta X-lambda min(X,w))]
        gap=F(lam)-F(eta)
        low=truncated_moments(self.S,self.jmax,self.w,None if gap==0 else ar(gap))
        if eta==0:tail=self.tail
        else:
            allx=truncated_moments(self.S,self.jmax,self.S['T'],-arb(eta))
            lowx=truncated_moments(self.S,self.jmax,self.w,-arb(eta))
            tail=[x-y for x,y in zip(allx,lowx)]
        ee=(-arb(lam)*self.w).exp()
        mu=[x+ee*y for x,y in zip(low,tail)]
        assert all(x>0 for x in mu),(lam,eta,mu)
        return mu
    def explore(self,lam,eta):
        self.calls+=1
        if lam<=0:return 1e5
        mu=self.mu(float(lam),float(eta));phi=mu[0]
        nu=[x/phi for x in mu];nu[0]=arb(1)
        vv=weights(self.k,nu,self.keys)
        vv=np.array([float(x) for x in vv]);assert np.all(vv>0)
        xends=self.l if eta>=0 else self.r
        b=np.max(self.logc-eta*xends[None,:],axis=1)
        logs=b+np.log(vv);m=float(np.max(logs));s=float(np.sum(np.exp(logs-m)))
        logB=float((self.k*phi.log()-self.dr.log()).mid())+m+math.log(s)
        return logB/(lam*float(self.sig))
    def certify(self,lam,eta):
        mu=self.mu(lam,eta);phi=mu[0];nu=[x/phi for x in mu];nu[0]=arb(1)
        vv=weights(self.k,nu,self.keys)
        ends=self.left if eta>=0 else self.right
        expo=[(-arb(eta)*ar(x)).exp() for x in ends]
        co=[]
        for row in self.cf:
            val=arb(0)
            for c,e in zip(row,expo):
                if c>0:
                    v=(ar(c)*e).upper()
                    if v>val:val=v
            co.append(val)
        bound=sum(c*v for c,v in zip(co,vv))
        logB=self.k*phi.log()+bound.log()-self.dr.log()
        return dict(m=self.m,lambda_value=float(lam),radial_tilt=float(eta),log_B_upper=up(logB),log_B_lower=down(logB),x_lower=down(-logB/(arb(lam)*ar(self.sig))),precision=ctx.prec,coefficients=len(co),method='radial exponential coefficient envelope')

if __name__=='__main__':
    import time
    from scipy.optimize import minimize
    ctx.prec=256
    for m in map(int,sys.argv[1:] or [4,5]):
        t=time.time();f=RadialMGF(m)
        for lam,eta in [(70,0),(70,30),(70,60),(70,-20),(120,70),(200,150)]:
            print('test',m,lam,eta,-f.explore(lam,eta),flush=True)
        res=minimize(lambda x:f.explore(*x),[90.,50.],method='Nelder-Mead',options={'maxiter':150,'xatol':1e-6,'fatol':1e-11})
        print('optimized',m,res.x,-res.fun,'calls',f.calls,'seconds',time.time()-t,flush=True)
        ctx.prec=384;out=f.certify(*map(float,res.x));ctx.prec=256
        (B/f'radial/radial_m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
        print(out,flush=True)
