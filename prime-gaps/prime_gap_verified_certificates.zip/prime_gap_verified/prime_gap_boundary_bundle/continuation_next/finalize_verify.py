"""New fixed-trial quotient, pair-aware witnesses, and complete integer checks.
All acceptance decisions use exact Fractions. Pair/support certificates are
inherited, not re-integrated by this script. Search is unnecessary for verification.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys,hashlib,subprocess,math
import numpy as np
B=Path(__file__).resolve().parents[1];O=Path(__file__).resolve().parent
sys.path.insert(0,str(B/'four_moment'))
import postprocess as pp

def frac(d):
 if isinstance(d,dict):return F(int(d['numerator']),int(d['denominator']))
 return F(d)
def encode(d):
 if isinstance(d,F):return dict(numerator=str(d.numerator),denominator=str(d.denominator),display=float(d))
 if isinstance(d,dict):return {k:encode(v) for k,v in d.items()}
 if isinstance(d,(list,tuple)):return [encode(x) for x in d]
 if isinstance(d,np.integer):return int(d)
 return d
old=json.load(open(B/'four_moment/m3_result.json'))
oldcert=json.load(open(B/'four_moment/m3_quotient_fine.interval_certificate.json'))
cert=json.load(open(O/'m3_finer.interval_certificate.json'))
tr=json.load(open(O/'m3_finer.json'));base_tr=json.load(open(B/'four_moment/m3_quotient_fine.json'))
for key in ['k','m','theta','beta','relative_shift','profiles','basis','smooth_delta','omega','ufrac']:
 assert tr[key]==base_tr[key],key
assert [F(tr['delta'])*x for x in tr['E']]==[F(base_tr['delta'])*x for x in base_tr['E']]
assert F(tr['delta'])*tr['eps_cells']==F(base_tr['delta'])*base_tr['eps_cells']
assert cert['trial_sha256']==hashlib.sha256((O/'m3_finer.json').read_bytes()).hexdigest()
assert cert['den_lower']==oldcert['den_lower'] and cert['den_upper']==oldcert['den_upper']
assert cert['k']==110070 and cert['Q_lower']>oldcert['Q_lower']
assert cert['elapsed']>0 and 'direct_fourier_checks' in cert and 'bitwise_CDF_checks' in cert
rho=frac(old['rho']);sigma=frac(old['sigma']);C=frac(old['pair_upper']);Cs=frac(old['strict_calculation']['pair_upper'])
loss=F(oldcert['Q_lower'])-frac(old['q_lower']);assert loss>0
q=F(cert['Q_lower'])-loss;sur=rho*q-3;ratio=sur/C
budget=(ratio.numerator-1)//ratio.denominator
assert 240*(rho-F(1,4))+80*F(6e-7)<3 and 2*rho*sigma<1
lam=rho-F(1,2**60)
v=pp.hp.inputs(3)
# Reproduce attribution in the original construction and in the new one.
w_old=pp.base.load_witness(v['witness']);a_old=pp.base.allowed(w_old,-v['extent'],v['extent'])
w=pp.base.load_witness(O/'m3_pair_search_witness.csv');a=pp.base.allowed(w,-v['extent'],v['extent'])
old_new,old_new_sel=pp.base.choose(a_old,110070,budget)
new_old,new_old_sel=pp.base.choose(a,110070,old['budget'])
selected,sel=pp.base.choose(a,110070,budget)
K=len(selected);D=sel['D'];cnt=sel['long_pairs']
margin=sur-cnt*C;strict_margin=lam*q-3-cnt*Cs
assert margin>0 and strict_margin>0
np.savetxt(O/'m3_tuple.txt',selected,fmt='%d')
np.savetxt(O/'m3_witness.csv',np.array(sorted(w.items()),dtype=np.int64),fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
pairs=pp.base.enumerate_long_pairs(selected,D);assert len(pairs)==cnt
np.savetxt(O/'m3_long_pairs.csv',pairs,fmt='%d',delimiter=',',header='i,j,hi,hj,separation',comments='')
for source,name in [('baseline/inherited/tuples/verify_tuple.cpp','verify_tuple'),('continuation2/check_pair_counts.cpp','check_pairs')]:
 subprocess.run(['g++','-O3','-std=c++17',str(B/source),'-o',str(O/name)],check=True)
def command(args,name):
 r=subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True,cwd=B)
 (O/name).write_text(r.stdout);return json.loads(r.stdout)
cpp=command([O/'verify_tuple',O/'m3_tuple.txt',O/'m3_witness.csv',K],'m3_cpp_admissibility.json')
cc=command([O/'check_pairs','tuple',O/'m3_tuple.txt',D],'m3_cpp_pairs.json')
# Independent primes and direct reduction (not the witness-progression algorithm).
isp=np.ones(K+1,dtype=bool);isp[:2]=False
for p in range(2,math.isqrt(K)+1):
 if isp[p]:isp[p*p::p]=False
primes=np.flatnonzero(isp)
assert len(selected)==K and np.all(np.diff(selected)>0)
for p in primes:
 assert int(p) in w
 assert 0<=w[int(p)]<p and np.all(selected%p!=w[int(p)])
py_pairs=[]
for i,x in enumerate(selected):
 j=int(np.searchsorted(selected,int(x)+D,side='right'))
 for t in range(j,K):py_pairs.append((i,t,int(x),int(selected[t]),int(selected[t]-x)))
assert np.array_equal(np.array(py_pairs,dtype=np.int64).reshape(-1,5),pairs)
assert cpp['verified'] and cpp['checked_primes']==len(primes) and cc['long_pairs']==cnt
row=dict(status='passed',bounds={'H2':19844,'H3':D,'H4':82234788,'H5':4830355416},
 previous_H3=1357812,reduction=1357812-D,k=K,first=int(selected[0]),last=int(selected[-1]),
 tuple_diameter=int(selected[-1]-selected[0]),selection=sel,
 old_Q_lower=F(oldcert['Q_lower']),new_Q_lower=F(cert['Q_lower']),inherited_support_loss=loss,
 rho=rho,sigma=sigma,q_lower=q,surplus=sur,pair_upper=C,strict_pair_upper=Cs,
 ratio=ratio,budget=budget,actual_pairs=cnt,margin=margin,strict_margin=strict_margin,
 primes_checked=len(primes),allowed_integers=len(a),
 new_quotient_old_witnesses=old_new_sel,old_quotient_new_witnesses=new_old_sel,
 tuple_sha256=hashlib.sha256((O/'m3_tuple.txt').read_bytes()).hexdigest(),
 inherited_pair_source='four_moment/m3_result.json',new_quotient_source='continuation_next/m3_finer.interval_certificate.json',
 scope='Fresh quotient evaluation of the unchanged physical H3 trial; new pair-aware integer search and independent complete finite checks. Pair and support-loss inputs and sieve/error proofs inherited.')
(O/'RESULTS.json').write_text(json.dumps(encode(row),indent=2)+'\n')
print(json.dumps({k:encode(row[k]) for k in ['status','bounds','reduction','new_Q_lower','budget','actual_pairs','margin','strict_margin','first','last','selection','new_quotient_old_witnesses','old_quotient_new_witnesses','primes_checked']}),flush=True)
