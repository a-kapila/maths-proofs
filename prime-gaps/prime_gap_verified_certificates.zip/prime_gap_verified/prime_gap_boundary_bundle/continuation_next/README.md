# Finer H3 quotient and pair-aware tuple selection

Within the inherited analytic and numerical-enclosure framework, the new result is
**H3 <= 1,357,780**, improving the preceding 1,357,812 by 32.
H2 <= 19,844, H4 <= 82,234,788, and H5 <= 4,830,355,416 are unchanged.

The authoritative current result file is `continuation_next/RESULTS.json`.
Older results elsewhere in this cumulative archive are historical dependencies.

## What was computed in this continuation

* A fresh evaluation of the identical physical 110,070-dimensional H3 trial,
  halving the integration spacing from 2^-25 to 2^-26. The unrestricted quotient
  lower endpoint increased from 11.428871133926435 to 11.428883229766504.
* Pair-count-directed missing-residue changes, preserving admissibility and
  cardinality. The heuristic search is not an infeasibility or optimality proof.
* Exact rational acceptance inequalities, window selection, two independent
  complete admissibility checks, and independent enumeration of every long pair.
* Two unsuccessful H2 arithmetic-support tests, recorded separately. No H2
  improvement follows. Plateau searches also made no additional improvement.

The fresh quotient run completed 94 integration blocks, 36 positive weighted
CDFs, 1,522 positive Fourier frequencies, 108 high-precision direct Fourier checks,
and 6,006 comparisons against the full-grid interpolant. Its denominator bounds
are exactly the preceding saved bounds. Physical trial equality is checked with
exact fractions. The existing arithmetic support loss and pair upper bound are
reused, not recomputed or improved here.

## Final finite data

The selected admissible tuple has 110,070 entries, endpoints -627,106 and 731,876,
and full diameter 1,358,982. It has 3,639 long pairs at span D = 1,357,780.
The inherited pair constant and new quotient permit 3,640 pairs. The sufficient
prime-count margin is greater than 3.0022e-8 and remains positive with the
inherited explicit strict-support choices.

The search set consists of all permitted integers in [-5,000,000,5,000,000]
under the new explicit missing-residue witnesses: 574,548 permitted integers,
464,479 consecutive windows. At D-2 its minimum long-pair count is 3,658.
This is a statement only about this finite construction and sufficient criterion.

Attribution: new quotient with old witnesses gives 1,357,788; new witnesses with
old quotient give 1,357,802; combining the two gives 1,357,780. Therefore the
sequential savings are 24 from the quotient and a further 8 from the witnesses.
The pair upper constant itself did not change.

## Reproduction

From the cumulative archive root:

```bash
bash continuation_next/reproduce.sh --checks-only
bash continuation_next/reproduce.sh --full
```

The first verifies the parent and new manifests, exact identities, preserved trial,
scalar deductions, all relevant primes, and explicit long-pair lists. It compares
all final mathematical result fields to the saved JSON. The second first rebuilds
the numerical kernels and recomputes the new Fourier quotient. It does not rerun
every inherited numerical or analytic dependency. Prior reproduction commands
remain in the corresponding earlier directories.

Dependencies: Python 3, NumPy, SciPy, mpmath, and a C++17 compiler with OpenMP.
Do not disable assertions or enable fast-math/FMA contraction for the numerical
kernels. Full integration uses several GB of memory and temporary working storage.
Reconstructible primitive-table binary files and compiled programs are omitted.

`pair_exchange.cpp` and `pair_exchange_plateau.cpp` are optional heuristic search
programs. Verification uses the fixed witnesses and does not rerun random search.
`h2_parameter_probe.json` contains unsuccessful upper-loss enclosures; they are
not impossibility results and are not used in any successful bound.

## Status and limitations

This is a computer-assisted research deduction, not an independently peer-reviewed
record or formalized proof. The retained prime-distribution theorem, enlarged-
support implication, support-loss and pair arguments, Fourier and rounding error
analysis, and stated arithmetic model remain dependencies. The scalar compatibility
backend is mpmath.iv with explicit remainders, not FLINT/Arb. Independent finite
integer checks do not constitute an expert audit of the analytic chain.
No smaller-dimensional DHL statement, global tuple optimum, terminal bound,
H1 improvement, new distribution exponent, or publication-priority claim is made.
