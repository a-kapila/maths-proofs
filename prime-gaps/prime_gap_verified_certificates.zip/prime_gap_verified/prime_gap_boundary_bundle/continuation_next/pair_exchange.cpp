#include <bits/stdc++.h>
using namespace std;
// Heuristic discovery only. Each output has explicit complete residue witnesses.
// One move changes one forbidden residue, preserving the allowed-set cardinality.
long long edges(const vector<int>& a,int D) {
 long long e=0; int n=a.size();
 for(int i=0;i<n && a[i]+D<a.back();++i)
   e+=a.end()-upper_bound(a.begin(),a.end(),a[i]+D);
 return e;
}
int main(int argc,char**argv){
 if(argc<8){cerr<<"tuple witnesses K D seconds seed prefix\n";return 2;}
 int K=stoi(argv[3]),D=stoi(argv[4])/2; double sec=stod(argv[5]);mt19937 rng(stoul(argv[6]));string out=argv[7];
 vector<long long> input; long long h; ifstream tin(argv[1]);while(tin>>h)input.push_back(h);
 if((int)input.size()!=K)throw runtime_error("cardinality");long long L=input.front();int N=(input.back()-L)/2+1;
 vector<int> ps,rr,ar;string s;ifstream wi(argv[2]);getline(wi,s);
 while(getline(wi,s)){replace(s.begin(),s.end(),',',' ');istringstream z(s);int p,r;if(!(z>>p>>r))continue;if(p>K)continue;
 ps.push_back(p);rr.push_back(r);int c=0;if(p>2){long long u=(r-L)%p;if(u<0)u+=p;c=(u*((p+1)/2))%p;} ar.push_back(c);}
 vector<int> cover(N,0);for(int j=0;j<(int)ps.size();j++)if(ps[j]>2)for(int t=ar[j];t<N;t+=ps[j])cover[t]++;
 vector<int>A;for(int x=0;x<N;x++)if(cover[x]==0)A.push_back(x);
 if(A.size()!=input.size()){cerr<<"Allowed size "<<A.size()<<" versus tuple "<<input.size()<<"\n";return 3;}
 for(int j=0;j<K;j++)if(L+2LL*A[j]!=input[j])throw runtime_error("initial mismatch");
 long long cur=edges(A,D),best=cur;int moves=0,improves=0,sweeps=0;
 auto start=chrono::steady_clock::now();auto elapsed=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 auto save=[&](){ofstream t(out+"_tuple.txt");for(int x:A)t<<L+2LL*x<<"\n";ofstream w(out+"_witness.csv");w<<"prime,missing_residue\n";for(int j=0;j<(int)ps.size();j++){long long r=(L+2LL*ar[j])%ps[j];if(r<0)r+=ps[j];if(ps[j]==2)r=1;w<<ps[j]<<","<<r<<"\n";}
 ofstream meta(out+".json");meta<<"{\"K\":"<<K<<",\"D\":"<<2*D<<",\"long_pairs\":"<<best<<",\"moves\":"<<moves<<",\"improving_moves\":"<<improves<<",\"elapsed\":"<<elapsed()<<"}\n";};
 save();cerr<<"initial pairs="<<cur<<"\n";
 vector<int> order(ps.size());iota(order.begin(),order.end(),0);vector<int>occ(K+1),candidates;vector<long long>degSum(K+1);
 while(elapsed()<sec){shuffle(order.begin(),order.end(),rng);sweeps++;
 for(int j:order){if(elapsed()>=sec)break;int p=ps[j];if(p<=2)continue;
 vector<int> extras;for(int t=ar[j];t<N;t+=p)if(cover[t]==1)extras.push_back(t);
 int nadd=extras.size();if(!nadd)continue;
 for(int t=ar[j];t<N;t+=p)cover[t]--;
 vector<int>T;T.reserve(K+nadd);merge(A.begin(),A.end(),extras.begin(),extras.end(),back_inserter(T));
 fill(occ.begin(),occ.begin()+p,0);fill(degSum.begin(),degSum.begin()+p,0);candidates.clear();
 for(int x:T)occ[x%p]++;
 long long ET=0;int nt=T.size();
 for(int i=0;i<nt;i++){
  int x=T[i]; if(x+D>=T.back() && x-D<=T.front())continue;
  long long dg=(lower_bound(T.begin(),T.end(),x-D)-T.begin())+(T.end()-upper_bound(T.begin(),T.end(),x+D));
  if(dg){int r=x%p;if(degSum[r]==0)candidates.push_back(r);degSum[r]+=dg;ET+=dg;}
 }
 ET/=2;long long minE=cur;vector<int>choices;
 for(int r:candidates){if(r==ar[j]||occ[r]!=nadd)continue;
  vector<int> removed;for(int x=r;x<N;x+=p)if(!cover[x])removed.push_back(x);
  if((int)removed.size()!=nadd)throw runtime_error("occupancy mismatch");
  long long er=edges(removed,D),e=ET-degSum[r]+er;
  if(e<minE){minE=e;choices.clear();choices.push_back(r);}else if(e==minE)choices.push_back(r);
 }
 bool take=!choices.empty()&&(minE<cur||rng()%8==0);
 if(take){int r=choices[rng()%choices.size()];ar[j]=r;A.clear();for(int x:T)if(x%p!=r)A.push_back(x);if((int)A.size()!=K)throw runtime_error("move cardinality");cur=minE;moves++;
  if(cur<best){best=cur;improves++;save();cerr<<"best="<<best<<" prime="<<p<<" add="<<nadd<<" seconds="<<elapsed()<<"\n";}
 }
 for(int t=ar[j];t<N;t+=p)cover[t]++;
 }
 cerr<<"sweep="<<sweeps<<" pairs="<<cur<<" best="<<best<<" moves="<<moves<<" seconds="<<elapsed()<<"\n";
 }
 cerr<<"done best="<<best<<"\n";
}
