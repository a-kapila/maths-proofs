"""Exact diagnostics for the integer objective and preserved physical trial."""
from pathlib import Path
from fractions import Fraction as F
import json,random,itertools
O=Path(__file__).resolve().parent;B=O.parent
r=random.Random(410314);cases=0
for _ in range(2000):
 T=sorted(r.sample(range(-80,81),r.randrange(3,35)))
 D=r.randrange(0,120);R=set(r.sample(T,r.randrange(len(T)+1)))
 edge=lambda A:sum(y-x>D for x,y in itertools.combinations(sorted(A),2))
 degrees={x:sum(abs(x-y)>D for y in T) for x in T}
 assert edge(set(T)-R)==edge(T)-sum(degrees[x] for x in R)+edge(R)
 cases+=1
tr=json.load(open(O/'m3_finer.json'));old=json.load(open(B/'four_moment/m3_quotient_fine.json'))
assert F(tr['delta'])*2==F(old['delta'])
assert [F(tr['delta'])*v for v in tr['E']]==[F(old['delta'])*v for v in old['E']]
assert F(tr['delta'])*tr['eps_cells']==F(old['delta'])*old['eps_cells']
for k in ['k','theta','beta','relative_shift','basis','profiles']:
 assert tr[k]==old[k]
out={'status':'passed','exact_pair_deletion_identities':cases,'exact_physical_trial_equality':True}
(O/'math_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
