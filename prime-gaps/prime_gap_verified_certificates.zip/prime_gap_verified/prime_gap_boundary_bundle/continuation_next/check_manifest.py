from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent;B=O.parent
m=json.load(open(O/'MANIFEST.json'))
for path,want in m['sha256'].items():
 p=B/path
 assert p.is_file(),path
 assert hashlib.sha256(p.read_bytes()).hexdigest()==want,path
print(f"NEW MANIFEST PASS: {len(m['sha256'])} files")
