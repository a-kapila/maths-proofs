from pathlib import Path
import sys,json,time,math
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'analysis'),str(B/'rescaled'),str(B/'baseline/inherited/analysis')]
from loss_tagged import restriction_loss
from flint import ctx
ctx.prec=256
t=json.load(open(B/'trials/m2_final.json'));ref=json.load(open(B/'radial23/m2_k2305_support.json'))
out=[]
for delta in [2.5e-5,2e-5]:
 start=time.time();omega=.0125-delta/3-1e-9
 r=restriction_loss(t['k'],t['theta'],t['beta'],delta,omega,ref['scaled_den_lower'],eta=1e-8,ufrac=t['ufrac'],ratio=1.03,sum_cap=1+t['delta']*t['eps_cells'],relative_shift=t['relative_shift'],inner_cap=1-t['delta']*t['eps_cells'])
 row=dict(delta=delta,omega=omega,restriction=r,seconds=time.time()-start)
 out.append(row);print(json.dumps(row),flush=True)
 (B/'continuation_next/h2_parameter_probe.json').write_text(json.dumps(out,indent=2)+'\n')
