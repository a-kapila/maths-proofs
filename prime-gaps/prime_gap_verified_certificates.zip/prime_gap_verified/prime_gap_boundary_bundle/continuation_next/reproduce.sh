#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mode="${1:---checks-only}"
case "$mode" in --checks-only|--full);; *) echo 'usage: bash continuation_next/reproduce.sh [--checks-only|--full]' >&2; exit 2;; esac
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 PYTHONUNBUFFERED=1
python four_moment/check_manifest.py
python continuation_next/check_manifest.py
if [[ "$mode" == "--full" ]]; then
 g++ -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
 g++ -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off progress/profile_parallel.cpp -o progress/profile_parallel.so
 g++ -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
 python continued/run_quotient.py continuation_next/m3_finer.json
fi
python continuation_next/check_math.py
python - <<'PY'
from pathlib import Path
import json,subprocess
p=Path('continuation_next/RESULTS.json');saved=json.loads(p.read_text())
subprocess.run(['python','continuation_next/finalize_verify.py'],check=True)
assert json.loads(p.read_text())==saved,'Recomputed mathematical fields differ'
print('PASS: all final mathematical result fields reproduced exactly')
PY
