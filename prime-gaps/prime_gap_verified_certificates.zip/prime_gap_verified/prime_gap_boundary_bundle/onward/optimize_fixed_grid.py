"""Floating-point exploratory Rayleigh-Ritz experiments, NOT certificates.
Basis monomials are tuples: (2,2) means Z_2^2, () means 1.
Joint moments use exact set-partition identities, evaluated in binary64.
"""
import sys,json,time,itertools,math
from pathlib import Path
from functools import lru_cache
import numpy as np
from scipy.special import roots_legendre, exp1
from scipy.interpolate import CubicSpline
from scipy.linalg import eigh
ROOT=Path(__file__).resolve().parents[1]/'baseline'/'inherited'
sys.path[:0]=[str(ROOT/'search'),str(ROOT/'analysis')]
from stable_model import Model
from explore_lifted import tables

@lru_cache(None)
def partitions(items):
 if not items:return ((),)
 x,*rest=items;out=[]
 for part in partitions(tuple(rest)):
  out.append(((x,),)+part)
  for j in range(len(part)):
   out.append(part[:j]+((x,)+part[j],)+part[j+1:])
 return tuple(out)

def poly_integrals(xi,T,jmax):
 z=1j*np.asarray(xi)*T;out=np.empty((jmax+1,len(z)),complex)
 high=np.abs(z)>=32
 zz=z[high];ez=np.exp(zz)
 out[0,high]=np.expm1(zz)/zz
 for j in range(1,jmax+1):out[j,high]=ez/zz-j*out[j-1,high]/zz
 u,w=roots_legendre(96);u=(u+1)/2;w=w/2
 ez=np.exp(u[:,None]*z[None,~high])
 for j in range(jmax+1):out[j,~high]=(w*u**j)@ez
 for j in range(jmax+1):out[j]*=T**(j+1)
 return out

def joint_transforms(M,n,keys):
 jm=max(map(sum,keys));xi=2*np.pi*np.arange(M.J+1)/M.P
 P=poly_integrals(xi,M.T,jm);J=np.empty_like(P);K=np.empty_like(P)
 c,b,T,A=M.c,M.b,M.T,M.A;u=c+b*T
 J[0,0]=np.log(u/c)/b;K[0,0]=(1/c-1/u)/b
 aa=xi[1:]/b;J[0,1:]=np.exp(-1j*aa*c)*(exp1(-1j*aa*c)-exp1(-1j*aa*u))/b
 K[0,1:]=(1/c-np.exp(1j*xi[1:]*T)/u)/b+1j*xi[1:]/b*J[0,1:]
 for j in range(1,jm+1):
  J[j]=P[j-1]/b-c/b*J[j-1];K[j]=J[j-1]/b-c/b*K[j-1]
 mu={j:(K[j]+2*A*J[j]+A*A*P[j])/(M.m2*T**j) for j in range(1,jm+1)}
 ph={r:np.exp((n-r)*M.logphi) for r in range(1+max(map(len,keys)))}
 out=[]
 for key in keys:
  v=np.zeros(M.J+1,complex)
  for part in partitions(key):
   r=len(part);coeff=math.prod(n-i for i in range(r));term=coeff*ph[r]
   for block in part:term=term*mu[sum(block)]
   v+=term
  out.append(v)
 return np.array(out)

@lru_cache(None)
def marginal_terms(mon):
 counts={}
 for mask in range(2**len(mon)):
  keep=tuple(mon[j] for j in range(len(mon)) if not (mask>>j)&1)
  power=sum(mon[j] for j in range(len(mon)) if (mask>>j)&1)
  counts[keep,power]=counts.get((keep,power),0)+1
 return tuple((ke,pw,ct) for (ke,pw),ct in counts.items())

def optimize(d,basis,ncell=160,N=2**18,ng=28,spacing=2**-22,tol=1e-12):
 start=time.time();k,th,be,rel=d['k'],d['theta'],d['beta'],d['relative_shift'];eps=d['delta']*d['eps_cells']
 A=rel/(th/np.log(k)+(k-1)*be/np.log(k));M=Model(k,th,be,A=A,N=N,P=16)
 basis=tuple(tuple(sorted(x)) for x in basis);nb=len(basis)
 needed={tuple(sorted(a+b)) for a in basis for b in basis}
 for a in basis:
  for b in basis:
   for aa,_,_ in marginal_terms(a):
    for bb,_,_ in marginal_terms(b):needed.add(tuple(sorted(aa+bb)))
 keys=sorted(needed,key=lambda x:(len(x),x));ki={key:i for i,key in enumerate(keys)}
 _,cs=tables(M,joint_transforms(M,k,keys));dens,_=tables(M,joint_transforms(M,k-1,keys));s=np.arange(N)*M.h
 s0=s[np.searchsorted(cs[ki[()],:N//8],1e-8)];ec=round(eps/spacing);one=round(1/spacing)
 E=np.rint(np.array(d['E'][1:])*d['delta']/spacing).astype(np.int64);ed=E*spacing;nc=len(E)-1
 DD=np.diff(CubicSpline(s[:N//8+1],cs[:,:N//8+1].T)(ed),axis=0).T
 cov=np.zeros((nc,nb,nb))
 for a in range(nb):
  for b in range(nb):cov[:,a,b]=DD[ki[tuple(sorted(basis[a]+basis[b]))]]
 eig,V=np.linalg.eigh(cov);keep=eig>np.max(eig)*tol
 w=np.where(keep,1/np.sqrt(np.maximum(eig,1e-300)),0);W=V*w[:,None,:]
 Wbig=np.zeros((nb*nc,nb*nc));idx=np.arange(nc)
 for a in range(nb):
  for b in range(nb):Wbig[idx+a*nc,idx+b*nc]=W[:,a,b]
 f=CubicSpline(s[:N//8+1],dens[:,:N//8+1].T)
 lo=max(0.,ed[0]-M.T);hi=(one-ec)*spacing
 cuts=np.unique(np.r_[lo,hi,ed[(ed>lo)&(ed<hi)],(ed-M.T)[(ed-M.T>lo)&(ed-M.T<hi)]])
 u,w=roots_legendre(ng);u=(u+1)/2;w=w/2;widths=np.diff(cuts)
 nodes=(cuts[1:,None]-widths[:,None]*u[None,:]**2).ravel();weights=(widths[:,None]*2*u[None,:]*w[None,:]).ravel()
 fs=f(nodes).T*weights;Bmat=np.zeros((nb*nc,nb*nc));maxpow=max(map(sum,basis))
 for j in range(0,len(nodes),1500):
  yy=np.clip(ed[:,None]-nodes[None,j:j+1500],0,M.T);GG={0:np.diff(M.Gt(yy),axis=0)}
  Jcur=np.log1p(M.b*yy/M.c)/M.b
  for p in range(1,maxpow+1):
   Jcur=yy**p/(p*M.b)-M.c/M.b*Jcur
   GG[p]=np.diff((Jcur+M.A*yy**(p+1)/(p+1))/M.T**p,axis=0)
  for a in range(nb):
   for b in range(a,nb):
    block=np.zeros((nc,nc))
    for aa,p,ca in marginal_terms(basis[a]):
     for bb,q,cb in marginal_terms(basis[b]):
      block+=ca*cb*(GG[p]*fs[ki[tuple(sorted(aa+bb))],j:j+1500])@GG[q].T
    Bmat[a*nc:(a+1)*nc,b*nc:(b+1)*nc]+=block
    if a!=b:Bmat[b*nc:(b+1)*nc,a*nc:(a+1)*nc]+=block.T
 B=Wbig.T@Bmat@Wbig;lam,Vv=eigh(B,subset_by_index=[nb*nc-1,nb*nc-1]);h=Wbig@Vv[:,0];h/=max(abs(h));h=np.rint(h*2**40)/2**40
 hv=h.reshape(nb,nc).T;den=np.einsum('ia,iab,ib',hv,cov,hv);Q=k/M.m2*(h@Bmat@h)/den
 return dict(k=k,theta=th,beta=be,relative_shift=rel,eps_cells=ec,delta=spacing,E=np.r_[0,E].tolist(),basis=basis,profiles=[np.r_[0,h[a*nc:(a+1)*nc]].tolist() for a in range(nb)],Q_exploratory=float(Q),den=float(den),ncell=ncell,N=N,ng=ng,tol=tol,seconds=time.time()-start,min_cov_eigen=float(np.min(eig)))

if __name__=='__main__':
 B=Path(__file__).resolve().parents[1]
 d=json.load(open(B/'focus23/m2_k2304.json'));d['k']=2303
 basis=[(),(2,),(3,),(4,),(2,2),(2,3)]
 r=optimize(d,basis,ncell=600,N=2**19,ng=40,spacing=2**-23,tol=1e-12)
 out={**d,**r};out['status']='exploratory only, not interval-certified'
 (B/'onward/m2_fixed_grid_k2303.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in r.items() if k not in ['E','profiles']}),flush=True)
