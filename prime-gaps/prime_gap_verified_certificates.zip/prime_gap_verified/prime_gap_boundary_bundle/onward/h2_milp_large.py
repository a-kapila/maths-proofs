"""Feasible-tuple search only. Solver outcomes are not impossibility certificates."""
from pathlib import Path
import json,sys,time,math
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
B=Path(__file__).resolve().parents[1];O=B/'onward'
def run(R=24,shift=0,width=19858,seconds=100):
 t=time.time();K=2304;raw=np.loadtxt(B/'advance/h2_final.csv',dtype=np.int64);raw=raw-raw[0]-shift;A=raw[(raw>=0)&(raw<=width)]//2;N=width//2+1
 sv=np.ones(K+1,bool);sv[:2]=False
 for p in range(2,math.isqrt(K)+1):
  if sv[p]:sv[p*p::p]=False
 ps=np.flatnonzero(sv)[1:];eligible={};ok=np.ones(N,bool)
 for p0 in ps:
  p=int(p0);co=np.bincount(A%p,minlength=p);r=np.flatnonzero(co<=R);eligible[p]=r
  if len(r)==1:ok[r[0]::p]=False
 U=np.flatnonzero(ok);uid={int(x):i for i,x in enumerate(U)};active=[];cntY=0
 for p0 in ps:
  p=int(p0);co=np.bincount(U%p,minlength=p)
  if np.any(co==0):continue
  rs=eligible[p];active.append((p,rs));cntY+=len(rs)
 nv=len(U)+cntY;rr=[];cc=[];vv=[];lower=[];upper=[]
 def row(idx,val,lo,hi):
  n=len(lower);rr.extend([n]*len(idx));cc.extend(idx);vv.extend(val);lower.append(lo);upper.append(hi)
 # Keep the cropped parent feasible: optimize toward 2304 rather than impose it.
 ai=[uid[int(a)] for a in A];row(ai,[1]*len(ai),len(A)-R,np.inf)
 y=len(U)
 for p,rs in active:
  yi=list(range(y,y+len(rs)));row(yi,[1]*len(yi),1,1)
  for r in rs:
   for x in range(int(r),N,p):
    if x in uid:row([uid[x],y],[1,1],-np.inf,1)
   y+=1
 M=coo_matrix((vv,(rr,cc)),shape=(len(lower),nv)).tocsc();objective=np.zeros(nv);objective[:len(U)]=-1
 print(json.dumps(dict(stage='model',R=R,shift=shift,universe=len(U),active_primes=len(active),variables=nv,rows=len(lower))),flush=True)
 opts={'time_limit':seconds,'mip_rel_gap':0.,'presolve':True,'disp':True,'threads':1}
 res=milp(objective,integrality=np.ones(nv),bounds=Bounds(0,1),constraints=LinearConstraint(M,lower,upper),options=opts)
 rec=dict(R=R,shift=shift,width=width,seconds=time.time()-t,status=int(res.status),message=res.message,success=False)
 if res.x is not None:
  a=2*U[res.x[:len(U)]>.5];rec['cardinality']=len(a);W=[(2,1)]
  for p0 in ps:
   p=int(p0);miss=np.flatnonzero(np.bincount(a%p,minlength=p)==0)
   assert len(miss)>0
   W.append((p,int(miss[0])))
  if len(a)>=K:
   j=int(np.argmin(a[K-1:]-a[:len(a)-K+1]));a=a[j:j+K];rec['success']=True;rec['diameter']=int(a[-1]-a[0])
  pref=O/f'h2_milp_large_{R}_{shift}'
  np.savetxt(str(pref)+'.csv',a,fmt='%d');np.savetxt(str(pref)+'_witness.csv',W,fmt='%d',delimiter=',',header='prime,missing_residue',comments='')
 print(json.dumps(rec),flush=True);(O/f'h2_milp_large_{R}_{shift}.json').write_text(json.dumps(rec,indent=2));return rec
if __name__=='__main__':run(int(sys.argv[1]),int(sys.argv[2]) if len(sys.argv)>2 else 0,seconds=float(sys.argv[3]) if len(sys.argv)>3 else 100)
