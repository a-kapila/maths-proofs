# Arithmetic retuning: current continuation

The authoritative new result is `DHL[110037,4]`, yielding `H3 <= 1358342`.
The preceding bound was 1358360; the reduction is 18. H2 = 19860,
H4 = 82258490 and H5 = 4831230984 remain inherited and unchanged.
These are computer-assisted deductions within the inherited sieve/error framework,
not independent expert verification, formal proofs, or published-record claims.

## Reproduce

From the archive root:

```bash
bash onward/reproduce.sh --checks-only
bash onward/reproduce.sh --full
```

The first command compiles the integer verifier, compares the new blockwise primitive
construction with the previous implementation, checks exact profile identities and
rational endpoint implications, and verifies both the new H3 and inherited H2 tuple
with independent C++ and Python algorithms. The second additionally recomputes the
fresh unrestricted quotient and arithmetic support-loss sweep. It does not rerun all
inherited numerical certificates. Their sources and reproduction commands are retained.

Dependencies: Python 3 with NumPy, SciPy and mpmath; a C++17 compiler with OpenMP.
Keep assertions enabled. The selected calculation uses several GB of working disk
storage for reconstructible memory-mapped primitive tables. These tables are excluded
from the archive. Remove `onward/primitive_*` directories after evaluations to recover
that space. No downloaded binaries are required for the selected reproduction path.

## How the final certificate is assembled

1. `m3_k110037.json` defines the exact unrestricted function. Its six signed profiles
   and physical boundaries are inherited; its dimension is 110037 and the integration
   step is 2^-26. It retains the old delta_s and omega in its metadata.
2. `m3_k110037.interval_certificate.json` is the completed fresh Fourier/integration
   evaluation. Its lower quotient is 11.428585924609166. At the old arithmetic
   parameters it fails the sufficient inequality by approximately 5.999e-8.
3. `retune_arithmetic.py` keeps this unrestricted function fixed and recomputes the
   support-loss bound at six alternative arithmetic parameter pairs. The selected pair
   is delta_s = 6e-7, omega = 0.012499799999, interpreted as exact binary64 inputs.
4. `selected_arithmetic.json` supplies the freshly computed loss upper endpoint
   2.344821387468247e-46. The target is approximately 11.42858013610459354.
5. `verify_results.py` combines these endpoints with exact rational arithmetic and
   verifies a positive corrected margin exceeding 5.78850457e-6. It also checks the
   strict arithmetic conditions, physical-profile identity, trial checksum, and failure
   of the same ordinary-slicing sufficient inequality after one further deletion.
6. The final tuple is `h3_completed.csv`, with one entry per line. Missing residues are
   in `h3_completed_witness.csv` (columns p,r). There are 110037 entries and 10455
   relevant primes; endpoints -626746 and 731596 give diameter 1358342.

The negative margin in the raw unrestricted evaluation is intentionally retained.
It belongs to the old arithmetic parameters and is NOT the final retuned deduction.
`RESULTS.json` is authoritative. Older result files elsewhere are historical.

## Numerical change and scope

`chunk_tables.py` evaluates the same interval primitive recurrences as the inherited
implementation, in blocks, storing endpoints in memory-mapped arrays. Each entry
preserves the arithmetic order and the same error allowances. Representative tests
compare 373236 binary64 endpoints bitwise. The completed selected evaluation also
includes 108 high-precision Fourier comparisons and 6006 CDF-interpolant comparisons.
These tests supplement, not replace, the inherited enclosure proofs. The scalar
backend is the documented mpmath.iv compatibility implementation, not FLINT/Arb.
The first unblocked fine-grid attempt was memory-interrupted and produced no result;
`m3_k110037_chunked.log` is the successful calculation log.

## Unsuccessful or exploratory material (not used in the bound)

- `h2_milp_large.py`: time-limited width-19858 search allowing 24 deletions; best2303.
  No solver infeasibility assertion is used as a theorem.
- `forced_cover.cpp`, `h2_force*.log`: forced-point residue perturbations and repairs;
  38128 and 38190 iterations, best2303, not exhaustive global searches.
- `phase_escape.cpp`, `h2_phase.log`: 1682 locked-small-prime restarts, best2303.
- `optimize_fixed_grid.py`, `m2_fixed_grid_k2303.json`: exploratory six-profile H2
  reoptimization, score 7.619277388587093, below the working threshold even before
  support removal. Not an interval upper bound or impossibility result.
- `h3_escape*`, `h3_tuple_search.py`: additional residue searches with no better tuple.
- `asymmetric_pilot*`, `asymmetric_tagged.py`: an unused support-allocation experiment.
  Its available inner-loss estimates are too large. No new criterion or bound relies
  on this exploratory code, and it is excluded from the successful reproduction path.

The selected tuple can be verified without rerunning any of these searches.

## Provenance

`PROVENANCE.json` records the preceding complete bundle checksum. `MANIFEST.json`
records the new source/data hashes. The inherited distribution theorem, enlarged-support
implication, signed-profile support loss, scalar/Fourier bounds, implementation and
floating-point model remain dependencies. The finite tuple verifiers do not constitute
an independent audit of that analytic chain. No global optimum or terminal Hm value
is claimed.
