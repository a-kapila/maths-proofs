"""Scalar enclosures for an asymmetric outer/inner arithmetic support.
This tests the derived asymmetric criterion; no new prime-gap bound uses it.
"""
from pathlib import Path
import sys,json,math,time
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'onward'),str(B/'analysis'),str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup
from loss_joint import joint_tail
from asymmetric_tagged import restriction_loss
ctx.prec=256

def inner_bad(k,th,be,rel,delta,omega,ufrac,kappa,tau,ratio=1.04):
 S=setup(k,th,be,rel);T=S['T'];rho=arb(1)/4+arb(omega);u0=arb(ufrac)*arb(delta)/rho
 F=S['F'];n=k-1;grid=[u0]
 while grid[-1]*arb(ratio)<T:grid.append(grid[-1]*arb(ratio))
 grid.append(T);lams=np.exp(np.linspace(math.log(1e-3),math.log(1e7),900));total=arb(0);eta=arb(1e-8);tau=arb(tau);kap=arb(kappa)
 up=lambda a:float(np.nextafter(float(a.upper()),np.inf))
 for w,wn in zip(grid[:-1],grid[1:]):
  H=kap-arb(2.5)*wn;r=max(0,math.floor(np.nextafter(float((H/T).lower()),-np.inf))+1)
  b=arb(min(up(tau-w-H+eta),up(tau-kap+arb(1.5)*wn+eta),up(tau-arb(r+1)*w+eta)))
  total+=arb(n)*(F(wn)-F(w))*joint_tail(n-1,r,b,w,S,lams)
 return up(total)

d=json.load(open(B/'focus23/m2_k2304.json'));c=json.load(open(B/'focus23/m2_k2304.interval_certificate.json'));a=json.load(open(B/'focus23/m2_k2304_amplitude.json'))
C=2.2069318204686756;den=arb(c['den_lower'])/arb(C)**2;denlo=float(np.nextafter(float(den.lower()),-np.inf))
S=setup(d['k'],d['theta'],d['beta'],d['relative_shift']);rho=arb(1)/4+arb(d['omega']);kap0=(arb(1)/4+arb(d['smooth_delta'])/2)/rho-arb(1e-8)
eps=d['delta']*d['eps_cells'];out=[]
for eta in [.005,.02,.05]:
 st=time.time();kf=float(kap0.mid())+eta;kg=float(kap0.mid())-eta
 assert arb(kf)>=arb(kg) and arb(3)*arb(kf)<arb(5)*arb(kg)
 assert rho*(arb(kf)+arb(kg))<arb(.5)+arb(d['smooth_delta'])
 assert arb(1.5)*S['T']<arb(kg)
 outer=restriction_loss(d['k'],d['theta'],d['beta'],d['smooth_delta'],d['omega'],denlo,eta=1e-8,ufrac=d['ufrac'],ratio=1.04,sum_cap=1+eps,relative_shift=d['relative_shift'],inner_cap=1-eps,region_kappa=kf)
 p=inner_bad(d['k'],d['theta'],d['beta'],d['relative_shift'],d['smooth_delta'],d['omega'],d['ufrac'],kg,1-eps)
 inner=arb(d['k'])*S['G'](S['T'])**2*arb(p)/(S['m2']*arb(denlo))
 inn=float(np.nextafter(float(inner.upper()),np.inf));loss=outer['loss_upper']+inn
 row=dict(eta=eta,kappa_outer=kf,kappa_inner=kg,outer_loss=outer['loss_upper'],inner_probability=p,inner_loss=inn,total_loss_display=loss,outer_certificate=outer,seconds=time.time()-st)
 out.append(row);(B/'onward/asymmetric_pilot.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in row.items() if k!='outer_certificate'}),flush=True)
