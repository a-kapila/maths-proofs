"""Chunk the existing interval primitive recurrences; do not change any formula.
Output arrays are memory mapped, so table construction has bounded workspace.
"""
from pathlib import Path
import sys, math, tempfile
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'focus23'),str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from fast_gtable import log_point
from shifted_core import setup
from certify_lifted import const,add,sub,mul,inv

def make_tables(d,cdf,block=2**18,directory=None):
 k=d['k'];spacing=d['delta'];nmax=math.ceil(cdf.Tf/spacing)+2;ctx.prec=256
 S=setup(k,d['theta'],d['beta'],d['relative_shift']);c,b,T,A=(const(S[x]) for x in ('c','b','T','A'))
 maxp=max(d['powers']);assert d['powers']==list(range(1,maxp+1))
 dr=Path(directory or tempfile.mkdtemp(prefix='primitive_',dir=B/'onward'))
 dr.mkdir(exist_ok=True)
 tabs=[tuple(np.memmap(dr/f'p{p}_{side}.bin',dtype='float64',mode='w+',shape=nmax+1) for side in ['lo','hi']) for p in range(maxp+1)]
 ib=inv(b);cb=mul(c,ib)
 for first in range(0,nmax+1,block):
  last=min(first+block,nmax+1);grid=np.arange(first,last,dtype=float)*spacing
  w=(np.minimum(grid,T[0]),np.minimum(grid,T[1]))
  x=add((1.,1.),mul(mul(b,w),inv(c)));xl=np.maximum(1.,x[0]);xh=np.maximum(1.,x[1])
  ll,_=log_point(xl);_,lh=log_point(xh)
  glo,ghi=add(mul((ll,lh),inv(b)),mul(A,w));glo=np.maximum(0,glo)
  if first==0:glo[0]=0.;ghi[0]=0.
  tabs[0][0][first:last]=glo;tabs[0][1][first:last]=ghi
  wp=w;Jcur=sub((glo,ghi),mul(A,w));tp=T
  for p in range(1,maxp+1):
   Jcur=sub(mul(mul(wp,ib),const(arb(1)/p)),mul(cb,Jcur));wnext=mul(wp,w)
   G=mul(add(Jcur,mul(mul(A,wnext),const(arb(1)/(p+1)))),inv(tp));G=(np.maximum(0,G[0]),np.maximum(0,G[1]))
   if first==0:G[0][0]=0.;G[1][0]=0.
   tabs[p][0][first:last]=G[0];tabs[p][1][first:last]=G[1]
   wp=wnext;tp=mul(tp,T)
 for pair in tabs:
  for a in pair:a.flush()
 return tabs,S['m2'],S

def check():
 import json
 import certify_multi
 from fast_gtable import gtable
 certify_multi.gtable=gtable
 from types import SimpleNamespace
 count=0
 for k in [2304,110037]:
  d=dict(k=k,delta=2**-15,theta=1.0078753919466732,beta=4.407650476075757,relative_shift=.24352577574567524,powers=list(range(1,6)))
  S=setup(k,d['theta'],d['beta'],d['relative_shift']);cdf=SimpleNamespace(Tf=float(S['T'].upper()))
  old,_,_=certify_multi.make_tables(d,cdf);new,_,_=make_tables(d,cdf,block=127)
  for a,b in zip(old,new):
   for x,y in zip(a,b):
    assert np.array_equal(x,y);count+=len(x)
 return {'bitwise_equal_interval_endpoints':count,'dimensions':[2304,110037]}
if __name__=='__main__':
 import json
 v=check();(B/'onward/chunk_table_checks.json').write_text(json.dumps(v,indent=2)+'\n');print(v)
