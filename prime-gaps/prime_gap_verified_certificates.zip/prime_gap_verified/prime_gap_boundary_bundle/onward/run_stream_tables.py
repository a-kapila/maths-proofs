from pathlib import Path
import sys
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'onward'),str(B/'progress')]
import run_refined
from chunk_tables import make_tables
run_refined.make_tables=make_tables
run_refined.run(sys.argv[1])
