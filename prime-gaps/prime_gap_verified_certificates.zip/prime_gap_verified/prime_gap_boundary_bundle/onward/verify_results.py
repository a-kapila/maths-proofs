"""Exact endpoint deductions and independently checked admissibility.
This does not independently audit the inherited sieve or Fourier error proofs.
"""
from pathlib import Path
from fractions import Fraction as F
import json,math,hashlib,subprocess
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'onward'

def primes(n):
 s=bytearray(b'\x01')*(n+1);s[:2]=b'\x00\x00'
 for p in range(2,math.isqrt(n)+1):
  if s[p]:s[p*p::p]=b'\x00'*(((n-p*p)//p)+1)
 return [p for p in range(2,n+1) if s[p]]
def integer_check(tp,wp,k):
 a=np.loadtxt(tp,dtype=np.int64);w=np.loadtxt(wp,dtype=np.int64,delimiter=',',skiprows=1)
 assert len(a)==k and np.all(np.diff(a)>0)
 ps=primes(k);wr={int(p):int(r) for p,r in w};assert all(p in wr for p in ps)
 for p in ps:
  assert 0<=wr[p]<p
  assert np.all(np.remainder(a,p)!=wr[p]),p
 cpp=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(tp),str(wp),str(k)],text=True));assert cpp['verified']
 for key,val in dict(k=k,first=int(a[0]),last=int(a[-1]),diameter=int(a[-1]-a[0]),checked_primes=len(ps)).items():assert cpp[key]==val
 cpp.update(python_verifier='independent sieve and direct modular reduction of all entries',tuple_sha256=hashlib.sha256(Path(tp).read_bytes()).hexdigest(),witness_sha256=hashlib.sha256(Path(wp).read_bytes()).hexdigest())
 return cpp

def main():
 d=json.load(open(O/'m3_k110037.json'));old=json.load(open(B/'advance/m3_k110039.json'));c=json.load(open(O/'m3_k110037.interval_certificate.json'))
 assert d['profiles']==old['profiles'] and d['basis']==old['basis']
 assert len(d['E'])==len(old['E'])
 for a,b in zip(d['E'],old['E']):assert a*F.from_float(d['delta'])==b*F.from_float(old['delta'])
 assert d['eps_cells']*F.from_float(d['delta'])==old['eps_cells']*F.from_float(old['delta'])
 for key in ['theta','beta','relative_shift']:assert d[key]==old[key]
 assert d['k']==c['k']==110037
 assert c['trial_sha256']==hashlib.sha256((O/'m3_k110037.json').read_bytes()).hexdigest()
 rows=json.load(open(O/'arithmetic_sweep.json'));r=next(x for x in rows if x['delta']==6e-7)
 delta,omega=map(F.from_float,[r['delta'],r['omega']]);rho=F(1,4)+omega;eps=F.from_float(d['delta'])*d['eps_cells']
 assert 240*omega+80*delta<3 and 2*rho*(1+eps)<1
 q=F.from_float(c['Q_lower'])-F.from_float(r['support']['loss_upper']);target=F(3)/rho;margin=q-target
 assert margin>0
 oldmargin=F.from_float(c['Q_lower'])-F(3)/(F(1,4)+F.from_float(old['omega']))
 assert oldmargin<0
 assert F(110036,110037)*q<=target
 h3=integer_check(O/'h3_completed.csv',O/'h3_completed_witness.csv',110037)
 h2=integer_check(B/'advance/h2_final.csv',B/'advance/h2_final_witness.csv',2304)
 out=dict(scope='Computer-assisted deduction within the inherited sieve and numerical-enclosure framework; no independent expert audit.',bounds=dict(H2=19860,H3=h3['diameter'],H4=82258490,H5=4831230984),
   H3=dict(previous_dimension=110039,dimension=110037,previous_bound=1358360,saving=1358360-h3['diameter'],Q_lower=c['Q_lower'],smooth_delta=r['delta'],omega=r['omega'],loss_upper=r['support']['loss_upper'],target_nearest=float(target),margin=float(margin),margin_fraction=[margin.numerator,margin.denominator],margin_at_old_arithmetic_parameters=float(oldmargin),ordinary_slicing_one_more_fails=True,tuple=h3),
   H2=dict(unchanged=True,analytic_certificate_reused=True,tuple=h2),
   diagnostics=dict(chunk_table_checks=json.load(open(O/'chunk_table_checks.json')),direct_fourier_checks=len(c['direct_fourier_checks']),bitwise_CDF_checks=c['bitwise_CDF_checks']),
   unsuccessful=dict(original_fine_run='memory limit; no certificate',arithmetic_at_original_parameters='negative sufficient margin',H2_mixed_trial='exploratory quotient below threshold before support deductions',asymmetric_pilot='available inner-loss bounds too large; not used'))
 (O/'RESULTS.json').write_text(json.dumps(out,indent=2)+'\n');(O/'selected_arithmetic.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps(out,indent=2));return out
if __name__=='__main__':main()
