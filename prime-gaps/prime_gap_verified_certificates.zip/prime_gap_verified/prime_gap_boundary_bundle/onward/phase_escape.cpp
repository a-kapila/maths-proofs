#include <bits/stdc++.h>
using namespace std;
// Search only. Final output is checked by independent integer verifiers.
int main(int argc,char**argv){
 if(argc!=7){cerr<<"width K witnesses seconds output seed\n";return 2;}
 int D=stoi(argv[1]),K=stoi(argv[2]),N=D/2+1;double limit=stod(argv[4]);string out=argv[5];mt19937 rng(stoul(argv[6]));
 vector<int>p,base;ifstream in(argv[3]);string s;getline(in,s);while(getline(in,s)){replace(s.begin(),s.end(),',',' ');istringstream f(s);int q,r;f>>q>>r;if(q>2&&q<=K){p.push_back(q);r=((r-10)%q+q)%q;base.push_back(1LL*r*((q+1)/2)%q);}}
 vector<int>a=base,c(N),cnt(K+1),order(p.size());iota(order.begin(),order.end(),0);auto start=chrono::steady_clock::now();auto secs=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 int best=0,trial=0;vector<tuple<int,int,int>>options;
 for(int i=0;i<(int)p.size();i++)if(p[i]>=7&&p[i]<=127)for(int r=0;r<p[i];r++)if(r!=base[i])options.emplace_back(i,r,rng());
 shuffle(options.begin(),options.end(),rng);
 for(auto [lock,rr,unused]:options){if(secs()>limit)break;trial++;a=base;a[lock]=rr;fill(c.begin(),c.end(),0);for(int i=0;i<(int)p.size();i++)for(int j=a[i];j<N;j+=p[i])++c[j];int cur=count(c.begin(),c.end(),0);
  for(int sweep=0;sweep<100;sweep++){
   shuffle(order.begin(),order.end(),rng);
   for(int i:order){if(sweep<80&&i==lock)continue;int q=p[i],freed=0,old=a[i];for(int j=old;j<N;j+=q)freed+=(c[j]==1);if(!freed&&rng()%20)continue;
    for(int j=old;j<N;j+=q)--c[j];fill(cnt.begin(),cnt.begin()+q,0);for(int off=0;off<N;off+=q)for(int r=0;r<min(q,N-off);r++)cnt[r]+=(c[off+r]==0);
    int mn=INT_MAX,br=old,n=0;for(int r=0;r<q;r++){if(cnt[r]<mn){mn=cnt[r];br=r;n=1;}else if(cnt[r]==mn&&rng()%++n==0)br=r;}
    for(int j=br;j<N;j+=q)++c[j];a[i]=br;cur+=freed-mn;
   }
   if(cur>best){best=cur;cerr<<"best="<<best<<" trial="<<trial<<" p="<<p[lock]<<" r="<<rr<<" sweep="<<sweep<<" sec="<<secs()<<"\n";}
   if(cur>=K){ofstream f(out+".csv"),w(out+"_witness.csv");for(int j=0;j<N;j++)if(c[j]==0)f<<2*j<<"\n";w<<"prime,missing_residue\n2,1\n";for(int i=0;i<(int)p.size();i++)w<<p[i]<<","<<2*a[i]%p[i]<<"\n";return 0;}
  }
  if(trial%50==0)cerr<<"trial="<<trial<<" best="<<best<<" secs="<<secs()<<"\n";
 }
 cerr<<"finished trial="<<trial<<" best="<<best<<" secs="<<secs()<<"\n";
}
