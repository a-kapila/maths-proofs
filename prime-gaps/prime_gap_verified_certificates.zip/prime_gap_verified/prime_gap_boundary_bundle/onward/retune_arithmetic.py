"""Recompute support losses when the arithmetic parameters change.
The unrestricted trial and its completed quotient are kept fixed.
"""
from pathlib import Path
import sys,json,math,time
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from loss_joint import restriction_loss
from fractions import Fraction as F
ctx.prec=256
j=json.load(open(B/'onward/m3_k110037.json'));cert=json.load(open(B/'onward/m3_k110037.interval_certificate.json'))
rows=[]
for delta in [9.9e-7,9.5e-7,9e-7,8e-7,7e-7,6e-7]:
 omega=float(F(1,80)-F.from_float(delta)/3-F(1,10**12))
 assert F(240)*F.from_float(omega)+F(80)*F.from_float(delta)<3
 st=time.time();eps=j['delta']*j['eps_cells']
 r=restriction_loss(j['k'],j['theta'],j['beta'],delta,omega,cert['scaled_den_lower'],ufrac=j['ufrac'],sum_cap=1+eps,relative_shift=j['relative_shift'],inner_cap=1-eps)
 q=F.from_float(cert['Q_lower'])-F.from_float(r['loss_upper']);rho=F(1,4)+F.from_float(omega);margin=q-F(3)/rho
 row=dict(delta=delta,omega=omega,support=r,margin=float(margin),margin_fraction=[margin.numerator,margin.denominator],seconds=time.time()-st)
 rows.append(row);(B/'onward/arithmetic_sweep.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(json.dumps(dict(delta=delta,omega=omega,loss=r['loss_upper'],margin=float(margin),seconds=row['seconds'])),flush=True)
