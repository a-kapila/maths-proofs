from pathlib import Path
import subprocess,json,time
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'onward';K=110037
wp=B/'advance/h3_final_witness.csv';tp=B/'advance/h3_final.csv';hist=[];start=time.time()
a=np.loadtxt(tp,dtype=np.int64);i=int(np.argmin(a[K-1:]-a[:len(a)-K+1]));a=a[i:i+K]
np.savetxt(O/'h3_seed.csv',a,fmt='%d')
for step in range(6):
 lo=int(a[0]);hi=int(a[-1])-2;pref=O/f'h3_search{step}'
 with open(str(pref)+'.log','w') as f:
  subprocess.run([str(O/'cover_descent'),str(K),str(lo),str(hi),str(wp),'35',str(pref),str(235736+141*step),str(K)],stdout=f,stderr=subprocess.STDOUT,check=True)
 if not Path(str(pref)+'.csv').exists():break
 tp=Path(str(pref)+'.csv');wp=Path(str(pref)+'_witness.csv');a=np.loadtxt(tp,dtype=np.int64)
 v=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(tp),str(wp),str(K)],text=True));hist.append(dict(**v,tuple=str(tp.relative_to(B)),witness=str(wp.relative_to(B)),seconds=time.time()-start))
 (O/'h3_search_history.json').write_text(json.dumps(hist,indent=2));print(json.dumps(hist[-1]),flush=True)
 if time.time()-start>170:break
