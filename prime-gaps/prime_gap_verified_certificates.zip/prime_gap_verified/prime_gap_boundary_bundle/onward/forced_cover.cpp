// Heuristic construction only. Every produced candidate needs independent verification.
#include <bits/stdc++.h>
using namespace std;
int main(int argc,char**argv){
 if(argc<7){cerr<<"D K witnesses seconds output seed [shift]\n";return 2;}
 int D=stoi(argv[1]),K=stoi(argv[2]),N=D/2+1;double seconds=stod(argv[4]);string out=argv[5];mt19937 rng(stoul(argv[6]));long shift=argc>7?stol(argv[7]):0;
 vector<int>p,a;ifstream f(argv[3]);string s;getline(f,s);
 while(getline(f,s)){replace(s.begin(),s.end(),',',' ');istringstream z(s);int x,r;z>>x>>r;if(x==2||x>K)continue;r=((r-shift)%x+x)%x;p.push_back(x);a.push_back(1LL*r*((x+1)/2)%x);}
 vector<int>cover(N),cnt(K+1),banned(K+1),order(p.size());iota(order.begin(),order.end(),0);
 auto rebuild=[&](){fill(cover.begin(),cover.end(),0);for(int i=0;i<(int)p.size();i++)for(int x=a[i];x<N;x+=p[i])++cover[x];};rebuild();
 auto countcur=[&](){return (int)count(cover.begin(),cover.end(),0);};
 int best=countcur(),cur=best;vector<int>besta=a;vector<vector<int>>pop{a};
 auto save=[&](){ofstream t(out+".csv"),w(out+"_witness.csv");for(int x=0;x<N;x++)if(cover[x]==0)t<<2*x<<"\n";w<<"prime,missing_residue\n2,1\n";for(int i=0;i<(int)p.size();i++)w<<p[i]<<","<<2*a[i]%p[i]<<"\n";};
 auto start=chrono::steady_clock::now();auto elapsed=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 cerr<<"initial="<<cur<<"\n";int it=0;
 while(elapsed()<seconds){
  if(it%6==0){a=pop[rng()%pop.size()];rebuild();cur=countcur();}
  vector<int>pool;
  for(int x=0;x<N;x++)if(cover[x]>0&&cover[x]<=3){bool ok=true;for(int i=0;i<(int)p.size()&&p[i]<=31;i++)if(x%p[i]==a[i]){ok=false;break;}if(ok)pool.push_back(x);}
  if(pool.empty())break;shuffle(pool.begin(),pool.end(),rng);
  int nf=1+rng()%8;vector<int>force;for(int x:pool){bool ok=true;for(int q:p){vector<int>r;for(int y:force)r.push_back(y%q);r.push_back(x%q);sort(r.begin(),r.end());r.erase(unique(r.begin(),r.end()),r.end());if((int)r.size()==q){ok=false;break;}}if(ok)force.push_back(x);if((int)force.size()==nf)break;}
  int plateau=0;
  for(int sweep=0;sweep<16;sweep++){
   if(sweep)shuffle(order.begin(),order.end(),rng);int before=cur;
   for(int i:order){int q=p[i],old=a[i],freed=0;bool conflict=false;for(int y:force)if(y%q==old)conflict=true;
    for(int x=old;x<N;x+=q)if(cover[x]==1)++freed;
    if(!freed&&!conflict&&rng()%30)continue;
    for(int x=old;x<N;x+=q)--cover[x];fill(cnt.begin(),cnt.begin()+q,0);fill(banned.begin(),banned.begin()+q,0);
    for(int y:force)banned[y%q]=1;
    for(int off=0;off<N;off+=q){int e=min(q,N-off);for(int r=0;r<e;r++)cnt[r]+=(cover[off+r]==0);}
    int mn=INT_MAX,br=-1,nopt=0;for(int r=0;r<q;r++)if(!banned[r]){if(cnt[r]<mn){mn=cnt[r];br=r;nopt=1;}else if(cnt[r]==mn&&rng()%++nopt==0)br=r;}
    assert(br>=0);a[i]=br;for(int x=br;x<N;x+=q)++cover[x];cur+=freed-mn;
   }
   if(cur>best){best=cur;besta=a;save();cerr<<"best="<<best<<" it="<<it<<" sec="<<elapsed()<<"\n";if(best>=K)return 0;}
   if(sweep==7)force.clear();
   if(cur==before){if(++plateau>=4&&force.empty())break;}else plateau=0;
  }
  if(cur>=best-1){if(pop.size()<24)pop.push_back(a);else pop[rng()%pop.size()]=a;}else{a=pop[rng()%pop.size()];rebuild();cur=countcur();}
  if(it%100==0)cerr<<"it="<<it<<" current="<<cur<<" best="<<best<<" pool="<<pop.size()<<" secs="<<elapsed()<<"\n";
  ++it;
 }
 cerr<<"finished best="<<best<<" it="<<it<<" secs="<<elapsed()<<"\n";
}
