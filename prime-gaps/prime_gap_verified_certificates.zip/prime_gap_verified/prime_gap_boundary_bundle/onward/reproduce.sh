#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
case "$mode" in --checks-only|--full) ;; *) echo 'usage: bash onward/reproduce.sh --checks-only|--full' >&2; exit 2;; esac
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-2}"
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o onward/verify_tuple
python onward/chunk_tables.py
if [[ "$mode" == --full ]]; then
 "$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
 "$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off progress/profile_parallel.cpp -o progress/profile_parallel.so
 "$cxx" -O3 -std=c++17 -shared -fPIC -fopenmp -ffp-contract=off new/fft_native.cpp -o new/fft_native_lib.so
 python onward/run_stream_tables.py onward/m3_k110037.json
 python onward/retune_arithmetic.py
fi
python onward/verify_results.py
