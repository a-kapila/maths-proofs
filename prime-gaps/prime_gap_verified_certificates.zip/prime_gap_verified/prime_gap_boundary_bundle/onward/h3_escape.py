from pathlib import Path
import subprocess,json,time
import numpy as np
B=Path(__file__).resolve().parents[1];O=B/'onward';K=110037;start=time.time();width=1358340;left=-626746
wp=B/'advance/h3_final_witness.csv';records=[]
for batch in range(4):
 jobs=[]
 for idx in range(2):
  shift=[2,-2,40,-40,400,-400,4000,-4000][batch*2+idx];pref=O/f'h3_escape_{batch}_{idx}'
  f=open(str(pref)+'.log','w');p=subprocess.Popen([str(O/'cover_descent'),str(K),str(left+shift),str(left+shift+width),str(wp),'90',str(pref),str(913752+batch*731+idx*11),str(K)],stdout=f,stderr=subprocess.STDOUT);jobs.append((p,f,pref))
 for p,f,pref in jobs:
  assert p.wait()==0;f.close()
  if not Path(str(pref)+'.csv').exists():continue
  r=json.loads(subprocess.check_output([str(O/'verify_tuple'),str(pref)+'.csv',str(pref)+'_witness.csv',str(K)],text=True));r.update(tuple=str(pref.relative_to(B))+'.csv',witness=str(pref.relative_to(B))+'_witness.csv',seconds=time.time()-start);records.append(r);print(json.dumps(r),flush=True)
 (O/'h3_escape_results.json').write_text(json.dumps(records,indent=2)+'\n')
