"""Capped-dilation slicing using an integrated Chernoff survival bound.
The original fixed-trial Fourier enclosures are reused; scalar MGFs are reevaluated.
"""
from pathlib import Path
import sys,json,time,math
import numpy as np
from fractions import Fraction as F
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from flint import arb,ctx
from shifted_core import setup,mgf_negative
ctx.prec=256
up=lambda z:float(np.nextafter(float(z.upper()),np.inf))
down=lambda z:float(np.nextafter(float(z.lower()),-np.inf))

def run(m):
 t=time.time();data=json.load(open(B/f'rescaled/scaled_m{m}_A11_10.json'))
 trial=json.load(open(B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
 k=data['k'];c=F(1,11);rho=F(1,4)+F(trial['omega']);tar=F(m)/rho
 q=F(data['original_quotient_lower'])-F(data['restriction']['loss_upper'])
 sig=1+arb(trial['delta'])*trial['eps_cells'];S=setup(k,trial['theta'],trial['beta'],trial['relative_shift']);w=sig/11
 DR=arb(data['restricted_den_lower']);C=arb(data['amplitude_upper']);best=None;records=[]
 for j in range(-8,209):
  lam=arb(float(2**(j/16)));L=lam*sig
  M=mgf_negative(lam,S['c'],S['b'],w,S['A'])/S['m2']+(-lam*w).exp()*(1-S['F'](w))
  assert M>0 and M<=1
  logB=((C*C/DR).log()+k*M.log()).upper()
  if not logB<0:continue
  t0=-logB/L
  if not (t0>0 and t0<1):continue
  BB=logB.exp()
  mu1=down(t0-(1-BB)/L)
  mu2=up(t0*t0-2*t0/L+2*(1-BB)/(L*L))
  if not(mu1>0 and mu2>0):continue
  a1=F(mu1);a2=F(mu2)
  def bet(d):return F(d,k)*a1-F(d*(d-1),2*k*(k-1))*a2/c
  def mar(d):return F(k-d,k)*q-tar*(1-bet(d))
  aa=float((q-tar*a1)/k-tar*a2/(2*c*k*(k-1)));bb=float(tar*a2/(2*c*k*(k-1)));dd=float(q-tar)
  d0=max(0,int(2*dd/(aa+math.sqrt(aa*aa+4*bb*dd))))
  while mar(d0)<=0:d0-=1
  while mar(d0+1)>0:d0+=1
  assert d0-1<=c*(k-1) and bet(d0)<1
  row=dict(lambda_value=float(lam),j=j,log_B_upper=up(logB),zero_crossing_lower=down(t0),zero_crossing_upper=up(t0),mu1_lower=mu1,mu2_upper=mu2,coordinates_deleted=d0,dimension=k-d0,beta_lower=float(bet(d0)),effective_quotient_lower=float(F(k-d0,k)*q/(1-bet(d0))),margin_lower=down(arb(mar(d0).numerator)/mar(d0).denominator/(1-arb(bet(d0).numerator)/bet(d0).denominator)),raw_margin_exact=[mar(d0).numerator,mar(d0).denominator],next_margin=float(mar(d0+1)))
  records.append(row)
  if best is None or row['dimension']<best['dimension'] or (row['dimension']==best['dimension'] and row['margin_lower']>best['margin_lower']):best=row
 assert best is not None
 clean={key:value for key,value in data.items() if key not in ['trimmed_mass','coordinates_deleted','dimension','margin','next_margin','elapsed']}
 out={**clean,**best,'method':'integrated Chernoff survival with capped-dilation slicing','elapsed_new_scalar_seconds':time.time()-t,'candidates_evaluated':len(records)}
 (B/f'rescaled/integrated_m{m}.json').write_text(json.dumps(out,indent=2)+'\n')
 (B/f'rescaled/integrated_m{m}_candidates.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps({x:out[x] for x in ['m','k','dimension','coordinates_deleted','lambda_value','mu1_lower','mu2_upper','margin_lower','elapsed_new_scalar_seconds']}),flush=True)
 return out
if __name__=='__main__':
 for m in (4,5):run(m)
