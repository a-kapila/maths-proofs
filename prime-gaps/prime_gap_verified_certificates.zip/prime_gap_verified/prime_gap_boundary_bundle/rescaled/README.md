# Capped rescaling: a stronger coordinate-slicing implication

4 November 2026. New results within the inherited sieve framework:

| Quantity | Previous | New | Sieve dimension |
|---|---:|---:|---:|
| H2 | 19,920 | unchanged | 2,305 |
| H3 | 1,359,754 | unchanged | 110,070 |
| H4 | 82,294,500 | **82,290,802** | **5,089,695** |
| H5 | 4,832,810,284 | **4,832,640,592** | **232,490,042** |

These are computer-assisted research derivations, not independently reviewed records.
Read `proof_note.pdf` for the complete new implication and its dependencies.

## What was computed, and what was reused

The earlier unrestricted Fourier quotient and denominator enclosures in
`../trials/m4_cross.interval_certificate.json` and
`../trials/m5_fine.interval_certificate.json` are **reused**, not reevaluated.
Their fixed trial dimensions are 5,090,000 and 232,500,000.

This continuation computes new stricter-support loss bounds, full-vector removed
probability bounds, truncated-coordinate MGFs, integrated Chernoff comparison
moments, and exact rational dimension inequalities. Rescaled slices remove 305
and 9,958 coordinates, instead of the earlier 82 and 2,139. No prime pairs are
restored; the smaller dimensions select narrower windows in the existing parents.
Both resulting tuples were checked in full. The H5 optimistic relaxation was
recomputed at the new dimension and is not an admissible-tuple upper bound.

The new argument does not change the external prime-distribution input, prove
optimality of the variational problem, or improve H1.

## Reproduction

From the bundle root:

```sh
bash rescaled/reproduce.sh --checks-only
bash rescaled/reproduce.sh --full
```

Checks-only reevaluates the selected scalar MGFs, checks all final rational
inequalities and exact algebra diagnostics, reconstructs and independently checks
both complete tuples, and reruns the fixed-universe optimistic relaxation.
Full additionally recomputes stricter-support losses and removed probabilities,
then reruns the finite scalar candidate search. Neither command reruns the
inherited high-dimensional Fourier quotient calculations; their earlier scripts
remain in the bundle.

Python 3, NumPy, SciPy, mpmath, and a C++17 compiler with OpenMP are needed.
Do not disable assertions. The scalar module called `flint.py` is the inherited
mpmath.iv compatibility backend with explicit exponential-integral remainder
bounds, **not FLINT/Arb**. The H5 independent byte sieve uses over 1 GB of memory.
The complete 94 MB uncompressed witness sequence is reconstructed from the
included compressed data and patches; it is not duplicated in this archive.

## Authoritative files

`integrated_m4.json` and `integrated_m5.json` contain the final scalar endpoints,
dimensions and exact rational margins. `integrated_m*_candidates.json` records
the finite search. Binary64 values are interpreted as their exact dyadic values.
The `scaled_m*_A11_10.json` source files also retain an earlier one-threshold
slicing calculation; its dimension is superseded by the integrated calculation.

`verify_scalar.py` separately reevaluates the selected MGFs and checks geometry,
comparison-moment enclosures, final exact margins and failure of the same
sufficient inequality one dimension lower. This last check is not an optimality
statement. `check_lemma.py` supplies exact algebra and simplex diagnostics, plus
independent high-precision integral comparisons; these tests supplement the proof.

`h4_final_selection.json` reconstructs the full selected tuple from its included
parent; `h4_final_verified.json` is the full independent integer check.
`h5_final_verified.json` records all 12,204,094 prime-witness checks and the
exhaustive 1,460,937-window scan. `h5_final_relaxation.json` records the separate
optimistic scan that omits admissibility. No earlier download is required.

The inherited distribution theorem, enlarged-support proof, numerical error
analysis, support-loss argument, software and arithmetic model remain dependencies.
Separate integer verification is not an independent expert audit of the full proof.
