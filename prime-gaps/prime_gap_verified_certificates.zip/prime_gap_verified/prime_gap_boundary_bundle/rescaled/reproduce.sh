#!/usr/bin/env bash
# Checks-only still checks selected scalar MGFs, exact inequalities and full tuples.
# --full additionally recomputes stricter-support probability and loss bounds.
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:---checks-only}"
if [[ "$mode" != --checks-only && "$mode" != --full ]]; then
 echo 'usage: bash rescaled/reproduce.sh [--checks-only|--full]' >&2; exit 2
fi
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS="${OMP_NUM_THREADS:-3}"
mkdir -p rescaled/recomputed
if [[ "$mode" == --full ]]; then
 python rescaled/scaled_slicing.py 4 11 10
 python rescaled/scaled_slicing.py 5 11 10
 python rescaled/integrated_slicing.py
fi
python rescaled/verify_scalar.py
python rescaled/check_lemma.py
python rescaled/rebuild_h4.py
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o rescaled/recomputed/verify_tuple
rescaled/recomputed/verify_tuple rescaled/recomputed/h4.csv baseline/inherited/tuples/h4_witness.csv 5089695 >rescaled/recomputed/h4_final_verified.json
python baseline/inherited/tuples/decode_h5.py rescaled/recomputed/old_unpatched.bin
python baseline/h5/apply_patches.py rescaled/recomputed/old_unpatched.bin rescaled/recomputed/previous_h5.bin
python new/apply_new_h5_patches.py rescaled/recomputed/previous_h5.bin rescaled/recomputed/current_h5.bin
"$cxx" -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o rescaled/recomputed/verify_h5
rescaled/recomputed/verify_h5 234360000 232490042 10000000 2432107459 rescaled/recomputed/current_h5.bin >rescaled/recomputed/h5_final_verified.json
"$cxx" -O3 -std=c++17 limits/optimistic_h5.cpp -o rescaled/recomputed/optimistic_h5
rescaled/recomputed/optimistic_h5 232490042 >rescaled/recomputed/h5_final_relaxation.json
python - <<'PY'
from pathlib import Path
import json
p=Path('rescaled')
for name in ['h4_final_verified.json','h5_final_verified.json','h5_final_relaxation.json']:
 old=json.loads((p/name).read_text());new=json.loads((p/'recomputed'/name).read_text())
 for key,value in old.items():
  if key!='seconds':assert new[key]==value,(name,key,new[key],value)
 print(name, 'all mathematical fields match')
print('All new checks completed. Inherited Fourier enclosures were not recomputed.')
PY
