"""Reevaluate selected scalar bounds and all final rational inequalities.
--full support computations are in reproduce.sh; this file does not rerun Fourier integrals.
"""
from pathlib import Path
import sys,json
from fractions import Fraction as F
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(B/'baseline/inherited/analysis'))
from flint import arb,ctx
from shifted_core import setup,mgf_negative
ctx.prec=256
up=lambda x:float(np.nextafter(float(x.upper()),np.inf))
down=lambda x:float(np.nextafter(float(x.lower()),-np.inf))
checks=[]
for m in [4,5]:
 d=json.load(open(B/'rescaled'/f'integrated_m{m}.json'))
 name='m4_cross' if m==4 else 'm5_fine'
 trial=json.load(open(B/'trials'/f'{name}.json'));old=json.load(open(B/'trials'/f'{name}.interval_certificate.json'))
 A=F(*d['A']);cap=1-1/A;k=trial['k'];rho=F(1,4)+F(trial['omega']);sig=1+F(trial['delta'])*trial['eps_cells']
 kap=(F(1,4)+F(trial['smooth_delta'])/2)/rho-F(1,10000)
 assert F(d['new_kappa'])*A<=kap and F(d['new_ufrac'])*A<=F(trial['ufrac'])
 assert 240*F(trial['omega'])+80*F(trial['smooth_delta'])<3 and 2*rho*sig<1
 assert d['original_quotient_lower']==old['Q_lower'] and d['amplitude_upper']==old['amplitude_upper']
 C=arb(d['amplitude_upper']);DR=arb(old['den_lower'])-C*C*arb(d['support_bad_probability_upper'])
 assert DR>0 and arb(d['restricted_den_lower'])<=DR.lower()
 DR=arb(d['restricted_den_lower']);S=setup(k,trial['theta'],trial['beta'],trial['relative_shift'])
 ss=arb(sig.numerator)/sig.denominator;w=ss/11;lam=arb(d['lambda_value']);L=lam*ss
 M=mgf_negative(lam,S['c'],S['b'],w,S['A'])/S['m2']+(-lam*w).exp()*(1-S['F'](w))
 logB=((C*C/DR).log()+k*M.log()).upper();BB=logB.exp();x0=-logB/L
 assert logB<0 and 0<x0 and x0<1
 mu1=x0-(1-BB)/L;mu2=x0*x0-2*x0/L+2*(1-BB)/(L*L)
 assert arb(d['mu1_lower'])<=mu1.lower() and arb(d['mu2_upper'])>=mu2.upper()
 q=F(d['original_quotient_lower'])-F(d['restriction']['loss_upper']);target=F(m)/rho
 a=F(d['mu1_lower']);b=F(d['mu2_upper']);n=d['coordinates_deleted'];K=k-n
 def beta(j):return F(j,k)*a-F(j*(j-1),2*k*(k-1))*b/cap
 def margin(j):return F(k-j,k)*q-target*(1-beta(j))
 assert n-1<=cap*(k-1) and beta(n)<1 and margin(n)>0 and margin(n+1)<=0
 assert K==d['dimension'] and margin(n)==F(*d['raw_margin_exact'])
 assert 0<F(d['margin_lower'])<=margin(n)/(1-beta(n))
 checks.append(dict(m=m,dimension=K,deleted=n,mu1_checked=True,mu2_checked=True,geometry_checked=True,raw_margin_exact=d['raw_margin_exact'],quotient_margin_lower=d['margin_lower'],next_sufficient_inequality_fails=True))
(B/'rescaled/scalar_checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks),flush=True)
