"""Capped-dilation slicing; fixed-trial calculations inherit earlier quotient enclosures.
Every lower-tail and support-removal probability is interval-evaluated.
"""
from pathlib import Path
import sys,json,math,time
import numpy as np
from fractions import Fraction
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'baseline/inherited/analysis')]
from flint import arb,ctx
from shifted_core import setup,mgf_negative
from loss_joint import restriction_loss,joint_tail
ctx.prec=256
up=lambda z:float(np.nextafter(float(z.upper()),np.inf))
down=lambda z:float(np.nextafter(float(z.lower()),-np.inf))

def bad_probability(d,ufrac,kappa):
 S=setup(d['k'],d['theta'],d['beta'],d['relative_shift'])
 k=d['k'];rho=arb(1)/4+arb(d['omega']);sig=1+arb(d['delta'])*d['eps_cells'];T=S['T']
 w=arb(ufrac)*arb(d['smooth_delta'])/rho;kap=arb(kappa);ratio=arb('1.02');eta=arb('0.0001')
 lams=np.exp(np.linspace(math.log(1e-3),math.log(1e7),900));res=arb(0);cells=0
 while w<T:
  en=w*ratio
  if en>T:en=T
  aa=kap-arb(3)/2*en
  r=math.floor(down(aa/T))+1
  bb=min(up(sig-aa+eta),up(sig-r*w+eta))
  res+=joint_tail(k,r,arb(bb),w,S,lams)
  w=en;cells+=1
 return up(res),cells

def calc(m,A_num,A_den):
 assert m in (4,5) and A_num>A_den>0
 t=time.time();tp=B/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')
 d=json.load(open(tp));old=json.load(open(tp.with_suffix('.interval_certificate.json')))
 k=d['k'];rho=arb(1)/4+arb(d['omega']);sig=1+arb(d['delta'])*d['eps_cells'];tau=2-sig
 Am=arb(A_num)/A_den;c=1-1/Am
 kap=(arb(1)/4+arb(d['smooth_delta'])/2)/rho-arb('0.0001')
 kp=down(kap/Am);uf=down(arb(d['ufrac'])/Am)
 print(json.dumps(dict(stage='start_stricter_support',m=m,k=k,A=[A_num,A_den])),flush=True)
 loss=restriction_loss(k,d['theta'],d['beta'],d['smooth_delta'],d['omega'],old['scaled_den_lower'],ufrac=uf,sum_cap=float(sig),region_kappa=kp,relative_shift=d['relative_shift'],inner_cap=float(tau))
 print(json.dumps(dict(stage='support_loss',m=m,seconds=time.time()-t,loss=loss)),flush=True)
 pbad,ncells=bad_probability(d,uf,kp)
 print(json.dumps(dict(stage='bad_mass',m=m,seconds=time.time()-t,pbad=pbad)),flush=True)
 C=arb(old['amplitude_upper']);DR=arb(old['den_lower'])-C*C*arb(pbad)
 if not DR>0:raise ValueError(('nonpositive restricted denominator',m,A_num,A_den,float(DR),pbad))
 S=setup(k,d['theta'],d['beta'],d['relative_shift']);w=c*sig
 assert w<S['T']
 best=None;tail_candidates=[]
 for j in range(-8,85):
  lam=arb(float(2**(j/4)))
  mg=mgf_negative(lam,S['c'],S['b'],w,S['A'])/S['m2']+(-lam*w).exp()*(1-S['F'](w))
  assert mg>0 and mg<=1
  logm=mg.log().upper()
  for e in range(2,31):
   eta=arb(2)**-e
   rr=((DR/(C*C)*eta).log()-k*logm)/(lam*sig)
   r=down(rr)
   if not 0<r<1:continue
   mulow=down(arb(r)*(1-eta))
   if best is None or mulow>best['mu_lower']:
    prob=up((lam*arb(r)*sig+k*logm).exp())
    best=dict(lambda_value=float(lam),threshold=r,relative_bad_mass=2**-e,probability_upper=prob,mu_lower=mulow,log_mgf_upper=up(logm))
 Q=Fraction(old['Q_lower'])-Fraction(loss['loss_upper']);target=Fraction(m)/(Fraction(1,4)+Fraction(d['omega']))
 mu=Fraction(best['mu_lower']);cc=Fraction(A_num-A_den,A_num)
 def margin(dd):
  beta=Fraction(dd,k)*mu*(1-Fraction(dd-1,1)/(2*cc*(k-1)))
  return Fraction(k-dd,k)*Q-target*(1-beta)
 lo=0;hi=min(k-1,int(float(cc)*k))
 assert margin(lo)>0
 while lo+1<hi:
  mid=(lo+hi)//2
  if margin(mid)>0:lo=mid
  else:hi=mid
 out=dict(m=m,k=k,previous_final_dimension=(5089918 if m==4 else 232497861),A=[A_num,A_den],c=[cc.numerator,cc.denominator],new_ufrac=uf,new_kappa=kp,original_quotient_lower=old['Q_lower'],restriction=loss,support_bad_probability_upper=pbad,support_bad_cells=ncells,restricted_den_lower=down(DR),amplitude_upper=old['amplitude_upper'],trimmed_mass=best,coordinates_deleted=lo,dimension=k-lo,margin=float(margin(lo)),next_margin=float(margin(lo+1)),elapsed=time.time()-t)
 (B/f'rescaled/scaled_m{m}_A{A_num}_{A_den}.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out),flush=True)
 return out
if __name__=='__main__':calc(*map(int,sys.argv[1:]))
