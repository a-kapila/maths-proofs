from pathlib import Path
import json,numpy as np
B=Path(__file__).resolve().parents[1]
d=json.load(open(B/'rescaled/h4_final_selection.json'));k=d['k']
h=np.loadtxt(B/'baseline/inherited/tuples/h4.csv',dtype=np.int64)
assert len(h)==d['parent_cardinality'] and np.all(np.diff(h)>0)
width=h[k-1:]-h[:len(h)-k+1];j=int(np.argmin(width));v=h[j:j+k]
assert j==d['start_index'] and len(width)==d['candidate_windows']
assert int(v[0])==d['first'] and int(v[-1])==d['last'] and int(v[-1]-v[0])==d['diameter']
out=B/'rescaled/recomputed';out.mkdir(exist_ok=True)
np.savetxt(out/'h4.csv',v,fmt='%d');print(json.dumps(d))
