"""Independent exact-rational tests of the capped-slicing algebra.
These tests supplement, not replace, the proofs in proof_note.pdf.
"""
from fractions import Fraction as F
from itertools import product,combinations
from math import comb
from pathlib import Path
import random,json
B=Path(__file__).resolve().parent
rng=random.Random(20261104);counts={}
n=0
# Normalize the cap to one. Pointwise two-term Bonferroni bound.
for d in range(1,7):
 for v in product([F(0),F(1,4),F(1,2),F(3,4),F(1)],repeat=d):
  rhs=sum(v)-sum(x*y for x,y in combinations(v,2))
  assert min(sum(v),F(1))>=rhs
  n+=1
counts['pointwise_capped_sum_cases']=n
n=0
for _ in range(1500):
 k=rng.randrange(2,10);d=rng.randrange(1,k);h=F(rng.randrange(1,10),10)
 z=[rng.randrange(20) for i in range(k)];den=max(1,sum(z)+rng.randrange(20));y=[F(a,den) for a in z];u=[min(a,h) for a in y];U=sum(u)
 exact=sum(min(sum(y[i] for i in ix),h) for ix in combinations(range(k),d))/comb(k,d)
 bound=F(d,k)*U-F(d*(d-1),2*k*(k-1))*U*U/h
 assert exact>=bound
 if d-1<=h*(k-1):
  assert F(d,k)-F(d*(d-1),k*(k-1))/h>=0
 n+=1
counts['exact_subset_average_cases']=n
n=0
for sig in [F(1),F(101,100),F(6,5)]:
 tau=2-sig
 for A in [F(101,100),F(103,100),F(11,10),F(3,2)]:
  for j in range(100):
   Z=sig*j/100;a=min(A,sig/(sig-Z));inv=1-min(Z/sig,1-1/A)
   assert 1/a==inv
   assert a*(sig-Z)<=sig and tau/a>=tau-Z
   assert a/A<=1 and 1/a>=1/A
   n+=1
counts['exact_rescaling_geometry_cases']=n
n=0
# Uniform-simplex marginals: exact beta-law capped sums.
for k in range(2,21):
 for d in range(1,k):
  for h in [F(1,11),F(1,3),F(1,2),F(1)]:
   EU=F(k,k+1)*(1-(1-h)**(k+1))
   beta=sum(F(comb(k,j)*comb(k-j,r)*(-1)**r,j+r+1)*h**(j+r+1) for j in range(d) for r in range(k-j+1))
   bound=F(d,k)*EU*(1-F(d-1,1)/(2*h*(k-1)))
   assert beta>=bound
   n+=1
counts['exact_simplex_checks']=n
# Independent high-precision quadrature of the integrated survival formulas.
import mpmath as mp
mp.mp.dps=90
qchecks=[]
for m in [4,5]:
 data=json.load(open(B/f'integrated_m{m}.json'))
 trial=json.load(open(B.parent/'trials'/('m4_cross.json' if m==4 else 'm5_fine.json')))
 sig=1+mp.mpf(trial['delta'])*trial['eps_cells'];L=mp.mpf(data['lambda_value'])*sig
 lb=mp.mpf(data['log_B_upper']);bb=mp.exp(lb);t0=-lb/L
 mu1=t0-(1-bb)/L;mu2=t0*t0-2*t0/L+2*(1-bb)/(L*L)
 i1=mp.quad(lambda x:1-bb*mp.exp(L*x),[0,t0/2,t0])
 i2=mp.quad(lambda x:2*x*(1-bb*mp.exp(L*x)),[0,t0/2,t0])
 assert abs(i1-mu1)<mp.mpf('1e-80') and abs(i2-mu2)<mp.mpf('1e-80')
 qchecks.append(dict(m=m,first_difference=mp.nstr(abs(i1-mu1),8),second_difference=mp.nstr(abs(i2-mu2),8)))
counts['independent_integral_checks']=qchecks
(B/'lemma_checks.json').write_text(json.dumps(counts,indent=2)+'\n')
print(json.dumps(counts),flush=True)
