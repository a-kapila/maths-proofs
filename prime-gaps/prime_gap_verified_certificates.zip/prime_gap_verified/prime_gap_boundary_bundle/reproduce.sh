#!/usr/bin/env bash
# Recompute fixed-trial certificates sequentially; do not disable assertions.
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
mkdir -p verification
cxx="${CXX:-g++}"
"$cxx" -O3 -std=c++17 -shared -fPIC -ffp-contract=off analysis/profile_bounds_raw.cpp -o analysis/profile_bounds_raw.so
python analysis/check_fast_profile.py
python analysis/check_enclosures.py
python analysis/check_tagged.py
# The H4 output uses the unchanged inherited polynomial certifier.
python baseline/polynomial/certify_polynomial.py trials/m4_cross.json
python analysis/certify_centered.py trials/m5_fine.json
if test -f trials/m2_cross.json; then
  python analysis/certify_centered.py trials/m2_cross.json
  python analysis/finalize_m2.py trials/m2_cross.json trials/m2_final.json
fi
python verify_saved.py
python rebuild_small_tuples.py
"$cxx" -O3 -std=c++17 baseline/inherited/tuples/verify_tuple.cpp -o verification/verify_tuple
for m in 2 4; do
  test -f "verification/h${m}_selection.json" || continue
  k=$(python -c "import json;print(json.load(open('verification/h${m}_selection.json'))['k'])")
  verification/verify_tuple "verification/h${m}.csv" "baseline/inherited/tuples/h${m}_witness.csv" "$k"
done
python baseline/inherited/tuples/decode_h5.py verification/baseline_h5.bin
python baseline/h5/apply_patches.py verification/baseline_h5.bin verification/current_h5.bin
"$cxx" -O3 -std=c++17 -fopenmp baseline/inherited/tuples/verify_asymmetric.cpp -o verification/verify_h5
k=$(python -c "import json;print(json.load(open('RESULTS.json'))['results']['H5']['K'])")
OMP_NUM_THREADS=4 verification/verify_h5 234360000 "$k" 10000000 2432107459 verification/current_h5.bin
"$cxx" -O3 -std=c++17 limits/optimistic_h5.cpp -o verification/optimistic_h5
verification/optimistic_h5 "$k"
