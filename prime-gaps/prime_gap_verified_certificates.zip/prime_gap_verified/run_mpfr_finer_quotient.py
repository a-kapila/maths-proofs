from pathlib import Path
import sys,json,runpy,time
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as iv;sys.modules['flint']=iv
m=int(sys.argv[1]);O=A/'mpfr_finer_runs';O.mkdir(exist_ok=True);source=B/f'accurate/m{m}.json';d=json.load(open(source));d['delta']/=2;d['E']=[2*x for x in d['E']];d['eps_cells']*=2;tr=O/f'm{m}.json';tr.write_text(json.dumps(d,indent=2)+'\n')
from fractions import Fraction as F
old=json.load(open(source));assert [F(d['delta'])*x for x in d['E']]==[F(old['delta'])*x for x in old['E']]
ns=runpy.run_path(str(B/'continued/run_quotient.py'),run_name='mpfr_finer_driver');from mpfr_primitives import make_tables;ns['run'].__globals__['make_tables']=make_tables
print(json.dumps({'stage':'finer_start','m':m,'physical_equality_checked':True}),flush=True);ns['run'](str(tr))
