"""Chunked fixed-trial evaluation with the inherited pointwise enclosures.
Each chunk's lower Abel bound is summed using scalar interval arithmetic.
The method requires no assumption of equality between chunks' endpoint errors.
"""
from pathlib import Path
import sys,json,time,math,hashlib
import numpy as np
B=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(B/'progress'),str(B/'focus23'),str(B/'accurate'),str(B/'analysis'),str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from flint import arb,ctx
from point_cdf import PointCDF
from fast_gtable import gtable
import certify_multi
certify_multi.gtable=gtable
from certify_multi import make_tables
sys.path.insert(0,str(B/'onward'))
from chunk_tables import make_tables
from polynomial_core import marginal_terms
from certify_polynomial import amplitude
from parallel_profile import profile_bounds
from certify_lifted import D,H,add,mul,square,scale,integrate_bound
from loss_joint import restriction_loss
from streaming_cdf import direct_check

def run(path):
 d=json.load(open(path));start=time.time();ctx.prec=256;k,m=d['k'],d['m'];spacing=d['delta'];eps=spacing*d['eps_cells'];one=round(1/spacing)
 assert m in (2,3,4,5)
 basis=[tuple(x) for x in d['basis']];E=np.array(d['E'],np.int64);hs=[np.array(x,float) for x in d['profiles']]
 assert basis[0]==() and E[0]==0 and E[-1]==one+d['eps_cells'] and np.all(np.diff(E)>0)
 assert all(len(h)==len(E)-1 and max(abs(h))<=1 and np.all(h*2**40==np.round(h*2**40)) for h in hs)
 cdf=PointCDF(k,d['theta'],d['beta'],d['relative_shift'],basis=basis,DELTA=spacing,P=d.get('period',8.),ymax=1.125)
 print(json.dumps(dict(stage='fourier_coefficients',seconds=time.time()-start)),flush=True)
 tdata=dict(d);tdata['powers']=list(range(1,max(map(sum,basis))+1));tabs,m2,S=make_tables(tdata,cdf)
 print(json.dumps(dict(stage='antiderivative_tables',seconds=time.time()-start)),flush=True)
 ki={key:i for i,key in enumerate(cdf.moment_keys)}
 dc={key:(np.zeros(len(hs[0])),np.zeros(len(hs[0]))) for key in cdf.moment_keys}
 for a,ma in enumerate(basis):
  for b in range(a,len(basis)):
   key=tuple(sorted(ma+basis[b]));co=square((hs[a],hs[a])) if a==b else scale(mul((hs[a],hs[a]),(hs[b],hs[b])),2.)
   dc[key]=add(dc[key],co)
 denlo=arb(0);denhi=arb(0)
 for key in cdf.moment_keys:
  co=dc[key];L,V=cdf.bounds(k,ki[key],E*spacing)
  denlo+=arb(integrate_bound(co[0],L,V,-1));denhi+=arb(integrate_bound(co[1],L,V,1))
 dl=float(D(float(denlo.lower())));dh=float(H(float(denhi.upper())));assert dl>0
 pairs={key:[] for key in cdf.moment_keys}
 for a,ma in enumerate(cdf.marginal_basis):
  for b in range(a,len(cdf.marginal_basis)):
   mb=cdf.marginal_basis[b];pairs[tuple(sorted(ma+mb))].append((ma,mb,1 if a==b else 2))
 nums={key:arb(0) for key in cdf.moment_keys};ilo=int(E[1]);itop=one-d['eps_cells'];block=2**30;blocks=0
 for first in range(ilo,itop,block):
  last=min(first+block,itop);I=np.arange(first,last,dtype=np.int64)
  AA={key:(np.zeros(len(I)),np.zeros(len(I))) for key in cdf.marginal_basis}
  for h,mon in zip(hs,basis):
   for keep,power,co in marginal_terms(mon):AA[keep]=add(AA[keep],scale(profile_bounds(h,tabs[power],E,I),float(co)))
  points=np.arange(first,last+1)*spacing
  for key in cdf.moment_keys:
   co=(np.zeros(len(I)),np.zeros(len(I)))
   for ma,mb,factor in pairs[key]:co=add(co,scale(square(AA[ma]) if ma==mb else mul(AA[ma],AA[mb]),float(factor)))
   L,V=cdf.bounds(k-1,ki[key],points);nums[key]+=arb(integrate_bound(co[0],L,V,-1))
  blocks+=1
  print(json.dumps(dict(stage='integrated_chunk',block=blocks,first=first,last=last,of=itop,seconds=time.time()-start)),flush=True)
 nl=float(D(float(sum(nums.values()).lower())));assert nl>0
 q=arb(k)/m2*arb(nl)/arb(dh);ql=float(D(float(q.lower())))
 Cup=amplitude(hs,basis,E,spacing,S);scaled_den=float(D(float((arb(dl)/arb(Cup)**2).lower())))
 print(json.dumps(dict(stage='quotient',k=k,Q_lower=ql,den_lower=dl,den_upper=dh,num_lower=nl,seconds=time.time()-start)),flush=True)
 target=arb(m)/(arb(1)/4+arb(d['omega']));tu=float(H(float(target.upper())));margin=float(D(float((arb(ql)-arb(tu)).lower())))
 assert 240*arb(d['omega'])+80*arb(d['smooth_delta'])<3
 assert 2*(arb(1)/4+arb(d['omega']))*(1+arb(eps))<1
 out=dict(m=m,k=k,trial=str(path),trial_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),basis=basis,Q_lower=ql,evaluation_scope='unrestricted quotient only; no support loss computed here',target_upper=tu,raw_margin_lower=margin,epsilon=eps,den_lower=dl,den_upper=dh,num_lower=nl,num_components_lower=[float(nums[key].lower()) for key in cdf.moment_keys],amplitude_upper=Cup,scaled_den_lower=scaled_den,moment_keys=cdf.moment_keys,cdf=dict(J=cdf.J,N=cdf.N,error={str(key):v for key,v in cdf.error.items()},alias={str(key):v for key,v in cdf.alias.items()},series_tail={str(key):v for key,v in cdf.tail.items()}),chunks=blocks,backend='Quotient-only; inherited mpmath.iv scalar enclosures; requested-point Fourier interpolation; parallel per-coordinate profile bounds; chunked Abel sums')
 target_path=Path(path).with_suffix('.interval_certificate.json');target_path.write_text(json.dumps(out,indent=2)+'\n')
 out['direct_fourier_checks']=direct_check(cdf)
 out['bitwise_CDF_checks']=[cdf.bitwise_test(key) for key in [cdf.keys[0],cdf.keys[len(cdf.keys)//2],cdf.keys[-1]]]
 out['elapsed']=time.time()-start;target_path.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({key:out[key] for key in ['m','k','Q_lower','target_upper','raw_margin_lower','elapsed','chunks']}),flush=True)
if __name__=='__main__':run(sys.argv[1])
