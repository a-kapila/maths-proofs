from pathlib import Path
from fractions import Fraction as F
import sys,json,math
import mpmath as mp
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';sys.path.insert(0,str(A/'mpfr_backend'))
import mpfr_interval as iv;sys.modules['flint']=iv
from mpfr_primitives import block_table
sys.path[:0]=[str(B/'focus23'),str(B/'baseline/inherited/analysis')]
from moment_amplitude import amax_interval,qmax
from shifted_core import setup
mp.mp.dps=140;iv.ctx.prec=256
records=[]
for m in [2,3,4,5]:
 tp=B/{2:'continued/m2_fine.json',3:'continuation_next/m3_finer.json',4:'accurate/m4.json',5:'accurate/m5.json'}[m];tr=json.load(open(tp));k=tr['k'];dt=tr['delta'];theta,beta,shift=[mp.mpf(tr[x]) for x in ['theta','beta','relative_shift']];c=theta/mp.log(k);T=beta/mp.log(k);b=k-1;aa=shift/(c+b*T);maxp=max(map(sum,tr['basis']))
 n=int(T/dt)
 for j in [0,1,7,n//10,n//2,n-1,n,n+1,n+3]:
  lo,hi=block_table(k,tr['theta'],tr['beta'],tr['relative_shift'],dt,j,1,maxp)
  w=min(T,mp.mpf(j)*mp.mpf(dt))
  for p in range(maxp+1):
   # Independent high-precision quadrature after t=w*v scaling.
   ref=mp.quad(lambda v:(w*v/T)**p*(1/(c+b*w*v)+aa)*w,[0,mp.mpf('0.001'),mp.mpf('.01'),mp.mpf('.1'),1]) if w else mp.mpf(0)
   assert mp.mpf(float(lo[p,0]))<=ref<=mp.mpf(float(hi[p,0])),(m,j,p,lo[p,0],ref,hi[p,0])
   records.append({'m':m,'grid_index':j,'power':p,'lower':float(lo[p,0]),'upper':float(hi[p,0]),'reference':str(ref)})
 print('primitive checked',m,flush=True)
amp=json.load(open(B/'radial23/m2_k2305_amplitude.json'));tr=json.load(open(B/amp['trial']));S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift']);upper=F(amp['amplitude_upper']);rows=[]
for j,row in enumerate(amp['cells']):
 zb=iv.arb(tr['E'][j+1])*iv.arb(tr['delta'])/S['T'];z=F(row['z_upper']);assert zb.upper_fraction()<=z
 U=F(*row['Umax']);q=z.numerator//z.denominator;assert U==min(F(tr['k']),q+(z-q)**2)
 for rr in row['signs']:
  h0,h2,h3,h4,h22=[rr['sign']*x[j] for x in tr['profiles']];bb=rr['b'];av=amax_interval(bb,h2,h3,h4);value=iv.arb(h0)+iv.arb(z)*av+iv.arb(qmax(F(bb),F(h22),U));assert value.upper_fraction()<=upper,(j,value,upper)
 rows.append({'cell':j,'verified':True})
print('all amplitude cells verified',len(rows),flush=True)
for m,source,sup in [(3,'focus23/m3_fine.json','direct_pair/m3_arithmetic.json'),(4,'accurate/m4.json','continuation/support_m4_10_9.json'),(5,'accurate/m5.json','continuation/support_m5_4_3.json')]:
 tr=json.load(open(B/source));S=setup(tr['k'],tr['theta'],tr['beta'],tr['relative_shift']);mx=F(0)
 for j in range(len(tr['E'])-1):
  z=iv.arb(tr['E'][j+1])*iv.arb(tr['delta'])/S['T'];c=iv.arb(0)
  for h,mon in zip(tr['profiles'],tr['basis']):c+=abs(iv.arb(h[j]))*z**len(mon)
  mx=max(mx,c.upper_fraction())
 saved=json.load(open(B/sup));C=saved.get('amplitude_upper')
 if C is None:C=json.load(open(B/'radial23/m3_support_mass.json'))['amplitude_upper']
 
 if mx>F(C):
  sys.path.insert(0,str(B/'analysis'));from amplitude_envelope import profile_amplitude
  tighter,_=profile_amplitude(tr['profiles'],tr['basis'],tr['E'],tr['delta'],S)
  C=math.nextafter(tighter,math.inf);assert F(tighter)<=F(C)
 else:assert mx<=F(C)

 rows.append({'m':m,'generic_amplitude_upper':C,'cells_verified':len(tr['E'])-1})
 print('generic amplitude checked',m,C,flush=True)
(A/'mpfr_primitives_amplitudes_checks.json').write_text(json.dumps({'mpfr_version':iv.L.iv_version().decode(),'primitive_tests':records,'amplitude_checks':rows},indent=2)+'\n')
