from pathlib import Path
from fractions import Fraction as F
import sys,json,time,hashlib,shutil
import numpy as np
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';O=A/'mpfr_pair_moments';O.mkdir(exist_ok=True)
sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as mpiv;sys.modules['flint']=mpiv
sys.path.insert(0,str(B/'direct_mean'))
from capped_mean import CappedMeanCDF,ar,up,down,arb,acb,ctx
from multi_core import single_moments
import capped_mean
from polynomial_core import weights
capped_mean.tagged_weights=lambda n,mu,nu,keys:weights(n,mu,keys)
TAGS=((1,),(2,),(3,),(4,),(2,2),(5,),(6,),(2,3),(2,4),(3,3))
class RawCDF(CappedMeanCDF):
 def __init__(self,tr,sigma):
  super().__init__(tr,sigma);self.base_keys=self.keys[:]
  self.keys=sorted({tuple(sorted(a+b)) for a in self.base_keys for b in TAGS},key=lambda x:(len(x),x));self.co={key:[F(0)]*(len(self.y)-1) for key in self.keys};self.jmax=max(map(sum,self.keys));self.nmin=self.k-max(map(len,self.keys))-1;self.J=128
  while True:
   z=self.phi(acb(self.freq*self.J))
   if z.abs_upper()<1 and self.nmin*z.abs_upper().log()<-140:break
   self.J=int(self.J*1.25)+1;assert self.J<100000
 def moments(self,kind='zero',value=0):
  mu=single_moments(self.S,self.jmax,kind,value);return mu,[x/self.k for x in mu]
def run(m):
 ctx.prec=256;start=time.time();tp=B/{2:'trials/m2_final.json',3:'focus23/m3_fine.json'}[m];tr=json.load(open(tp));sigma=1+F(tr['delta'])*tr['eps_cells'];cdf=RawCDF(tr,sigma)
 print(json.dumps(dict(stage='start_all_pair_moments',m=m,keys=len(cdf.keys),highest_power=cdf.jmax,J=cdf.J,backend='MPFR '+mpiv.L.iv_version().decode())),flush=True)
 cdf.run_setup();cdf.evaluate();np.savez_compressed(O/f'm{m}_raw.npz',y=cdf.y,C=cdf.C,L=cdf.L,V=cdf.V)
 summary=dict(m=m,keys=cdf.keys,precision_bits=ctx.prec,frequencies=cdf.J,tail=cdf.tail,alias=list(map(up,cdf.alias)),cdf_errors=cdf.errors,source=str(tp),source_sha256=hashlib.sha256(tp.read_bytes()).hexdigest(),backend='MPFR '+mpiv.L.iv_version().decode(),tags=[])
 for tag in TAGS:
  name=''.join(map(str,tag));folder=B/('continued' if tag==(2,) else ('next_pair' if tag in TAGS[:5] else 'four_moment'));stem=folder/f'm{m}_power{name}'
  old=json.load(open(stem.with_suffix('.json')));assert old['moment_keys']==[list(x) for x in cdf.base_keys]
  factor=(cdf.S['T']/ar(sigma))**sum(tag);inds=[cdf.keys.index(tuple(sorted(key+tag))) for key in cdf.base_keys];ls=[];us=[]
  for ind in inds:
   ls.append([max(0.,down(arb(float(x))*factor)) for x in cdf.L[ind]])
   us.append([up(arb(float(x))*factor) for x in cdf.V[ind]])
  ls,us=np.array(ls),np.array(us);olddata=np.load(str(stem)+'_cdf.npz');assert np.array_equal(olddata['y'],cdf.y);overlap=bool(np.all(ls<=olddata['V']) and np.all(us>=olddata['L']))
  out=O/f'm{m}_power{name}';np.savez_compressed(str(out)+'_cdf.npz',y=cdf.y,L=ls,V=us)
  # Replace working copies only, with independently recomputed tables.
  shutil.copyfile(str(out)+'_cdf.npz',str(stem)+'_cdf.npz')
  old.update(recomputed_backend=summary['backend'],highest_power=cdf.jmax,raw_measure_keys=[list(cdf.keys[i]) for i in inds],overlap_with_archived_enclosures=overlap)
  out.with_suffix('.json').write_text(json.dumps(old,indent=2)+'\n');stem.with_suffix('.json').write_text(json.dumps(old,indent=2)+'\n')
  summary['tags'].append(dict(tag=list(tag),old_overlap=overlap,entries=int(ls.size),file=str(out)))
 summary['seconds']=time.time()-start;(O/f'm{m}_summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(dict(stage='completed_all_pair_moments',m=m,seconds=summary['seconds'],keys=len(cdf.keys),all_old_overlaps=all(t['old_overlap'] for t in summary['tags']))),flush=True)
for m in map(int,sys.argv[1:] or [2,3]):run(m)
