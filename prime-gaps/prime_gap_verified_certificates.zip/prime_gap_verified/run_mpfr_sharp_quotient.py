from pathlib import Path
import sys,json,runpy,time,hashlib
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle';sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as mpiv;sys.modules['flint']=mpiv
m=int(sys.argv[1]);out=A/'mpfr_sharp_runs';out.mkdir(exist_ok=True);source=B/f'accurate/m{m}.json';trial=out/f'm{m}.json';trial.write_bytes(source.read_bytes());print(json.dumps({'stage':'start','m':m,'backend':'MPFR directed endpoints and MPFR antiderivatives'}),flush=True)
ns=runpy.run_path(str(B/'continued/run_quotient.py'),run_name='independent_primitive_driver');from mpfr_primitives import make_tables
ns['run'].__globals__['make_tables']=make_tables;ns['run'](str(trial))
p=trial.with_suffix('.interval_certificate.json');v=json.load(open(p));v['backend']='MPFR 4.2.2 directed endpoints; independently evaluated MPFR primitive tables; audited outward binary64 integration';p.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({'stage':'completed','m':m,'Q_lower':v['Q_lower']}),flush=True)
