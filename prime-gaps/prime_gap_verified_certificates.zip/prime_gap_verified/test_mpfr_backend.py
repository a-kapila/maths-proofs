from pathlib import Path
import sys,random,json,time
from fractions import Fraction as F
A=Path(__file__).resolve().parent
sys.path.insert(0,str(A/'mpfr_backend'))
import mpfr_interval as mpiv
from mpfr_interval import arb,acb,ctx
ctx.prec=192
r=random.Random(187)
count=0
for j in range(1000):
 x=F(r.randrange(-10**8,10**8),r.randrange(1,10**8));y=F(r.randrange(-10**8,10**8),r.randrange(1,10**8))
 a,b=arb(x),arb(y)
 for z,v in [(a+b,x+y),(a-b,x-y),(a*b,x*y),(a/b,x/y),(a**2,x*x),(a**3,x*x*x)]:
  assert z.lower_fraction()<=v<=z.upper_fraction();count+=1
import mpmath as mp
mp.mp.dps=170
scalar=[]
for x in ['0.000001','0.01','0.1','1','30','127.9','128','128.1','200','700']:
 z=arb(x)
 for kind,v,ref in [('E1',z.expint(1),mp.e1(mp.mpf(x))),('Ei',z.ei(),mp.ei(mp.mpf(x)))]:
  lo,hi=v.lower_fraction(),v.upper_fraction();l=mp.mpf(lo.numerator)/lo.denominator;h=mp.mpf(hi.numerator)/hi.denominator
  assert l<=ref<=h,(x,kind,mp.nstr(ref-l,10),mp.nstr(h-ref,10));scalar.append((x,kind))
 v=acb(0,-z).expint(1);ref=mp.e1(-1j*mp.mpf(x))
 for w,t in [(v.real,ref.real),(v.imag,ref.imag)]:
  lo,hi=w.lower_fraction(),w.upper_fraction();assert mp.mpf(lo.numerator)/lo.denominator<=t<=mp.mpf(hi.numerator)/hi.denominator
 scalar.append((x,'imaginary E1'))
ctx.prec=256
sys.modules['flint']=mpiv
B=A/'prime_gap_boundary_bundle'
sys.path[:0]=[str(B/'baseline/inherited/analysis'),str(B/'baseline/polynomial')]
from shifted_core import setup
from polynomial_core import single_moments
p=json.load(open(B/'continued/m2_fine.json'));S=setup(p['k'],p['theta'],p['beta'],p['relative_shift'])
t=time.time();m=single_moments(S,14,'fourier',arb.pi()*1217/4)
assert all(v.is_finite() for v in m)
report=dict(mpfr_version=mpiv.L.iv_version().decode(),exact_arithmetic_checks=count,special_function_checks=scalar,moment_seconds=time.time()-t,max_moment_radius=max(float(v.real.rad())+float(v.imag.rad()) for v in m))
(A/'mpfr_backend_tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
