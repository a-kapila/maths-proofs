from pathlib import Path
import sys,json,time,runpy,shutil
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle'
sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as mpiv
sys.modules['flint']=mpiv
jobs=[('radial23/support2305.py',[],['radial23/m2_k2305_support.json']),('direct_pair/retune_m3.py',[],['direct_pair/m3_arithmetic.json']),('radial23/support_mass.py',['3'],['radial23/m3_support_mass.json']),('continuation/test_support.py',['4','10','9'],['continuation/support_m4_10_9.json']),('continuation/test_support.py',['5','4','3'],['continuation/support_m5_4_3.json'])]
O=A/'mpfr_support';O.mkdir(exist_ok=True)
for p,args,outs in jobs:
 print(json.dumps({'stage':'start','script':p,'args':args,'MPFR':mpiv.L.iv_version().decode()}),flush=True)
 for out in outs:shutil.copyfile(B/out,O/(Path(out).stem+'.original.json'))
 sys.argv=[str(B/p)]+args;t=time.time();runpy.run_path(str(B/p),run_name='__main__')
 for out in outs:shutil.copyfile(B/out,O/(Path(out).name))
 print(json.dumps({'stage':'finished','script':p,'seconds':time.time()-t}),flush=True)
