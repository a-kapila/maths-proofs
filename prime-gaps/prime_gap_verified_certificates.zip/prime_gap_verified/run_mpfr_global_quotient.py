from pathlib import Path
import sys,json,time,hashlib,os
A=Path(__file__).resolve().parent;B=A/'prime_gap_boundary_bundle'
sys.path.insert(0,str(A/'mpfr_backend'));import mpfr_interval as mpiv;sys.modules['flint']=mpiv
m=int(sys.argv[1]);out=A/'mpfr_global_runs';out.mkdir(exist_ok=True);source=B/f'accurate/m{m}.json';trial=out/f'm{m}.json';trial.write_bytes(source.read_bytes())
code=(B/'continued/run_quotient.py').read_text();assert code.count('block=2**18;')==1;code=code.replace('block=2**18;','block=2**30;')
(out/f'global_driver_m{m}.py').write_text(code)
ns={'__name__':'independent_global_driver','__file__':str(B/'continued/run_quotient.py')};exec(compile(code,str(out/f'global_driver_m{m}.py'),'exec'),ns)
from mpfr_primitives import make_tables
ns['make_tables']=make_tables
print(json.dumps({'stage':'start_global_Abel','m':m,'backend':'MPFR 4.2.2 directed endpoints and independent MPFR primitive tables'}),flush=True)
ns['run'](str(trial))
p=trial.with_suffix('.interval_certificate.json');v=json.load(open(p));v['backend']='MPFR 4.2.2 directed endpoints, independent MPFR primitives, global signed Abel integration';p.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({'stage':'complete_global','m':m,'Q_lower':v['Q_lower']}),flush=True)
